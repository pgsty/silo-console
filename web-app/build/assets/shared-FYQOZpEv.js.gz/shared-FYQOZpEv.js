import"./rolldown-runtime-BWaJ3C7D.js";import{P as e,t}from"./react-vendor-UL3KVrSx.js";import{T as n}from"./shared-vendor-BQfq49S_.js";import{S as r,W as i}from"./mds-DIGH6qee.js";e();var a=t(),o=n.span`
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
  border: 0;
`,s=n(r)`
  && {
    width: var(--control-height, 36px);
    height: var(--control-height, 36px);
    flex-shrink: 0;
    border-radius: var(--silo-radius-button);
    color: var(--silo-text-secondary);
    background: transparent;
    transition: background-color var(--silo-motion-hover);
  }
  @media (pointer: coarse) {
    && {
      width: 40px;
      height: 40px;
    }
  }
  && svg {
    width: var(--icon-size, 16px);
    height: var(--icon-size, 16px);
    margin: 0;
    fill: currentColor;
  }
`,c=({children:e,text:t,placement:n})=>(0,a.jsx)(i,{tooltip:t,placement:n,children:e});export{c as n,o as r,s as t};