import"./rolldown-runtime-BWaJ3C7D.js";import{P as e,j as t,r as n,t as r}from"./react-vendor-UL3KVrSx.js";import{T as i}from"./shared-vendor-BQfq49S_.js";import{C as a,E as o,Rn as s,bt as c,ht as l,mt as u,n as d,vt as f,w as p,yt as m}from"./store-u0LCkSUK.js";import{i as h,n as g}from"./lang-BxJGrDHW.js";import{E as _,X as v,v as y,z as b}from"./mds-YaKHoCCJ.js";import{t as x}from"./trash-D6JXtEqL.js";import{t as S}from"./download-BaVlgZxL.js";import{t as C}from"./upload-gNs1GxPB.js";import{t as w}from"./rotate-ccw-v_NUsCZb.js";import{t as T}from"./ModalBox-B1Mqh9LH.js";import{a as E}from"./i18n-CkC2HRew.js";import{t as D}from"./StatusBadge-QSmH-cfD.js";import{t as O}from"./mutationTasks-BiNmJo9W.js";import{et as k}from"./ConsoleKBar-DP8Xdmgh.js";e();var A=r(),j=i.article`
  ${v(`body`)}
  padding: 8px 0;
  border-bottom: 1px solid var(--border);
  min-width: 0;
  color: var(--foreground);
  .task-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 550;
  }
  .task-title > svg {
    width: 16px;
    height: 16px;
    flex: 0 0 16px;
    color: var(--muted-foreground);
  }
  .task-title .task-name {
    flex: 1;
    overflow-wrap: anywhere;
    min-width: 0;
  }
  .task-meta {
    ${v(`caption`)}
    color: var(--muted-foreground);
    display: flex;
    gap: 8px;
    align-items: center;
    margin: 4px 0;
    flex-wrap: wrap;
  }
  .task-progress {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 4px 0;
    font-variant-numeric: tabular-nums;
    ${v(`caption`)}
  }
  progress {
    flex: 1;
    min-width: 0;
    height: 4px;
    accent-color: var(--foreground);
  }
  p {
    margin: 4px 0;
    color: var(--muted-foreground);
    ${v(`caption`)}
    overflow-wrap: anywhere;
  }
  .task-actions {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    flex-wrap: wrap;
    margin-top: 4px;
  }
  a {
    color: var(--foreground);
    ${v(`caption`)}
    text-underline-offset: 3px;
    overflow-wrap: anywhere;
  }
  a:focus-visible,
  summary:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 3px;
  }
  details {
    margin-top: 8px;
    ${v(`caption`)}
  }
  details ul {
    padding-left: 20px;
  }
  details li {
    margin-top: 8px;
    overflow-wrap: anywhere;
  }
`,M=i(y).attrs({size:`small`})`
  --icon-size: 14px;
  color: var(--muted-foreground);
  @media (pointer: coarse) {
    width: 40px;
    height: 40px;
  }
`,N={queued:h(`Queued`),running:h(`Running`),done:h(`Completed`),failed:h(`Failed`),cancelled:h(`Cancelled`)},P={upload:h(`Upload`),download:h(`Download`),zip:h(`ZIP download`),delete:h(`Delete`),restore:h(`Restore`)},F=({objectToDisplay:e,deleteFromList:t})=>{let r=E(),i=u(e),a=c(e),o=f(e),d=e.kind??e.type,p=e.type===`upload`||e.type===`download`,h=e.browserManaged&&e.done&&!e.failed&&!e.cancelled,v=e.targets?.filter(e=>e.status===`failed`||e.status===`cancelled`)??[],y=l(e.targets??[]),T=d===`upload`?C:d===`delete`?x:d===`restore`?w:S;return(0,A.jsxs)(j,{"data-task-id":e.instanceID,"data-task-status":a,children:[(0,A.jsxs)(`div`,{className:`task-title`,children:[(0,A.jsx)(T,{}),(0,A.jsx)(`span`,{className:`task-name`,title:e.targets?void 0:e.prefix,children:e.targets?r(e.prefix):e.prefix.match(/[^/]+\/*$/)?.[0]||e.prefix}),!i&&(0,A.jsx)(M,{"aria-label":r(p?`Remove transfer`:`Remove task`),onClick:()=>t(e.instanceID),children:(0,A.jsx)(_,{})})]}),(0,A.jsxs)(`div`,{className:`task-meta`,children:[(0,A.jsx)(`span`,{children:r(P[d])}),(0,A.jsx)(D,{tone:e.failed?`danger`:`neutral`,label:r(h?`Browser handoff`:N[a])}),!i&&!e.failed&&(0,A.jsxs)(`span`,{className:`progressPercentage`,children:[e.percentage,`%`]})]}),i&&(0,A.jsxs)(`div`,{className:`task-progress`,children:[(0,A.jsx)(`progress`,{"aria-label":r(h?`Browser handoff`:`Task progress`),max:100,value:e.waitingForFile&&i?void 0:e.percentage}),(!e.waitingForFile||!i)&&(0,A.jsxs)(`span`,{className:`progressPercentage`,children:[e.percentage,`%`]}),e.waitingForFile&&i&&(0,A.jsx)(`span`,{children:r(`Waiting for data`)})]}),o.total>0&&(0,A.jsx)(`p`,{children:g(r(`{done}/{total} completed · {failed} failed · {cancelled} cancelled`),o)}),e.receivedBytes!==void 0&&(0,A.jsx)(`p`,{children:g(r(`{bytes} bytes received`),{bytes:e.receivedBytes.toLocaleString()})}),h&&(0,A.jsxs)(`p`,{children:[(0,A.jsx)(`span`,{children:r(`Track or cancel this download in your browser's download manager.`)}),` `,(0,A.jsx)(`span`,{children:r(`Handoff is complete; final download progress is unavailable here.`)})]}),e.errorMessage&&(0,A.jsx)(`p`,{role:`status`,children:p&&e.failed?`${r(`Error:`)} ${e.errorMessage}`:e.errorMessage}),e.targets?.some(e=>e.recursive||e.nonCurrent||e.allVersions)&&(0,A.jsx)(`p`,{children:r(`Counts represent selected targets. Progress within a folder or version cleanup is unavailable.`)}),e.cancelled&&e.targets&&(0,A.jsx)(`p`,{children:r(`Completed changes remain in place. In-flight requests may have reached the server; inspect before repeating them.`)}),v.length>0&&(0,A.jsxs)(`details`,{children:[(0,A.jsx)(`summary`,{children:g(r(`Review {count} results`),{count:v.length})}),(0,A.jsx)(`ul`,{children:v.map((e,t)=>(0,A.jsxs)(`li`,{children:[(0,A.jsx)(`strong`,{children:e.key}),e.versionId!==void 0&&(0,A.jsxs)(A.Fragment,{children:[` · `,e.versionId]}),(0,A.jsx)(`br`,{}),r(N[e.status]),e.error&&(0,A.jsxs)(A.Fragment,{children:[`: `,e.error]}),e.uncertain&&(0,A.jsx)(`p`,{children:r(`Server outcome is unconfirmed. Inspect this object before another operation.`)})]},t))})]}),(0,A.jsxs)(`div`,{className:`task-actions`,children:[(0,A.jsxs)(n,{to:`/browser/${encodeURIComponent(e.bucketName)}/${encodeURIComponent(m(e))}`,children:[(0,A.jsx)(`span`,{title:`${e.bucketName}/${m(e)}`,children:e.bucketName}),` · `,r(`Open bucket/prefix`)]}),i?(0,A.jsx)(b,{id:`cancel-${e.ID}`,variant:`text`,label:r(`Cancel`),"aria-label":r(p?`Cancel transfer`:`Cancel task`),icon:(0,A.jsx)(_,{}),onClick:()=>s(e.ID)}):y.length>0?(0,A.jsx)(b,{id:`retry-${e.ID}`,variant:`secondary`,label:r(`Retry failed`),onClick:()=>O(e.instanceID)}):null]})]})},I=i.section`
  border: 0;
  border-radius: 0;
  padding: 0;
  margin: 0;
  background: transparent;
  box-shadow: none;
  h3 {
    ${v(`subtitle`)}
    font-weight: 550;
    margin: 12px 0 4px;
  }
  > p {
    color: var(--muted-foreground);
  }
`,L=()=>{let e=d(),n=E(),{objectsToManage:r,managerOpen:i}=t(e=>e.objectBrowser.objectManager),s=r.filter(u),c=r.filter(e=>!u(e));return(0,A.jsxs)(T,{open:i,onClose:()=>e(p()),title:n(`Tasks`),titleIcon:(0,A.jsx)(k,{}),closeLabel:n(`Close Tasks`),customMaxWidth:440,sx:{justifyContent:`flex-end`,alignItems:`stretch`,"& .modalContainer":{width:`100%`,height:`100dvh`,maxHeight:`100dvh`,borderRadius:`16px 0 0 16px`,transform:`none`,padding:24},"& .dialogContent":{flex:1},"@media (max-width: 600px)":{"& .modalContainer":{maxWidth:`100%`,borderRadius:0,padding:20}}},children:[(0,A.jsxs)(`p`,{style:{color:`var(--muted-foreground)`,margin:`0 0 16px`,fontSize:`var(--fs-caption)`,lineHeight:`var(--lh-caption)`},children:[(0,A.jsx)(`span`,{children:n(`Downloads / Uploads`)}),` · `,n(`Object operations`)]}),(s.length>0||c.length===0)&&(0,A.jsxs)(I,{"aria-label":n(`Running`),children:[(0,A.jsxs)(`h3`,{children:[n(`Running`),` · `,s.length]}),!s.length&&(0,A.jsx)(`p`,{children:n(`No running tasks`)}),s.map(t=>(0,A.jsx)(F,{objectToDisplay:t,deleteFromList:t=>e(o(t))},t.instanceID))]}),(0,A.jsxs)(I,{"aria-label":n(`Finished`),children:[(0,A.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,gap:8},children:[(0,A.jsxs)(`h3`,{children:[n(`Finished`),` · `,c.length]}),(0,A.jsx)(b,{id:`clear-finished-tasks`,variant:`text`,label:n(`Clear finished`),disabled:!c.length,onClick:()=>e(a())})]}),!c.length&&(0,A.jsx)(`p`,{children:n(`No finished tasks`)}),c.slice().reverse().map(t=>(0,A.jsx)(F,{objectToDisplay:t,deleteFromList:t=>e(o(t))},t.instanceID))]})]})};export{L as default};