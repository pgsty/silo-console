const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./BulkReplicationModal-DjSTUw3-.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./store-BPBianru.js","./lang-D2C58lf1.js","./mds-Br1NHt8T.js","./triangle-alert-BTNxUVAN.js","./circle-check-CT0d2UKJ.js","./ReadBox-DnF8kUfB.js","./Wizard-DOEEU_QC.js","./i18n-0MkheqSN.js","./replicationValidation-BQK7c9L0.js","./ConsoleKBar-CPYbssRu.js","./gauge-CiYprLXt.js","./pencil-C3yvM3Qb.js","./search-L_Bp7nH8.js","./CircleIcon-BsXHTBH6.js","./shield-check-CJrXb05T.js","./chart-no-axes-column-eAgMaeUB.js","./heart-pulse-tz8W0-3S.js","./trash-CmVQ4Foy.js","./clock-BAbZOuYg.js","./activity-CztX29bw.js","./plus-CSzokEQ9.js","./users-DrCxRCis.js","./shield-D9uxuuFX.js","./archive-BSAQ97yg.js","./webhook-C2NZ7GSR.js","./users-round-8FZalhpX.js","./layers-DYz3_66d.js","./rotate-ccw-BiAbZJ4Q.js","./settings-r3Fk-kb7.js","./logs-Cl9on7GI.js","./info-D-qYvsq8.js","./scan-search-CdteC60m.js","./console-vendor-I3rSB1nD.js","./listPopup-D2sWpuy2.js","./SectionTitle-BxFOjOHC.js","./useAvailableWidth-COFYcObd.js","./ModalBox-CLgFXgZ9.js","./ModalPresence-DFPlGVKA.js","./index-BgYArd__.js","./index-BFo1l52q.css","./shared-DNNv_4dQ.js","./OverflowMenu-C2dwENsn.js","./typography-FIWfJMKK.js","./permissions-C2qgxAIa.js","./StatusBadge-Cr2Cg8oC.js","./CliEquivalent-CFN2Hn22.js","./copy-Br4HbfKd.js","./code-nMrcKYmU.js","./lib-BVN4wEer.js","./SecureComponent-CC5yJmBw.js","./BulkLifecycleModal-CXO86eQf.js","./QueryMultiSelector-BE84GJfi.js","./DeleteBucket-BWEAhyw-.js","./ConfirmDialog-DRT8TlJ1.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,d as n,f as r,h as i,r as a,t as o}from"./react-vendor-UL3KVrSx.js";import{D as s,T as c}from"./shared-vendor-BQfq49S_.js";import{Cn as l,Er as u,Tr as d,Zt as f,ir as p,n as ee,nn as te,r as ne,wn as re}from"./store-BPBianru.js";import{n as m}from"./lang-D2C58lf1.js";import{F as ie,T as h,g as ae,l as g,v as oe,w as se,z as _}from"./mds-Br1NHt8T.js";import{t as ce}from"./trash-CmVQ4Foy.js";import{t as le}from"./boxes-DjZf1SAZ.js";import{t as ue}from"./calendar-clock-gb9Oftqo.js";import{t as de}from"./plus-CSzokEQ9.js";import{t as v}from"./archive-BSAQ97yg.js";import{t as fe}from"./settings-r3Fk-kb7.js";import{t as y}from"./folder-BwVAesao.js";import{t as b}from"./Checkbox-COP74xp1.js";import{c as x,s as S}from"./listPopup-D2sWpuy2.js";import{t as pe}from"./useTableLayout-B6JEQJff.js";import{a as C,n as w}from"./i18n-0MkheqSN.js";import{t as T}from"./ModalPresence-DFPlGVKA.js";import{s as me}from"./index-BgYArd__.js";import{n as he}from"./shared-DNNv_4dQ.js";import{t as ge}from"./OverflowMenu-C2dwENsn.js";import{t as E}from"./typography-FIWfJMKK.js";import{A as _e,a as ve,g as D,i as O,n as k,o as A,p as j,r as M,t as ye}from"./permissions-C2qgxAIa.js";import{t as N}from"./StatusBadge-Cr2Cg8oC.js";import{t as be}from"./SearchBox-s61IbPJA.js";import{t as P}from"./withSuspense-DTbtEWjP.js";import{n as F}from"./SecureComponent-CC5yJmBw.js";import{t as I}from"./bucketMetadata-BAg0j77c.js";import{n as L}from"./react-window-0T2cJ04-.js";import{A as xe,J as R,K as Se,V as Ce,f as we}from"./ConsoleKBar-CPYbssRu.js";var z=e(t()),B=[`name`,`objects`,`size`,`created`],V=e=>({sort:B.includes(e.get(`sort`)||``)?e.get(`sort`):`name`,dir:e.get(`dir`)===`desc`?`desc`:`asc`,q:e.get(`q`)||``}),H=(e,t)=>{let n=new URLSearchParams(e),r={...V(e),...t};for(let e of[`sort`,`dir`,`q`])!r[e]||e===`sort`&&r.sort===`name`||e===`dir`&&r.dir===`asc`?n.delete(e):n.set(e,r[e]);return n},Te=e=>e===`cards`?`cards`:`table`,U=e=>!!(e&&Number.isFinite(Date.parse(e))),W=(e,t,n,r)=>{if(!(!e||n&&!U(r)))return!n&&e[t]===void 0?0:I(e,t,r)},Ee=(e,t,n,r)=>{let i=t.q.trim().toLocaleLowerCase(),a=e=>{if(t.sort===`name`)return e.name;if(t.sort===`created`){let t=Date.parse(e.creation_date||``);return Number.isFinite(t)?t:void 0}return W(e,t.sort,n,r)};return e.filter(e=>e.name.toLocaleLowerCase().includes(i)).sort((e,n)=>{let r=a(e),i=a(n);return r===void 0&&i!==void 0?1:i===void 0&&r!==void 0?-1:(r===i||r===void 0||i===void 0?0:r<i?-1:1)*(t.dir===`desc`?-1:1)||e.name.localeCompare(n.name)})},De=(e,t)=>t.length>0&&t.every(t=>e.includes(t))?e.filter(e=>!t.includes(e)):Array.from(new Set([...e,...t])),G=o(),K=(e,t)=>({browse:F(e,j),settings:!t&&F(e,M[k.BUCKETS_ADMIN_VIEW]),delete:!t&&F(e,D),select:!t&&F(e,[A.S3_PUT_LIFECYCLE_CONFIGURATION,A.S3_PUT_REPLICATION_CONFIGURATION,A.S3_PUT_ACTIONS])}),q=({bucket:e,field:t,canReadUsage:n,usageUpdatedAt:r})=>{let i=C(),a=w(),o=W(e,t,n,r);return o===void 0?(0,G.jsx)(he,{text:n&&!U(r)?i(`Calculating…`):i(`Unknown`),children:(0,G.jsx)(`span`,{tabIndex:0,children:`—`})}):(0,G.jsx)(G.Fragment,{children:t===`size`?p(o):o.toLocaleString(a)})},J=({bucket:e})=>{let t=C();return(0,G.jsx)(G.Fragment,{children:e.rw_access?.read?e.rw_access.write?t(`Read & write`):t(`Read only`):e.rw_access?.write?t(`Write only`):t(`Unknown`)})},Y=({enabled:e,suspended:t=!1})=>{let n=C();return(0,G.jsx)(N,{tone:t?`warning`:e?`success`:`neutral`,label:n(t?`Suspended`:e===void 0?`Unknown`:e?`Enabled`:`Disabled`)})},X=({at:e})=>{let t=w(),n=e?s.fromISO(e).setLocale(t===`zh`?`zh-CN`:`en`):void 0;return n?.isValid?(0,G.jsx)(he,{text:n.toLocaleString(s.DATETIME_FULL_WITH_SECONDS),children:(0,G.jsx)(`time`,{dateTime:e,tabIndex:0,children:n.toRelative()})}):(0,G.jsx)(G.Fragment,{children:`—`})},Z=({bucket:e,obOnly:t,onDelete:n})=>{let i=C(),a=r(),o=K(e.name,t),s=encodeURIComponent(e.name),c=[...o.browse?[{label:i(`Browse`),icon:(0,G.jsx)(y,{}),onClick:()=>a(`/browser/${s}`)}]:[],...o.settings?[{label:i(`Settings`),icon:(0,G.jsx)(fe,{}),onClick:()=>a(`/buckets/${s}/admin/summary`)}]:[],...o.delete?[{label:i(`Delete bucket`),icon:(0,G.jsx)(ce,{}),danger:!0,onClick:()=>n(e.name)}]:[]];return c.length?(0,G.jsx)(`div`,{onClick:e=>e.stopPropagation(),onKeyDown:e=>e.stopPropagation(),children:(0,G.jsx)(ge,{label:m(i(`Actions for {bucket}`),{bucket:e.name}),tooltipPlacement:`left`,tooltipLabel:i(`Actions`),items:c})}):null},Oe=c.div`
  ${E.body}
  height: 112px;
  box-sizing: border-box;
  min-width: 0;
  padding: 8px 12px 12px;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  color: var(--muted-foreground);
  font-variant-numeric: tabular-nums;
  &[data-clickable="true"] {
    cursor: pointer;
  }
  &:hover,
  &[data-selected="true"] {
    color: var(--foreground);
    background: color-mix(in srgb, var(--hover) 100%, var(--surface-3));
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }
  .cardTitle {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;
    height: 36px;
  }
  .cardTitle > svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
  }
  h2 {
    ${E.section} margin: 0;
    min-width: 0;
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  a {
    color: inherit;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
  .cardMetrics {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    margin-top: 4px;
  }
  .metricLabel {
    ${E.caption} color: var(--muted-foreground);
  }
  .metricValue {
    display: block;
    color: var(--foreground);
  }
  .cardAccess {
    ${E.caption} text-align: right;
    align-self: end;
  }
`,ke=e=>{let{bucket:t,onSelect:n,selected:i,obOnly:o}=e,s=C(),c=r(),l=K(t.name,o),u=()=>l.browse&&c(`/browser/${encodeURIComponent(t.name)}`);return(0,G.jsxs)(Oe,{className:`bucket-card`,role:`listitem`,"aria-label":t.name,"data-clickable":l.browse,"data-selected":n?i:void 0,tabIndex:l.browse?0:void 0,onClick:u,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),u())},children:[(0,G.jsxs)(`div`,{className:`cardTitle`,children:[n?(0,G.jsx)(`span`,{onClick:e=>e.stopPropagation(),children:(0,G.jsx)(b,{label:``,checked:i,disabled:!l.select,"aria-label":m(s(`Select {bucket}`),{bucket:t.name}),onChange:()=>n(t.name)})}):(0,G.jsx)(v,{"aria-hidden":`true`}),(0,G.jsx)(`h2`,{children:l.browse?(0,G.jsx)(a,{to:`/browser/${encodeURIComponent(t.name)}`,onClick:e=>e.stopPropagation(),children:t.name}):t.name}),(0,G.jsx)(Z,{...e})]}),(0,G.jsxs)(`div`,{className:`cardMetrics`,children:[(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`span`,{className:`metricLabel`,children:s(`Objects`)}),(0,G.jsx)(`span`,{className:`metricValue`,children:(0,G.jsx)(q,{...e,field:`objects`})})]}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`span`,{className:`metricLabel`,children:s(`Size`)}),(0,G.jsx)(`span`,{className:`metricValue`,children:(0,G.jsx)(q,{...e,field:`size`})})]}),(0,G.jsx)(`span`,{className:`cardAccess`,children:(0,G.jsx)(J,{bucket:t})})]})]})},Q=c.div`
  ${E.body}
  min-width: 0;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  overflow: hidden;
  font-variant-numeric: tabular-nums;
  --bucket-select-width: 28px;
  --bucket-menu-width: 36px;
  .bucketGrid {
    display: grid;
    grid-template-columns:
      minmax(120px, 1.8fr)
      minmax(0, 0.8fr) minmax(0, 0.9fr) minmax(0, 1.1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    align-items: center;
    column-gap: 8px;
    padding: 0 12px;
    box-sizing: border-box;
    height: var(--bucket-row-height, var(--control-height));
  }
  &[data-selection="true"] .bucketGrid {
    grid-template-columns:
      var(--bucket-select-width) minmax(120px, 1.8fr)
      minmax(0, 0.8fr) minmax(0, 0.9fr) minmax(0, 1.1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
  }
  .bucketCell {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .bucketCell a {
    color: inherit;
    text-decoration: none;
  }
  .bucketCell a:hover {
    text-decoration: underline;
  }
  .bucketCell a:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  .bucketNumber {
    text-align: right;
  }
  @media (min-width: 1200px) {
    .bucketNumber {
      padding-right: 12px;
    }
  }
  .bucketCheck {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .bucketMenu {
    overflow: visible;
    display: flex;
    justify-content: end;
  }
  .bucketRow {
    border-bottom: 1px solid var(--border);
    color: var(--muted-foreground);
    transition:
      color var(--dur-fast) ease,
      border-color var(--dur-fast) ease;
  }
  .bucketRow[data-fluid-activator] {
    cursor: pointer;
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[aria-selected="true"] {
    color: var(--foreground);
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[data-fluid-before] {
    border-bottom-color: transparent;
  }
  .bucketRow[aria-selected="true"] {
    background: var(--active);
  }
  .bucketRow:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  @media (max-width: 1199.98px) {
    .bucketGrid {
      grid-template-columns:
        minmax(100px, 1.6fr) minmax(0, 0.7fr) minmax(0, 0.8fr)
        minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns:
        var(--bucket-select-width) minmax(100px, 1.6fr)
        minmax(0, 0.7fr) minmax(0, 0.8fr) minmax(0, 1fr) minmax(0, 1fr) var(
          --bucket-menu-width
        );
    }
    .bucketLow {
      display: none;
    }
  }
  @media (max-width: 767.98px) {
    .bucketGrid {
      grid-template-columns: minmax(0, 1fr) 76px var(--bucket-menu-width);
      padding: 0 8px;
      gap: 4px;
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns: var(--bucket-select-width) minmax(0, 1fr) 76px var(
          --bucket-menu-width
        );
    }
    .bucketMedium {
      display: none;
    }
  }
  @media (pointer: coarse) {
    --bucket-select-width: 40px;
    --bucket-menu-width: 40px;
  }
`,Ae=c.div`
  position: sticky;
  top: 0;
  z-index: 1;
  background: var(--surface-3);
  color: var(--foreground);
  font-weight: var(--fw-semibold);
  border-bottom: 1px solid var(--border);
  button {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    border: 0;
    padding: 0;
    background: transparent;
    color: inherit;
    font: inherit;
    cursor: pointer;
    max-width: 100%;
  }
  @media (pointer: coarse) {
    button {
      min-height: 40px;
    }
  }
  button:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
  }
  button > svg {
    width: 12px;
    height: 12px;
    fill: currentColor;
  }
`,je=c.div`
  position: relative;
  isolation: isolate;
  min-height: 0;
  [data-fluid-highlight] {
    z-index: -1;
  }
`;function Me({index:e,style:t,records:n,columns:r,selected:i,common:a}){let o=n[e];return(0,G.jsx)(Ne,{index:e,style:t,columns:r,...a,bucket:o,selected:i.includes(o.name)},o.name)}function Ne({index:e,style:t,columns:n,...i}){let a=r(),{bucket:o,selected:s,onSelect:c,obOnly:l}=i,u=C(),d=K(o.name,l),f=()=>d.browse&&a(`/browser/${encodeURIComponent(o.name)}`);return(0,G.jsxs)(`div`,{role:`row`,"aria-rowindex":e+2,"aria-label":o.name,"aria-selected":c?s:void 0,style:t,className:`bucketGrid bucketRow`,"data-fluid-index":d.browse?e:void 0,"data-fluid-key":o.name,"data-fluid-activator":d.browse?`true`:void 0,tabIndex:d.browse?0:void 0,onClick:f,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),f())},children:[c&&(0,G.jsx)(`div`,{role:`cell`,className:`bucketCheck`,onClick:e=>e.stopPropagation(),children:(0,G.jsx)(b,{label:``,"aria-label":m(u(`Select {bucket}`),{bucket:o.name}),checked:s,disabled:!d.select,onChange:()=>c(o.name)})}),n.map(e=>(0,G.jsx)(`div`,{role:`cell`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``} ${e.id===`actions`?`bucketMenu`:``}`,children:e.render(i)},e.id))]})}function Pe({records:e,query:t,onSort:n,selected:r,onSelectAll:i,...o}){let s=C(),c=pe(),l=(0,z.useRef)(null),u=x(l,{gapClick:!1}),d=[{id:`name`,label:s(`Name`),sort:`name`,render:({bucket:e,obOnly:t})=>K(e.name,t).browse?(0,G.jsx)(a,{to:`/browser/${encodeURIComponent(e.name)}`,onClick:e=>e.stopPropagation(),children:e.name}):e.name},{id:`objects`,label:s(`Objects`),priority:`Medium`,number:!0,sort:`objects`,render:e=>(0,G.jsx)(q,{...e,field:`objects`})},{id:`size`,label:s(`Size`),number:!0,sort:`size`,render:e=>(0,G.jsx)(q,{...e,field:`size`})},{id:`versioning`,label:s(`Versioning`),priority:`Medium`,render:({bucket:e})=>(0,G.jsx)(Y,{enabled:e.details?!!e.details.versioning:void 0,suspended:e.details?.versioningSuspended})},{id:`locking`,label:s(`Object lock`),priority:`Low`,render:({bucket:e})=>(0,G.jsx)(Y,{enabled:e.details?!!e.details.locking:void 0})},{id:`quota`,label:s(`Quota`),priority:`Low`,number:!0,render:({bucket:e})=>(e.details?.quota?.quota||0)>0?p(e.details.quota.quota):`—`},{id:`replication`,label:s(`Replication`),priority:`Low`,render:({bucket:e})=>(0,G.jsx)(Y,{enabled:e.details?!!e.details.replication:void 0})},{id:`access`,label:s(`Access`),priority:`Medium`,render:({bucket:e})=>(0,G.jsx)(J,{bucket:e})},{id:`created`,label:s(`Created`),priority:`Low`,sort:`created`,render:({bucket:e})=>(0,G.jsx)(X,{at:e.creation_date})},{id:`actions`,label:s(`Actions`),render:e=>(0,G.jsx)(Z,{...e})}],f=e.filter(e=>K(e.name,o.obOnly).select),ee={records:e,columns:d,selected:r,common:o};return(0,G.jsxs)(Q,{role:`table`,"aria-label":s(`Buckets`),"aria-rowcount":e.length+1,"aria-colcount":d.length+ +!!o.onSelect,"data-selection":!!o.onSelect,style:{"--bucket-row-height":`${c}px`},children:[(0,G.jsxs)(Ae,{role:`row`,className:`bucketGrid`,"aria-rowindex":1,children:[o.onSelect&&(0,G.jsx)(`div`,{role:`columnheader`,className:`bucketCheck`,children:(0,G.jsx)(b,{label:``,"aria-label":s(`Select all visible buckets`),checked:f.length>0&&f.every(e=>r.includes(e.name)),disabled:!f.length,onChange:i})}),d.map(e=>(0,G.jsx)(`div`,{role:`columnheader`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``}`,"aria-sort":e.sort?t.sort===e.sort?t.dir===`asc`?`ascending`:`descending`:`none`:void 0,children:e.sort?(0,G.jsxs)(`button`,{type:`button`,"aria-label":e.label,onClick:()=>n(e.sort),children:[e.label,t.sort===e.sort&&(t.dir===`asc`?(0,G.jsx)(h,{}):(0,G.jsx)(se,{}))]}):e.id===`actions`?(0,G.jsx)(`span`,{className:`selectionHeaderLabel`,style:{position:`absolute`,clipPath:`inset(50%)`,width:1,height:1},children:e.label}):e.label},e.id))]}),(0,G.jsxs)(je,{ref:l,children:[(0,G.jsx)(S,{hover:u}),e.length>100?(0,G.jsx)(L,{role:`rowgroup`,"aria-label":s(`Bucket rows`),rowCount:e.length,rowHeight:c,rowComponent:Me,rowProps:ee,overscanCount:6,style:{height:`min(65vh, 720px)`,minHeight:c*4}}):(0,G.jsx)(`div`,{role:`rowgroup`,style:{maxHeight:`min(65vh, 720px)`,overflowY:`auto`},children:e.map((e,t)=>(0,G.jsx)(Ne,{...o,columns:d,bucket:e,index:t,selected:r.includes(e.name)},e.name))})]})]})}function Fe(){let e=n(),[t,r]=i(),a=V(t),[o,s]=(0,z.useState)(a.q);return(0,z.useEffect)(()=>s(a.q),[e.key,a.q]),(0,z.useEffect)(()=>{if(o===a.q)return;let e=window.location.href,t=window.setTimeout(()=>{window.location.href===e&&r(e=>H(e,{q:o}),{replace:!0})},150);return()=>window.clearTimeout(t)},[o,a.q,e.key,r]),{query:a,search:o,setSearch:s,sort:e=>r(t=>H(t,{sort:e,dir:a.sort===e&&a.dir===`asc`?`desc`:`asc`,q:o})),clear:()=>{s(``),r(e=>H(e,{q:``}))}}}var Ie=P(z.lazy(()=>g(()=>import(`./BulkReplicationModal-DjSTUw3-.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54]),import.meta.url))),Le=P(z.lazy(()=>g(()=>import(`./BulkLifecycleModal-CXO86eQf.js`),__vite__mapDeps([55,1,2,3,4,5,6,7,8,9,10,11,12,56,25,37,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,31,32,33,34,35,36,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54]),import.meta.url))),Re=P(z.lazy(()=>g(()=>import(`./DeleteBucket-BWEAhyw-.js`),__vite__mapDeps([57,1,2,5,3,4,6,22,7,12,43,42,44,58,41]),import.meta.url))),ze=c.h1`
  ${E.title}
  margin: 0 0 16px;
`,Be=c.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 16px;
  .bucketSearch {
    min-width: 160px;
    flex: 1 1 190px;
  }
  .bucketActions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: flex-end;
    gap: 8px;
    margin-left: auto;
  }
  .bucketView {
    display: flex;
    gap: 4px;
  }
  @media (max-width: 767.98px) {
    .bucketFreshness {
      order: 3;
      flex-basis: 100%;
    }
    .bucketSearch {
      flex-basis: 100%;
    }
    .bucketActions {
      flex-basis: 100%;
      flex-wrap: nowrap;
      justify-content: flex-start;
      gap: 8px;
    }
    .bucketView {
      margin-right: auto;
    }
  }
`,Ve=c.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  @media (max-width: 1199.98px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: 767.98px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,He=c.div`
  ${E.caption}
  color: var(--muted-foreground);
  margin-bottom: 8px;
`,$=c.div`
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  border-radius: var(--radius-card);
  min-height: 180px;
`,Ue=()=>{let e=ee(),t=r(),n=C(),i=me(),a=ne(te),o=!!a.features?.includes(`object-browser-only`),s=F(ye,[A.ADMIN_DATA_USAGE_INFO]),c=!o&&f(a.permissions),{updateListing:p}=we(),{query:h,search:g,setSearch:se,sort:ce,clear:fe}=Fe(),[y,b]=(0,z.useState)(),[x,S]=(0,z.useState)(!0),[pe,w]=(0,z.useState)(!1),[he,E]=(0,z.useState)(0),[D,j]=(0,z.useState)([]),[M,N]=(0,z.useState)(null),[P,I]=(0,z.useState)(null),[L,B]=(0,z.useState)(()=>{try{return Te(localStorage.getItem(`silo.buckets.view`))}catch{return`table`}}),V=(0,z.useCallback)(()=>E(e=>e+1),[]);(0,z.useEffect)(()=>{e(u(`ob_bucket_list`))},[e]),(0,z.useEffect)(()=>{let t=new AbortController;return S(!0),w(!1),l.buckets.listBuckets({signal:t.signal}).then(e=>{if(t.signal.aborted)return;if(!Array.isArray(e.data?.buckets))throw Error(n(`The bucket list could not be loaded.`));b(e.data),p(e.data);let r=new Set(e.data.buckets.map(e=>e.name));j(e=>e.filter(e=>r.has(e)))}).catch(n=>{t.signal.aborted||(w(!0),e(d(re(n))))}).finally(()=>{t.signal.aborted||S(!1)}),()=>t.abort()},[he,e,p,a.accountAccessKey,n]),(0,z.useEffect)(()=>{try{localStorage.setItem(`silo.buckets.view`,L)}catch{}},[L]);let H=y?.buckets||[],W=(0,z.useMemo)(()=>Ee(H,h,s,y?.usageUpdatedAt),[H,h.sort,h.dir,h.q,s,y?.usageUpdatedAt]),q=!o&&F(`*`,[A.S3_PUT_LIFECYCLE_CONFIGURATION,A.S3_PUT_REPLICATION_CONFIGURATION,A.S3_PUT_ACTIONS]),J=e=>j(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e]),Y=()=>j(e=>De(e,W.filter(e=>K(e.name,o).select).map(e=>e.name))),X=D.every(e=>F(e,O[ve.BUCKET_LIFECYCLE],!0)),Z=D.every(e=>F(e,[A.S3_PUT_REPLICATION_CONFIGURATION,A.S3_PUT_ACTIONS])),Oe=n(`Select one or more buckets first.`),Q=(e,t)=>D.length?e?void 0:_e(t,n(`configure the selected buckets`)):Oe,Ae=e=>{N(null),e&&(j([]),V())},je={canReadUsage:s,usageUpdatedAt:y?.usageUpdatedAt,obOnly:o,onSelect:q?J:void 0,onDelete:I},Me=c?(0,G.jsx)(_,{id:`empty-create-bucket`,variant:`callAction`,label:n(`Create bucket`),onClick:()=>t(k.ADD_BUCKETS)}):void 0;return(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(T,{open:M?.type===`replication`,children:M?.type===`replication`&&(0,G.jsx)(Ie,{open:!0,buckets:M.names,closeModalAndRefresh:Ae})}),(0,G.jsx)(T,{open:M?.type===`lifecycle`,children:M?.type===`lifecycle`&&(0,G.jsx)(Le,{open:!0,buckets:M.names,closeModalAndRefresh:Ae})}),(0,G.jsx)(T,{open:P!==null,children:P!==null&&(0,G.jsx)(Re,{deleteOpen:!0,selectedBucket:P,closeDeleteModalAndRefresh:e=>{I(null),e&&(j(e=>e.filter(e=>e!==P)),V())}})}),!o&&(0,G.jsx)(xe,{label:n(`Buckets`),titleElement:`h1`,help:!0}),(0,G.jsxs)(ae,{children:[o&&(0,G.jsx)(ze,{children:n(`Buckets`)}),(0,G.jsxs)(Be,{children:[(0,G.jsx)(`div`,{className:`bucketSearch`,children:(0,G.jsx)(be,{id:`bucket-search`,placeholder:n(`Search buckets`),value:g,onChange:se,sx:{width:`100%`}})}),s&&(0,G.jsx)(`div`,{className:`bucketFreshness`,children:(0,G.jsx)(Se,{at:y?.usageUpdatedAt,pending:!U(y?.usageUpdatedAt),prefix:`Calculated`})}),(0,G.jsxs)(`div`,{className:`bucketActions`,children:[(0,G.jsxs)(`div`,{className:`bucketView`,role:`group`,"aria-label":n(`Bucket view`),children:[(0,G.jsx)(_,{id:`buckets-view-table`,collapseOnSmall:!1,label:n(`Table`),variant:L===`table`?`secondary`:`ghost`,"aria-pressed":L===`table`,onClick:()=>B(`table`)}),(0,G.jsx)(_,{id:`buckets-view-cards`,collapseOnSmall:!1,label:n(`Cards`),variant:L===`cards`?`secondary`:`ghost`,"aria-pressed":L===`cards`,onClick:()=>B(`cards`)})]}),(0,G.jsx)(oe,{id:`refresh-buckets`,"aria-label":n(`Refresh buckets`),size:`medium`,disabled:x,onClick:V,children:(0,G.jsx)(ie,{})}),q&&(i?(0,G.jsx)(ge,{label:n(`Actions`),items:[{label:n(`Set replication`),icon:(0,G.jsx)(le,{}),disabled:x||!D.length||!Z,disabledReason:Q(Z,[A.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>N({type:`replication`,names:[...D]})},{label:n(`Set lifecycle`),icon:(0,G.jsx)(ue,{}),disabled:x||!D.length||!X,disabledReason:Q(X,O[ve.BUCKET_LIFECYCLE]),onClick:()=>N({type:`lifecycle`,names:[...D]})}]}):(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(_,{id:`set-replication`,collapseOnSmall:!1,label:n(`Set replication`),icon:(0,G.jsx)(le,{}),disabled:x||!D.length||!Z,disabledReason:Q(Z,[A.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>N({type:`replication`,names:[...D]})}),(0,G.jsx)(_,{id:`set-lifecycle`,collapseOnSmall:!1,label:n(`Set lifecycle`),icon:(0,G.jsx)(ue,{}),disabled:x||!D.length||!X,disabledReason:Q(X,O[ve.BUCKET_LIFECYCLE]),onClick:()=>N({type:`lifecycle`,names:[...D]})})]})),!o&&(0,G.jsx)(_,{id:`create-bucket`,label:n(`Create bucket`),icon:(0,G.jsx)(de,{}),disabled:!c,disabledReason:c?void 0:_e([A.S3_CREATE_BUCKET],n(`create a bucket`)),onClick:()=>t(k.ADD_BUCKETS),variant:`primary`,collapseOnSmall:!1})]})]}),D.length>0&&(0,G.jsx)(He,{role:`status`,children:m(n(D.length===1?`1 bucket selected`:`{count} buckets selected`),{count:D.length})}),x?(0,G.jsx)($,{children:(0,G.jsx)(Ce,{rows:5,columns:4})}):pe&&!y?(0,G.jsx)($,{children:(0,G.jsx)(R,{compact:!0,icon:(0,G.jsx)(v,{}),title:n(`The bucket list could not be loaded.`),action:(0,G.jsx)(_,{id:`retry-buckets`,label:n(`Retry`),onClick:V})})}):W.length===0?(0,G.jsx)($,{children:h.q.trim()?(0,G.jsx)(R,{compact:!0,icon:(0,G.jsx)(v,{}),title:m(n(`No buckets match “{q}”`),{q:h.q.trim()}),action:(0,G.jsx)(_,{id:`clear-bucket-filter`,label:n(`Clear filter`),onClick:fe})}):(0,G.jsx)(R,{icon:(0,G.jsx)(v,{}),title:n(`No buckets yet`),description:n(`Create a bucket to start storing objects.`),action:Me})}):L===`table`?(0,G.jsx)(Pe,{...je,records:W,query:h,onSort:ce,selected:D,onSelectAll:Y}):(0,G.jsx)(Ve,{role:`list`,"aria-label":n(`Buckets`),children:W.map(e=>(0,G.jsx)(ke,{...je,bucket:e,selected:D.includes(e.name)},e.name))})]})]})};export{Ue as default};