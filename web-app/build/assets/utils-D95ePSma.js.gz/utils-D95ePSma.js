var e=`{
    "Version": "2012-10-17",
    "Statement": [
        
    ]
}`;export{e as t};