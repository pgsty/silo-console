const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./DeleteBucket-B-rn1dvh.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./store-u0LCkSUK.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./lang-BxJGrDHW.js","./mds-YaKHoCCJ.js","./trash-D6JXtEqL.js","./i18n-CkC2HRew.js","./index-Bhxp0Pd2.js","./ModalPresence-DpAARFPv.js","./index-BFo1l52q.css","./ConfirmDialog-CEeXK5RZ.js","./ModalBox-B1Mqh9LH.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,d as n,f as r,r as i,t as a}from"./react-vendor-UL3KVrSx.js";import{D as o,T as s}from"./shared-vendor-BQfq49S_.js";import{Cr as ee,ar as c,r as l}from"./store-u0LCkSUK.js";import{i as u,n as d}from"./lang-BxJGrDHW.js";import{F as f,l as p,v as m}from"./mds-YaKHoCCJ.js";import{t as te}from"./trash-D6JXtEqL.js";import{t as ne}from"./archive-swEOSDZm.js";import{t as re}from"./settings-BGAESn0x.js";import{t as h}from"./folder-DGc8Lwwm.js";import{t as g}from"./Tabs-Cx_lZDzy.js";import{a as _,n as v}from"./i18n-CkC2HRew.js";import{t as ie}from"./ModalPresence-DpAARFPv.js";import{s as ae}from"./index-Bhxp0Pd2.js";import{t as oe}from"./OverflowMenu-D1aICRMe.js";import{t as y}from"./typography-DxndMn2P.js";import{g as b,n as x,o as S,p as C,r as w}from"./permissions-BaYWxI8a.js";import{t as T}from"./withSuspense-DTbtEWjP.js";import{n as se}from"./SecureComponent-BuNNF0Qr.js";import{t as E}from"./bucketMetadata-BAg0j77c.js";import{A as ce,K as le,d as ue,f as de}from"./ConsoleKBar-DouLK5Za.js";var D=e(t()),fe=(e,t,n)=>{let r=n=>t.hasPermission(e,n),i=!t.features.includes(`object-browser-only`)&&r(w[x.BUCKETS_ADMIN_VIEW]),a=`/buckets/${encodeURIComponent(e)}/admin`;return[{id:`objects`,label:u(`Objects`),to:`/browser/${encodeURIComponent(e)}`,permitted:r(C)},{id:`summary`,label:u(`Summary`),to:`${a}/summary`,permitted:i},{id:`events`,label:u(`Events`),to:`${a}/events`,permitted:i&&r([S.S3_GET_BUCKET_NOTIFICATIONS,S.S3_PUT_BUCKET_NOTIFICATIONS,S.S3_GET_ACTIONS,S.S3_PUT_ACTIONS])},{id:`replication`,label:u(`Replication`),to:`${a}/replication`,permitted:i&&t.distributedSetup&&!n&&r([S.S3_GET_REPLICATION_CONFIGURATION,S.S3_PUT_REPLICATION_CONFIGURATION,S.S3_GET_ACTIONS,S.S3_PUT_ACTIONS])},{id:`lifecycle`,label:u(`Lifecycle`),to:`${a}/lifecycle`,permitted:i&&t.distributedSetup&&r([S.S3_GET_LIFECYCLE_CONFIGURATION,S.S3_PUT_LIFECYCLE_CONFIGURATION,S.S3_GET_ACTIONS,S.S3_PUT_ACTIONS])},{id:`access`,label:u(`Access`),to:`${a}/access`,permitted:i&&r([S.ADMIN_GET_POLICY,S.ADMIN_LIST_USER_POLICIES,S.ADMIN_LIST_USERS])},{id:`anonymous`,label:u(`Anonymous`),to:`${a}/prefix`,permitted:i&&r([S.S3_GET_BUCKET_POLICY,S.S3_GET_ACTIONS])}].filter(e=>e.permitted)},O=a(),k=T(D.lazy(()=>p(()=>import(`./DeleteBucket-B-rn1dvh.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]),import.meta.url))),pe=s.span`
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  a {
    color: var(--muted-foreground);
    text-decoration: none;
  }
  a:hover {
    color: var(--foreground);
  }
  > span:last-child {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
`,A=s.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  padding: 20px 24px 12px;
  @media (max-width: 1199px) {
    padding-inline: 16px;
  }
  @media (max-width: 767px) {
    padding-inline: 12px;
    .bucketIdentity {
      flex-basis: 100%;
    }
  }
  .bucketIdentity {
    min-width: 0;
    flex: 1;
  }
  h1 {
    ${y.title} margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    overflow-wrap: anywhere;
  }
  h1 svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
    color: var(--muted-foreground);
  }
  .bucketActions {
    display: flex;
    align-items: center;
    gap: 8px;
  }
`,j=s.div`
  ${y.caption}
  color: var(--muted-foreground);
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  row-gap: 4px;
  column-gap: 12px;
  margin-top: 8px;
  > span {
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }
  @media (min-width: 768px) {
    > span + span::before {
      content: "·";
      margin-right: 4px;
    }
  }
`,M=s.div`
  min-width: 0;
  > .tabs-container {
    height: auto;
  }
  > .tabs-container > .optionsContainer {
    padding: 0 24px 12px;
    border-bottom: 1px solid var(--border);
    @media (max-width: 767px) {
      padding-inline: 12px;
    }
  }
  > .tabs-container > .tabsPanels {
    padding: 0;
  }
`;function N({bucketName:e,bucketInfo:t,primaryAction:a,refreshAction:s,onRefresh:u,anonymous:p=!1,children:y}){let x=_(),S=ae(),C=v(),w=n(),T=r(),N=ue(),P=l(ee),{listing:F,visit:I,objectRoute:L,refresh:R}=de(),[z,B]=(0,D.useState)(null),V=F?.buckets?.find(t=>t.name===e),H=t?.name===e?t:void 0,U=V||H,W=V?F?.usageUpdatedAt:void 0,G=E(U,`size`,W),K=E(U,`objects`,W),q=H?.access||V?.access,J=V?.rw_access,me=q?x(q.toLowerCase()):J?.read?J.write?x(`Read and write`):x(`Read only`):J?.write?x(`Write only`):void 0,Y=U?.creation_date?o.fromISO(U.creation_date).setLocale(C===`zh`?`zh-CN`:`en`):void 0,X=fe(e,N,P.enabled&&P.curSite),Z=X.find(e=>e.id===`objects`),Q=X.find(e=>e.id===`summary`),$=w.pathname.startsWith(`/browser/`),he=$?Z?.to:w.pathname;(0,D.useEffect)(()=>{p||I(e),B(null)},[e,p,I]);let ge=[...!$&&Z?[{label:x(`Browse Bucket`),icon:(0,O.jsx)(h,{}),onClick:()=>T(L(e))}]:[],...$&&Q?[{label:x(`Configure Bucket`),icon:(0,O.jsx)(re,{}),onClick:()=>T(Q.to)}]:[],...!p&&se(e,b)?[{label:x(`Delete Bucket`),icon:(0,O.jsx)(te,{}),danger:!0,onClick:()=>B(e)}]:[]];return(0,O.jsxs)(O.Fragment,{children:[!p&&(0,O.jsx)(ce,{sx:{minHeight:56},label:(0,O.jsxs)(pe,{children:[(0,O.jsx)(i,{to:`/buckets`,children:x(`Buckets`)}),(0,O.jsx)(`span`,{"aria-hidden":`true`,children:`/`}),(0,O.jsx)(`span`,{children:e})]}),help:!0}),(0,O.jsxs)(A,{children:[(0,O.jsxs)(`div`,{className:`bucketIdentity`,children:[(0,O.jsxs)(`h1`,{children:[(0,O.jsx)(ne,{"aria-hidden":`true`}),e]}),!p&&(0,O.jsx)(j,{children:[Y?.isValid?(0,O.jsx)(`span`,{title:Y.toLocaleString(o.DATETIME_FULL),children:d(x(`Created {date}`),{date:Y.toLocaleString(o.DATE_MED)})}):null,me||null,G===void 0?null:c(G),K===void 0?null:d(x(`{count} objects`),{count:K.toLocaleString(C)}),V&&F?.usageUpdatedAt?(0,O.jsx)(le,{at:F.usageUpdatedAt,prefix:`Calculated`}):null].filter(e=>e!==null).map((e,t)=>(0,O.jsx)(`span`,{children:e},t))})]}),(0,O.jsxs)(`div`,{className:`bucketActions`,children:[a,!S&&(0,O.jsx)(m,{id:s?.id||`refresh-bucket-info`,label:s?.label||x(`Refresh`),disabled:s?.disabled,disabledReason:s?.disabledReason,onClick:s?.onClick||(()=>{u?.(),R()}),children:(0,O.jsx)(f,{})}),(0,O.jsx)(oe,{label:x(`Bucket actions`),items:[...S?[s||{label:x(`Refresh`),onClick:()=>{u?.(),R()},icon:(0,O.jsx)(f,{})}]:[],...ge]})]})]}),p?y:(0,O.jsx)(M,{children:(0,O.jsx)(g,{horizontal:!0,useRouteTabs:!0,currentTabOrPath:he||``,options:X.map(({id:e,label:t,to:n})=>({tabConfig:{id:e,label:x(t),to:n}})),onTabClick:t=>T(t===Z?.to?L(e):t),routes:y})}),(0,O.jsx)(ie,{open:z!==null,children:z!==null&&(0,O.jsx)(k,{deleteOpen:!0,selectedBucket:z,closeDeleteModalAndRefresh:e=>{B(null),e&&(R(),T(`/buckets`))}})})]})}export{N as t};