import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{N as t,P as n,t as r}from"./react-vendor-UL3KVrSx.js";import{Y as i}from"./mds-Hm6-garf.js";import{T as a}from"./shared-vendor-BQfq49S_.js";import{a as o,c as s,i as c,n as l,o as u,r as d,s as f,t as p}from"./listPopup-D2sWpuy2.js";import{a as m}from"./i18n-Drk-M_7X.js";import{n as h,t as g}from"./shared-DOoon_mo.js";import{t as _}from"./typography-BO7lxH25.js";var v=e(n()),y=e(t()),b=e=>[...e.filter(e=>!e.danger),...e.filter(e=>e.danger)],x=r(),S=a.div`
  display: inline-flex;
`,C=a(i).attrs({offset:2,shadowLevel:3})`
  ${c}
  position: fixed;
  z-index: 10000;
  width: 240px;
  max-width: calc(100vw - 24px);
  overflow-y: auto;
  padding: 4px;
  border: 0;
  border-radius: var(--radius-popover, 12px);
  isolation: isolate;
  [data-fluid-highlight] {
    z-index: -1;
  }
  > span,
  > span > span:first-child {
    width: 100%;
  }
`,w=a.button`
  ${_.body}
  display: flex;
  position: relative;
  align-items: center;
  gap: var(--gap, 8px);
  width: 100%;
  height: var(--control-height, 36px);
  padding: 0 var(--control-padding, 12px);
  border: 0;
  border-radius: var(--radius-control, 8px);
  background: transparent;
  text-align: left;
  cursor: pointer;
  outline: none;
  color: ${({$danger:e})=>e?`var(--destructive-text)`:`var(--muted-foreground)`};
  &&:focus-visible {
    outline: none;
    background: var(--hover);
  }
  &[data-fluid-hover] {
    color: ${({$danger:e})=>e?`var(--destructive-text)`:`var(--foreground)`};
  }
  &[aria-disabled="true"] {
    color: var(--muted-foreground);
    cursor: not-allowed;
  }
  @media (pointer: coarse) {
    min-height: 40px;
  }
  svg {
    width: var(--icon-size, 16px);
    height: var(--icon-size, 16px);
    flex-shrink: 0;
    fill: currentColor;
  }
`,T=a.div`
  border-top: 1px solid var(--border);
  margin: 4px 0;
`,E=({items:e,label:t,tooltipPlacement:n,tooltipLabel:r,triggerRef:i})=>{let a=m(),c=t||a(`More actions`),_=(0,v.useId)(),E=(0,v.useRef)(null),D=(0,v.useRef)(null),[O,k]=(0,v.useState)(!1),A=(0,v.useRef)({text:``,at:0}),j=b(e),M=(e=!1)=>{k(!1),e&&E.current?.querySelector(`button`)?.focus({preventScroll:!0})},N=u(O,E.current,D,()=>M(),`end`),P=s(D,{gapClick:{maxDistance:8},disabled:!O||j.every(e=>e.danger),onActiveChange:e=>{e!==null&&O&&D.current?.querySelector(`[data-fluid-index="${e}"]`)?.focus({preventScroll:!0})}});return(0,v.useEffect)(()=>{if(!O)return;let e=requestAnimationFrame(()=>(p(D.current)[0]||D.current)?.focus({preventScroll:!0}));return()=>cancelAnimationFrame(e)},[O]),(0,x.jsxs)(S,{ref:E,id:`${_}-anchor`,children:[(0,x.jsx)(h,{text:r??c,placement:n,children:(0,x.jsx)(g,{ref:i,type:`button`,"aria-label":c,"aria-haspopup":`menu`,"aria-expanded":O,"aria-controls":O?_:void 0,onClick:()=>O?M():e.length&&k(!0),onKeyDown:e=>{[`ArrowDown`,`ArrowUp`].includes(e.key)&&(e.preventDefault(),k(!0))},children:(0,x.jsx)(`span`,{"aria-hidden":`true`,style:{fontSize:24,lineHeight:1},children:`⋯`})})}),N.mounted&&(0,y.createPortal)((0,x.jsxs)(C,{ref:D,id:_,role:`menu`,tabIndex:-1,"aria-label":c,"data-silo-popup":`true`,"data-popup-anchor":`${_}-anchor`,"data-side":N.side,"data-closing":!O,style:N.style,onKeyDown:e=>{if(e.key===`Escape`)e.preventDefault(),e.stopPropagation();else if(e.key===`Tab`)d(D.current,E.current,M);else if(!l(e,D.current)&&e.key.length===1&&e.key!==` `&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&!e.nativeEvent.isComposing){let t=Date.now();A.current={text:(t-A.current.at<500?A.current.text:``)+e.key.toLocaleLowerCase(),at:t};let n=p(D.current),r=n.indexOf(document.activeElement),i=[...n.slice(r+1),...n.slice(0,r+1)].find(e=>e.textContent?.trim().toLocaleLowerCase().startsWith(A.current.text));i&&(e.preventDefault(),i.focus({preventScroll:!0}),o(i))}},onKeyUp:e=>{e.key===`Escape`&&(e.preventDefault(),e.stopPropagation(),M(!0))},children:[(0,x.jsx)(f,{hover:P}),j.map((e,t)=>{let n=(0,x.jsxs)(w,{type:`button`,role:`menuitem`,tabIndex:-1,"aria-disabled":e.disabled||void 0,$danger:e.danger,"data-fluid-index":t,"data-fluid-key":e.label,"data-fluid-gap-click":e.danger?`false`:void 0,onClick:()=>{e.disabled||(M(!0),e.onClick())},children:[e.icon&&(0,x.jsx)(`span`,{"aria-hidden":`true`,children:e.icon}),e.label]});return(0,x.jsxs)(v.Fragment,{children:[e.danger&&t>0&&!j[t-1].danger&&(0,x.jsx)(T,{role:`separator`}),e.disabled&&e.disabledReason?(0,x.jsx)(h,{text:e.disabledReason,children:n}):n]},`${e.label}-${t}`)})]}),document.body)]})};export{E as t};