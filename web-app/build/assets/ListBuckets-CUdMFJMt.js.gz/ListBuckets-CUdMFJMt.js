const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./BulkReplicationModal-lK-FAAc8.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./mds-BO2rKL5Q.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./store-BGxI9kEo.js","./lang-deC2ggFn.js","./triangle-alert-CiC2cMSC.js","./circle-check-BITyuNum.js","./ReadBox-B5GgYvSb.js","./Wizard-DMngrbhr.js","./i18n-Bv0O4wSF.js","./replicationValidation-CGle0kPg.js","./ConsoleKBar-DWQBCirp.js","./gauge-ChcF6Bq2.js","./pencil-DBbyLqGZ.js","./search-Bbok0NS8.js","./CircleIcon-BsXHTBH6.js","./shield-check-BChGe80Z.js","./chart-no-axes-column-rWZIwpLS.js","./heart-pulse-iSChCoNS.js","./trash-Bfbr9RVQ.js","./clock-CPDlM_96.js","./activity-BVoJ9E4U.js","./plus-CSB22Jm-.js","./users-C-RzLQMr.js","./shield-BfA2vgA0.js","./archive-CTc9EA80.js","./webhook-Dw5HD9ic.js","./users-round-CPKNmg8w.js","./layers-ABvJTXSP.js","./rotate-ccw-BHm_nXo5.js","./settings-J9nKBzCo.js","./logs-jHflK370.js","./info-Bv343I8W.js","./scan-search-DbpYUeMk.js","./console-vendor-I3rSB1nD.js","./listPopup-D2sWpuy2.js","./SectionTitle-BVdhf7cL.js","./useAvailableWidth-COFYcObd.js","./ModalBox-DT-uaPZI.js","./ModalPresence-OF_v2s_H.js","./index-UVRc8OT4.js","./index-BFo1l52q.css","./shared-BiAQgjwv.js","./OverflowMenu-DC4Ttstq.js","./typography-DqmBZROV.js","./permissions-6ArR3S_m.js","./StatusBadge-C5OEbTRh.js","./CliEquivalent-BDBaceFv.js","./copy-Bz6mlqnF.js","./code-DiVYB7WE.js","./lib-BVN4wEer.js","./SecureComponent-BarZQrW7.js","./BulkLifecycleModal-Bj17hMSk.js","./QueryMultiSelector-DeRGeMOK.js","./DeleteBucket-xeaVjmsk.js","./ConfirmDialog-DX63qcXf.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,d as n,f as r,h as i,r as a,t as o}from"./react-vendor-UL3KVrSx.js";import{n as s,o as c}from"./lang-deC2ggFn.js";import{C as l,P as u,R as d,_ as f,h as p,ot as m,w as h}from"./mds-BO2rKL5Q.js";import{D as ee,T as g}from"./shared-vendor-BQfq49S_.js";import{$t as te,Dr as ne,En as re,Or as ie,Tn as _,i as ae,in as oe,or as v,r as se}from"./store-BGxI9kEo.js";import{t as ce}from"./trash-Bfbr9RVQ.js";import{t as le}from"./boxes-z4ix3s6Z.js";import{t as ue}from"./calendar-clock-C9bsoh0h.js";import{t as de}from"./plus-CSB22Jm-.js";import{t as y}from"./archive-CTc9EA80.js";import{t as b}from"./settings-J9nKBzCo.js";import{t as fe}from"./folder-D6mn022e.js";import{t as x}from"./Checkbox-CkIkx1jU.js";import{c as S,s as pe}from"./listPopup-D2sWpuy2.js";import{t as me}from"./useTableLayout-BqOhLQsu.js";import{a as C,n as w,t as he}from"./i18n-Bv0O4wSF.js";import{t as ge}from"./ModalPresence-OF_v2s_H.js";import{c as _e}from"./index-UVRc8OT4.js";import{n as T}from"./shared-BiAQgjwv.js";import{t as ve}from"./OverflowMenu-DC4Ttstq.js";import{t as E}from"./typography-DqmBZROV.js";import{A as ye,a as D,g as O,i as k,n as A,o as j,p as M,r as N,t as be}from"./permissions-6ArR3S_m.js";import{t as P}from"./StatusBadge-C5OEbTRh.js";import{t as xe}from"./SearchBox-CixAqQZ8.js";import{t as F}from"./withSuspense-DTbtEWjP.js";import{n as I}from"./SecureComponent-BarZQrW7.js";import{a as L,i as R,n as z,r as B,t as V}from"./prefixUsage-D1cyEXEG.js";import{t as H}from"./bucketMetadata-BAg0j77c.js";import{n as U}from"./react-window-0T2cJ04-.js";import{A as Se,J as Ce,V as we,f as Te}from"./ConsoleKBar-DWQBCirp.js";var W=e(t()),Ee=(0,W.createContext)(void 0),De=Ee.Provider,G=()=>(0,W.useContext)(Ee),K=e=>e.state===`queued`||e.state===`running`,q=[`not_scanned`,`queued`,`running`,`complete`,`error`,`limited`,`forbidden`,`missing`,`unavailable`],J=(e,t)=>e==null||t(e),Y=e=>{if(typeof e!=`object`||!e)return!1;let t=e,n=t.totals;return!!n&&B(n.current_bytes)&&R(n.current_objects)&&J(n.retained_bytes,B)&&J(n.retained_versions,R)&&J(n.delete_markers,R)&&R(t.scanned_entries)},Oe=e=>{if(e&&typeof e.bucket==`string`)return q.includes(e.state)?{...e,last_good:Y(e.last_good)?e.last_good:void 0,progress:Y(e.progress)?e.progress:void 0}:{bucket:e.bucket,state:`unavailable`,versions_visible:!1}},ke=e=>({...e,totals:{current_bytes:e.totals.current_bytes,current_objects:e.totals.current_objects}}),Ae=(e,t)=>e.state===`unavailable`&&!e.last_good&&t?.last_good?{...e,last_good:e.versions_visible?t.last_good:ke(t.last_good),last_completed_at:t.last_completed_at}:e;function je(e){let t=JSON.stringify(e),n=L(),r=(0,W.useRef)(),[i,a]=(0,W.useState)(0),o=(0,W.useRef)(!1),[s,c]=(0,W.useState)({requesting:!1,records:{}}),l=(0,W.useCallback)(()=>{o.current=!0,a(e=>e+1)},[]);return(0,W.useEffect)(()=>{let e=JSON.parse(t),i=new AbortController;r.current?.abort(),r.current=i;let a,s=()=>!i.signal.aborted&&n(),l=o.current;o.current=!1;let u=!l;c(t=>({...t,records:Object.fromEntries(Object.entries(t.records).filter(([t])=>e.includes(t)).flatMap(([e,n])=>t.enabled===!1&&n.state===`running`?n.last_good?[[e,{...n,state:`complete`,progress:void 0}]]:[]:[[e,n]]))}));let d=async()=>{c(e=>({...e,requesting:!0}));let t=[...e],n=async()=>{for(;s()&&t.length;){let e=t.shift(),n=I(e,[j.S3_LIST_BUCKET_VERSIONS]),r={bucket:e,state:`running`,versions_visible:n},a=()=>s()&&c(t=>{let i=t.records[e],a=i?.versions_visible===n&&r.state!==`forbidden`&&r.state!==`missing`;return{...t,records:{...t.records,[e]:{...r,last_good:r.last_good??(a?i?.last_good:void 0),last_completed_at:r.last_completed_at??(a?i?.last_completed_at:void 0)}}}});a();try{let t,o=await _.buckets.prefixUsage(e,{prefix:``,versions:n,folders:!1},{signal:i.signal});await z(o,{bucket:e,prefix:``,mode:n?`versions`:`current`},e=>{let i={totals:{...e.totals,...n?{}:{retained_bytes:void 0,retained_versions:void 0,delete_markers:void 0}},scanned_entries:e.scanned_entries,started_at:e.started_at,updated_at:e.updated_at};r={...r,state:e.status===`scanning`||e.status===`complete`?`running`:e.status===`failed`?`error`:e.status,progress:i},e.status===`complete`&&(t=i),a()}),t&&(r={...r,state:`complete`,last_good:t,last_completed_at:t.updated_at},a())}catch(e){let t=e instanceof Response?e.status:0;r={...r,state:t===401||t===403?`forbidden`:t===404?`missing`:`error`},a()}}};await Promise.all([n(),n()]),s()&&c(e=>({...e,requesting:!1}))},f=async t=>{if(s()){t&&c(e=>({...e,requesting:!0,error:!1}));try{let n=!1,r=2e3,o,l=[];for(let a=0;a<Math.max(e.length,1);a+=100){let s={buckets:e.slice(a,a+100)},c=t?await _.bucketUsage.bucketUsageRefresh(s,{signal:i.signal}):await _.bucketUsage.bucketUsageStatus(s,{signal:i.signal});if(n=c.data.enabled,r=c.data.poll_after_ms,o=c.data.coverage,l.push(...c.data.buckets),!n)break}if(!s())return;if(n&&t&&(u=!0),c(e=>({enabled:n,requesting:!1,records:n?Object.fromEntries(l.flatMap(t=>{let n=Oe(t);return n?[[n.bucket,Ae(n,e.records[n.bucket])]]:[]})):e.enabled===!1?e.records:{},coverage:o})),!n){t&&(await d(),s()&&(u=!0));return}let p=l.some(K);a=setTimeout(()=>void f(!1),Math.min(6e4,Math.max(250,r)*(p?1:10)))}catch{s()&&(u=!0,c(e=>({...e,requesting:!1,error:!0})),a=setTimeout(()=>void f(!1),1e4))}}};return f(l),()=>{!u&&n()&&(o.current=!0),i.abort(),clearTimeout(a)}},[t,i,n]),{...s,refresh:l}}var X=o(),Me=g.small`
  ${E.caption}
  display: block;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--muted-foreground);
`,Ne=g(Me)`
  white-space: normal;
  text-overflow: clip;
  .usageValue {
    white-space: nowrap;
  }
`;function Pe({bucket:e}){let t=G(),n=t?.records[e],r=C(),i=c(w());if(!t||!n&&!t.enabled)return null;let a={not_scanned:r(`Not scanned`),queued:r(`Update queued`),running:r(`Updating usage…`),complete:r(`Updated`),error:r(`Update failed — retry with Refresh`),limited:r(`Scan limit reached — operator action required`),forbidden:r(`Usage listing not permitted`),missing:r(`Bucket no longer exists`),unavailable:r(`Usage temporarily unavailable`)},o=n?.last_completed_at?new Date(n.last_completed_at):void 0,l=[n?a[n.state]:r(`Checking usage…`),n?.state===`running`&&n.progress?s(r(`{count} entries scanned`),{count:n.progress.scanned_entries.toLocaleString(i)}):``,o&&Number.isFinite(o.getTime())?o.toLocaleTimeString(i):``].filter(Boolean).join(` · `);return(0,X.jsx)(Me,{title:o&&Number.isFinite(o.getTime())?`${l} (${o.toLocaleString(i)})`:l,children:l})}function Fe(){let e=G(),t=C(),n=w()===`zh`?``:` `;if(!e)return null;let r=Object.values(e.records),i=r.filter(e=>e.state===`queued`||e.state===`running`).length,a=r.filter(e=>[`error`,`limited`,`unavailable`].includes(e.state)).length,o=e.coverage?.observer_alive&&e.coverage.connected&&e.coverage.reconciled;return(0,X.jsxs)(`div`,{role:`status`,"aria-live":`polite`,style:{marginBottom:12},children:[e.requesting?t(`Requesting usage updates…`):i?s(t(`{count} usage updates queued or running. Last completed totals remain visible.`),{count:i}):t(`Refresh requests a new metadata scan of all listed buckets.`),n,e.error?t(`Usage status is unavailable. Retrying…`):e.enabled?t(o?`Automatic change monitoring is active.`:`Automatic change monitoring is recovering; totals may be out of date.`):e.enabled===!1?t(`Automatic updates are not configured. Refresh calculates usage while this page is open.`):t(`Checking automatic updates…`),a>0&&(0,X.jsxs)(X.Fragment,{children:[n,s(t(`{count} updates need attention. Use Refresh to retry.`),{count:a})]})]})}var Ie=[`name`,`objects`,`size`,`created`],Le=e=>({sort:Ie.includes(e.get(`sort`)||``)?e.get(`sort`):`name`,dir:e.get(`dir`)===`desc`?`desc`:`asc`,q:e.get(`q`)||``}),Re=(e,t)=>{let n=new URLSearchParams(e),r={...Le(e),...t};for(let e of[`sort`,`dir`,`q`])!r[e]||e===`sort`&&r.sort===`name`||e===`dir`&&r.dir===`asc`?n.delete(e):n.set(e,r[e]);return n},ze=e=>e===`cards`?`cards`:`table`,Be=e=>!!(e&&Number.isFinite(Date.parse(e))),Ve=(e,t,n,r)=>{if(!(!e||n&&!Be(r)))return!n&&e[t]===void 0?0:H(e,t,r)},He=(e,t,n,r,i)=>{let a=t.q.trim().toLocaleLowerCase(),o=e=>{if(t.sort===`name`)return e.name;if(t.sort===`created`){let t=Date.parse(e.creation_date||``);return Number.isFinite(t)?t:void 0}if(i){let n=i[e.name]?.last_good?.totals;return n?t.sort===`size`?BigInt(n.current_bytes):n.current_objects:void 0}return Ve(e,t.sort,n,r)};return e.filter(e=>e.name.toLocaleLowerCase().includes(a)).sort((e,n)=>{let r=o(e),i=o(n);return r===void 0&&i!==void 0?1:i===void 0&&r!==void 0?-1:(r===i||r===void 0||i===void 0?0:r<i?-1:1)*(t.dir===`desc`?-1:1)||e.name.localeCompare(n.name)})},Ue=(e,t)=>t.length>0&&t.every(t=>e.includes(t))?e.filter(e=>!t.includes(e)):Array.from(new Set([...e,...t])),Z=(e,t)=>({browse:I(e,M),settings:!t&&I(e,N[A.BUCKETS_ADMIN_VIEW]),delete:!t&&I(e,O),select:!t&&I(e,[j.S3_PUT_LIFECYCLE_CONFIGURATION,j.S3_PUT_REPLICATION_CONFIGURATION,j.S3_PUT_ACTIONS])}),Q=({bucket:e,field:t,canReadUsage:n,usageUpdatedAt:r})=>{let i=C(),a=w(),o=G(),s=(o?.records[e.name])?.last_good?.totals;if(s)return t===`objects`?(0,X.jsx)(X.Fragment,{children:s.current_objects.toLocaleString(a)}):(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`span`,{title:`${s.current_bytes} B`,children:V(s.current_bytes)}),s.retained_bytes!=null&&(0,X.jsx)(Ne,{title:`${s.retained_bytes} B`,children:he(i(`Retained: {size}`),{size:(0,X.jsx)(`span`,{className:`usageValue`,children:V(s.retained_bytes)})})})]});if(o)return(0,X.jsx)(`span`,{children:`—`});let c=Ve(e,t,n,r);return c===void 0?(0,X.jsx)(T,{text:n&&!Be(r)?i(`Calculating…`):i(`Unknown`),children:(0,X.jsx)(`span`,{tabIndex:0,children:`—`})}):(0,X.jsx)(X.Fragment,{children:t===`size`?v(c):c.toLocaleString(a)})},We=({bucket:e})=>{let t=C();return(0,X.jsx)(X.Fragment,{children:e.rw_access?.read?e.rw_access.write?t(`Read & write`):t(`Read only`):e.rw_access?.write?t(`Write only`):t(`Unknown`)})},Ge=({enabled:e,suspended:t=!1})=>{let n=C();return(0,X.jsx)(P,{tone:t?`warning`:e?`success`:`neutral`,label:n(t?`Suspended`:e===void 0?`Unknown`:e?`Enabled`:`Disabled`)})},Ke=({at:e})=>{let t=w(),n=e?ee.fromISO(e).setLocale(c(t)):void 0;return n?.isValid?(0,X.jsx)(T,{text:n.toLocaleString(ee.DATETIME_FULL_WITH_SECONDS),children:(0,X.jsx)(`time`,{dateTime:e,tabIndex:0,children:n.toRelative()})}):(0,X.jsx)(X.Fragment,{children:`—`})},qe=({bucket:e,obOnly:t,onDelete:n})=>{let i=C(),a=r(),o=Z(e.name,t),c=encodeURIComponent(e.name),l=[...o.browse?[{label:i(`Browse`),icon:(0,X.jsx)(fe,{}),onClick:()=>a(`/browser/${c}`)}]:[],...o.settings?[{label:i(`Settings`),icon:(0,X.jsx)(b,{}),onClick:()=>a(`/buckets/${c}/admin/summary`)}]:[],...o.delete?[{label:i(`Delete bucket`),icon:(0,X.jsx)(ce,{}),danger:!0,onClick:()=>n(e.name)}]:[]];return l.length?(0,X.jsx)(`div`,{onClick:e=>e.stopPropagation(),onKeyDown:e=>e.stopPropagation(),children:(0,X.jsx)(ve,{label:s(i(`Actions for {bucket}`),{bucket:e.name}),tooltipPlacement:`left`,tooltipLabel:i(`Actions`),items:l})}):null},Je=g.div`
  ${E.body}
  min-height: 148px;
  box-sizing: border-box;
  min-width: 0;
  padding: 8px 12px 12px;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  color: var(--muted-foreground);
  font-variant-numeric: tabular-nums;
  &[data-clickable="true"] {
    cursor: pointer;
  }
  &:hover,
  &[data-selected="true"] {
    color: var(--foreground);
    background: color-mix(in srgb, var(--hover) 100%, var(--surface-3));
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }
  .cardTitle {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;
    height: 36px;
  }
  .cardTitle > svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
  }
  h2 {
    ${E.section} margin: 0;
    min-width: 0;
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  a {
    color: inherit;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
  .cardMetrics {
    /* Fixed tracks keep each metric aligned across every card. */
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) auto;
    gap: 12px;
    margin-top: 4px;
  }
  .cardMetrics > div {
    min-width: 0;
  }
  .metricLabel {
    ${E.caption} color: var(--muted-foreground);
  }
  .metricValue {
    display: block;
    color: var(--foreground);
  }
  .cardAccess {
    ${E.caption} text-align: right;
    align-self: end;
  }
`,Ye=e=>{let{bucket:t,onSelect:n,selected:i,obOnly:o}=e,c=C(),l=r(),u=Z(t.name,o),d=()=>u.browse&&l(`/browser/${encodeURIComponent(t.name)}`);return(0,X.jsxs)(Je,{className:`bucket-card`,role:`listitem`,"aria-label":t.name,"data-clickable":u.browse,"data-selected":n?i:void 0,tabIndex:u.browse?0:void 0,onClick:d,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),d())},children:[(0,X.jsxs)(`div`,{className:`cardTitle`,children:[n?(0,X.jsx)(`span`,{onClick:e=>e.stopPropagation(),children:(0,X.jsx)(x,{label:``,checked:i,disabled:!u.select,"aria-label":s(c(`Select {bucket}`),{bucket:t.name}),onChange:()=>n(t.name)})}):(0,X.jsx)(y,{"aria-hidden":`true`}),(0,X.jsx)(`h2`,{children:u.browse?(0,X.jsx)(a,{to:`/browser/${encodeURIComponent(t.name)}`,onClick:e=>e.stopPropagation(),children:t.name}):t.name}),(0,X.jsx)(qe,{...e})]}),(0,X.jsx)(Pe,{bucket:t.name}),(0,X.jsxs)(`div`,{className:`cardMetrics`,children:[(0,X.jsxs)(`div`,{children:[(0,X.jsx)(`span`,{className:`metricLabel`,children:c(`Objects`)}),(0,X.jsx)(`span`,{className:`metricValue`,children:(0,X.jsx)(Q,{...e,field:`objects`})})]}),(0,X.jsxs)(`div`,{children:[(0,X.jsx)(`span`,{className:`metricLabel`,children:c(`Current size`)}),(0,X.jsx)(`span`,{className:`metricValue`,children:(0,X.jsx)(Q,{...e,field:`size`})})]}),(0,X.jsx)(`span`,{className:`cardAccess`,children:(0,X.jsx)(We,{bucket:t})})]})]})},Xe=g.div`
  ${E.body}
  min-width: 0;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  overflow: hidden;
  font-variant-numeric: tabular-nums;
  --bucket-select-width: 28px;
  --bucket-menu-width: 36px;
  /* Font-relative, so "Retained: 9.5 MiB" fits with wider fallback fonts
     (e.g. DejaVu Sans on Linux); longer values wrap rather than clip. */
  --bucket-size-min: 15ch;
  .bucketGrid {
    display: grid;
    grid-template-columns:
      minmax(120px, 1.8fr)
      minmax(0, 0.7fr) minmax(var(--bucket-size-min), 1.1fr) minmax(0, 1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    align-items: center;
    column-gap: 8px;
    padding: 0 12px;
    box-sizing: border-box;
    height: var(--bucket-row-height, var(--control-height));
  }
  &[data-selection="true"] .bucketGrid {
    grid-template-columns:
      var(--bucket-select-width) minmax(120px, 1.8fr)
      minmax(0, 0.7fr) minmax(var(--bucket-size-min), 1.1fr) minmax(0, 1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
  }
  .bucketCell {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .bucketCell a {
    color: inherit;
    text-decoration: none;
  }
  /* Text overflow applies per line; the name and its usage caption are blocks. */
  .bucketName {
    display: block;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .bucketCell a:hover {
    text-decoration: underline;
  }
  .bucketCell a:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  .bucketNumber {
    text-align: right;
  }
  @media (min-width: 1200px) {
    .bucketNumber {
      padding-right: 12px;
    }
  }
  .bucketCheck {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .bucketMenu {
    overflow: visible;
    display: flex;
    justify-content: end;
  }
  .bucketRow {
    border-bottom: 1px solid var(--border);
    color: var(--muted-foreground);
    transition:
      color var(--dur-fast) ease,
      border-color var(--dur-fast) ease;
  }
  .bucketRow[data-fluid-activator] {
    cursor: pointer;
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[aria-selected="true"] {
    color: var(--foreground);
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[data-fluid-before] {
    border-bottom-color: transparent;
  }
  .bucketRow[aria-selected="true"] {
    background: var(--active);
  }
  .bucketRow:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  @media (max-width: 1199.98px) {
    .bucketGrid {
      grid-template-columns:
        minmax(100px, 1.6fr) minmax(0, 0.6fr) minmax(
          var(--bucket-size-min),
          1fr
        )
        minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns:
        var(--bucket-select-width) minmax(100px, 1.6fr)
        minmax(0, 0.6fr) minmax(var(--bucket-size-min), 1fr) minmax(0, 1fr)
        minmax(0, 1fr) var(--bucket-menu-width);
    }
    .bucketLow {
      display: none;
    }
  }
  @media (max-width: 767.98px) {
    .bucketGrid {
      grid-template-columns: minmax(0, 1fr) var(--bucket-size-min) var(
          --bucket-menu-width
        );
      padding: 0 8px;
      gap: 4px;
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns:
        var(--bucket-select-width) minmax(0, 1fr)
        var(--bucket-size-min) var(--bucket-menu-width);
    }
    .bucketMedium {
      display: none;
    }
  }
  @media (pointer: coarse) {
    --bucket-select-width: 40px;
    --bucket-menu-width: 40px;
  }
`,Ze=g.div`
  position: sticky;
  top: 0;
  z-index: 1;
  background: var(--surface-3);
  color: var(--foreground);
  border-bottom: 1px solid var(--border);
  /* Weight the cells, not the grid row: font-relative tracks (ch) must
     resolve against the same font as body rows to keep columns aligned. */
  & > * {
    font-weight: var(--fw-semibold);
  }
  button {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    border: 0;
    padding: 0;
    background: transparent;
    color: inherit;
    font: inherit;
    cursor: pointer;
    max-width: 100%;
  }
  @media (pointer: coarse) {
    button {
      min-height: 40px;
    }
  }
  button:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
  }
  button > svg {
    width: 12px;
    height: 12px;
    flex-shrink: 0;
    fill: currentColor;
  }
  /* A narrow column truncates its label, never the sort direction. */
  .sortLabel {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`,Qe=g.div`
  position: relative;
  isolation: isolate;
  min-height: 0;
  [data-fluid-highlight] {
    z-index: -1;
  }
`;function $e({index:e,style:t,records:n,columns:r,selected:i,common:a}){let o=n[e];return(0,X.jsx)(et,{index:e,style:t,columns:r,...a,bucket:o,selected:i.includes(o.name)},o.name)}function et({index:e,style:t,columns:n,...i}){let a=r(),{bucket:o,selected:c,onSelect:l,obOnly:u}=i,d=C(),f=Z(o.name,u),p=()=>f.browse&&a(`/browser/${encodeURIComponent(o.name)}`);return(0,X.jsxs)(`div`,{role:`row`,"aria-rowindex":e+2,"aria-label":o.name,"aria-selected":l?c:void 0,style:t,className:`bucketGrid bucketRow`,"data-fluid-index":f.browse?e:void 0,"data-fluid-key":o.name,"data-fluid-activator":f.browse?`true`:void 0,tabIndex:f.browse?0:void 0,onClick:p,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),p())},children:[l&&(0,X.jsx)(`div`,{role:`cell`,className:`bucketCheck`,onClick:e=>e.stopPropagation(),children:(0,X.jsx)(x,{label:``,"aria-label":s(d(`Select {bucket}`),{bucket:o.name}),checked:c,disabled:!f.select,onChange:()=>l(o.name)})}),n.map(e=>(0,X.jsx)(`div`,{role:`cell`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``} ${e.id===`actions`?`bucketMenu`:``}`,children:e.render(i)},e.id))]})}function tt({records:e,query:t,onSort:n,selected:r,onSelectAll:i,...o}){let s=C(),c=me(),u=(0,W.useRef)(null),d=S(u,{gapClick:!1}),f=[{id:`name`,label:s(`Name`),sort:`name`,render:({bucket:e,obOnly:t})=>(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`span`,{className:`bucketName`,title:e.name,children:Z(e.name,t).browse?(0,X.jsx)(a,{to:`/browser/${encodeURIComponent(e.name)}`,onClick:e=>e.stopPropagation(),children:e.name}):e.name}),(0,X.jsx)(Pe,{bucket:e.name})]})},{id:`objects`,label:s(`Objects`),priority:`Medium`,number:!0,sort:`objects`,render:e=>(0,X.jsx)(Q,{...e,field:`objects`})},{id:`size`,label:s(`Current size`),number:!0,sort:`size`,render:e=>(0,X.jsx)(Q,{...e,field:`size`})},{id:`versioning`,label:s(`Versioning`),priority:`Medium`,render:({bucket:e})=>(0,X.jsx)(Ge,{enabled:e.details?!!e.details.versioning:void 0,suspended:e.details?.versioningSuspended})},{id:`locking`,label:s(`Object lock`),priority:`Low`,render:({bucket:e})=>(0,X.jsx)(Ge,{enabled:e.details?!!e.details.locking:void 0})},{id:`quota`,label:s(`Quota`),priority:`Low`,number:!0,render:({bucket:e})=>(e.details?.quota?.quota||0)>0?v(e.details.quota.quota):`—`},{id:`replication`,label:s(`Replication`),priority:`Low`,render:({bucket:e})=>(0,X.jsx)(Ge,{enabled:e.details?!!e.details.replication:void 0})},{id:`access`,label:s(`Access`),priority:`Medium`,render:({bucket:e})=>(0,X.jsx)(We,{bucket:e})},{id:`created`,label:s(`Created`),priority:`Low`,sort:`created`,render:({bucket:e})=>(0,X.jsx)(Ke,{at:e.creation_date})},{id:`actions`,label:s(`Actions`),render:e=>(0,X.jsx)(qe,{...e})}],p=e.filter(e=>Z(e.name,o.obOnly).select),m={records:e,columns:f,selected:r,common:o};return(0,X.jsxs)(Xe,{role:`table`,"aria-label":s(`Buckets`),"aria-rowcount":e.length+1,"aria-colcount":f.length+ +!!o.onSelect,"data-selection":!!o.onSelect,style:{"--bucket-row-height":`${Math.max(c,64)}px`},children:[(0,X.jsxs)(Ze,{role:`row`,className:`bucketGrid`,"aria-rowindex":1,style:{"--bucket-row-height":`${c}px`},children:[o.onSelect&&(0,X.jsx)(`div`,{role:`columnheader`,className:`bucketCheck`,children:(0,X.jsx)(x,{label:``,"aria-label":s(`Select all visible buckets`),checked:p.length>0&&p.every(e=>r.includes(e.name)),disabled:!p.length,onChange:i})}),f.map(e=>(0,X.jsx)(`div`,{role:`columnheader`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``}`,"aria-sort":e.sort?t.sort===e.sort?t.dir===`asc`?`ascending`:`descending`:`none`:void 0,children:e.sort?(0,X.jsxs)(`button`,{type:`button`,"aria-label":e.label,onClick:()=>n(e.sort),children:[(0,X.jsx)(`span`,{className:`sortLabel`,children:e.label}),t.sort===e.sort&&(t.dir===`asc`?(0,X.jsx)(h,{}):(0,X.jsx)(l,{}))]}):e.id===`actions`?(0,X.jsx)(`span`,{className:`selectionHeaderLabel`,style:{position:`absolute`,clipPath:`inset(50%)`,width:1,height:1},children:e.label}):e.label},e.id))]}),(0,X.jsxs)(Qe,{ref:u,children:[(0,X.jsx)(pe,{hover:d}),e.length>100?(0,X.jsx)(U,{role:`rowgroup`,"aria-label":s(`Bucket rows`),rowCount:e.length,rowHeight:Math.max(c,64),rowComponent:$e,rowProps:m,overscanCount:6,style:{height:`min(65vh, 720px)`,minHeight:c*4}}):(0,X.jsx)(`div`,{role:`rowgroup`,style:{maxHeight:`min(65vh, 720px)`,overflowY:`auto`},children:e.map((e,t)=>(0,X.jsx)(et,{...o,columns:f,bucket:e,index:t,selected:r.includes(e.name)},e.name))})]})]})}function nt(){let e=n(),[t,r]=i(),a=Le(t),[o,s]=(0,W.useState)(a.q);return(0,W.useEffect)(()=>s(a.q),[e.key,a.q]),(0,W.useEffect)(()=>{if(o===a.q)return;let e=window.location.href,t=window.setTimeout(()=>{window.location.href===e&&r(e=>Re(e,{q:o}),{replace:!0})},150);return()=>window.clearTimeout(t)},[o,a.q,e.key,r]),{query:a,search:o,setSearch:s,sort:e=>r(t=>Re(t,{sort:e,dir:a.sort===e&&a.dir===`asc`?`desc`:`asc`,q:o})),clear:()=>{s(``),r(e=>Re(e,{q:``}))}}}var rt=F(W.lazy(()=>m(()=>import(`./BulkReplicationModal-lK-FAAc8.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54]),import.meta.url))),it=F(W.lazy(()=>m(()=>import(`./BulkLifecycleModal-Bj17hMSk.js`),__vite__mapDeps([55,1,2,3,4,5,6,7,8,9,10,11,12,56,25,37,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,31,32,33,34,35,36,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54]),import.meta.url))),at=F(W.lazy(()=>m(()=>import(`./DeleteBucket-xeaVjmsk.js`),__vite__mapDeps([57,1,2,6,7,3,4,5,22,12,43,42,44,58,41]),import.meta.url))),ot=g.h1`
  ${E.title}
  margin: 0 0 16px;
`,st=g.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 16px;
  .bucketSearch {
    min-width: 160px;
    flex: 1 1 190px;
  }
  .bucketActions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: flex-end;
    gap: 8px;
    margin-left: auto;
  }
  .bucketView {
    display: flex;
    gap: 4px;
  }
  @media (max-width: 767.98px) {
    .bucketFreshness {
      order: 3;
      flex-basis: 100%;
    }
    .bucketSearch {
      flex-basis: 100%;
    }
    .bucketActions {
      flex-basis: 100%;
      /* Touch-sized controls and longer labels can exceed a phone's width;
         wrap the primary action instead of scrolling the page sideways. */
      flex-wrap: wrap;
      justify-content: flex-start;
      gap: 8px;
    }
    .bucketView {
      margin-right: auto;
    }
    .bucketActions > #create-bucket {
      margin-left: auto;
    }
  }
`,ct=g.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  @media (max-width: 1199.98px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: 767.98px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,lt=g.div`
  ${E.caption}
  color: var(--muted-foreground);
  margin-bottom: 8px;
`,$=g.div`
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  border-radius: var(--radius-card);
  min-height: 180px;
`,ut=()=>{let e=se(),t=r(),n=C(),i=_e(),a=ae(oe),o=!!a.features?.includes(`object-browser-only`),c=I(be,[j.ADMIN_DATA_USAGE_INFO]),l=!o&&te(a.permissions),{updateListing:m}=Te(),{query:h,search:ee,setSearch:g,sort:v,clear:ce}=nt(),[b,fe]=(0,W.useState)(),[x,S]=(0,W.useState)(!0),[pe,me]=(0,W.useState)(!1),[w,he]=(0,W.useState)(0),[T,E]=(0,W.useState)([]),[O,M]=(0,W.useState)(null),[N,P]=(0,W.useState)(null),[F,L]=(0,W.useState)(()=>{try{return ze(localStorage.getItem(`silo.buckets.view`))}catch{return`table`}}),R=(0,W.useCallback)(()=>he(e=>e+1),[]);(0,W.useEffect)(()=>{e(ie(`ob_bucket_list`))},[e]),(0,W.useEffect)(()=>{let t=new AbortController;return S(!0),me(!1),_.buckets.listBuckets({signal:t.signal}).then(e=>{if(t.signal.aborted)return;if(!Array.isArray(e.data?.buckets))throw Error(n(`The bucket list could not be loaded.`));fe(e.data),m(e.data);let r=new Set(e.data.buckets.map(e=>e.name));E(e=>e.filter(e=>r.has(e)))}).catch(n=>{t.signal.aborted||(me(!0),e(ne(re(n))))}).finally(()=>{t.signal.aborted||S(!1)}),()=>t.abort()},[w,e,m,a.accountAccessKey,n]),(0,W.useEffect)(()=>{try{localStorage.setItem(`silo.buckets.view`,F)}catch{}},[F]);let z=b?.buckets||[],B=je(z.map(e=>e.name)),V=()=>{R(),B.refresh()},H=(0,W.useMemo)(()=>He(z,h,c,b?.usageUpdatedAt,B.records),[z,h.sort,h.dir,h.q,c,b?.usageUpdatedAt,B.records]),U=!o&&I(`*`,[j.S3_PUT_LIFECYCLE_CONFIGURATION,j.S3_PUT_REPLICATION_CONFIGURATION,j.S3_PUT_ACTIONS]),Ee=e=>E(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e]),G=()=>E(e=>Ue(e,H.filter(e=>Z(e.name,o).select).map(e=>e.name))),K=T.every(e=>I(e,k[D.BUCKET_LIFECYCLE],!0)),q=T.every(e=>I(e,[j.S3_PUT_REPLICATION_CONFIGURATION,j.S3_PUT_ACTIONS])),J=n(`Select one or more buckets first.`),Y=(e,t)=>T.length?e?void 0:ye(t,n(`configure the selected buckets`)):J,Oe=e=>{M(null),e&&(E([]),R())},ke={canReadUsage:c,usageUpdatedAt:b?.usageUpdatedAt,obOnly:o,onSelect:U?Ee:void 0,onDelete:P},Ae=l?(0,X.jsx)(d,{id:`empty-create-bucket`,variant:`callAction`,label:n(`Create bucket`),onClick:()=>t(A.ADD_BUCKETS)}):void 0;return(0,X.jsxs)(De,{value:B,children:[(0,X.jsx)(ge,{open:O?.type===`replication`,children:O?.type===`replication`&&(0,X.jsx)(rt,{open:!0,buckets:O.names,closeModalAndRefresh:Oe})}),(0,X.jsx)(ge,{open:O?.type===`lifecycle`,children:O?.type===`lifecycle`&&(0,X.jsx)(it,{open:!0,buckets:O.names,closeModalAndRefresh:Oe})}),(0,X.jsx)(ge,{open:N!==null,children:N!==null&&(0,X.jsx)(at,{deleteOpen:!0,selectedBucket:N,closeDeleteModalAndRefresh:e=>{P(null),e&&(E(e=>e.filter(e=>e!==N)),R())}})}),!o&&(0,X.jsx)(Se,{label:n(`Buckets`),titleElement:`h1`,help:!0}),(0,X.jsxs)(p,{children:[o&&(0,X.jsx)(ot,{children:n(`Buckets`)}),(0,X.jsxs)(st,{children:[(0,X.jsx)(`div`,{className:`bucketSearch`,children:(0,X.jsx)(xe,{id:`bucket-search`,placeholder:n(`Search buckets`),value:ee,onChange:g,sx:{width:`100%`}})}),(0,X.jsxs)(`div`,{className:`bucketActions`,children:[(0,X.jsxs)(`div`,{className:`bucketView`,role:`group`,"aria-label":n(`Bucket view`),children:[(0,X.jsx)(d,{id:`buckets-view-table`,collapseOnSmall:!1,label:n(`Table`),variant:F===`table`?`secondary`:`ghost`,"aria-pressed":F===`table`,onClick:()=>L(`table`)}),(0,X.jsx)(d,{id:`buckets-view-cards`,collapseOnSmall:!1,label:n(`Cards`),variant:F===`cards`?`secondary`:`ghost`,"aria-pressed":F===`cards`,onClick:()=>L(`cards`)})]}),(0,X.jsx)(f,{id:`refresh-buckets`,"aria-label":n(`Refresh buckets`),size:`medium`,disabled:x||B.requesting,onClick:V,children:(0,X.jsx)(u,{})}),U&&(i?(0,X.jsx)(ve,{label:n(`Actions`),items:[{label:n(`Set replication`),icon:(0,X.jsx)(le,{}),disabled:x||!T.length||!q,disabledReason:Y(q,[j.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>M({type:`replication`,names:[...T]})},{label:n(`Set lifecycle`),icon:(0,X.jsx)(ue,{}),disabled:x||!T.length||!K,disabledReason:Y(K,k[D.BUCKET_LIFECYCLE]),onClick:()=>M({type:`lifecycle`,names:[...T]})}]}):(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(d,{id:`set-replication`,collapseOnSmall:!1,label:n(`Set replication`),icon:(0,X.jsx)(le,{}),disabled:x||!T.length||!q,disabledReason:Y(q,[j.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>M({type:`replication`,names:[...T]})}),(0,X.jsx)(d,{id:`set-lifecycle`,collapseOnSmall:!1,label:n(`Set lifecycle`),icon:(0,X.jsx)(ue,{}),disabled:x||!T.length||!K,disabledReason:Y(K,k[D.BUCKET_LIFECYCLE]),onClick:()=>M({type:`lifecycle`,names:[...T]})})]})),!o&&(0,X.jsx)(d,{id:`create-bucket`,label:n(`Create bucket`),icon:(0,X.jsx)(de,{}),disabled:!l,disabledReason:l?void 0:ye([j.S3_CREATE_BUCKET],n(`create a bucket`)),onClick:()=>t(A.ADD_BUCKETS),variant:`primary`,collapseOnSmall:!1})]})]}),(0,X.jsx)(Fe,{}),T.length>0&&(0,X.jsx)(lt,{role:`status`,children:s(n(T.length===1?`1 bucket selected`:`{count} buckets selected`),{count:T.length})}),x&&!b?(0,X.jsx)($,{children:(0,X.jsx)(we,{rows:5,columns:4})}):pe&&!b?(0,X.jsx)($,{children:(0,X.jsx)(Ce,{compact:!0,icon:(0,X.jsx)(y,{}),title:n(`The bucket list could not be loaded.`),action:(0,X.jsx)(d,{id:`retry-buckets`,label:n(`Retry`),onClick:R})})}):H.length===0?(0,X.jsx)($,{children:h.q.trim()?(0,X.jsx)(Ce,{compact:!0,icon:(0,X.jsx)(y,{}),title:s(n(`No buckets match “{q}”`),{q:h.q.trim()}),action:(0,X.jsx)(d,{id:`clear-bucket-filter`,label:n(`Clear filter`),onClick:ce})}):(0,X.jsx)(Ce,{icon:(0,X.jsx)(y,{}),title:n(`No buckets yet`),description:n(`Create a bucket to start storing objects.`),action:Ae})}):F===`table`?(0,X.jsx)(tt,{...ke,records:H,query:h,onSort:v,selected:T,onSelectAll:G}):(0,X.jsx)(ct,{role:`list`,"aria-label":n(`Buckets`),children:H.map(e=>(0,X.jsx)(Ye,{...ke,bucket:e,selected:T.includes(e.name)},e.name))})]})]})};export{ut as default};