const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./BulkReplicationModal-DYZHmnRj.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./store-DyGppGmE.js","./lang-C3jwSQOV.js","./mds-CZq1--ww.js","./triangle-alert-DyB-H9L7.js","./circle-check-CtX_Laq-.js","./ReadBox-DuhyXXBR.js","./Wizard-B3h7zfG-.js","./i18n-CIW0Sd3N.js","./replicationValidation-BlWHKWdF.js","./ConsoleKBar-D8jsjzUL.js","./gauge-gONH3VyS.js","./pencil-ChBvw8ut.js","./search-CArbkwNh.js","./CircleIcon-BsXHTBH6.js","./shield-check-CSB6z6Nn.js","./chart-no-axes-column-ZcSYvKmY.js","./heart-pulse-D4u1Wzdc.js","./trash-CuCA6AjS.js","./clock-CapBYq2Q.js","./activity-ClNxkpjQ.js","./plus-AKHBTPz7.js","./users-C01FTjzb.js","./shield-yuCfQKB_.js","./archive-HWt0ACI7.js","./webhook-DHpE7XM6.js","./users-round-C_G5VQ9_.js","./layers-Cc0skkTp.js","./rotate-ccw-D5MwBoVS.js","./settings-BfFjTu5m.js","./logs-xFPevlAO.js","./info-DdVfdlVt.js","./scan-search-7X6POkaM.js","./console-vendor-I3rSB1nD.js","./listPopup-D2sWpuy2.js","./SectionTitle-DRK2Ntjc.js","./useAvailableWidth-COFYcObd.js","./ModalBox-DUgWkjn8.js","./ModalPresence-BhY37W9w.js","./index-ZSphk4pW.js","./index-BFo1l52q.css","./shared-aYSINoiF.js","./OverflowMenu-BI2FbPSH.js","./typography-AosPjJwJ.js","./permissions-Dy9Xt0P0.js","./StatusBadge-Dz68D-h4.js","./CliEquivalent-CfB1yb1t.js","./copy-PrT08m-L.js","./code-DVsjL-ty.js","./lib-BVN4wEer.js","./SecureComponent-Bbnmj6ES.js","./BulkLifecycleModal-C7CL_jRC.js","./QueryMultiSelector-JPgA4qSp.js","./DeleteBucket-BrGPG4g0.js","./ConfirmDialog-XAFudS8Q.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,d as n,f as r,h as i,r as a,t as o}from"./react-vendor-UL3KVrSx.js";import{D as s,T as c}from"./shared-vendor-BQfq49S_.js";import{Cn as l,Er as u,Tr as d,Zt as f,ir as p,n as ee,nn as te,r as ne,wn as re}from"./store-DyGppGmE.js";import{n as m}from"./lang-C3jwSQOV.js";import{F as ie,T as h,g as ae,l as g,v as oe,w as se,z as _}from"./mds-CZq1--ww.js";import{t as ce}from"./trash-CuCA6AjS.js";import{t as le}from"./boxes-BKu2zxjS.js";import{t as ue}from"./calendar-clock--hcigwiL.js";import{t as de}from"./plus-AKHBTPz7.js";import{t as v}from"./archive-HWt0ACI7.js";import{t as fe}from"./settings-BfFjTu5m.js";import{t as y}from"./folder-DXzw3QwG.js";import{t as b}from"./Checkbox-yTwnIOUe.js";import{c as x,s as pe}from"./listPopup-D2sWpuy2.js";import{t as me}from"./useTableLayout-BKaw50zS.js";import{a as S,n as C}from"./i18n-CIW0Sd3N.js";import{t as he}from"./ModalPresence-BhY37W9w.js";import{s as ge}from"./index-ZSphk4pW.js";import{n as w}from"./shared-aYSINoiF.js";import{t as _e}from"./OverflowMenu-BI2FbPSH.js";import{t as T}from"./typography-AosPjJwJ.js";import{A as ve,a as E,g as D,i as O,n as k,o as A,p as j,r as M,t as ye}from"./permissions-Dy9Xt0P0.js";import{t as N}from"./StatusBadge-Dz68D-h4.js";import{t as be}from"./SearchBox-CyZ7jB7U.js";import{t as P}from"./withSuspense-DTbtEWjP.js";import{n as F}from"./SecureComponent-Bbnmj6ES.js";import{n as I,r as L,t as R}from"./prefixUsage-08LMowT1.js";import{t as z}from"./bucketMetadata-BAg0j77c.js";import{n as B}from"./react-window-0T2cJ04-.js";import{A as xe,J as V,V as Se,f as Ce}from"./ConsoleKBar-D8jsjzUL.js";var H=e(t()),U=(0,H.createContext)(void 0),we=U.Provider,W=()=>(0,H.useContext)(U),G=e=>e.state===`queued`||e.state===`running`;function Te(e){let t=JSON.stringify(e),n=L(),r=(0,H.useRef)(),[i,a]=(0,H.useState)(0),o=(0,H.useRef)(!1),[s,c]=(0,H.useState)({requesting:!1,records:{}}),u=(0,H.useCallback)(()=>{o.current=!0,a(e=>e+1)},[]);return(0,H.useEffect)(()=>{let e=JSON.parse(t),i=new AbortController;r.current?.abort(),r.current=i;let a,s=()=>!i.signal.aborted&&n(),u=o.current;o.current=!1,c(t=>({...t,records:Object.fromEntries(Object.entries(t.records).filter(([t])=>e.includes(t)))}));let d=async()=>{c(e=>({...e,requesting:!0}));let t=[...e],n=async()=>{for(;s()&&t.length;){let e=t.shift(),n=F(e,[A.S3_LIST_BUCKET_VERSIONS]),r={bucket:e,state:`running`,versions_visible:n},a=()=>s()&&c(t=>{let i=t.records[e],a=i?.versions_visible===n&&r.state!==`forbidden`&&r.state!==`missing`;return{...t,records:{...t.records,[e]:{...r,last_good:r.last_good??(a?i?.last_good:void 0),last_completed_at:r.last_completed_at??(a?i?.last_completed_at:void 0)}}}});a();try{let t,o=await l.buckets.prefixUsage(e,{prefix:``,versions:n,folders:!1},{signal:i.signal});await I(o,{bucket:e,prefix:``,mode:n?`versions`:`current`},e=>{let i={totals:{...e.totals,...n?{}:{retained_bytes:void 0,retained_versions:void 0,delete_markers:void 0}},scanned_entries:e.scanned_entries,started_at:e.started_at,updated_at:e.updated_at};r={...r,state:e.status===`scanning`||e.status===`complete`?`running`:e.status===`failed`?`error`:e.status,progress:i},e.status===`complete`&&(t=i),a()}),t&&(r={...r,state:`complete`,last_good:t,last_completed_at:t.updated_at},a())}catch(e){let t=e instanceof Response?e.status:0;r={...r,state:t===401||t===403?`forbidden`:t===404?`missing`:`error`},a()}}};await Promise.all([n(),n()]),s()&&c(e=>({...e,requesting:!1}))},f=async t=>{if(s()){t&&c(e=>({...e,requesting:!0,error:!1}));try{let n=!1,r=2e3,o,u=[];for(let a=0;a<Math.max(e.length,1);a+=100){let s={buckets:e.slice(a,a+100)},c=t?await l.bucketUsage.bucketUsageRefresh(s,{signal:i.signal}):await l.bucketUsage.bucketUsageStatus(s,{signal:i.signal});if(n=c.data.enabled,r=c.data.poll_after_ms,o=c.data.coverage,u.push(...c.data.buckets),!n)break}if(!s())return;if(c(e=>({enabled:n,requesting:!1,records:n?Object.fromEntries(u.map(e=>[e.bucket,e])):e.enabled===!1?e.records:{},coverage:o})),!n){t&&await d();return}let p=u.some(G);a=setTimeout(()=>void f(!1),Math.min(6e4,Math.max(250,r)*(p?1:10)))}catch{s()&&(c(e=>({...e,requesting:!1,error:!0})),a=setTimeout(()=>void f(!1),1e4))}}};return f(u),()=>{i.abort(),clearTimeout(a)}},[t,i,n]),{...s,refresh:u}}var K=o();function q({bucket:e}){let t=W(),n=t?.records[e],r=S();if(!t||!n&&!t.enabled)return null;let i={not_scanned:r(`Not scanned`),queued:r(`Update queued`),running:r(`Updating usage…`),complete:r(`Updated`),error:r(`Update failed — retry with Refresh`),limited:r(`Scan limit reached — operator action required`),forbidden:r(`Usage listing not permitted`),missing:r(`Bucket no longer exists`),unavailable:r(`Usage temporarily unavailable`)};return(0,K.jsxs)(`small`,{style:{display:`block`,fontWeight:400,overflow:`hidden`,textOverflow:`ellipsis`},title:n?.last_completed_at?new Date(n.last_completed_at).toLocaleString():void 0,children:[n?i[n.state]:r(`Checking usage…`),n?.state===`running`&&n.progress?` · ${m(r(`{count} entries scanned`),{count:n.progress.scanned_entries.toLocaleString()})}`:``,n?.last_completed_at?` · ${new Date(n.last_completed_at).toLocaleTimeString()}`:``]})}function Ee(){let e=W(),t=S();if(!e)return null;let n=Object.values(e.records),r=n.filter(e=>e.state===`queued`||e.state===`running`).length,i=n.filter(e=>[`error`,`limited`,`unavailable`].includes(e.state)).length,a=e.coverage?.observer_alive&&e.coverage.connected&&e.coverage.reconciled;return(0,K.jsxs)(`div`,{role:`status`,"aria-live":`polite`,style:{marginBottom:12},children:[e.requesting?t(`Requesting usage updates…`):r?m(t(`{count} usage updates queued or running. Last completed totals remain visible.`),{count:r}):t(`Refresh requests a new metadata scan of all listed buckets.`),` `,e.error?t(`Usage status is unavailable. Retrying…`):e.enabled?t(a?`Automatic change monitoring is active.`:`Automatic change monitoring is recovering; totals may be out of date.`):e.enabled===!1?t(`Automatic updates are not configured. Refresh calculates usage while this page is open.`):t(`Checking automatic updates…`),i>0&&(0,K.jsxs)(K.Fragment,{children:[` `,m(t(`{count} updates need attention. Use Refresh to retry.`),{count:i})]})]})}var De=[`name`,`objects`,`size`,`created`],Oe=e=>({sort:De.includes(e.get(`sort`)||``)?e.get(`sort`):`name`,dir:e.get(`dir`)===`desc`?`desc`:`asc`,q:e.get(`q`)||``}),J=(e,t)=>{let n=new URLSearchParams(e),r={...Oe(e),...t};for(let e of[`sort`,`dir`,`q`])!r[e]||e===`sort`&&r.sort===`name`||e===`dir`&&r.dir===`asc`?n.delete(e):n.set(e,r[e]);return n},ke=e=>e===`cards`?`cards`:`table`,Y=e=>!!(e&&Number.isFinite(Date.parse(e))),Ae=(e,t,n,r)=>{if(!(!e||n&&!Y(r)))return!n&&e[t]===void 0?0:z(e,t,r)},je=(e,t,n,r,i)=>{let a=t.q.trim().toLocaleLowerCase(),o=e=>{if(t.sort===`name`)return e.name;if(t.sort===`created`){let t=Date.parse(e.creation_date||``);return Number.isFinite(t)?t:void 0}if(i){let n=i[e.name]?.last_good?.totals;return n?t.sort===`size`?BigInt(n.current_bytes):n.current_objects:void 0}return Ae(e,t.sort,n,r)};return e.filter(e=>e.name.toLocaleLowerCase().includes(a)).sort((e,n)=>{let r=o(e),i=o(n);return r===void 0&&i!==void 0?1:i===void 0&&r!==void 0?-1:(r===i||r===void 0||i===void 0?0:r<i?-1:1)*(t.dir===`desc`?-1:1)||e.name.localeCompare(n.name)})},Me=(e,t)=>t.length>0&&t.every(t=>e.includes(t))?e.filter(e=>!t.includes(e)):Array.from(new Set([...e,...t])),X=(e,t)=>({browse:F(e,j),settings:!t&&F(e,M[k.BUCKETS_ADMIN_VIEW]),delete:!t&&F(e,D),select:!t&&F(e,[A.S3_PUT_LIFECYCLE_CONFIGURATION,A.S3_PUT_REPLICATION_CONFIGURATION,A.S3_PUT_ACTIONS])}),Z=({bucket:e,field:t,canReadUsage:n,usageUpdatedAt:r})=>{let i=S(),a=C(),o=W(),s=(o?.records[e.name])?.last_good?.totals;if(s)return t===`objects`?(0,K.jsx)(K.Fragment,{children:s.current_objects.toLocaleString(a)}):(0,K.jsxs)(K.Fragment,{children:[(0,K.jsx)(`span`,{title:`${s.current_bytes} B`,children:R(s.current_bytes)}),s.retained_bytes!=null&&(0,K.jsxs)(`small`,{style:{display:`block`},title:`${s.retained_bytes} B`,children:[i(`Retained`),`: `,R(s.retained_bytes)]})]});if(o)return(0,K.jsx)(`span`,{children:`—`});let c=Ae(e,t,n,r);return c===void 0?(0,K.jsx)(w,{text:n&&!Y(r)?i(`Calculating…`):i(`Unknown`),children:(0,K.jsx)(`span`,{tabIndex:0,children:`—`})}):(0,K.jsx)(K.Fragment,{children:t===`size`?p(c):c.toLocaleString(a)})},Q=({bucket:e})=>{let t=S();return(0,K.jsx)(K.Fragment,{children:e.rw_access?.read?e.rw_access.write?t(`Read & write`):t(`Read only`):e.rw_access?.write?t(`Write only`):t(`Unknown`)})},$=({enabled:e,suspended:t=!1})=>{let n=S();return(0,K.jsx)(N,{tone:t?`warning`:e?`success`:`neutral`,label:n(t?`Suspended`:e===void 0?`Unknown`:e?`Enabled`:`Disabled`)})},Ne=({at:e})=>{let t=C(),n=e?s.fromISO(e).setLocale(t===`zh`?`zh-CN`:`en`):void 0;return n?.isValid?(0,K.jsx)(w,{text:n.toLocaleString(s.DATETIME_FULL_WITH_SECONDS),children:(0,K.jsx)(`time`,{dateTime:e,tabIndex:0,children:n.toRelative()})}):(0,K.jsx)(K.Fragment,{children:`—`})},Pe=({bucket:e,obOnly:t,onDelete:n})=>{let i=S(),a=r(),o=X(e.name,t),s=encodeURIComponent(e.name),c=[...o.browse?[{label:i(`Browse`),icon:(0,K.jsx)(y,{}),onClick:()=>a(`/browser/${s}`)}]:[],...o.settings?[{label:i(`Settings`),icon:(0,K.jsx)(fe,{}),onClick:()=>a(`/buckets/${s}/admin/summary`)}]:[],...o.delete?[{label:i(`Delete bucket`),icon:(0,K.jsx)(ce,{}),danger:!0,onClick:()=>n(e.name)}]:[]];return c.length?(0,K.jsx)(`div`,{onClick:e=>e.stopPropagation(),onKeyDown:e=>e.stopPropagation(),children:(0,K.jsx)(_e,{label:m(i(`Actions for {bucket}`),{bucket:e.name}),tooltipPlacement:`left`,tooltipLabel:i(`Actions`),items:c})}):null},Fe=c.div`
  ${T.body}
  min-height: 148px;
  box-sizing: border-box;
  min-width: 0;
  padding: 8px 12px 12px;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  color: var(--muted-foreground);
  font-variant-numeric: tabular-nums;
  &[data-clickable="true"] {
    cursor: pointer;
  }
  &:hover,
  &[data-selected="true"] {
    color: var(--foreground);
    background: color-mix(in srgb, var(--hover) 100%, var(--surface-3));
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }
  .cardTitle {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;
    height: 36px;
  }
  .cardTitle > svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
  }
  h2 {
    ${T.section} margin: 0;
    min-width: 0;
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  a {
    color: inherit;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
  .cardMetrics {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    margin-top: 4px;
  }
  .metricLabel {
    ${T.caption} color: var(--muted-foreground);
  }
  .metricValue {
    display: block;
    color: var(--foreground);
  }
  .cardAccess {
    ${T.caption} text-align: right;
    align-self: end;
  }
`,Ie=e=>{let{bucket:t,onSelect:n,selected:i,obOnly:o}=e,s=S(),c=r(),l=X(t.name,o),u=()=>l.browse&&c(`/browser/${encodeURIComponent(t.name)}`);return(0,K.jsxs)(Fe,{className:`bucket-card`,role:`listitem`,"aria-label":t.name,"data-clickable":l.browse,"data-selected":n?i:void 0,tabIndex:l.browse?0:void 0,onClick:u,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),u())},children:[(0,K.jsxs)(`div`,{className:`cardTitle`,children:[n?(0,K.jsx)(`span`,{onClick:e=>e.stopPropagation(),children:(0,K.jsx)(b,{label:``,checked:i,disabled:!l.select,"aria-label":m(s(`Select {bucket}`),{bucket:t.name}),onChange:()=>n(t.name)})}):(0,K.jsx)(v,{"aria-hidden":`true`}),(0,K.jsx)(`h2`,{children:l.browse?(0,K.jsx)(a,{to:`/browser/${encodeURIComponent(t.name)}`,onClick:e=>e.stopPropagation(),children:t.name}):t.name}),(0,K.jsx)(Pe,{...e})]}),(0,K.jsx)(q,{bucket:t.name}),(0,K.jsxs)(`div`,{className:`cardMetrics`,children:[(0,K.jsxs)(`div`,{children:[(0,K.jsx)(`span`,{className:`metricLabel`,children:s(`Objects`)}),(0,K.jsx)(`span`,{className:`metricValue`,children:(0,K.jsx)(Z,{...e,field:`objects`})})]}),(0,K.jsxs)(`div`,{children:[(0,K.jsx)(`span`,{className:`metricLabel`,children:s(`Current size`)}),(0,K.jsx)(`span`,{className:`metricValue`,children:(0,K.jsx)(Z,{...e,field:`size`})})]}),(0,K.jsx)(`span`,{className:`cardAccess`,children:(0,K.jsx)(Q,{bucket:t})})]})]})},Le=c.div`
  ${T.body}
  min-width: 0;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  overflow: hidden;
  font-variant-numeric: tabular-nums;
  --bucket-select-width: 28px;
  --bucket-menu-width: 36px;
  .bucketGrid {
    display: grid;
    grid-template-columns:
      minmax(120px, 1.8fr)
      minmax(0, 0.8fr) minmax(0, 0.9fr) minmax(0, 1.1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    align-items: center;
    column-gap: 8px;
    padding: 0 12px;
    box-sizing: border-box;
    height: var(--bucket-row-height, var(--control-height));
  }
  &[data-selection="true"] .bucketGrid {
    grid-template-columns:
      var(--bucket-select-width) minmax(120px, 1.8fr)
      minmax(0, 0.8fr) minmax(0, 0.9fr) minmax(0, 1.1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
  }
  .bucketCell {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .bucketCell a {
    color: inherit;
    text-decoration: none;
  }
  .bucketCell a:hover {
    text-decoration: underline;
  }
  .bucketCell a:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  .bucketNumber {
    text-align: right;
  }
  @media (min-width: 1200px) {
    .bucketNumber {
      padding-right: 12px;
    }
  }
  .bucketCheck {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .bucketMenu {
    overflow: visible;
    display: flex;
    justify-content: end;
  }
  .bucketRow {
    border-bottom: 1px solid var(--border);
    color: var(--muted-foreground);
    transition:
      color var(--dur-fast) ease,
      border-color var(--dur-fast) ease;
  }
  .bucketRow[data-fluid-activator] {
    cursor: pointer;
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[aria-selected="true"] {
    color: var(--foreground);
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[data-fluid-before] {
    border-bottom-color: transparent;
  }
  .bucketRow[aria-selected="true"] {
    background: var(--active);
  }
  .bucketRow:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  @media (max-width: 1199.98px) {
    .bucketGrid {
      grid-template-columns:
        minmax(100px, 1.6fr) minmax(0, 0.7fr) minmax(0, 0.8fr)
        minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns:
        var(--bucket-select-width) minmax(100px, 1.6fr)
        minmax(0, 0.7fr) minmax(0, 0.8fr) minmax(0, 1fr) minmax(0, 1fr) var(
          --bucket-menu-width
        );
    }
    .bucketLow {
      display: none;
    }
  }
  @media (max-width: 767.98px) {
    .bucketGrid {
      grid-template-columns: minmax(0, 1fr) 76px var(--bucket-menu-width);
      padding: 0 8px;
      gap: 4px;
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns: var(--bucket-select-width) minmax(0, 1fr) 76px var(
          --bucket-menu-width
        );
    }
    .bucketMedium {
      display: none;
    }
  }
  @media (pointer: coarse) {
    --bucket-select-width: 40px;
    --bucket-menu-width: 40px;
  }
`,Re=c.div`
  position: sticky;
  top: 0;
  z-index: 1;
  background: var(--surface-3);
  color: var(--foreground);
  font-weight: var(--fw-semibold);
  border-bottom: 1px solid var(--border);
  button {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    border: 0;
    padding: 0;
    background: transparent;
    color: inherit;
    font: inherit;
    cursor: pointer;
    max-width: 100%;
  }
  @media (pointer: coarse) {
    button {
      min-height: 40px;
    }
  }
  button:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
  }
  button > svg {
    width: 12px;
    height: 12px;
    fill: currentColor;
  }
`,ze=c.div`
  position: relative;
  isolation: isolate;
  min-height: 0;
  [data-fluid-highlight] {
    z-index: -1;
  }
`;function Be({index:e,style:t,records:n,columns:r,selected:i,common:a}){let o=n[e];return(0,K.jsx)(Ve,{index:e,style:t,columns:r,...a,bucket:o,selected:i.includes(o.name)},o.name)}function Ve({index:e,style:t,columns:n,...i}){let a=r(),{bucket:o,selected:s,onSelect:c,obOnly:l}=i,u=S(),d=X(o.name,l),f=()=>d.browse&&a(`/browser/${encodeURIComponent(o.name)}`);return(0,K.jsxs)(`div`,{role:`row`,"aria-rowindex":e+2,"aria-label":o.name,"aria-selected":c?s:void 0,style:t,className:`bucketGrid bucketRow`,"data-fluid-index":d.browse?e:void 0,"data-fluid-key":o.name,"data-fluid-activator":d.browse?`true`:void 0,tabIndex:d.browse?0:void 0,onClick:f,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),f())},children:[c&&(0,K.jsx)(`div`,{role:`cell`,className:`bucketCheck`,onClick:e=>e.stopPropagation(),children:(0,K.jsx)(b,{label:``,"aria-label":m(u(`Select {bucket}`),{bucket:o.name}),checked:s,disabled:!d.select,onChange:()=>c(o.name)})}),n.map(e=>(0,K.jsx)(`div`,{role:`cell`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``} ${e.id===`actions`?`bucketMenu`:``}`,children:e.render(i)},e.id))]})}function He({records:e,query:t,onSort:n,selected:r,onSelectAll:i,...o}){let s=S(),c=me(),l=(0,H.useRef)(null),u=x(l,{gapClick:!1}),d=[{id:`name`,label:s(`Name`),sort:`name`,render:({bucket:e,obOnly:t})=>(0,K.jsxs)(`div`,{children:[X(e.name,t).browse?(0,K.jsx)(a,{to:`/browser/${encodeURIComponent(e.name)}`,onClick:e=>e.stopPropagation(),children:e.name}):e.name,(0,K.jsx)(q,{bucket:e.name})]})},{id:`objects`,label:s(`Objects`),priority:`Medium`,number:!0,sort:`objects`,render:e=>(0,K.jsx)(Z,{...e,field:`objects`})},{id:`size`,label:s(`Current size`),number:!0,sort:`size`,render:e=>(0,K.jsx)(Z,{...e,field:`size`})},{id:`versioning`,label:s(`Versioning`),priority:`Medium`,render:({bucket:e})=>(0,K.jsx)($,{enabled:e.details?!!e.details.versioning:void 0,suspended:e.details?.versioningSuspended})},{id:`locking`,label:s(`Object lock`),priority:`Low`,render:({bucket:e})=>(0,K.jsx)($,{enabled:e.details?!!e.details.locking:void 0})},{id:`quota`,label:s(`Quota`),priority:`Low`,number:!0,render:({bucket:e})=>(e.details?.quota?.quota||0)>0?p(e.details.quota.quota):`—`},{id:`replication`,label:s(`Replication`),priority:`Low`,render:({bucket:e})=>(0,K.jsx)($,{enabled:e.details?!!e.details.replication:void 0})},{id:`access`,label:s(`Access`),priority:`Medium`,render:({bucket:e})=>(0,K.jsx)(Q,{bucket:e})},{id:`created`,label:s(`Created`),priority:`Low`,sort:`created`,render:({bucket:e})=>(0,K.jsx)(Ne,{at:e.creation_date})},{id:`actions`,label:s(`Actions`),render:e=>(0,K.jsx)(Pe,{...e})}],f=e.filter(e=>X(e.name,o.obOnly).select),ee={records:e,columns:d,selected:r,common:o};return(0,K.jsxs)(Le,{role:`table`,"aria-label":s(`Buckets`),"aria-rowcount":e.length+1,"aria-colcount":d.length+ +!!o.onSelect,"data-selection":!!o.onSelect,style:{"--bucket-row-height":`${Math.max(c,64)}px`},children:[(0,K.jsxs)(Re,{role:`row`,className:`bucketGrid`,"aria-rowindex":1,children:[o.onSelect&&(0,K.jsx)(`div`,{role:`columnheader`,className:`bucketCheck`,children:(0,K.jsx)(b,{label:``,"aria-label":s(`Select all visible buckets`),checked:f.length>0&&f.every(e=>r.includes(e.name)),disabled:!f.length,onChange:i})}),d.map(e=>(0,K.jsx)(`div`,{role:`columnheader`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``}`,"aria-sort":e.sort?t.sort===e.sort?t.dir===`asc`?`ascending`:`descending`:`none`:void 0,children:e.sort?(0,K.jsxs)(`button`,{type:`button`,"aria-label":e.label,onClick:()=>n(e.sort),children:[e.label,t.sort===e.sort&&(t.dir===`asc`?(0,K.jsx)(h,{}):(0,K.jsx)(se,{}))]}):e.id===`actions`?(0,K.jsx)(`span`,{className:`selectionHeaderLabel`,style:{position:`absolute`,clipPath:`inset(50%)`,width:1,height:1},children:e.label}):e.label},e.id))]}),(0,K.jsxs)(ze,{ref:l,children:[(0,K.jsx)(pe,{hover:u}),e.length>100?(0,K.jsx)(B,{role:`rowgroup`,"aria-label":s(`Bucket rows`),rowCount:e.length,rowHeight:Math.max(c,64),rowComponent:Be,rowProps:ee,overscanCount:6,style:{height:`min(65vh, 720px)`,minHeight:c*4}}):(0,K.jsx)(`div`,{role:`rowgroup`,style:{maxHeight:`min(65vh, 720px)`,overflowY:`auto`},children:e.map((e,t)=>(0,K.jsx)(Ve,{...o,columns:d,bucket:e,index:t,selected:r.includes(e.name)},e.name))})]})]})}function Ue(){let e=n(),[t,r]=i(),a=Oe(t),[o,s]=(0,H.useState)(a.q);return(0,H.useEffect)(()=>s(a.q),[e.key,a.q]),(0,H.useEffect)(()=>{if(o===a.q)return;let e=window.location.href,t=window.setTimeout(()=>{window.location.href===e&&r(e=>J(e,{q:o}),{replace:!0})},150);return()=>window.clearTimeout(t)},[o,a.q,e.key,r]),{query:a,search:o,setSearch:s,sort:e=>r(t=>J(t,{sort:e,dir:a.sort===e&&a.dir===`asc`?`desc`:`asc`,q:o})),clear:()=>{s(``),r(e=>J(e,{q:``}))}}}var We=P(H.lazy(()=>g(()=>import(`./BulkReplicationModal-DYZHmnRj.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54]),import.meta.url))),Ge=P(H.lazy(()=>g(()=>import(`./BulkLifecycleModal-C7CL_jRC.js`),__vite__mapDeps([55,1,2,3,4,5,6,7,8,9,10,11,12,56,25,37,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,31,32,33,34,35,36,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54]),import.meta.url))),Ke=P(H.lazy(()=>g(()=>import(`./DeleteBucket-BrGPG4g0.js`),__vite__mapDeps([57,1,2,5,3,4,6,7,22,12,43,42,44,58,41]),import.meta.url))),qe=c.h1`
  ${T.title}
  margin: 0 0 16px;
`,Je=c.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 16px;
  .bucketSearch {
    min-width: 160px;
    flex: 1 1 190px;
  }
  .bucketActions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: flex-end;
    gap: 8px;
    margin-left: auto;
  }
  .bucketView {
    display: flex;
    gap: 4px;
  }
  @media (max-width: 767.98px) {
    .bucketFreshness {
      order: 3;
      flex-basis: 100%;
    }
    .bucketSearch {
      flex-basis: 100%;
    }
    .bucketActions {
      flex-basis: 100%;
      flex-wrap: nowrap;
      justify-content: flex-start;
      gap: 8px;
    }
    .bucketView {
      margin-right: auto;
    }
  }
`,Ye=c.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  @media (max-width: 1199.98px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: 767.98px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Xe=c.div`
  ${T.caption}
  color: var(--muted-foreground);
  margin-bottom: 8px;
`,Ze=c.div`
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  border-radius: var(--radius-card);
  min-height: 180px;
`,Qe=()=>{let e=ee(),t=r(),n=S(),i=ge(),a=ne(te),o=!!a.features?.includes(`object-browser-only`),s=F(ye,[A.ADMIN_DATA_USAGE_INFO]),c=!o&&f(a.permissions),{updateListing:p}=Ce(),{query:h,search:g,setSearch:se,sort:ce,clear:fe}=Ue(),[y,b]=(0,H.useState)(),[x,pe]=(0,H.useState)(!0),[me,C]=(0,H.useState)(!1),[w,T]=(0,H.useState)(0),[D,j]=(0,H.useState)([]),[M,N]=(0,H.useState)(null),[P,I]=(0,H.useState)(null),[L,R]=(0,H.useState)(()=>{try{return ke(localStorage.getItem(`silo.buckets.view`))}catch{return`table`}}),z=(0,H.useCallback)(()=>T(e=>e+1),[]);(0,H.useEffect)(()=>{e(u(`ob_bucket_list`))},[e]),(0,H.useEffect)(()=>{let t=new AbortController;return pe(!0),C(!1),l.buckets.listBuckets({signal:t.signal}).then(e=>{if(t.signal.aborted)return;if(!Array.isArray(e.data?.buckets))throw Error(n(`The bucket list could not be loaded.`));b(e.data),p(e.data);let r=new Set(e.data.buckets.map(e=>e.name));j(e=>e.filter(e=>r.has(e)))}).catch(n=>{t.signal.aborted||(C(!0),e(d(re(n))))}).finally(()=>{t.signal.aborted||pe(!1)}),()=>t.abort()},[w,e,p,a.accountAccessKey,n]),(0,H.useEffect)(()=>{try{localStorage.setItem(`silo.buckets.view`,L)}catch{}},[L]);let B=y?.buckets||[],U=Te(B.map(e=>e.name)),W=()=>{z(),U.refresh()},G=(0,H.useMemo)(()=>je(B,h,s,y?.usageUpdatedAt,U.records),[B,h.sort,h.dir,h.q,s,y?.usageUpdatedAt,U.records]),q=!o&&F(`*`,[A.S3_PUT_LIFECYCLE_CONFIGURATION,A.S3_PUT_REPLICATION_CONFIGURATION,A.S3_PUT_ACTIONS]),De=e=>j(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e]),Oe=()=>j(e=>Me(e,G.filter(e=>X(e.name,o).select).map(e=>e.name))),J=D.every(e=>F(e,O[E.BUCKET_LIFECYCLE],!0)),Y=D.every(e=>F(e,[A.S3_PUT_REPLICATION_CONFIGURATION,A.S3_PUT_ACTIONS])),Ae=n(`Select one or more buckets first.`),Z=(e,t)=>D.length?e?void 0:ve(t,n(`configure the selected buckets`)):Ae,Q=e=>{N(null),e&&(j([]),z())},$={canReadUsage:s,usageUpdatedAt:y?.usageUpdatedAt,obOnly:o,onSelect:q?De:void 0,onDelete:I},Ne=c?(0,K.jsx)(_,{id:`empty-create-bucket`,variant:`callAction`,label:n(`Create bucket`),onClick:()=>t(k.ADD_BUCKETS)}):void 0;return(0,K.jsxs)(we,{value:U,children:[(0,K.jsx)(he,{open:M?.type===`replication`,children:M?.type===`replication`&&(0,K.jsx)(We,{open:!0,buckets:M.names,closeModalAndRefresh:Q})}),(0,K.jsx)(he,{open:M?.type===`lifecycle`,children:M?.type===`lifecycle`&&(0,K.jsx)(Ge,{open:!0,buckets:M.names,closeModalAndRefresh:Q})}),(0,K.jsx)(he,{open:P!==null,children:P!==null&&(0,K.jsx)(Ke,{deleteOpen:!0,selectedBucket:P,closeDeleteModalAndRefresh:e=>{I(null),e&&(j(e=>e.filter(e=>e!==P)),z())}})}),!o&&(0,K.jsx)(xe,{label:n(`Buckets`),titleElement:`h1`,help:!0}),(0,K.jsxs)(ae,{children:[o&&(0,K.jsx)(qe,{children:n(`Buckets`)}),(0,K.jsxs)(Je,{children:[(0,K.jsx)(`div`,{className:`bucketSearch`,children:(0,K.jsx)(be,{id:`bucket-search`,placeholder:n(`Search buckets`),value:g,onChange:se,sx:{width:`100%`}})}),(0,K.jsxs)(`div`,{className:`bucketActions`,children:[(0,K.jsxs)(`div`,{className:`bucketView`,role:`group`,"aria-label":n(`Bucket view`),children:[(0,K.jsx)(_,{id:`buckets-view-table`,collapseOnSmall:!1,label:n(`Table`),variant:L===`table`?`secondary`:`ghost`,"aria-pressed":L===`table`,onClick:()=>R(`table`)}),(0,K.jsx)(_,{id:`buckets-view-cards`,collapseOnSmall:!1,label:n(`Cards`),variant:L===`cards`?`secondary`:`ghost`,"aria-pressed":L===`cards`,onClick:()=>R(`cards`)})]}),(0,K.jsx)(oe,{id:`refresh-buckets`,"aria-label":n(`Refresh buckets`),size:`medium`,disabled:x||U.requesting,onClick:W,children:(0,K.jsx)(ie,{})}),q&&(i?(0,K.jsx)(_e,{label:n(`Actions`),items:[{label:n(`Set replication`),icon:(0,K.jsx)(le,{}),disabled:x||!D.length||!Y,disabledReason:Z(Y,[A.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>N({type:`replication`,names:[...D]})},{label:n(`Set lifecycle`),icon:(0,K.jsx)(ue,{}),disabled:x||!D.length||!J,disabledReason:Z(J,O[E.BUCKET_LIFECYCLE]),onClick:()=>N({type:`lifecycle`,names:[...D]})}]}):(0,K.jsxs)(K.Fragment,{children:[(0,K.jsx)(_,{id:`set-replication`,collapseOnSmall:!1,label:n(`Set replication`),icon:(0,K.jsx)(le,{}),disabled:x||!D.length||!Y,disabledReason:Z(Y,[A.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>N({type:`replication`,names:[...D]})}),(0,K.jsx)(_,{id:`set-lifecycle`,collapseOnSmall:!1,label:n(`Set lifecycle`),icon:(0,K.jsx)(ue,{}),disabled:x||!D.length||!J,disabledReason:Z(J,O[E.BUCKET_LIFECYCLE]),onClick:()=>N({type:`lifecycle`,names:[...D]})})]})),!o&&(0,K.jsx)(_,{id:`create-bucket`,label:n(`Create bucket`),icon:(0,K.jsx)(de,{}),disabled:!c,disabledReason:c?void 0:ve([A.S3_CREATE_BUCKET],n(`create a bucket`)),onClick:()=>t(k.ADD_BUCKETS),variant:`primary`,collapseOnSmall:!1})]})]}),(0,K.jsx)(Ee,{}),D.length>0&&(0,K.jsx)(Xe,{role:`status`,children:m(n(D.length===1?`1 bucket selected`:`{count} buckets selected`),{count:D.length})}),x&&!y?(0,K.jsx)(Ze,{children:(0,K.jsx)(Se,{rows:5,columns:4})}):me&&!y?(0,K.jsx)(Ze,{children:(0,K.jsx)(V,{compact:!0,icon:(0,K.jsx)(v,{}),title:n(`The bucket list could not be loaded.`),action:(0,K.jsx)(_,{id:`retry-buckets`,label:n(`Retry`),onClick:z})})}):G.length===0?(0,K.jsx)(Ze,{children:h.q.trim()?(0,K.jsx)(V,{compact:!0,icon:(0,K.jsx)(v,{}),title:m(n(`No buckets match “{q}”`),{q:h.q.trim()}),action:(0,K.jsx)(_,{id:`clear-bucket-filter`,label:n(`Clear filter`),onClick:fe})}):(0,K.jsx)(V,{icon:(0,K.jsx)(v,{}),title:n(`No buckets yet`),description:n(`Create a bucket to start storing objects.`),action:Ne})}):L===`table`?(0,K.jsx)(He,{...$,records:G,query:h,onSort:ce,selected:D,onSelectAll:Oe}):(0,K.jsx)(Ye,{role:`list`,"aria-label":n(`Buckets`),children:G.map(e=>(0,K.jsx)(Ie,{...$,bucket:e,selected:D.includes(e.name)},e.name))})]})]})};export{Qe as default};