import"./rolldown-runtime-BWaJ3C7D.js";import{P as e,j as t,r as n,t as r}from"./react-vendor-UL3KVrSx.js";import{i,n as a}from"./lang-deC2ggFn.js";import{R as o,T as s,Y as c,_ as l}from"./mds-BO2rKL5Q.js";import{T as u}from"./shared-vendor-BQfq49S_.js";import{D as d,T as f,bt as p,gt as m,ht as h,r as g,w as _,xt as v,yt as y,zn as b}from"./store-BGxI9kEo.js";import{t as x}from"./trash-Bfbr9RVQ.js";import{t as S}from"./download-CTASypiU.js";import{t as C}from"./upload-Dhx4N42x.js";import{t as w}from"./rotate-ccw-BHm_nXo5.js";import{t as T}from"./ModalBox-DT-uaPZI.js";import{a as E}from"./i18n-Bv0O4wSF.js";import{t as D}from"./StatusBadge-C5OEbTRh.js";import{t as O}from"./mutationTasks-BEEecJuh.js";import{et as k}from"./ConsoleKBar-DWQBCirp.js";e();var A=r(),j=u.article`
  ${c(`body`)}
  padding: 8px 0;
  border-bottom: 1px solid var(--border);
  min-width: 0;
  color: var(--foreground);
  .task-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 550;
  }
  .task-title > svg {
    width: 16px;
    height: 16px;
    flex: 0 0 16px;
    color: var(--muted-foreground);
  }
  .task-title .task-name {
    flex: 1;
    overflow-wrap: anywhere;
    min-width: 0;
  }
  .task-meta {
    ${c(`caption`)}
    color: var(--muted-foreground);
    display: flex;
    gap: 8px;
    align-items: center;
    margin: 4px 0;
    flex-wrap: wrap;
  }
  .task-progress {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 4px 0;
    font-variant-numeric: tabular-nums;
    ${c(`caption`)}
  }
  progress {
    flex: 1;
    min-width: 0;
    height: 4px;
    accent-color: var(--foreground);
  }
  p {
    margin: 4px 0;
    color: var(--muted-foreground);
    ${c(`caption`)}
    overflow-wrap: anywhere;
  }
  .task-actions {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    flex-wrap: wrap;
    margin-top: 4px;
  }
  a {
    color: var(--foreground);
    ${c(`caption`)}
    text-underline-offset: 3px;
    overflow-wrap: anywhere;
  }
  a:focus-visible,
  summary:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 3px;
  }
  details {
    margin-top: 8px;
    ${c(`caption`)}
  }
  details ul {
    padding-left: 20px;
  }
  details li {
    margin-top: 8px;
    overflow-wrap: anywhere;
  }
`,M=u(l).attrs({size:`small`})`
  --icon-size: 14px;
  color: var(--muted-foreground);
  @media (pointer: coarse) {
    width: 40px;
    height: 40px;
  }
`,N={queued:i(`Queued`),running:i(`Running`),done:i(`Completed`),failed:i(`Failed`),cancelled:i(`Cancelled`)},P={upload:i(`Upload`),download:i(`Download`),zip:i(`ZIP download`),delete:i(`Delete`),restore:i(`Restore`)},F=({objectToDisplay:e,deleteFromList:t})=>{let r=E(),i=h(e),c=v(e),l=y(e),u=e.kind??e.type,d=e.type===`upload`||e.type===`download`,f=e.browserManaged&&e.done&&!e.failed&&!e.cancelled,g=e.targets?.filter(e=>e.status===`failed`||e.status===`cancelled`)??[],_=m(e.targets??[]),T=u===`upload`?C:u===`delete`?x:u===`restore`?w:S;return(0,A.jsxs)(j,{"data-task-id":e.instanceID,"data-task-status":c,children:[(0,A.jsxs)(`div`,{className:`task-title`,children:[(0,A.jsx)(T,{}),(0,A.jsx)(`span`,{className:`task-name`,title:e.targets?void 0:e.prefix,children:e.targets?r(e.prefix):e.prefix.match(/[^/]+\/*$/)?.[0]||e.prefix}),!i&&(0,A.jsx)(M,{"aria-label":r(d?`Remove transfer`:`Remove task`),onClick:()=>t(e.instanceID),children:(0,A.jsx)(s,{})})]}),(0,A.jsxs)(`div`,{className:`task-meta`,children:[(0,A.jsx)(`span`,{children:r(P[u])}),(0,A.jsx)(D,{tone:e.failed?`danger`:`neutral`,label:r(f?`Browser handoff`:N[c])}),!i&&!e.failed&&(0,A.jsxs)(`span`,{className:`progressPercentage`,children:[e.percentage,`%`]})]}),i&&(0,A.jsxs)(`div`,{className:`task-progress`,children:[(0,A.jsx)(`progress`,{"aria-label":r(f?`Browser handoff`:`Task progress`),max:100,value:e.waitingForFile&&i?void 0:e.percentage}),(!e.waitingForFile||!i)&&(0,A.jsxs)(`span`,{className:`progressPercentage`,children:[e.percentage,`%`]}),e.waitingForFile&&i&&(0,A.jsx)(`span`,{children:r(`Waiting for data`)})]}),l.total>0&&(0,A.jsx)(`p`,{children:a(r(`{done}/{total} completed · {failed} failed · {cancelled} cancelled`),l)}),e.receivedBytes!==void 0&&(0,A.jsx)(`p`,{children:a(r(`{bytes} bytes received`),{bytes:e.receivedBytes.toLocaleString()})}),f&&(0,A.jsxs)(`p`,{children:[(0,A.jsx)(`span`,{children:r(`Track or cancel this download in your browser's download manager.`)}),` `,(0,A.jsx)(`span`,{children:r(`Handoff is complete; final download progress is unavailable here.`)})]}),e.errorMessage&&(0,A.jsx)(`p`,{role:`status`,children:d&&e.failed?`${r(`Error:`)} ${e.errorMessage}`:e.errorMessage}),e.targets?.some(e=>e.recursive||e.nonCurrent||e.allVersions)&&(0,A.jsx)(`p`,{children:r(`Counts represent selected targets. Progress within a folder or version cleanup is unavailable.`)}),e.cancelled&&e.targets&&(0,A.jsx)(`p`,{children:r(`Completed changes remain in place. In-flight requests may have reached the server; inspect before repeating them.`)}),g.length>0&&(0,A.jsxs)(`details`,{children:[(0,A.jsx)(`summary`,{children:a(r(`Review {count} results`),{count:g.length})}),(0,A.jsx)(`ul`,{children:g.map((e,t)=>(0,A.jsxs)(`li`,{children:[(0,A.jsx)(`strong`,{children:e.key}),e.versionId!==void 0&&(0,A.jsxs)(A.Fragment,{children:[` · `,e.versionId]}),(0,A.jsx)(`br`,{}),r(N[e.status]),e.error&&(0,A.jsxs)(A.Fragment,{children:[`: `,e.error]}),e.uncertain&&(0,A.jsx)(`p`,{children:r(`Server outcome is unconfirmed. Inspect this object before another operation.`)})]},t))})]}),(0,A.jsxs)(`div`,{className:`task-actions`,children:[(0,A.jsxs)(n,{to:`/browser/${encodeURIComponent(e.bucketName)}/${encodeURIComponent(p(e))}`,children:[(0,A.jsx)(`span`,{title:`${e.bucketName}/${p(e)}`,children:e.bucketName}),` · `,r(`Open bucket/prefix`)]}),i?(0,A.jsx)(o,{id:`cancel-${e.ID}`,variant:`text`,label:r(`Cancel`),"aria-label":r(d?`Cancel transfer`:`Cancel task`),icon:(0,A.jsx)(s,{}),onClick:()=>b(e.ID)}):_.length>0?(0,A.jsx)(o,{id:`retry-${e.ID}`,variant:`secondary`,label:r(`Retry failed`),onClick:()=>O(e.instanceID)}):null]})]})},I=u.section`
  border: 0;
  border-radius: 0;
  padding: 0;
  margin: 0;
  background: transparent;
  box-shadow: none;
  h3 {
    ${c(`subtitle`)}
    font-weight: 550;
    margin: 12px 0 4px;
  }
  > p {
    color: var(--muted-foreground);
  }
`,L=()=>{let e=g(),n=E(),{objectsToManage:r,managerOpen:i}=t(e=>e.objectBrowser.objectManager),a=r.filter(h),s=r.filter(e=>!h(e));return(0,A.jsxs)(T,{open:i,onClose:()=>e(f()),title:n(`Tasks`),titleIcon:(0,A.jsx)(k,{}),closeLabel:n(`Close Tasks`),customMaxWidth:440,sx:{justifyContent:`flex-end`,alignItems:`stretch`,"& .modalContainer":{width:`100%`,height:`100dvh`,maxHeight:`100dvh`,borderRadius:`16px 0 0 16px`,transform:`none`,padding:24},"& .dialogContent":{flex:1},"@media (max-width: 600px)":{"& .modalContainer":{maxWidth:`100%`,borderRadius:0,padding:20}}},children:[(0,A.jsxs)(`p`,{style:{color:`var(--muted-foreground)`,margin:`0 0 16px`,fontSize:`var(--fs-caption)`,lineHeight:`var(--lh-caption)`},children:[(0,A.jsx)(`span`,{children:n(`Downloads / Uploads`)}),` · `,n(`Object operations`)]}),(a.length>0||s.length===0)&&(0,A.jsxs)(I,{"aria-label":n(`Running`),children:[(0,A.jsxs)(`h3`,{children:[n(`Running`),` · `,a.length]}),!a.length&&(0,A.jsx)(`p`,{children:n(`No running tasks`)}),a.map(t=>(0,A.jsx)(F,{objectToDisplay:t,deleteFromList:t=>e(d(t))},t.instanceID))]}),(0,A.jsxs)(I,{"aria-label":n(`Finished`),children:[(0,A.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,gap:8},children:[(0,A.jsxs)(`h3`,{children:[n(`Finished`),` · `,s.length]}),(0,A.jsx)(o,{id:`clear-finished-tasks`,variant:`text`,label:n(`Clear finished`),disabled:!s.length,onClick:()=>e(_())})]}),!s.length&&(0,A.jsx)(`p`,{children:n(`No finished tasks`)}),s.slice().reverse().map(t=>(0,A.jsx)(F,{objectToDisplay:t,deleteFromList:t=>e(d(t))},t.instanceID))]})]})};export{L as default};