import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,t as n}from"./react-vendor-UL3KVrSx.js";import{r,t as i}from"./mds-Hm6-garf.js";import{C as a,T as o,x as s}from"./shared-vendor-BQfq49S_.js";import{t as c}from"./typography-CvHJfn8U.js";var l=e(t()),u=a`from { opacity: 0; transform: translateY(var(--popup-slide, -4px)) scaleY(.96); } to { opacity: 1; transform: none; }`,d=a`from { opacity: 1; transform: none; } to { opacity: 0; transform: translateY(var(--popup-slide, -4px)) scaleY(.96); }`;s`
  transform-origin: top;
  animation: ${u} var(--dur-fast, 80ms) var(--ease-fast, ease-out) both;
  &[data-side="top"] {
    --popup-slide: 4px;
    transform-origin: bottom;
  }
  &[data-closing="true"] {
    animation: ${d} var(--dur-fast-exit, 60ms) var(--ease-exit, ease-in) both;
    pointer-events: none;
  }
  @media (prefers-reduced-motion: reduce) {
    animation: none;
    transition: opacity var(--dur-fast, 80ms) ease;
    &[data-closing="true"] {
      animation: none;
      opacity: 0;
      transform: none;
    }
  }
`;function f(e){for(let t=e.parentElement;t&&t!==document.body;t=t.parentElement){let n=getComputedStyle(t),r=t.getBoundingClientRect(),i=e.getBoundingClientRect(),a=r.height/t.offsetHeight||1,o=r.width/t.offsetWidth||1,s=r.top+t.clientTop*a,c=r.left+t.clientLeft*o;/(auto|scroll)/.test(n.overflowY)&&t.scrollHeight>t.clientHeight&&(i.top<s?t.scrollTop+=(i.top-s)/a:i.bottom>s+t.clientHeight*a&&(t.scrollTop+=(i.bottom-s)/a-t.clientHeight)),/(auto|scroll)/.test(n.overflowX)&&t.scrollWidth>t.clientWidth&&(i.left<c?t.scrollLeft+=(i.left-c)/o:i.right>c+t.clientWidth*o&&(t.scrollLeft+=(i.right-c)/o-t.clientWidth))}}var p=n(),m=o.button`
  ${c(`body`)}
  display: flex;
  position: relative;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  gap: var(--gap, 8px);
  cursor: pointer;
  height: calc(var(--control-height, 36px) - var(--segment-pad, 4px) * 2);
  padding: 0 var(--control-padding, 12px);
  @media (pointer: coarse) { min-height: 40px; }
  border: 0;
  border-radius: var(--radius-control, 8px);
  background: transparent;
  color: var(--muted-foreground, #737373);
  &[aria-selected="true"],
  &[data-fluid-hover] {
    color: var(--foreground, #171717);
  }
  &[aria-selected="true"] {
    font-weight: var(--fw-semibold, 550);
  }
  &:disabled {
    cursor: not-allowed;
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring, #6b97ff);
    outline-offset: 1px;
  }
  svg {
    width: var(--icon-size, 16px);
    height: var(--icon-size, 16px);
  }
  .label {
    display: grid;
  }
  .label > span {
    grid-area: 1 / 1;
  }
  .measure {
    visibility: hidden;
    font-weight: var(--fw-semibold, 550);
  }
`,h=({id:e,panelId:t,index:n,tabIndex:r,onClick:i,label:a,disabled:o,icon:s,selected:c})=>(0,p.jsxs)(m,{id:e,type:`button`,role:`tab`,"aria-selected":!!c,"aria-controls":t,tabIndex:r,disabled:o,"data-fluid-index":n,"data-fluid-key":e,"data-fluid-selected":c,onClick:i,children:[s,(0,p.jsxs)(`span`,{className:`label`,children:[(0,p.jsx)(`span`,{className:`measure`,"aria-hidden":`true`,children:a}),(0,p.jsx)(`span`,{children:a})]})]}),g=(0,l.createContext)(`default`),_=e=>{let t={};for(let[n,r]of Object.entries(i[e])){let e=n.replace(/[A-Z]/g,e=>`-${e.toLowerCase()}`);t[`--${e}`]=`${r}px`}for(let[n,i]of Object.entries(r))t[`--fs-${n}`]=`${e===`compact`?i.compactSize:i.size}px`,t[`--lh-${n}`]=`${e===`compact`?i.compactLine:i.line}px`;return t};o.div`
  display: contents;
  ${({$density:e})=>_(e)}
`;var v=()=>{let e=(0,l.useContext)(g),t=e===`compact`;return{density:e,compact:t,...i[e],type:Object.fromEntries(Object.keys(r).map(e=>[e,c(e,{compact:t})]))}};function y(e,t,n=`y`){let r=null,i=1/0;for(let a=0;a<t.length;a++){let o=t[a];if(!o||o.width<=0||o.height<=0)continue;let s=e.x>=o.left&&e.x<=o.left+o.width,c=e.y>=o.top&&e.y<=o.top+o.height;if((n===`y`||s)&&(n===`x`||c))return a;let l=e.x-o.left-o.width/2,u=e.y-o.top-o.height/2,d=n===`x`?Math.abs(l):n===`y`?Math.abs(u):Math.hypot(l,u);d<i&&(r=a,i=d)}return r}var b=(e,t)=>e===t||!!e&&!!t&&e.left===t.left&&e.top===t.top&&e.width===t.width&&e.height===t.height,x={key:null,rect:null,visible:!1,session:0,travel:!1,from:null};function S(e,t){return t.type===`hide`?e.visible?{...e,visible:!1}:e:t.rect.width<=0||t.rect.height<=0||!t.fresh&&e.visible&&e.key===t.key&&b(e.rect,t.rect)?e:{key:t.key,rect:t.rect,visible:!0,session:e.session+ +!!t.fresh,travel:!t.fresh&&e.visible&&e.key!==t.key,from:t.fresh?t.from??null:null}}var C=`[data-fluid-index]`,w=`input,textarea,select,button,a[href],summary,[contenteditable],[role=button],[role=option],[role=menuitem],[role=menuitemcheckbox],[role=tab],[data-fluid-activator]`,T=e=>e.matches(`:disabled,[aria-disabled=true]`);function E(){let e=null,t={},n={hover:x,selected:x},r=new Set,i=[],a=[],o,s,c=0,l=!1,u=!1,d=null,f,p,m,h=(e,t)=>{let i=S(n[e],t);i!==n[e]&&(n={...n,[e]:i},r.forEach(e=>e()))},g=n=>{let r=n===null?void 0:i[n],a=n===null?void 0:i[n-1];m!==a&&(m?.removeAttribute(`data-fluid-before`),m=a,m?.setAttribute(`data-fluid-before`,`true`)),e?.toggleAttribute(`data-fluid-first`,n===0),f!==r&&(f?.removeAttribute(`data-fluid-hover`),f=r,p=r?.dataset.fluidKey,f?.setAttribute(`data-fluid-hover`,`true`),t.onActiveChange?.(n))},_=(e,n=!1)=>{let r=e===null?void 0:i[e],o=e===null?void 0:a[e];!r||!o||T(r)||t.disabled?(g(null),h(`hover`,{type:`hide`})):(g(e),h(`hover`,{type:`target`,key:r.dataset.fluidKey||String(e),rect:o,fresh:n,from:t.from===void 0?void 0:a[t.from]}))},v=(t,n)=>{let r=e.getBoundingClientRect(),i=r.width/e.offsetWidth||1,a=r.height/e.offsetHeight||1;return{x:(t-r.left)/i+e.scrollLeft-e.clientLeft,y:(n-r.top)/a+e.scrollTop-e.clientTop}},b=()=>{d&&!t.frozen?.()&&(_(y(v(d.x,d.y),a,t.axis),u),u=!1)},E=(n=0)=>{if(!e)return;let r=Array.from(e.querySelectorAll(C)).filter(t=>t.closest(`[data-fluid-container]`)===e);(i.length!==r.length||i.some((e,t)=>e!==r[t]))&&(o?.disconnect(),o?.observe(e),r.forEach(e=>o?.observe(e)));let s=r.map(e=>{if(T(e)||!e.offsetWidth||!e.offsetHeight)return;let t=e.getBoundingClientRect(),n=v(t.left,t.top);return{left:n.x,top:n.y,width:e.offsetWidth,height:e.offsetHeight}});if(r.length&&!s.some(Boolean)&&n<2){c=requestAnimationFrame(()=>{c=0,E(n+1)});return}i=r,a=s;let l=i.findIndex(e=>e.matches(t.selectedSelector||`[data-fluid-selected=true]`));if(l>=0&&a[l]?h(`selected`,{type:`target`,key:i[l].dataset.fluidKey||String(l),rect:a[l]}):h(`selected`,{type:`hide`}),f&&(!i.includes(f)||!a[i.indexOf(f)]||f.dataset.fluidKey!==p))_(null),d=null;else if(d)b();else if(f)_(i.indexOf(f));else if(document.activeElement instanceof HTMLElement){let e=document.activeElement.closest(C);e&&i.includes(e)&&_(i.indexOf(e))}},D=()=>{c||=requestAnimationFrame(()=>{c=0,l?(l=!1,E()):b()})},O=()=>{l=!0,D()},k=e=>{t.disabled||t.frozen?.()||(e.target instanceof Element&&e.target.closest(`[role=columnheader],[data-fluid-ignore]`)?(d=null,_(null)):(d={x:e.clientX,y:e.clientY},D()))},A=e=>{u=!0,k(e)},j=()=>{if(d=null,t.frozen?.())return;let n=document.activeElement instanceof HTMLElement?document.activeElement.closest(C):null;_(n&&e?.contains(n)?i.indexOf(n):null)},M=e=>{let t=e.target instanceof Element?e.target.closest(C):null;t&&i.includes(t)&&_(i.indexOf(t),!n.hover.visible)},N=t=>{!d&&!(t.relatedTarget instanceof Node&&e?.contains(t.relatedTarget))&&_(null)},P=()=>{d=null,u=!1},F=n=>{let r=n.target;if(!(r instanceof Element)||!r.isConnected||!e?.contains(r)||n.button||t.gapClick===!1||t.disabled||r.closest(C)||r.closest(w)||!f||T(f)||f.dataset.fluidGapClick===`false`)return;let i=f.getBoundingClientRect();Math.hypot(Math.max(i.left-n.clientX,0,n.clientX-i.right),Math.max(i.top-n.clientY,0,n.clientY-i.bottom))<=(typeof t.gapClick==`object`?t.gapClick.maxDistance:t.axis===`xy`?16:1/0)&&(f.matches(w)?f:f.querySelector(w))?.click()},I=()=>{c&&cancelAnimationFrame(c),c=0,o?.disconnect(),s?.disconnect(),e?.removeEventListener(`mousemove`,k),e?.removeEventListener(`mouseenter`,A),e?.removeEventListener(`mouseleave`,j),e?.removeEventListener(`click`,F),e?.removeEventListener(`focusin`,M),e?.removeEventListener(`focusout`,N),e?.removeEventListener(`keydown`,P,!0),e?.removeEventListener(`scroll`,O,!0),window.removeEventListener(`resize`,O),g(null),e?.removeAttribute(`data-fluid-container`),e=null,d=null,u=!0,i=[],a=[],l=!1,h(`hover`,{type:`hide`}),h(`selected`,{type:`hide`})};return{subscribe:e=>(r.add(e),()=>{r.delete(e)}),getSnapshot:()=>n,setActiveIndex:e=>{P(),l&&(l=!1,E()),_(e)},refresh:O,disconnect:I,connect:(n,r)=>{if(t=r,e!==n){if(I(),e=n,!e)return;e.setAttribute(`data-fluid-container`,`true`),o=new ResizeObserver(O),o.observe(e),s=new MutationObserver(O),s.observe(e,{childList:!0,subtree:!0,attributes:!0,attributeFilter:[`data-fluid-index`,`data-fluid-key`,`data-fluid-selected`,`disabled`,`aria-disabled`,`hidden`]}),e.addEventListener(`mousemove`,k),e.addEventListener(`mouseenter`,A),e.addEventListener(`mouseleave`,j),e.addEventListener(`click`,F),e.addEventListener(`focusin`,M),e.addEventListener(`focusout`,N),e.addEventListener(`keydown`,P,!0),e.addEventListener(`scroll`,O,!0),window.addEventListener(`resize`,O)}O()}}}function D(e,t={}){let n=(0,l.useMemo)(E,[]);return(0,l.useLayoutEffect)(()=>{n.connect(e.current,t)}),(0,l.useEffect)(()=>()=>n.disconnect(),[n]),n}var O=o.div`
  position: absolute;
  top: 0;
  left: 0;
  pointer-events: none;
  border-radius: var(--radius-control, 8px);
  background: var(--hover, rgba(0, 0, 0, 0.04));
  opacity: 0;
  transition:
    transform var(--dur-fast, 80ms) var(--ease-fast, ease-out),
    opacity var(--dur-fast, 80ms) ease;
  &[data-selected="true"] {
    background: var(--active, rgba(0, 0, 0, 0.07));
  }
  &[data-visible="false"] {
    transition-duration: var(--dur-fast, 80ms), var(--dur-fast-exit, 60ms);
  }
  @media (prefers-reduced-motion: reduce) {
    transition: opacity var(--dur-fast, 80ms) ease;
  }
`;function k({hover:e,selected:t=!1,className:n,style:r}){let i=(0,l.useSyncExternalStore)(e.subscribe,e.getSnapshot,e.getSnapshot)[t?`selected`:`hover`],a=(0,l.useRef)(null),o=(0,l.useRef)(-1);return(0,l.useLayoutEffect)(()=>{let e=a.current;if(!e||!i.rect)return;let n=`translate(${i.rect.left}px, ${i.rect.top}px)`,r=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches,s=o.current!==i.session;o.current=i.session;let c=!r&&(i.travel||s&&!!i.from),l=i.visible?`var(--dur-fast, 80ms)`:`var(--dur-fast-exit, 60ms)`;e.style.transitionProperty=c?`transform, opacity`:`opacity`,e.style.transitionDuration=c?`${t?`var(--dur-moderate, 160ms)`:`var(--dur-fast, 80ms)`}, ${l}`:l,e.style.transitionTimingFunction=c?`${t?`var(--ease-moderate, ease-out)`:`var(--ease-fast, ease-out)`}, ease`:`ease`,e.style.transform=n,s&&i.visible&&(e.style.opacity=`0`,i.from&&!r&&(e.style.transform=`translate(${i.from.left}px, ${i.from.top}px)`),e.getBoundingClientRect(),e.style.transform=n),e.style.opacity=i.visible?`1`:`0`},[i,t]),i.rect?(0,p.jsx)(O,{ref:a,"aria-hidden":`true`,"data-fluid-highlight":t?`selected`:`hover`,"data-selected":t,"data-visible":i.visible,className:n,style:{width:i.rect.width,height:i.rect.height,...r}}):null}var A=o.div`
  display: flex;
  flex-direction: ${({$horizontal:e})=>e?`column`:`row`};
  height: 100%;
  min-width: 0;
  .optionsContainer {
    display: flex;
    align-items: ${({$horizontal:e})=>e?`center`:`flex-start`};
    max-height: 100%;
    gap: var(--gap, 8px);
    min-width: 0;
    overflow: auto;
  }
  .optionsList {
    position: relative;
    isolation: isolate;
    display: flex;
    flex-direction: ${({$horizontal:e})=>e?`row`:`column`};
    width: ${({$horizontal:e})=>e?`max-content`:`220px`};
    max-width: 100%;
    max-height: 100%;
    overflow: auto;
    flex-shrink: 0;
    padding: var(--segment-pad, 4px);
    border-radius: var(--radius-control, 8px);
    background: var(--muted, #f4f4f5);
  }
  .optionsList:not(.subtle) [role="tab"] {
    color: var(--foreground, #171717);
  }
  [aria-orientation="vertical"] [role="tab"] {
    justify-content: flex-start;
    text-align: left;
    min-height: var(--control-height, 36px);
  }
  [aria-orientation="vertical"] [role="tab"] > svg {
    flex-shrink: 0;
  }
  [data-fluid-highlight] {
    z-index: -1;
  }
  [data-selected="true"] {
    background: var(--surface-3, white);
    box-shadow: var(--shadow-2);
  }
  .subtle {
    background: transparent;
    box-shadow: none;
    padding: 4px;
  }
  .subtle [data-selected="true"] {
    background: transparent;
    border-radius: 0;
    box-shadow: inset 0 -2px 0 var(--foreground);
  }
  .tabsPanels {
    min-width: 0;
    flex: 1;
    width: 100%;
    padding: 16px;
  }
  ${({$sx:e})=>e}
`,j=({horizontal:e,options:t,currentTabOrPath:n,useRouteTabs:r=!1,routes:i,onTabClick:a,optionsInitialComponent:o,optionsEndComponent:s,sx:c,variant:u=`segmented`})=>{let d=(0,l.useId)(),m=(0,l.useRef)(null),{compact:g}=v(),_=D(m,{axis:e?`x`:`y`,gapClick:{maxDistance:16}}),y=e=>(r?t[e].tabConfig.to:t[e].tabConfig.id)===n,b=t.findIndex((e,t)=>y(t)),x=t.findIndex(e=>!e.tabConfig.disabled),S=b>=0&&!t[b].tabConfig.disabled?b:x,[C,w]=(0,l.useState)(t[S]?.tabConfig.id);(0,l.useEffect)(()=>{let e=t.find(e=>(r?e.tabConfig.to:e.tabConfig.id)===n);e&&w(e.tabConfig.id)},[n,r]);let T=t.findIndex(e=>e.tabConfig.id===C&&!e.tabConfig.disabled),E=T>=0?T:S;return(0,l.useEffect)(()=>{let e=m.current;if(!e)return;let t=()=>{let t=e.querySelector(`[role="tab"]:focus:not(:disabled)`)??e.querySelector(`[aria-selected="true"]`);t&&f(t)},n=new ResizeObserver(t);return n.observe(e),t(),()=>n.disconnect()},[b,e]),(0,p.jsxs)(A,{$horizontal:!!e,className:`tabs-container`,$sx:c,style:{"--segment-pad":g?`2px`:`4px`},children:[(0,p.jsxs)(`div`,{className:`optionsContainer`,children:[o,(0,p.jsxs)(`div`,{ref:m,role:`tablist`,"aria-orientation":e?`horizontal`:`vertical`,className:`optionsList ${u===`subtle`?`subtle`:``}`,onKeyDown:n=>{let r=e?`ArrowRight`:`ArrowDown`;if(![r,e?`ArrowLeft`:`ArrowUp`,`Home`,`End`].includes(n.key))return;let i=Array.from(m.current?.querySelectorAll(`[role="tab"]:not(:disabled)`)||[]),a=i.indexOf(document.activeElement);if(a<0)return;n.preventDefault(),n.stopPropagation();let o=n.key===`Home`?0:n.key===`End`?i.length-1:(a+(n.key===r?1:-1)+i.length)%i.length;i[o]?.focus({preventScroll:!0});let s=i[o];s&&(w(t.find(e=>`${d}-${e.tabConfig.id}`===s.id)?.tabConfig.id),f(s))},children:[(0,p.jsx)(k,{hover:_,selected:!0}),(0,p.jsx)(k,{hover:_}),t.map((t,n)=>(0,p.jsx)(h,{id:`${d}-${t.tabConfig.id}`,panelId:r?`${d}-route-panel`:`${d}-${t.tabConfig.id}-panel`,index:n,tabIndex:n===E?0:-1,onClick:()=>{w(t.tabConfig.id),a(r?t.tabConfig.to||``:t.tabConfig.id)},horizontal:!!e,label:t.tabConfig.label,disabled:!!t.tabConfig.disabled,icon:t.tabConfig.icon,selected:y(n)},t.tabConfig.id))]}),s]}),(0,p.jsx)(`div`,{className:`tabsPanels`,children:r?(0,p.jsx)(`div`,{role:`tabpanel`,id:`${d}-route-panel`,"aria-labelledby":b>=0?`${d}-${t[b].tabConfig.id}`:void 0,children:i}):t.map((e,t)=>(0,p.jsx)(`div`,{role:`tabpanel`,id:`${d}-${e.tabConfig.id}-panel`,"aria-labelledby":`${d}-${e.tabConfig.id}`,hidden:!y(t),tabIndex:0,children:y(t)?e.content:null},e.tabConfig.id))})]})};export{j as default};