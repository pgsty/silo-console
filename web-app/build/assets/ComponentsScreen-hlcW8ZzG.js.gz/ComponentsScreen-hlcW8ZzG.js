const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./FluidHoverShowcase-D9gKy4xz.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./mds-YaKHoCCJ.js","./DataTable-By4apyvg.js","./circle-slash-D9vEtOj8.js","./hard-drive-0vZvUa8O.js","./share-2-YEmz1E96.js","./pencil-C5sHQui2.js","./shield-check-BL08EFCo.js","./trash-D6JXtEqL.js","./circle-check-PKb6fSYx.js","./download-BaVlgZxL.js","./terminal-Cm4kNKzd.js","./Checkbox-FHttryja.js","./console-vendor-I3rSB1nD.js","./listPopup-D2sWpuy2.js","./useTableLayout-uQiMFybd.js","./Tabs-Cx_lZDzy.js","./i18n-CkC2HRew.js","./lang-BxJGrDHW.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,r as n,t as r}from"./react-vendor-UL3KVrSx.js";import{T as i}from"./shared-vendor-BQfq49S_.js";import{Dr as a,n as o}from"./store-u0LCkSUK.js";import{i as s,n as c}from"./lang-BxJGrDHW.js";import{$ as l,B as u,F as d,J as f,K as p,R as m,X as h,Y as g,a as _,g as v,i as y,l as b,o as x,q as ee,s as S,u as C,v as w,z as T}from"./mds-YaKHoCCJ.js";import{t as E}from"./database-ByY28mw_.js";import{t as te}from"./pencil-C5sHQui2.js";import{t as D}from"./trash-D6JXtEqL.js";import{t as O}from"./archive-swEOSDZm.js";import{t as ne}from"./info-CNve3BGk.js";import{t as k}from"./Checkbox-FHttryja.js";import{n as A,t as re}from"./HelpBox-CL8k1S8m.js";import{t as ie}from"./SectionTitle-jlaicNvQ.js";import{t as j}from"./ModalBox-B1Mqh9LH.js";import{t as M}from"./CommentBox-I-CdL0cw.js";import{t as N}from"./Autocomplete-CpvwQhoD.js";import{a as P,t as ae}from"./i18n-CkC2HRew.js";import{i as oe,n as se,r as ce,t as F}from"./index-BCJkkRQw.js";import{t as le}from"./OverflowMenu-D1aICRMe.js";import{t as I}from"./typography-DxndMn2P.js";import{t as L}from"./StatusBadge-QSmH-cfD.js";import{t as ue}from"./CliEquivalent-BKW-DUIf.js";import{t as de}from"./ConfirmDialog-CEeXK5RZ.js";import{A as fe,H as pe,J as R,K as z,U as B,V as me,W as V,X as he,Y as H,Z as U,q as ge}from"./ConsoleKBar-CIf1MkWB.js";var W=e(t()),G=r(),K=i.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 280px), 1fr));
  gap: var(--space-16);
`,q=i.div`
  padding: var(--space-20);
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  color: var(--foreground);
  min-width: 0;
  h2 {
    ${h(`title`)} margin: 0 0 var(--space-16);
  }
`,_e=i.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--space-8);
`,ve=i.div`
  ${h(`caption`)}
  padding: var(--space-12) var(--space-4);
  text-align: center;
  border-radius: var(--radius-control);
  box-shadow: var(--shadow-1);
  background: ${({$color:e})=>e};
`,ye=i.div`
  ${({$role:e})=>h(e)}
  padding: var(--space-8) 0;
  & + & {
    border-top: 1px solid var(--border);
  }
`,be=i.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--space-24);
  padding: var(--space-16) 0;
`,xe=i(p)`
  ${h(`caption`)}
  padding: var(--space-16) var(--space-4);
  border-radius: var(--radius-control);
  text-align: center;
`,Se=i.div`
  ${({$roleStyle:e})=>e}
  display: flex;
  align-items: center;
  height: var(--control-height);
  padding: 0 var(--control-padding);
  gap: var(--gap);
  border-radius: var(--radius-control);
  background: var(--hover);
  svg {
    width: var(--icon-size);
    height: var(--icon-size);
    color: var(--muted-foreground);
  }
`,J=()=>{let{compact:e,type:t,controlHeight:n}=g(),r=P();return(0,G.jsx)(`div`,{children:(0,G.jsxs)(Se,{$roleStyle:t.body,children:[(0,G.jsx)(O,{}),(0,G.jsx)(`span`,{children:r(e?`Compact density`:`Default density`)}),(0,G.jsx)(`span`,{className:`silo-num`,children:c(r(`{height} px`),{height:n})})]})})},Ce=i.div`
  margin-top: var(--space-12);
  padding: var(--space-4);
  border-radius: var(--radius-control);
  background: var(--muted);
`,we=i.div`
  width: 28px;
  height: 28px;
  border-radius: var(--radius-control);
  background: var(--foreground);
  transform: translateX(${({$moved:e})=>e?`140px`:`0`});
  opacity: ${({$moved:e})=>e?.6:1};
  transition:
    transform var(--dur-${({$tier:e})=>e})
      var(--ease-${({$tier:e})=>e}),
    opacity var(--dur-${({$tier:e})=>e})
      var(--ease-${({$tier:e})=>e});
  @media (prefers-reduced-motion: reduce) {
    transform: none;
  }
`,Te=i.button`
  ${h(`body`,{weight:`semibold`})}
  padding: var(--space-8) var(--space-12);
  border: none;
  border-radius: var(--radius-control);
  color: var(--foreground);
  background: var(--tint);
  cursor: pointer;
  &:hover {
    background: var(--tint-hover);
  }
`,Y=({tier:e,label:t})=>{let[n,r]=(0,W.useState)(!1),i=P();return(0,G.jsxs)(`div`,{children:[(0,G.jsx)(Te,{type:`button`,"aria-pressed":n,onClick:()=>r(!n),children:i(t)}),(0,G.jsx)(Ce,{children:(0,G.jsx)(we,{"data-motion-tier":e,$tier:e,$moved:n})})]})},Ee={display:s(`Display type`),title:s(`Title type`),subtitle:s(`Subtitle type`),body:s(`Body type`),caption:s(`Caption type`),micro:s(`Micro type`)},De=()=>{let e=P();return(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(K,{children:[`light`,`dark`].map(t=>(0,G.jsxs)(q,{style:oe(t===`light`?ce:se),children:[(0,G.jsx)(`h2`,{children:e(t===`light`?`Light palette`:`Dark palette`)}),(0,G.jsx)(_e,{children:Array.from({length:8},(t,n)=>(0,G.jsx)(ve,{$color:`var(--surface-${n+1})`,children:c(e(`Surface {level}`),{level:n+1})},n))}),(0,G.jsx)(`p`,{style:{marginTop:`var(--space-12)`,color:`var(--foreground)`},children:e(`Primary text`)}),(0,G.jsx)(`p`,{style:{color:`var(--muted-foreground)`},children:e(`Secondary text`)})]},t))}),(0,G.jsxs)(K,{children:[(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Typography roles`)}),Object.keys(l).map(t=>(0,G.jsxs)(ye,{$role:t,children:[e(Ee[t]),` `,(0,G.jsxs)(`span`,{className:`silo-num`,children:[l[t].size,`/`,l[t].line]})]},t))]}),(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Shadow ladder`)}),(0,G.jsx)(be,{children:Array.from({length:8},(e,t)=>(0,G.jsx)(xe,{offset:t,shadowLevel:t+1,children:t+1},t))}),(0,G.jsx)(`h2`,{children:e(`Density comparison`)}),(0,G.jsx)(f,{children:(0,G.jsx)(J,{})}),(0,G.jsx)(`div`,{style:{height:`var(--space-8)`}}),(0,G.jsx)(f,{density:`compact`,children:(0,G.jsx)(J,{})})]})]}),(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Motion tiers`)}),(0,G.jsxs)(K,{children:[(0,G.jsx)(Y,{tier:`fast`,label:s(`Fast · 80 ms`)}),(0,G.jsx)(Y,{tier:`moderate`,label:s(`Moderate · 160 ms`)}),(0,G.jsx)(Y,{tier:`slow`,label:s(`Slow · 240 ms`)})]})]})]})},Oe=i.section`
  display: grid;
  gap: 16px;
  padding: 24px;
  border-radius: 12px;
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  h2 {
    ${h(`title`)} margin: 0;
  }
  h3 {
    ${h(`subtitle`)} margin: 0;
  }
  .control-row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 12px;
  }
  .control-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 16px;
  }
  .inputItem {
    min-width: 0;
  }
  .inputLabel {
    margin-right: 8px;
  }
  .inputLabel > span {
    min-width: 0;
  }
`,ke=()=>{let e=P(),[t,n]=(0,W.useState)(!0),[r,i]=(0,W.useState)(`one`),[a,o]=(0,W.useState)(`one`),[s,c]=(0,W.useState)(null),[l,p]=(0,W.useState)(!1),[m,h]=(0,W.useState)(!1),[g,v]=(0,W.useState)(!1),b=[{label:e(`Default`),value:`one`},{label:e(`Compact`),value:`two`}];return(0,G.jsx)(ee,{level:3,children:(0,G.jsxs)(Oe,{id:`control-craft`,children:[(0,G.jsx)(`h2`,{children:e(`Control craft`)}),(0,G.jsx)(`p`,{children:e(`Hover, press or use Tab to inspect each control. All changes here are local demos.`)}),(0,G.jsx)(`h3`,{children:e(`Buttons and loading`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(T,{id:`press-80`,variant:`primary`,sx:{width:80},label:e(`Save`)}),(0,G.jsx)(T,{id:`press-400`,variant:`primary`,sx:{width:400,maxWidth:`100%`},label:e(`Create bucket`)}),(0,G.jsx)(T,{id:`control-secondary`,variant:`secondary`,label:e(`Secondary`)}),(0,G.jsx)(T,{id:`control-outline`,variant:`outline`,label:e(`Outline`)}),(0,G.jsx)(T,{id:`control-ghost`,variant:`ghost`,label:e(`Ghost`)}),(0,G.jsx)(T,{id:`control-danger`,variant:`danger`,label:e(`Delete`)}),(0,G.jsx)(T,{id:`control-disabled`,disabled:!0,disabledReason:e(`Select an object to download.`),label:e(`Disabled`)}),(0,G.jsx)(T,{id:`control-loading`,loading:!0,label:e(`Loading`)}),(0,G.jsx)(T,{id:`control-toggle-loading`,loading:g,label:e(`Save changes`),onClick:()=>{v(!0),setTimeout(()=>v(!1),1500)}}),(0,G.jsx)(w,{"aria-label":e(`Refresh`),children:(0,G.jsx)(d,{})})]}),(0,G.jsxs)(f,{density:`compact`,children:[(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(T,{id:`control-compact`,variant:`primary`,label:e(`Compact`)}),(0,G.jsx)(C,{id:`control-compact-input`,label:e(`Compact`),placeholder:e(`Name`)})]}),(0,G.jsx)(`div`,{id:`control-compact-help`,children:(0,G.jsx)(re,{iconComponent:(0,G.jsx)(ne,{}),title:e(`Compact`),help:e(`Usage is calculated by the server.`)})})]}),(0,G.jsx)(`h3`,{children:e(`Fields and validation`)}),(0,G.jsxs)(`div`,{className:`control-grid`,children:[(0,G.jsx)(C,{id:`control-input`,label:e(`Name`),placeholder:e(`Name`)}),(0,G.jsx)(C,{id:`control-password`,type:`password`,label:e(`Password`),defaultValue:`example`}),(0,G.jsx)(C,{id:`control-error`,label:e(`Name`),error:e(`A name is required.`)}),(0,G.jsx)(C,{id:`control-disabled-input`,label:e(`Disabled`),disabled:!0,value:e(`Unavailable`)}),(0,G.jsx)(C,{id:`control-disabled-empty`,label:e(`Disabled`),disabled:!0,placeholder:e(`Name`)}),(0,G.jsx)(C,{id:`control-number`,type:`number`,label:e(`Capacity`),defaultValue:20}),(0,G.jsx)(S,{id:`control-select`,label:e(`Density`),value:a,options:b,onChange:o}),(0,G.jsx)(S,{id:`control-disabled-select`,label:e(`Disabled`),value:`one`,options:b,onChange:()=>{},disabled:!0}),(0,G.jsx)(S,{id:`control-error-select`,label:e(`Density`),options:b,onChange:()=>{},error:e(`A name is required.`),placeholder:e(`Select`)}),(0,G.jsx)(S,{id:`control-disabled-placeholder`,label:e(`Disabled`),options:b,onChange:()=>{},disabled:!0,placeholder:e(`Select`)}),(0,G.jsx)(N,{id:`control-autocomplete`,label:e(`Search`),placeholder:e(`Select`),value:a,options:b,onChange:o}),(0,G.jsx)(N,{id:`control-error-autocomplete`,label:e(`Search`),placeholder:e(`Select`),options:b,onChange:()=>{},error:e(`A name is required.`)}),(0,G.jsx)(N,{id:`control-disabled-autocomplete`,label:e(`Disabled`),placeholder:e(`Select`),options:b,onChange:()=>{},disabled:!0}),(0,G.jsx)(M,{id:`control-disabled-textarea`,label:e(`Disabled`),disabled:!0,placeholder:e(`Description`)}),(0,G.jsx)(M,{id:`control-textarea`,label:e(`Description`),placeholder:e(`Description`)})]}),(0,G.jsx)(`h3`,{children:e(`Selection controls`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(k,{id:`control-checkbox`,label:e(`Enabled`),checked:t,onChange:e=>n(e.target.checked)}),(0,G.jsx)(k,{id:`control-disabled-checkbox`,label:e(`Disabled`),disabled:!0,checked:!0,readOnly:!0}),(0,G.jsx)(U,{id:`control-switch`,label:e(`Enabled`),checked:t,onChange:e=>n(e.target.checked)}),(0,G.jsx)(U,{id:`control-disabled-switch`,label:e(`Disabled`),checked:!0,disabled:!0}),(0,G.jsx)(he,{id:`control-radio`,name:`control-radio`,label:e(`Density`),currentValue:r,selectorOptions:b,onChange:e=>i(e.target.value)})]}),(0,G.jsx)(`h3`,{children:e(`Status and feedback`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(x,{id:`control-tag`,label:e(`Enabled`),color:`ok`}),(0,G.jsx)(x,{id:`control-tag-dot`,label:e(`Warning`),color:`warn`,variant:`dot`}),(0,G.jsx)(L,{tone:`danger`,label:e(`Offline`)}),(0,G.jsx)(L,{tone:`info`,label:e(`Built-in`),dot:!1}),(0,G.jsx)(u,{tooltip:e(`First tooltip`),children:(0,G.jsx)(T,{id:`control-tip-one`,label:e(`First tooltip`)})}),(0,G.jsx)(u,{tooltip:e(`Second tooltip`),children:(0,G.jsx)(T,{id:`control-tip-two`,label:e(`Second tooltip`)})})]}),(0,G.jsx)(A,{title:e(`Information`),tone:`info`,children:e(`Usage is calculated by the server.`)}),(0,G.jsx)(A,{title:e(`Warning`),tone:`warning`,contrast:`high`,children:e(`Above the 85% warning threshold`)}),(0,G.jsx)(_,{value:65,variant:`determinate`,progressLabel:!0,notificationLabel:e(`Progress`)}),(0,G.jsx)(_,{notificationLabel:e(`Loading`)}),(0,G.jsx)(`h3`,{children:e(`Dialogs`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[[`sm`,`lg`,`xl`].map(t=>(0,G.jsx)(T,{id:`control-dialog-${t}`,label:`${e(`Open Dialog`)} · ${t===`sm`?`400`:t===`lg`?`540`:`880`}`,onClick:()=>c(t)},t)),(0,G.jsx)(T,{id:`control-snackbar`,label:e(`Show notification`),onClick:()=>h(!0)})]}),(0,G.jsxs)(j,{open:s!==null,size:s||`lg`,title:e(`Dialog controls`),onClose:()=>c(null),children:[(0,G.jsxs)(`div`,{className:`control-grid`,style:{display:`grid`,gap:16},children:[(0,G.jsx)(C,{id:`dialog-name`,label:e(`Name`)}),(0,G.jsx)(S,{id:`dialog-select`,label:e(`Density`),value:a,options:b,onChange:o})]}),(0,G.jsxs)(`div`,{className:`control-row`,style:{display:`flex`,flexWrap:`wrap`,gap:8,justifyContent:`flex-end`,marginTop:24},children:[(0,G.jsx)(T,{id:`control-nested-open`,label:e(`Nested dialog`),onClick:()=>p(!0)}),(0,G.jsx)(T,{id:`control-dialog-cancel`,label:e(`Cancel`),onClick:()=>c(null)}),(0,G.jsx)(T,{id:`control-dialog-save`,variant:`primary`,label:e(`Save`),onClick:()=>c(null)})]}),(0,G.jsx)(j,{open:l,size:`sm`,title:e(`Nested dialog`),onClose:()=>p(!1),children:(0,G.jsx)(T,{id:`control-nested-close`,variant:`primary`,label:e(`Close`),onClick:()=>p(!1)})})]}),(0,G.jsx)(y,{open:m,onClose:()=>h(!1),message:e(`Demo action completed.`),closeButton:!0})]})})},Ae=(0,W.lazy)(()=>b(()=>import(`./FluidHoverShowcase-D9gKy4xz.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]),import.meta.url)),X=i.div`
  color: var(--silo-text);
  display: grid;
  gap: var(--silo-space-24);
  margin-bottom: var(--silo-space-32);
  h1 {
    ${I.title} margin: 0 0 var(--silo-space-8);
  }
  h2 {
    ${I.section} margin: 0 0 var(--silo-space-16);
  }
  p {
    ${I.body} color: var(--silo-text-secondary);
    margin: 0;
  }
  a {
    color: var(--silo-primary);
  }
  #root & button.button-regular,
  #root & button.button-callAction {
    border-radius: var(--silo-radius-button);
    letter-spacing: normal;
  }
`,je=i.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--silo-space-16);
  @media (max-width: ${F.lg-1}px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: ${F.md-1}px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Z=i.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--silo-space-16);
  @media (max-width: ${F.md-1}px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Q=i.div`
  min-width: 0;
  padding: var(--silo-space-20);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  border-radius: var(--silo-radius-card);
`,$=i.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--silo-space-12);
  & + & {
    margin-top: var(--silo-space-16);
  }
`,Me=i.span`
  ${I.small}
  display: inline-flex;
  align-items: center;
  padding: var(--silo-space-8) var(--silo-space-12);
  border: 1px dashed var(--silo-border-strong);
  border-radius: var(--silo-radius-input);
  color: var(--silo-text-muted);
`,Ne=()=>{let[e,t]=(0,W.useState)(!1),[r,i]=(0,W.useState)(!0),[c,l]=(0,W.useState)(``),[u]=(0,W.useState)(()=>new Date(Date.now()-18e4).toISOString()),f=o(),p=P();return(0,W.useEffect)(()=>{f(a(`components`))},[]),(0,G.jsxs)(W.Fragment,{children:[(0,G.jsx)(fe,{label:s(`Components`),help:!0}),(0,G.jsxs)(v,{sx:{padding:24,[`@media (max-width: ${F.lg-1}px)`]:{padding:16},[`@media (max-width: ${F.md-1}px)`]:{padding:12}},children:[(0,G.jsxs)(X,{children:[(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h1`,{children:p(`SILO primitives`)}),(0,G.jsx)(`p`,{children:p(`Shared building blocks for storage, identity and monitoring.`)})]}),(0,G.jsx)(ke,{}),(0,G.jsx)(De,{}),(0,G.jsx)(W.Suspense,{fallback:null,children:(0,G.jsx)(Ae,{})}),(0,G.jsxs)(je,{children:[(0,G.jsx)(V,{label:p(`Capacity`),icon:(0,G.jsx)(E,{}),value:`7.2`,unit:`TiB`,subline:p(`Healthy capacity`),progress:{value:.72},footer:(0,G.jsx)(z,{at:u,prefix:`Calculated`})}),(0,G.jsx)(V,{label:p(`Capacity warning`),icon:(0,G.jsx)(E,{}),value:`8.7`,unit:`TiB`,subline:p(`Above the 85% warning threshold`),progress:{value:.87}}),(0,G.jsx)(V,{label:p(`Capacity critical`),icon:(0,G.jsx)(E,{}),value:`9.6`,unit:`TiB`,subline:p(`Above the 95% critical threshold`),progress:{value:.96}}),(0,G.jsx)(V,{label:p(`Buckets`),icon:(0,G.jsx)(O,{}),value:`28`,subline:p(`Usage is calculated by the server.`),footer:(0,G.jsx)(n,{to:`/buckets`,children:p(`View buckets`)})})]}),(0,G.jsxs)(Z,{children:[(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:p(`Status and values`)}),(0,G.jsxs)($,{children:[(0,G.jsx)(L,{tone:`success`,label:p(`Online`)}),(0,G.jsx)(L,{tone:`warning`,label:p(`Healing`)}),(0,G.jsx)(L,{tone:`danger`,label:p(`Offline`)}),(0,G.jsx)(L,{tone:`neutral`,label:p(`Disabled`)}),(0,G.jsx)(L,{tone:`info`,label:p(`Built-in`),dot:!1})]}),(0,G.jsxs)($,{children:[(0,G.jsx)(H,{label:p(`Versioning`),value:(0,G.jsx)(L,{tone:r?`success`:`neutral`,label:p(r?`Enabled`:`Disabled`)}),onEdit:()=>i(e=>!e)}),(0,G.jsx)(H,{label:p(`Objects`),value:(0,G.jsx)(`span`,{className:`silo-num`,children:`1,248`})})]})]}),(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:p(`Freshness and actions`)}),(0,G.jsxs)($,{children:[(0,G.jsx)(z,{at:u}),(0,G.jsx)(z,{}),(0,G.jsx)(z,{at:u,pending:!0})]}),(0,G.jsxs)($,{children:[(0,G.jsx)(ge,{reason:p(`Select an object to inspect its details.`),children:(0,G.jsx)(Me,{children:p(`Object details`)})}),(0,G.jsx)(le,{items:[{label:p(`Delete`),icon:(0,G.jsx)(D,{}),danger:!0,onClick:()=>l(p(`Demo action completed.`))},{label:p(`Refresh`),icon:(0,G.jsx)(d,{}),onClick:()=>l(p(`Demo action completed.`))},{label:p(`Edit`),icon:(0,G.jsx)(te,{}),onClick:()=>l(p(`Demo action completed.`))},{label:p(`Download`),disabled:!0,disabledReason:p(`Select an object to download.`),onClick:()=>{}}]})]}),(0,G.jsx)(`p`,{role:`status`,children:c})]})]}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{children:p(`Empty and unavailable states`)}),(0,G.jsxs)(Z,{children:[(0,G.jsx)(Q,{children:(0,G.jsx)(R,{icon:(0,G.jsx)(O,{}),title:p(`No buckets yet`),description:p(`Create a bucket to start storing objects.`),docsUrl:`https://silo.pgsty.com/`,action:(0,G.jsx)(T,{id:`showcase-create-bucket`,type:`button`,variant:`callAction`,label:p(`Create bucket`),onClick:()=>l(p(`Demo action completed.`))})})}),(0,G.jsx)(Q,{children:(0,G.jsx)(R,{compact:!0,icon:(0,G.jsx)(O,{}),title:p(`No matching objects`),description:p(`Try a different name or clear the search filter.`)})}),(0,G.jsx)(Q,{children:(0,G.jsx)(B,{title:p(`Metrics are unavailable`),description:p(`Connect a Prometheus endpoint to view monitoring metrics.`),docsUrl:`https://silo.pgsty.com/`})}),(0,G.jsx)(Q,{children:(0,G.jsx)(pe,{required:[`admin:ServerInfo`,`s3:ListAllMyBuckets`]})})]})]}),(0,G.jsxs)(Z,{children:[(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:p(`Loading rows`)}),(0,G.jsx)(me,{columns:3})]}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{children:p(`Command preview`)}),(0,G.jsx)(ue,{alias:`silo`,commands:[`mcli ls ALIAS`,`mcli version info ALIAS/demo-data`]})]})]})]}),(0,G.jsxs)(m,{container:!0,children:[(0,G.jsx)(m,{item:!0,xs:12,children:(0,G.jsx)(ie,{children:p(`Confirm Dialogs`)})}),(0,G.jsx)(m,{item:!0,xs:12,children:(0,G.jsx)(`p`,{children:p(`Used to confirm a non-idempotent action.`)})}),(0,G.jsxs)(m,{item:!0,xs:12,children:[(0,G.jsx)(T,{id:`open-dialog-test`,type:`button`,variant:`regular`,onClick:()=>{t(!0)},label:p(`Open Dialog`)}),(0,G.jsx)(de,{destructive:!0,title:p(`Delete Bucket`),confirmText:p(`Delete`),isOpen:e,titleIcon:(0,G.jsx)(D,{}),isLoading:!1,onConfirm:()=>{t(!1)},onClose:()=>{t(!1)},confirmationContent:(0,G.jsxs)(W.Fragment,{children:[ae(p(`Are you sure you want to delete bucket {bucket}?`),{bucket:(0,G.jsx)(`b`,{children:`bucket`})}),(0,G.jsx)(`br`,{}),p(`A bucket can only be deleted if it's empty.`)]})})]})]})]})]})};export{Ne as default};