import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,f as n,r,t as i}from"./react-vendor-UL3KVrSx.js";import{D as a,T as o}from"./shared-vendor-BQfq49S_.js";import{Dr as s,Qt as c,ir as l,n as u,or as d,r as f,rn as p,wn as m}from"./store-HGwDj7kv.js";import{i as h,m as g,n as _}from"./lang-C_0WK4Bf.js";import{$ as v,C as y,H as ee,K as b,S as x,h as te,j as S,rt as C,tt as w}from"./mds-B7pDlMNU.js";import{t as ne}from"./hard-drive-B4CIRsJz.js";import{t as T}from"./server-CGq9PK5-.js";import{t as E}from"./chevron-right-DFIPYKMk.js";import{t as re}from"./circle-check--s-qzPFr.js";import{t as D}from"./boxes-_8PXvP4Q.js";import{t as O}from"./archive-Cu6uIv3W.js";import{t as k}from"./info-Cg15zJKq.js";import{a as A,n as ie}from"./i18n-CKF7kMSP.js";import{n as j,o as M,t as N}from"./permissions-BCt8lMfX.js";import{t as P}from"./StatusBadge-BTgl2fcD.js";import{n as F}from"./SecureComponent-Cyii73MM.js";import{A as I,G as L,J as R,K as ae,V as z,W as B,a as oe,d as se,o as ce}from"./ConsoleKBar-C0VoXAuI.js";var V=e(t()),H=e=>typeof e==`number`&&Number.isFinite(e)&&e>=0?e:void 0,U=e=>{let t=Array.isArray(e),n=t?e:[],r=n.flatMap(e=>e.drives??[]),i=t&&n.every(e=>Array.isArray(e.drives));return{serversOnline:t?n.filter(e=>e.state===`online`).length:void 0,serversTotal:t?n.length:void 0,serversOffline:n.filter(e=>e.state&&e.state!==`online`).length,drivesOnline:i?r.filter(e=>e.state===`ok`).length:void 0,drivesTotal:i?r.length:void 0,drivesOffline:r.filter(e=>e.state&&e.state!==`ok`).length,healing:r.filter(e=>e.healing===!0).length,incomplete:!t||!n.length||!i||n.some(e=>!e.state)||r.some(e=>!e.state)}},W=e=>{let t=H(e.totalSpace),n=H(e.usedSpace),r=H(e.availableSpace);return t!==void 0&&t>0?{total:t,used:n,available:r,ratio:n===void 0?void 0:n/t}:{total:void 0,used:void 0,available:void 0,ratio:void 0}},G=e=>{let t=e??[],n=t.flatMap(e=>e.drives??[]),r=n.map(W).filter(e=>e.total!==void 0),i=e=>{if(r.length&&r.every(t=>t[e]!==void 0))return H(r.reduce((t,n)=>t+n[e],0))},a=i(`total`),o=i(`used`),s=i(`available`);return{rawTotal:a,rawUsed:o,rawAvailable:s,usedRatio:a&&o!==void 0?o/a:void 0,measuredDrives:r.length,incomplete:!Array.isArray(e)||!t.length||t.some(e=>!Array.isArray(e.drives))||r.length!==n.length||o===void 0||s===void 0}},K=e=>{let t=!!(e.usageUpdatedAt&&a.fromISO(e.usageUpdatedAt).isValid),n=e=>t?H(e===void 0?0:e):void 0;return{computed:t,objects:n(e.objects),bytes:n(e.usage),buckets:H(e.buckets)??(e.buckets===void 0&&t?0:void 0)}},le=(e,t)=>{let n=[],r=U(e.servers);r.serversOffline&&n.push({id:`servers-offline`,severity:`danger`,message:h(`{count} server(s) offline`),values:{count:r.serversOffline},href:`#overview-servers`}),r.drivesOffline&&n.push({id:`drives-offline`,severity:`danger`,message:h(`{count} drive(s) offline`),values:{count:r.drivesOffline},href:`#overview-servers`});for(let[t,r]of(e.servers??[]).entries())for(let[e,i]of(r.drives??[]).entries()){let r=W(i).ratio;r===void 0||r<.85||n.push({id:`drive-capacity-${t}-${e}`,severity:r>=.95?`danger`:`warning`,message:h(r>=.95?`Drive {drive} is at least 95% full. The server may reject writes.`:`Drive {drive} is at least 85% full.`),values:{drive:i.drivePath||i.endpoint||`${t+1}/${e+1}`},href:`#overview-servers`})}r.healing&&n.push({id:`healing`,severity:`warning`,message:h(`{count} drive(s) healing`),values:{count:r.healing},href:`#overview-servers`}),t&&n.push({id:`restart`,severity:`warning`,message:h(`Configuration changes are waiting for a server restart.`),href:`#restart-server`}),r.incomplete&&n.push({id:`health-unknown`,severity:`info`,message:h(`Some server or drive health information is unavailable.`)}),G(e.servers).incomplete&&n.push({id:`capacity-unknown`,severity:`info`,message:h(`Capacity is incomplete. Only reported drive measurements are shown.`)}),K(e).computed||n.push({id:`usage-pending`,severity:`info`,message:h(`The server has not finished computing usage yet.`)});let i={danger:0,warning:1,info:2};return n.sort((e,t)=>i[e.severity]-i[t.severity])},ue=(e,t,n)=>[{id:`bucket`,label:h(`Create bucket`),path:`/buckets/${j.ADD_BUCKETS}`,allowed:c(e)},{id:`user`,label:h(`Create user`),path:j.USER_ADD,allowed:!t.includes(`ldap-idp`)&&n(`console-ui`,[M.ADMIN_CREATE_USER,M.ADMIN_LIST_USER_POLICIES,M.ADMIN_LIST_GROUPS,M.ADMIN_ATTACH_USER_OR_GROUP_POLICY],!0)},{id:`access-key`,label:h(`Create access key`),path:j.ACCOUNT_ADD,allowed:n(N,[M.ADMIN_CREATE_SERVICEACCOUNT])},{id:`health`,label:h(`Generate health report`),path:j.TOOLS_DIAGNOSTICS,allowed:n(N,[M.ADMIN_HEALTH_INFO])}].filter(e=>e.allowed),de=async e=>(await m.admin.adminInfo({defaultOnly:!0},{signal:e})).data,fe=({refreshMs:e=6e4}={})=>{let[t,n]=(0,V.useState)({refreshing:!0,error:!1}),r=(0,V.useRef)(),i=(0,V.useRef)(0),a=(0,V.useRef)(!1),o=(0,V.useCallback)(async()=>{if(!a.current)return;let e=++i.current;r.current?.abort();let t=new AbortController;r.current=t,n(e=>({...e,refreshing:!0,error:!1}));let o=()=>a.current&&e===i.current&&!t.signal.aborted;try{let e=await de(t.signal);if(!e||typeof e!=`object`)throw Error(`Invalid admin info response`);o()&&n({data:e,refreshing:!1,error:!1})}catch{o()&&n(e=>({...e,refreshing:!1,error:!0}))}finally{e===i.current&&(r.current=void 0)}},[]);return(0,V.useEffect)(()=>{a.current=!0,o();let t,n=()=>{t!==void 0&&clearInterval(t),t=void 0,document.visibilityState===`visible`&&e>0&&(t=setInterval(()=>{document.visibilityState===`visible`&&o()},e))},s=()=>{n(),document.visibilityState===`visible`&&o()};return n(),document.addEventListener(`visibilitychange`,s),()=>{a.current=!1,i.current++,r.current?.abort(),r.current=void 0,t!==void 0&&clearInterval(t),document.removeEventListener(`visibilitychange`,s)}},[o,e]),{...t,refresh:o}},pe=o.div`
  .page-header {
    min-height: 56px;
    flex-wrap: nowrap;
  }
  .page-header .page-header-label,
  .page-header .page-header-actions {
    flex: 0 1 auto;
    width: auto;
    max-width: none;
    margin: 0;
  }
  .page-header .page-header-actions {
    flex-shrink: 0;
  }
`,me=o.h1`
  ${C(`title`)}
  margin: 0;
`,he=o.div`
  display: grid;
  grid-template-columns: repeat(12, minmax(0, 1fr));
  gap: 16px;
  font-variant-numeric: tabular-nums;
  > * {
    min-width: 0;
  }
`,ge=o.div`
  grid-column: 1 / -1;
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 16px;
  @media (max-width: 1199px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: 767px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,q=o(v)`
  grid-column: span ${({$columns:e})=>e??12};
  border-radius: var(--radius-card);
  padding: 20px;
  min-width: 0;
  @media (max-width: 1199px) {
    grid-column: 1 / -1;
  }
  @media (max-width: 767px) {
    padding: 16px;
  }
`,J=o.h2`
  ${C(`title`)}
  margin: 0 0 16px;
  color: var(--foreground);
`,Y=o.span`
  ${C(`caption`)}
  color: var(--muted-foreground);
`,X=o.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,_e=o.div`
  ${C(`body`)}
  grid-column: 1 / -1;
  display: flex;
  gap: 12px;
  align-items: center;
  padding: 12px 16px;
  border-radius: var(--radius-control);
  background: var(--hover);
  color: var(--foreground);
  svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
    fill: currentColor;
  }
`,ve=o.ul`
  ${C(`body`)}
  list-style: none;
  padding: 0;
  margin: 0;
  li {
    display: flex;
    gap: 12px;
    padding: 12px 0;
    align-items: flex-start;
  }
  li + li {
    border-top: 1px solid var(--border);
  }
  && li::before {
    content: none;
  }
  a,
  span {
    overflow-wrap: anywhere;
  }
  a {
    color: var(--foreground);
    text-underline-offset: 3px;
  }
  svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
    fill: currentColor;
  }
`,ye=o.span`
  display: inline-flex;
  margin-top: 2px;
  color: ${({$severity:e})=>`var(--${e===`danger`?`destructive`:e})`};
`,be=o.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
  @media (max-width: 767px) {
    grid-template-columns: minmax(0, 1fr);
  }
  button {
    justify-content: flex-start;
  }
`,xe=o.span`
  display: inline-block;
  width: 96px;
  height: 28px;
  background: var(--muted);
  border-radius: var(--radius-control);
`,Se=o.div`
  grid-column: 1 / -1;
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 16px;
  @media (max-width: 1199px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: 767px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Z=o(v)`
  min-width: 0;
  border-radius: var(--radius-card);
  padding: 16px;
  h2 {
    margin: 0 8px 12px;
  }
  nav {
    display: grid;
    gap: 4px;
  }
`,Ce=o(r)`
  ${C(`body`)}
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: var(--control-height);
  padding: 4px 8px;
  color: var(--foreground);
  text-decoration: none;
  border-radius: var(--radius-control);
  transition: background var(--dur-fast) var(--ease-fast);
  span {
    display: flex;
    flex: 0 0 16px;
    color: var(--muted-foreground);
  }
  svg {
    width: 16px;
    height: 16px;
  }
  &:hover {
    background: var(--hover);
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  @media (pointer: coarse) {
    min-height: 40px;
  }
`,Q=i(),we=o.div`
  position: relative;
  table {
    position: relative;
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
  }
  th,
  td {
    ${C(`body`,{compact:!0})} text-align: start;
    padding: 8px;
    vertical-align: top;
    overflow-wrap: anywhere;
    border-bottom: 1px solid var(--border);
  }
  th {
    font-weight: 550;
    color: var(--foreground);
  }
  td {
    color: var(--muted-foreground);
  }
  th:first-child {
    width: 30%;
  }
  .server-row {
    cursor: pointer;
  }
  .server-row[data-fluid-hover="true"] td,
  .server-row:focus-within td {
    color: var(--foreground);
  }
  .server-row[data-fluid-hover="true"] td,
  .server-row[data-fluid-before="true"] td {
    border-bottom-color: transparent;
  }
  .endpoint {
    display: flex;
    align-items: center;
    gap: 4px;
  }
  .endpoint button {
    flex-shrink: 0;
  }
  .version {
    width: 20%;
  }
  @media (max-width: 1199px) {
    table {
      table-layout: auto;
    }
    .version {
      display: none;
    }
    th:first-child {
      width: 35%;
    }
  }
  @media (max-width: 767px) {
    .network,
    .uptime {
      display: none;
    }
    th,
    td {
      padding: 8px 4px;
    }
    th:first-child {
      width: 48%;
    }
  }
`,Te=o.div`
  padding: 8px;
  background: var(--hover);
  border-radius: var(--radius-control);
  min-width: 0;
  ${Y} {
    color: var(--foreground);
  }
`,Ee=o.dl`
  ${C(`caption`)}
  display: none;
  margin: 0 0 12px;
  gap: 8px;
  dt {
    color: var(--foreground);
  }
  dd {
    color: var(--foreground);
    margin: 0;
    overflow-wrap: anywhere;
  }
  @media (max-width: 1199px) {
    display: grid;
    grid-template-columns: max-content minmax(0, 1fr);
  }
`,De=o.ul`
  list-style: none;
  margin: 0;
  padding: 0;
  li {
    display: grid;
    grid-template-columns: minmax(0, 2fr) auto minmax(0, 2fr);
    gap: 12px;
    align-items: center;
    padding: 12px 0;
  }
  li + li {
    border-top: 1px solid var(--border);
  }
  && li::before {
    content: none;
  }
  .path {
    overflow-wrap: anywhere;
    color: var(--foreground);
  }
  @media (max-width: 767px) {
    li {
      grid-template-columns: minmax(0, 1fr) auto;
    }
    .drive-usage {
      grid-column: 1 / -1;
    }
  }
`,Oe=o.div`
  height: 4px;
  margin-top: 8px;
  background: var(--border);
  border-radius: var(--radius-pill);
  &::after {
    content: "";
    display: block;
    height: 100%;
    width: ${({$ratio:e})=>Math.min(1,e)*100}%;
    background: ${({$tone:e})=>`var(--silo-${e})`};
    border-radius: inherit;
  }
`,$=e=>e===void 0?`—`:l(`${e}`);function ke({servers:e}){let t=A(),n=(0,V.useId)(),r=(0,V.useRef)(null),i=y(r,{gapClick:!1}),[a,o]=(0,V.useState)([]),s=(e,n)=>(0,Q.jsx)(P,{tone:e?e===n?`success`:`danger`:`neutral`,label:t(e?e===n?`Online`:`Offline`:`Unknown`)});return e?.length?(0,Q.jsx)(w,{density:`compact`,children:(0,Q.jsxs)(we,{ref:r,children:[(0,Q.jsx)(x,{hover:i}),(0,Q.jsxs)(`table`,{"aria-label":t(`Servers`),children:[(0,Q.jsx)(`thead`,{children:(0,Q.jsxs)(`tr`,{children:[(0,Q.jsx)(`th`,{scope:`col`,children:t(`Server`)}),(0,Q.jsx)(`th`,{scope:`col`,children:t(`Status`)}),(0,Q.jsx)(`th`,{scope:`col`,children:t(`Drives`)}),(0,Q.jsx)(`th`,{scope:`col`,className:`network`,children:t(`Network`)}),(0,Q.jsx)(`th`,{scope:`col`,className:`uptime`,children:t(`Uptime`)}),(0,Q.jsx)(`th`,{scope:`col`,className:`version`,children:t(`Version`)})]})}),(0,Q.jsx)(`tbody`,{children:e.map((e,r)=>{let i=e.endpoint||String(r),c=a.includes(i),l=e.endpoint||t(`Unknown`),u=e.drives?.filter(e=>e.state===`ok`).length,f=e.network?Object.values(e.network):void 0,p=f?`${f.filter(e=>e===`online`).length}/${f.length}`:`—`,m=H(e.uptime)===void 0?`—`:e.uptime===0?t(`Just started`):d(`${e.uptime}`),h=()=>o(e=>c?e.filter(e=>e!==i):[...e,i]),g=`${n}-drives-${r}`;return(0,Q.jsxs)(V.Fragment,{children:[(0,Q.jsxs)(`tr`,{className:`server-row`,"data-fluid-index":r,onClick:h,children:[(0,Q.jsx)(`td`,{children:(0,Q.jsxs)(`div`,{className:`endpoint`,children:[(0,Q.jsx)(b,{id:`${n}-expand-${r}`,variant:`ghost`,"aria-expanded":c,"aria-controls":c?g:void 0,"aria-label":_(t(c?`Hide drives for {server}`:`Show drives for {server}`),{server:l}),icon:c?(0,Q.jsx)(S,{}):(0,Q.jsx)(E,{}),onClick:e=>{e.stopPropagation(),h()}}),(0,Q.jsx)(`span`,{children:l})]})}),(0,Q.jsx)(`td`,{children:s(e.state,`online`)}),(0,Q.jsx)(`td`,{children:u===void 0?`—`:`${u}/${e.drives.length}`}),(0,Q.jsx)(`td`,{className:`network`,children:p}),(0,Q.jsx)(`td`,{className:`uptime`,children:m}),(0,Q.jsx)(`td`,{className:`version`,children:e.version||`—`})]}),c&&(0,Q.jsx)(`tr`,{children:(0,Q.jsx)(`td`,{colSpan:6,children:(0,Q.jsxs)(Te,{id:g,children:[(0,Q.jsxs)(Ee,{children:[(0,Q.jsx)(`dt`,{children:t(`Network`)}),(0,Q.jsx)(`dd`,{children:p}),(0,Q.jsx)(`dt`,{children:t(`Uptime`)}),(0,Q.jsx)(`dd`,{children:m}),(0,Q.jsx)(`dt`,{children:t(`Version`)}),(0,Q.jsx)(`dd`,{children:e.version||`—`})]}),e.drives?.length?(0,Q.jsx)(De,{"aria-label":_(t(`Drives on {server}`),{server:l}),children:e.drives.map((e,n)=>{let r=W(e),i=e.drivePath||e.endpoint||t(`Unknown`);return(0,Q.jsxs)(`li`,{children:[(0,Q.jsx)(`span`,{className:`path`,children:i}),(0,Q.jsxs)(`div`,{children:[s(e.state,`ok`),e.healing&&(0,Q.jsx)(`div`,{children:(0,Q.jsx)(Y,{children:t(`Healing`)})})]}),(0,Q.jsxs)(`div`,{className:`drive-usage`,children:[(0,Q.jsx)(Y,{children:_(t(`{used} / {total} used`),{used:$(r.used),total:$(r.total)})}),r.ratio!==void 0&&(0,Q.jsx)(Oe,{role:`progressbar`,"aria-label":_(t(`Drive usage: {drive}`),{drive:i}),"aria-valuemin":0,"aria-valuemax":100,"aria-valuenow":Math.min(100,r.ratio*100),$ratio:r.ratio,$tone:L(r.ratio)})]})]},e.uuid||`${i}-${n}`)})}):(0,Q.jsx)(Y,{children:t(`No drive information available`)})]})})})]},i)})})]})]})}):(0,Q.jsx)(R,{compact:!0,icon:(0,Q.jsx)(T,{}),title:t(`No servers reported`)})}function Ae(){let e=A(),t=ie(),i=n(),a=f(p),o=u();(0,V.useEffect)(()=>{o(s(`overview`))},[o]);let c=se(),d=oe(c),m=f(e=>e.system.serverNeedsRestart),{data:h,refreshing:v,error:y,refresh:x}=fe({refreshMs:6e4}),S=e=>e===void 0?`—`:new Intl.NumberFormat(g(t)).format(e),C=e=>e===void 0?`—`:l(`${e}`),w=e=>{if(e===void 0)return`—`;let[t,n]=l(`${e}`).split(` `);return(0,Q.jsxs)(Q.Fragment,{children:[t,` `,(0,Q.jsx)(Y,{children:n})]})},E=U(h?.servers),j=G(h?.servers),M=h?K(h):void 0,N=h?le(h,m):[],P=ue(a.permissions,a.features??[],F),L=e=>!h&&v?(0,Q.jsx)(xe,{"aria-hidden":`true`}):e,H=(e,t)=>e===void 0||t===void 0?`—`:`${S(e)}/${S(t)}`;return(0,Q.jsxs)(Q.Fragment,{children:[(0,Q.jsx)(pe,{children:(0,Q.jsx)(I,{label:(0,Q.jsx)(me,{children:e(`Overview`)}),primaryAction:{id:`refresh-overview`,label:e(`Refresh`),icon:(0,Q.jsx)(ee,{}),iconOnly:!0,loading:v,onClick:()=>void x()}})}),(0,Q.jsx)(te,{children:(0,Q.jsxs)(he,{children:[y&&(0,Q.jsxs)(_e,{role:`alert`,children:[(0,Q.jsx)(k,{"aria-hidden":`true`}),e(h?`Refresh failed. The last received data is still shown.`:`Could not load deployment information. Try refreshing.`)]}),(0,Q.jsxs)(ge,{role:`group`,"aria-busy":v,"aria-label":e(`Deployment statistics`),children:[(0,Q.jsx)(B,{label:e(`Cluster health`),icon:(0,Q.jsx)(T,{}),value:L(H(E.serversOnline,E.serversTotal)),unit:(0,Q.jsx)(Y,{children:e(`servers online`)}),subline:h&&(0,Q.jsxs)(X,{children:[(0,Q.jsx)(`span`,{children:_(e(`{count} drives online`),{count:H(E.drivesOnline,E.drivesTotal)})}),E.healing>0&&(0,Q.jsx)(`span`,{children:_(e(`{count} drive(s) healing`),{count:S(E.healing)})})]})}),(0,Q.jsx)(B,{label:e(`Capacity`),icon:(0,Q.jsx)(ne,{}),value:L((0,Q.jsx)(`span`,{"data-testid":`overview-used`,"data-bytes":j.rawUsed,children:w(j.rawUsed)})),subline:h&&(0,Q.jsxs)(X,{children:[(0,Q.jsx)(`span`,{"data-testid":`overview-total`,"data-bytes":j.rawTotal,children:_(e(`of {total} raw capacity`),{total:C(j.rawTotal)})}),(0,Q.jsx)(Y,{"data-testid":`overview-available`,"data-bytes":j.rawAvailable,children:_(e(`{available} available`),{available:C(j.rawAvailable)})})]}),progress:h&&j.usedRatio!==void 0?{value:j.usedRatio}:void 0}),(0,Q.jsx)(B,{label:e(`Data`),icon:(0,Q.jsx)(D,{}),value:L(S(M?.objects)),unit:(0,Q.jsx)(Y,{children:e(`objects`)}),subline:h&&(0,Q.jsxs)(X,{children:[(0,Q.jsx)(`span`,{children:C(M?.bytes)}),(0,Q.jsx)(ae,{at:h.usageUpdatedAt,prefix:`Calculated`})]})}),(0,Q.jsx)(B,{label:e(`Buckets`),icon:(0,Q.jsx)(O,{}),value:L(S(M?.buckets)),footer:(0,Q.jsxs)(r,{to:`/buckets`,children:[e(`View buckets`),` →`]})})]}),(0,Q.jsxs)(q,{shadowLevel:2,id:`overview-servers`,tabIndex:-1,role:`group`,"aria-labelledby":`overview-servers-title`,children:[(0,Q.jsx)(J,{id:`overview-servers-title`,children:e(`Servers`)}),!h&&v?(0,Q.jsx)(z,{rows:3,columns:4}):(0,Q.jsx)(ke,{servers:h?.servers})]}),(0,Q.jsxs)(q,{$columns:h&&!N.length?4:8,shadowLevel:2,role:`group`,"aria-labelledby":`overview-alerts-title`,children:[(0,Q.jsx)(J,{id:`overview-alerts-title`,children:e(`Alerts`)}),h?N.length?(0,Q.jsx)(ve,{children:N.map(t=>{let n=_(e(t.message),t.values??{});return(0,Q.jsxs)(`li`,{children:[(0,Q.jsx)(ye,{role:`img`,$severity:t.severity,"aria-label":t.severity===`danger`?e(`Error`):t.severity===`warning`?e(`Warning`):e(`Information`),children:(0,Q.jsx)(k,{})}),t.href?(0,Q.jsx)(`a`,{href:t.href,onClick:e=>{let n=document.getElementById(t.href.slice(1));n&&(e.preventDefault(),n.scrollIntoView({block:`nearest`}),n.focus())},children:n}):(0,Q.jsx)(`span`,{children:n})]},t.id)})}):(0,Q.jsxs)(X,{as:`p`,style:{margin:0,flexDirection:`row`,alignItems:`center`,color:`var(--muted-foreground)`},children:[(0,Q.jsx)(re,{"aria-hidden":`true`,style:{width:20,height:20,color:`var(--success)`,flexShrink:0}}),e(`All systems normal`)]}):v?(0,Q.jsx)(z,{rows:3,columns:1}):(0,Q.jsx)(R,{compact:!0,title:e(`Health information unavailable`)})]}),(0,Q.jsxs)(q,{$columns:h&&!N.length?8:4,shadowLevel:2,role:`group`,"aria-labelledby":`overview-actions-title`,children:[(0,Q.jsx)(J,{id:`overview-actions-title`,children:e(`Quick actions`)}),(0,Q.jsx)(be,{children:P.map(t=>(0,Q.jsx)(b,{id:`overview-${t.id}`,variant:`secondary`,label:e(t.label),onClick:()=>i(t.path)},t.id))}),!P.length&&(0,Q.jsx)(Y,{children:e(`No quick actions available for your permissions.`)})]}),(0,Q.jsx)(Se,{children:ce.map(t=>{let n=d.filter(e=>e.section===t.id);return n.length?(0,Q.jsxs)(Z,{shadowLevel:2,role:`group`,"aria-labelledby":`overview-nav-${t.id}`,children:[(0,Q.jsx)(J,{id:`overview-nav-${t.id}`,children:e(t.title)}),(0,Q.jsx)(`nav`,{"aria-labelledby":`overview-nav-${t.id}`,children:n.map(t=>(0,Q.jsxs)(Ce,{to:t.path,children:[(0,Q.jsx)(`span`,{"aria-hidden":`true`,children:t.menu.icon}),e(t.title)]},t.id))})]},t.id):null})})]})})]})}export{Ae as default};