const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./BulkReplicationModal-BKMvS5oS.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./mds-Hm6-garf.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./store-C9Mm53c2.js","./lang-DMKw_tbl.js","./triangle-alert-DPki1Fw6.js","./circle-check-BZP-AfIi.js","./ReadBox-C3hOTC6w.js","./Wizard-CO4tt-Nl.js","./i18n-Drk-M_7X.js","./replicationValidation-BSHNIzBL.js","./ConsoleKBar-Dxo3YH9b.js","./pencil-CwNxaxuc.js","./search-CRkIzdcR.js","./CircleIcon-BsXHTBH6.js","./trash-BB_JaxBi.js","./clock-BDJuCxth.js","./plus-CwZ5nYPT.js","./info-SZqCz3Nv.js","./console-vendor-I3rSB1nD.js","./listPopup-D2sWpuy2.js","./SectionTitle-fTvk06tJ.js","./useAvailableWidth-COFYcObd.js","./ModalBox-CgAJAa_u.js","./ModalPresence-EA3czOP5.js","./index-DALAjBvJ.js","./index-BFo1l52q.css","./typography-CvHJfn8U.js","./shared-DOoon_mo.js","./OverflowMenu-uk7R8BYl.js","./typography-BO7lxH25.js","./permissions-DtXShYFJ.js","./StatusBadge-BzPAjqeM.js","./CliEquivalent-_icu06lc.js","./copy-D2zpeJeK.js","./code-BTTQulz1.js","./lib-BVN4wEer.js","./SecureComponent-CpdQFUTP.js","./BulkLifecycleModal-DZop33-2.js","./QueryMultiSelector-BmxWrrur.js","./DeleteBucket-7E-iv0kN.js","./ConfirmDialog-yG250qEO.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,d as n,f as r,h as i,r as a,t as o}from"./react-vendor-UL3KVrSx.js";import{n as s,o as c}from"./lang-DMKw_tbl.js";import{D as l,H as u,O as d,R as f,ct as p,x as m,y as ee}from"./mds-Hm6-garf.js";import{D as te,T as h}from"./shared-vendor-BQfq49S_.js";import{$t as ne,Dr as re,En as ie,Or as ae,Tn as g,i as oe,in as se,or as _,r as ce}from"./store-C9Mm53c2.js";import{t as le}from"./trash-BB_JaxBi.js";import{t as ue}from"./boxes-Df2UqltH.js";import{t as de}from"./calendar-clock-7mItpbVS.js";import{t as fe}from"./plus-CwZ5nYPT.js";import{t as v}from"./archive-OuPIyv4o.js";import{n as y,t as pe}from"./folder-Bp_xrdzR.js";import{t as b}from"./Checkbox-D6PaAoo8.js";import{c as x,s as me}from"./listPopup-D2sWpuy2.js";import{t as he}from"./useTableLayout-B19JFDSA.js";import{a as S,n as C,t as ge}from"./i18n-Drk-M_7X.js";import{t as _e}from"./ModalPresence-EA3czOP5.js";import{c as ve}from"./index-DALAjBvJ.js";import{n as w}from"./shared-DOoon_mo.js";import{t as ye}from"./OverflowMenu-uk7R8BYl.js";import{t as T}from"./typography-BO7lxH25.js";import{A as be,a as E,g as D,i as O,n as k,o as A,p as j,r as M,t as xe}from"./permissions-DtXShYFJ.js";import{t as N}from"./StatusBadge-BzPAjqeM.js";import{t as Se}from"./SearchBox-Brbj5QlP.js";import{t as P}from"./withSuspense-DTbtEWjP.js";import{n as F}from"./SecureComponent-CpdQFUTP.js";import{a as I,i as L,n as R,r as z,t as B}from"./prefixUsage-Cs8tV4-R.js";import{t as V}from"./bucketMetadata-BAg0j77c.js";import{n as H}from"./react-window-0T2cJ04-.js";import{A as Ce,J as U,V as we,f as Te}from"./ConsoleKBar-Dxo3YH9b.js";var W=e(t()),Ee=(0,W.createContext)(void 0),De=Ee.Provider,G=()=>(0,W.useContext)(Ee),K=e=>e.state===`queued`||e.state===`running`,q=[`not_scanned`,`queued`,`running`,`complete`,`error`,`limited`,`forbidden`,`missing`,`unavailable`],J=(e,t)=>e==null||t(e),Y=e=>{if(typeof e!=`object`||!e)return!1;let t=e,n=t.totals;return!!n&&z(n.current_bytes)&&L(n.current_objects)&&J(n.retained_bytes,z)&&J(n.retained_versions,L)&&J(n.delete_markers,L)&&L(t.scanned_entries)},Oe=e=>{if(e&&typeof e.bucket==`string`)return q.includes(e.state)?{...e,last_good:Y(e.last_good)?e.last_good:void 0,progress:Y(e.progress)?e.progress:void 0}:{bucket:e.bucket,state:`unavailable`,versions_visible:!1}},ke=e=>({...e,totals:{current_bytes:e.totals.current_bytes,current_objects:e.totals.current_objects}}),Ae=(e,t)=>e.state===`unavailable`&&!e.last_good&&t?.last_good?{...e,last_good:e.versions_visible?t.last_good:ke(t.last_good),last_completed_at:t.last_completed_at}:e;function je(e){let t=JSON.stringify(e),n=I(),r=(0,W.useRef)(),[i,a]=(0,W.useState)(0),o=(0,W.useRef)(!1),[s,c]=(0,W.useState)({requesting:!1,records:{}}),l=(0,W.useCallback)(()=>{o.current=!0,a(e=>e+1)},[]);return(0,W.useEffect)(()=>{let e=JSON.parse(t),i=new AbortController;r.current?.abort(),r.current=i;let a,s=()=>!i.signal.aborted&&n(),l=o.current;o.current=!1;let u=!l;c(t=>({...t,records:Object.fromEntries(Object.entries(t.records).filter(([t])=>e.includes(t)).flatMap(([e,n])=>t.enabled===!1&&n.state===`running`?n.last_good?[[e,{...n,state:`complete`,progress:void 0}]]:[]:[[e,n]]))}));let d=async()=>{c(e=>({...e,requesting:!0}));let t=[...e],n=async()=>{for(;s()&&t.length;){let e=t.shift(),n=F(e,[A.S3_LIST_BUCKET_VERSIONS]),r={bucket:e,state:`running`,versions_visible:n},a=()=>s()&&c(t=>{let i=t.records[e],a=i?.versions_visible===n&&r.state!==`forbidden`&&r.state!==`missing`;return{...t,records:{...t.records,[e]:{...r,last_good:r.last_good??(a?i?.last_good:void 0),last_completed_at:r.last_completed_at??(a?i?.last_completed_at:void 0)}}}});a();try{let t,o=await g.buckets.prefixUsage(e,{prefix:``,versions:n,folders:!1},{signal:i.signal});await R(o,{bucket:e,prefix:``,mode:n?`versions`:`current`},e=>{let i={totals:{...e.totals,...n?{}:{retained_bytes:void 0,retained_versions:void 0,delete_markers:void 0}},scanned_entries:e.scanned_entries,started_at:e.started_at,updated_at:e.updated_at};r={...r,state:e.status===`scanning`||e.status===`complete`?`running`:e.status===`failed`?`error`:e.status,progress:i},e.status===`complete`&&(t=i),a()}),t&&(r={...r,state:`complete`,last_good:t,last_completed_at:t.updated_at},a())}catch(e){let t=e instanceof Response?e.status:0;r={...r,state:t===401||t===403?`forbidden`:t===404?`missing`:`error`},a()}}};await Promise.all([n(),n()]),s()&&c(e=>({...e,requesting:!1}))},f=async t=>{if(s()){t&&c(e=>({...e,requesting:!0,error:!1}));try{let n=!1,r=2e3,o,l=[];for(let a=0;a<Math.max(e.length,1);a+=100){let s={buckets:e.slice(a,a+100)},c=t?await g.bucketUsage.bucketUsageRefresh(s,{signal:i.signal}):await g.bucketUsage.bucketUsageStatus(s,{signal:i.signal});if(n=c.data.enabled,r=c.data.poll_after_ms,o=c.data.coverage,l.push(...c.data.buckets),!n)break}if(!s())return;if(n&&t&&(u=!0),c(e=>({enabled:n,requesting:!1,records:n?Object.fromEntries(l.flatMap(t=>{let n=Oe(t);return n?[[n.bucket,Ae(n,e.records[n.bucket])]]:[]})):e.enabled===!1?e.records:{},coverage:o})),!n){t&&(await d(),s()&&(u=!0));return}let p=l.some(K);a=setTimeout(()=>void f(!1),Math.min(6e4,Math.max(250,r)*(p?1:10)))}catch{s()&&(u=!0,c(e=>({...e,requesting:!1,error:!0})),a=setTimeout(()=>void f(!1),1e4))}}};return f(l),()=>{!u&&n()&&(o.current=!0),i.abort(),clearTimeout(a)}},[t,i,n]),{...s,refresh:l}}var X=o(),Me=h.small`
  ${T.caption}
  display: block;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--muted-foreground);
`,Ne=h(Me)`
  white-space: normal;
  text-overflow: clip;
  .usageValue {
    white-space: nowrap;
  }
`;function Pe({bucket:e}){let t=G(),n=t?.records[e],r=S(),i=c(C());if(!t||!n&&!t.enabled)return null;let a={not_scanned:r(`Not scanned`),queued:r(`Update queued`),running:r(`Updating usage…`),complete:r(`Updated`),error:r(`Update failed — retry with Refresh`),limited:r(`Scan limit reached — operator action required`),forbidden:r(`Usage listing not permitted`),missing:r(`Bucket no longer exists`),unavailable:r(`Usage temporarily unavailable`)},o=n?.last_completed_at?new Date(n.last_completed_at):void 0,l=[n?a[n.state]:r(`Checking usage…`),n?.state===`running`&&n.progress?s(r(`{count} entries scanned`),{count:n.progress.scanned_entries.toLocaleString(i)}):``,o&&Number.isFinite(o.getTime())?o.toLocaleTimeString(i):``].filter(Boolean).join(` · `);return(0,X.jsx)(Me,{title:o&&Number.isFinite(o.getTime())?`${l} (${o.toLocaleString(i)})`:l,children:l})}function Fe(){let e=G(),t=S(),n=C()===`zh`?``:` `;if(!e)return null;let r=Object.values(e.records),i=r.filter(e=>e.state===`queued`||e.state===`running`).length,a=r.filter(e=>[`error`,`limited`,`unavailable`].includes(e.state)).length,o=e.coverage?.observer_alive&&e.coverage.connected&&e.coverage.reconciled;return(0,X.jsxs)(`div`,{role:`status`,"aria-live":`polite`,style:{marginBottom:12},children:[e.requesting?t(`Requesting usage updates…`):i?s(t(`{count} usage updates queued or running. Last completed totals remain visible.`),{count:i}):t(`Refresh requests a new metadata scan of all listed buckets.`),n,e.error?t(`Usage status is unavailable. Retrying…`):e.enabled?t(o?`Automatic change monitoring is active.`:`Automatic change monitoring is recovering; totals may be out of date.`):e.enabled===!1?t(`Automatic updates are not configured. Refresh calculates usage while this page is open.`):t(`Checking automatic updates…`),a>0&&(0,X.jsxs)(X.Fragment,{children:[n,s(t(`{count} updates need attention. Use Refresh to retry.`),{count:a})]})]})}var Ie=[`name`,`objects`,`size`,`created`],Le=e=>({sort:Ie.includes(e.get(`sort`)||``)?e.get(`sort`):`name`,dir:e.get(`dir`)===`desc`?`desc`:`asc`,q:e.get(`q`)||``}),Re=(e,t)=>{let n=new URLSearchParams(e),r={...Le(e),...t};for(let e of[`sort`,`dir`,`q`])!r[e]||e===`sort`&&r.sort===`name`||e===`dir`&&r.dir===`asc`?n.delete(e):n.set(e,r[e]);return n},ze=e=>e===`cards`?`cards`:`table`,Be=e=>!!(e&&Number.isFinite(Date.parse(e))),Ve=(e,t,n,r)=>{if(!(!e||n&&!Be(r)))return!n&&e[t]===void 0?0:V(e,t,r)},He=(e,t,n,r,i)=>{let a=t.q.trim().toLocaleLowerCase(),o=e=>{if(t.sort===`name`)return e.name;if(t.sort===`created`){let t=Date.parse(e.creation_date||``);return Number.isFinite(t)?t:void 0}if(i){let n=i[e.name]?.last_good?.totals;return n?t.sort===`size`?BigInt(n.current_bytes):n.current_objects:void 0}return Ve(e,t.sort,n,r)};return e.filter(e=>e.name.toLocaleLowerCase().includes(a)).sort((e,n)=>{let r=o(e),i=o(n);return r===void 0&&i!==void 0?1:i===void 0&&r!==void 0?-1:(r===i||r===void 0||i===void 0?0:r<i?-1:1)*(t.dir===`desc`?-1:1)||e.name.localeCompare(n.name)})},Ue=(e,t)=>t.length>0&&t.every(t=>e.includes(t))?e.filter(e=>!t.includes(e)):Array.from(new Set([...e,...t])),Z=(e,t)=>({browse:F(e,j),settings:!t&&F(e,M[k.BUCKETS_ADMIN_VIEW]),delete:!t&&F(e,D),select:!t&&F(e,[A.S3_PUT_LIFECYCLE_CONFIGURATION,A.S3_PUT_REPLICATION_CONFIGURATION,A.S3_PUT_ACTIONS])}),Q=({bucket:e,field:t,canReadUsage:n,usageUpdatedAt:r})=>{let i=S(),a=C(),o=G(),s=(o?.records[e.name])?.last_good?.totals;if(s)return t===`objects`?(0,X.jsx)(X.Fragment,{children:s.current_objects.toLocaleString(a)}):(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`span`,{title:`${s.current_bytes} B`,children:B(s.current_bytes)}),s.retained_bytes!=null&&(0,X.jsx)(Ne,{title:`${s.retained_bytes} B`,children:ge(i(`Retained: {size}`),{size:(0,X.jsx)(`span`,{className:`usageValue`,children:B(s.retained_bytes)})})})]});if(o)return(0,X.jsx)(`span`,{children:`—`});let c=Ve(e,t,n,r);return c===void 0?(0,X.jsx)(w,{text:n&&!Be(r)?i(`Calculating…`):i(`Unknown`),children:(0,X.jsx)(`span`,{tabIndex:0,children:`—`})}):(0,X.jsx)(X.Fragment,{children:t===`size`?_(c):c.toLocaleString(a)})},We=({bucket:e})=>{let t=S();return(0,X.jsx)(X.Fragment,{children:e.rw_access?.read?e.rw_access.write?t(`Read & write`):t(`Read only`):e.rw_access?.write?t(`Write only`):t(`Unknown`)})},$=({enabled:e,suspended:t=!1})=>{let n=S();return(0,X.jsx)(N,{tone:t?`warning`:e?`success`:`neutral`,label:n(t?`Suspended`:e===void 0?`Unknown`:e?`Enabled`:`Disabled`)})},Ge=({at:e})=>{let t=C(),n=e?te.fromISO(e).setLocale(c(t)):void 0;return n?.isValid?(0,X.jsx)(w,{text:n.toLocaleString(te.DATETIME_FULL_WITH_SECONDS),children:(0,X.jsx)(`time`,{dateTime:e,tabIndex:0,children:n.toRelative()})}):(0,X.jsx)(X.Fragment,{children:`—`})},Ke=({bucket:e,obOnly:t,onDelete:n})=>{let i=S(),a=r(),o=Z(e.name,t),c=encodeURIComponent(e.name),l=[...o.browse?[{label:i(`Browse`),icon:(0,X.jsx)(pe,{}),onClick:()=>a(`/browser/${c}`)}]:[],...o.settings?[{label:i(`Settings`),icon:(0,X.jsx)(y,{}),onClick:()=>a(`/buckets/${c}/admin/summary`)}]:[],...o.delete?[{label:i(`Delete bucket`),icon:(0,X.jsx)(le,{}),danger:!0,onClick:()=>n(e.name)}]:[]];return l.length?(0,X.jsx)(`div`,{onClick:e=>e.stopPropagation(),onKeyDown:e=>e.stopPropagation(),children:(0,X.jsx)(ye,{label:s(i(`Actions for {bucket}`),{bucket:e.name}),tooltipPlacement:`left`,tooltipLabel:i(`Actions`),items:l})}):null},qe=h.div`
  ${T.body}
  min-height: 148px;
  box-sizing: border-box;
  min-width: 0;
  padding: 8px 12px 12px;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  color: var(--muted-foreground);
  font-variant-numeric: tabular-nums;
  &[data-clickable="true"] {
    cursor: pointer;
  }
  &:hover,
  &[data-selected="true"] {
    color: var(--foreground);
    background: color-mix(in srgb, var(--hover) 100%, var(--surface-3));
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }
  .cardTitle {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;
    height: 36px;
  }
  .cardTitle > svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
  }
  h2 {
    ${T.section} margin: 0;
    min-width: 0;
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  a {
    color: inherit;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
  .cardMetrics {
    /* Fixed tracks keep each metric aligned across every card. */
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) auto;
    gap: 12px;
    margin-top: 4px;
  }
  .cardMetrics > div {
    min-width: 0;
  }
  .metricLabel {
    ${T.caption} color: var(--muted-foreground);
  }
  .metricValue {
    display: block;
    color: var(--foreground);
  }
  .cardAccess {
    ${T.caption} text-align: right;
    align-self: end;
  }
`,Je=e=>{let{bucket:t,onSelect:n,selected:i,obOnly:o}=e,c=S(),l=r(),u=Z(t.name,o),d=()=>u.browse&&l(`/browser/${encodeURIComponent(t.name)}`);return(0,X.jsxs)(qe,{className:`bucket-card`,role:`listitem`,"aria-label":t.name,"data-clickable":u.browse,"data-selected":n?i:void 0,tabIndex:u.browse?0:void 0,onClick:d,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),d())},children:[(0,X.jsxs)(`div`,{className:`cardTitle`,children:[n?(0,X.jsx)(`span`,{onClick:e=>e.stopPropagation(),children:(0,X.jsx)(b,{label:``,checked:i,disabled:!u.select,"aria-label":s(c(`Select {bucket}`),{bucket:t.name}),onChange:()=>n(t.name)})}):(0,X.jsx)(v,{"aria-hidden":`true`}),(0,X.jsx)(`h2`,{children:u.browse?(0,X.jsx)(a,{to:`/browser/${encodeURIComponent(t.name)}`,onClick:e=>e.stopPropagation(),children:t.name}):t.name}),(0,X.jsx)(Ke,{...e})]}),(0,X.jsx)(Pe,{bucket:t.name}),(0,X.jsxs)(`div`,{className:`cardMetrics`,children:[(0,X.jsxs)(`div`,{children:[(0,X.jsx)(`span`,{className:`metricLabel`,children:c(`Objects`)}),(0,X.jsx)(`span`,{className:`metricValue`,children:(0,X.jsx)(Q,{...e,field:`objects`})})]}),(0,X.jsxs)(`div`,{children:[(0,X.jsx)(`span`,{className:`metricLabel`,children:c(`Current size`)}),(0,X.jsx)(`span`,{className:`metricValue`,children:(0,X.jsx)(Q,{...e,field:`size`})})]}),(0,X.jsx)(`span`,{className:`cardAccess`,children:(0,X.jsx)(We,{bucket:t})})]})]})},Ye=h.div`
  ${T.body}
  min-width: 0;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  overflow: hidden;
  font-variant-numeric: tabular-nums;
  --bucket-select-width: 28px;
  --bucket-menu-width: 36px;
  /* Font-relative, so "Retained: 9.5 MiB" fits with wider fallback fonts
     (e.g. DejaVu Sans on Linux); longer values wrap rather than clip. */
  --bucket-size-min: 15ch;
  .bucketGrid {
    display: grid;
    grid-template-columns:
      minmax(120px, 1.8fr)
      minmax(0, 0.7fr) minmax(var(--bucket-size-min), 1.1fr) minmax(0, 1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    align-items: center;
    column-gap: 8px;
    padding: 0 12px;
    box-sizing: border-box;
    height: var(--bucket-row-height, var(--control-height));
  }
  &[data-selection="true"] .bucketGrid {
    grid-template-columns:
      var(--bucket-select-width) minmax(120px, 1.8fr)
      minmax(0, 0.7fr) minmax(var(--bucket-size-min), 1.1fr) minmax(0, 1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
  }
  .bucketCell {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .bucketCell a {
    color: inherit;
    text-decoration: none;
  }
  /* Text overflow applies per line; the name and its usage caption are blocks. */
  .bucketName {
    display: block;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .bucketCell a:hover {
    text-decoration: underline;
  }
  .bucketCell a:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  .bucketNumber {
    text-align: right;
  }
  @media (min-width: 1200px) {
    .bucketNumber {
      padding-right: 12px;
    }
  }
  .bucketCheck {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .bucketMenu {
    overflow: visible;
    display: flex;
    justify-content: end;
  }
  .bucketRow {
    border-bottom: 1px solid var(--border);
    color: var(--muted-foreground);
    transition:
      color var(--dur-fast) ease,
      border-color var(--dur-fast) ease;
  }
  .bucketRow[data-fluid-activator] {
    cursor: pointer;
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[aria-selected="true"] {
    color: var(--foreground);
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[data-fluid-before] {
    border-bottom-color: transparent;
  }
  .bucketRow[aria-selected="true"] {
    background: var(--active);
  }
  .bucketRow:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  @media (max-width: 1199.98px) {
    .bucketGrid {
      grid-template-columns:
        minmax(100px, 1.6fr) minmax(0, 0.6fr) minmax(
          var(--bucket-size-min),
          1fr
        )
        minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns:
        var(--bucket-select-width) minmax(100px, 1.6fr)
        minmax(0, 0.6fr) minmax(var(--bucket-size-min), 1fr) minmax(0, 1fr)
        minmax(0, 1fr) var(--bucket-menu-width);
    }
    .bucketLow {
      display: none;
    }
  }
  @media (max-width: 767.98px) {
    .bucketGrid {
      grid-template-columns: minmax(0, 1fr) var(--bucket-size-min) var(
          --bucket-menu-width
        );
      padding: 0 8px;
      gap: 4px;
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns:
        var(--bucket-select-width) minmax(0, 1fr)
        var(--bucket-size-min) var(--bucket-menu-width);
    }
    .bucketMedium {
      display: none;
    }
  }
  @media (pointer: coarse) {
    --bucket-select-width: 40px;
    --bucket-menu-width: 40px;
  }
`,Xe=h.div`
  position: sticky;
  top: 0;
  z-index: 1;
  background: var(--surface-3);
  color: var(--foreground);
  border-bottom: 1px solid var(--border);
  /* Weight the cells, not the grid row: font-relative tracks (ch) must
     resolve against the same font as body rows to keep columns aligned. */
  & > * {
    font-weight: var(--fw-semibold);
  }
  button {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    border: 0;
    padding: 0;
    background: transparent;
    color: inherit;
    font: inherit;
    cursor: pointer;
    max-width: 100%;
  }
  @media (pointer: coarse) {
    button {
      min-height: 40px;
    }
  }
  button:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
  }
  button > svg {
    width: 12px;
    height: 12px;
    flex-shrink: 0;
    fill: currentColor;
  }
  /* A narrow column truncates its label, never the sort direction. */
  .sortLabel {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`,Ze=h.div`
  position: relative;
  isolation: isolate;
  min-height: 0;
  [data-fluid-highlight] {
    z-index: -1;
  }
`;function Qe({index:e,style:t,records:n,columns:r,selected:i,common:a}){let o=n[e];return(0,X.jsx)($e,{index:e,style:t,columns:r,...a,bucket:o,selected:i.includes(o.name)},o.name)}function $e({index:e,style:t,columns:n,...i}){let a=r(),{bucket:o,selected:c,onSelect:l,obOnly:u}=i,d=S(),f=Z(o.name,u),p=()=>f.browse&&a(`/browser/${encodeURIComponent(o.name)}`);return(0,X.jsxs)(`div`,{role:`row`,"aria-rowindex":e+2,"aria-label":o.name,"aria-selected":l?c:void 0,style:t,className:`bucketGrid bucketRow`,"data-fluid-index":f.browse?e:void 0,"data-fluid-key":o.name,"data-fluid-activator":f.browse?`true`:void 0,tabIndex:f.browse?0:void 0,onClick:p,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),p())},children:[l&&(0,X.jsx)(`div`,{role:`cell`,className:`bucketCheck`,onClick:e=>e.stopPropagation(),children:(0,X.jsx)(b,{label:``,"aria-label":s(d(`Select {bucket}`),{bucket:o.name}),checked:c,disabled:!f.select,onChange:()=>l(o.name)})}),n.map(e=>(0,X.jsx)(`div`,{role:`cell`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``} ${e.id===`actions`?`bucketMenu`:``}`,children:e.render(i)},e.id))]})}function et({records:e,query:t,onSort:n,selected:r,onSelectAll:i,...o}){let s=S(),c=he(),u=(0,W.useRef)(null),f=x(u,{gapClick:!1}),p=[{id:`name`,label:s(`Name`),sort:`name`,render:({bucket:e,obOnly:t})=>(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`span`,{className:`bucketName`,title:e.name,children:Z(e.name,t).browse?(0,X.jsx)(a,{to:`/browser/${encodeURIComponent(e.name)}`,onClick:e=>e.stopPropagation(),children:e.name}):e.name}),(0,X.jsx)(Pe,{bucket:e.name})]})},{id:`objects`,label:s(`Objects`),priority:`Medium`,number:!0,sort:`objects`,render:e=>(0,X.jsx)(Q,{...e,field:`objects`})},{id:`size`,label:s(`Current size`),number:!0,sort:`size`,render:e=>(0,X.jsx)(Q,{...e,field:`size`})},{id:`versioning`,label:s(`Versioning`),priority:`Medium`,render:({bucket:e})=>(0,X.jsx)($,{enabled:e.details?!!e.details.versioning:void 0,suspended:e.details?.versioningSuspended})},{id:`locking`,label:s(`Object lock`),priority:`Low`,render:({bucket:e})=>(0,X.jsx)($,{enabled:e.details?!!e.details.locking:void 0})},{id:`quota`,label:s(`Quota`),priority:`Low`,number:!0,render:({bucket:e})=>(e.details?.quota?.quota||0)>0?_(e.details.quota.quota):`—`},{id:`replication`,label:s(`Replication`),priority:`Low`,render:({bucket:e})=>(0,X.jsx)($,{enabled:e.details?!!e.details.replication:void 0})},{id:`access`,label:s(`Access`),priority:`Medium`,render:({bucket:e})=>(0,X.jsx)(We,{bucket:e})},{id:`created`,label:s(`Created`),priority:`Low`,sort:`created`,render:({bucket:e})=>(0,X.jsx)(Ge,{at:e.creation_date})},{id:`actions`,label:s(`Actions`),render:e=>(0,X.jsx)(Ke,{...e})}],m=e.filter(e=>Z(e.name,o.obOnly).select),ee={records:e,columns:p,selected:r,common:o};return(0,X.jsxs)(Ye,{role:`table`,"aria-label":s(`Buckets`),"aria-rowcount":e.length+1,"aria-colcount":p.length+ +!!o.onSelect,"data-selection":!!o.onSelect,style:{"--bucket-row-height":`${Math.max(c,64)}px`},children:[(0,X.jsxs)(Xe,{role:`row`,className:`bucketGrid`,"aria-rowindex":1,style:{"--bucket-row-height":`${c}px`},children:[o.onSelect&&(0,X.jsx)(`div`,{role:`columnheader`,className:`bucketCheck`,children:(0,X.jsx)(b,{label:``,"aria-label":s(`Select all visible buckets`),checked:m.length>0&&m.every(e=>r.includes(e.name)),disabled:!m.length,onChange:i})}),p.map(e=>(0,X.jsx)(`div`,{role:`columnheader`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``}`,"aria-sort":e.sort?t.sort===e.sort?t.dir===`asc`?`ascending`:`descending`:`none`:void 0,children:e.sort?(0,X.jsxs)(`button`,{type:`button`,"aria-label":e.label,onClick:()=>n(e.sort),children:[(0,X.jsx)(`span`,{className:`sortLabel`,children:e.label}),t.sort===e.sort&&(t.dir===`asc`?(0,X.jsx)(d,{}):(0,X.jsx)(l,{}))]}):e.id===`actions`?(0,X.jsx)(`span`,{className:`selectionHeaderLabel`,style:{position:`absolute`,clipPath:`inset(50%)`,width:1,height:1},children:e.label}):e.label},e.id))]}),(0,X.jsxs)(Ze,{ref:u,children:[(0,X.jsx)(me,{hover:f}),e.length>100?(0,X.jsx)(H,{role:`rowgroup`,"aria-label":s(`Bucket rows`),rowCount:e.length,rowHeight:Math.max(c,64),rowComponent:Qe,rowProps:ee,overscanCount:6,style:{height:`min(65vh, 720px)`,minHeight:c*4}}):(0,X.jsx)(`div`,{role:`rowgroup`,style:{maxHeight:`min(65vh, 720px)`,overflowY:`auto`},children:e.map((e,t)=>(0,X.jsx)($e,{...o,columns:p,bucket:e,index:t,selected:r.includes(e.name)},e.name))})]})]})}function tt(){let e=n(),[t,r]=i(),a=Le(t),[o,s]=(0,W.useState)(a.q);return(0,W.useEffect)(()=>s(a.q),[e.key,a.q]),(0,W.useEffect)(()=>{if(o===a.q)return;let e=window.location.href,t=window.setTimeout(()=>{window.location.href===e&&r(e=>Re(e,{q:o}),{replace:!0})},150);return()=>window.clearTimeout(t)},[o,a.q,e.key,r]),{query:a,search:o,setSearch:s,sort:e=>r(t=>Re(t,{sort:e,dir:a.sort===e&&a.dir===`asc`?`desc`:`asc`,q:o})),clear:()=>{s(``),r(e=>Re(e,{q:``}))}}}var nt=P(W.lazy(()=>p(()=>import(`./BulkReplicationModal-BKMvS5oS.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40]),import.meta.url))),rt=P(W.lazy(()=>p(()=>import(`./BulkLifecycleModal-DZop33-2.js`),__vite__mapDeps([41,1,2,3,4,5,6,7,8,9,10,11,12,42,20,22,14,15,16,17,18,19,21,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40]),import.meta.url))),it=P(W.lazy(()=>p(()=>import(`./DeleteBucket-7E-iv0kN.js`),__vite__mapDeps([43,1,2,6,7,3,4,5,18,12,28,27,29,44,26]),import.meta.url))),at=h.h1`
  ${T.title}
  margin: 0 0 16px;
`,ot=h.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 16px;
  .bucketSearch {
    min-width: 160px;
    flex: 1 1 190px;
  }
  .bucketActions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: flex-end;
    gap: 8px;
    margin-left: auto;
  }
  .bucketView {
    display: flex;
    gap: 4px;
  }
  @media (max-width: 767.98px) {
    .bucketFreshness {
      order: 3;
      flex-basis: 100%;
    }
    .bucketSearch {
      flex-basis: 100%;
    }
    .bucketActions {
      flex-basis: 100%;
      /* Touch-sized controls and longer labels can exceed a phone's width;
         wrap the primary action instead of scrolling the page sideways. */
      flex-wrap: wrap;
      justify-content: flex-start;
      gap: 8px;
    }
    .bucketView {
      margin-right: auto;
    }
    .bucketActions > #create-bucket {
      margin-left: auto;
    }
  }
`,st=h.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  @media (max-width: 1199.98px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: 767.98px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,ct=h.div`
  ${T.caption}
  color: var(--muted-foreground);
  margin-bottom: 8px;
`,lt=h.div`
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  border-radius: var(--radius-card);
  min-height: 180px;
`,ut=()=>{let e=ce(),t=r(),n=S(),i=ve(),a=oe(se),o=!!a.features?.includes(`object-browser-only`),c=F(xe,[A.ADMIN_DATA_USAGE_INFO]),l=!o&&ne(a.permissions),{updateListing:d}=Te(),{query:p,search:te,setSearch:h,sort:_,clear:le}=tt(),[y,pe]=(0,W.useState)(),[b,x]=(0,W.useState)(!0),[me,he]=(0,W.useState)(!1),[C,ge]=(0,W.useState)(0),[w,T]=(0,W.useState)([]),[D,j]=(0,W.useState)(null),[M,N]=(0,W.useState)(null),[P,I]=(0,W.useState)(()=>{try{return ze(localStorage.getItem(`silo.buckets.view`))}catch{return`table`}}),L=(0,W.useCallback)(()=>ge(e=>e+1),[]);(0,W.useEffect)(()=>{e(ae(`ob_bucket_list`))},[e]),(0,W.useEffect)(()=>{let t=new AbortController;return x(!0),he(!1),g.buckets.listBuckets({signal:t.signal}).then(e=>{if(t.signal.aborted)return;if(!Array.isArray(e.data?.buckets))throw Error(n(`The bucket list could not be loaded.`));pe(e.data),d(e.data);let r=new Set(e.data.buckets.map(e=>e.name));T(e=>e.filter(e=>r.has(e)))}).catch(n=>{t.signal.aborted||(he(!0),e(re(ie(n))))}).finally(()=>{t.signal.aborted||x(!1)}),()=>t.abort()},[C,e,d,a.accountAccessKey,n]),(0,W.useEffect)(()=>{try{localStorage.setItem(`silo.buckets.view`,P)}catch{}},[P]);let R=y?.buckets||[],z=je(R.map(e=>e.name)),B=()=>{L(),z.refresh()},V=(0,W.useMemo)(()=>He(R,p,c,y?.usageUpdatedAt,z.records),[R,p.sort,p.dir,p.q,c,y?.usageUpdatedAt,z.records]),H=!o&&F(`*`,[A.S3_PUT_LIFECYCLE_CONFIGURATION,A.S3_PUT_REPLICATION_CONFIGURATION,A.S3_PUT_ACTIONS]),Ee=e=>T(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e]),G=()=>T(e=>Ue(e,V.filter(e=>Z(e.name,o).select).map(e=>e.name))),K=w.every(e=>F(e,O[E.BUCKET_LIFECYCLE],!0)),q=w.every(e=>F(e,[A.S3_PUT_REPLICATION_CONFIGURATION,A.S3_PUT_ACTIONS])),J=n(`Select one or more buckets first.`),Y=(e,t)=>w.length?e?void 0:be(t,n(`configure the selected buckets`)):J,Oe=e=>{j(null),e&&(T([]),L())},ke={canReadUsage:c,usageUpdatedAt:y?.usageUpdatedAt,obOnly:o,onSelect:H?Ee:void 0,onDelete:N},Ae=l?(0,X.jsx)(u,{id:`empty-create-bucket`,variant:`callAction`,label:n(`Create bucket`),onClick:()=>t(k.ADD_BUCKETS)}):void 0;return(0,X.jsxs)(De,{value:z,children:[(0,X.jsx)(_e,{open:D?.type===`replication`,children:D?.type===`replication`&&(0,X.jsx)(nt,{open:!0,buckets:D.names,closeModalAndRefresh:Oe})}),(0,X.jsx)(_e,{open:D?.type===`lifecycle`,children:D?.type===`lifecycle`&&(0,X.jsx)(rt,{open:!0,buckets:D.names,closeModalAndRefresh:Oe})}),(0,X.jsx)(_e,{open:M!==null,children:M!==null&&(0,X.jsx)(it,{deleteOpen:!0,selectedBucket:M,closeDeleteModalAndRefresh:e=>{N(null),e&&(T(e=>e.filter(e=>e!==M)),L())}})}),!o&&(0,X.jsx)(Ce,{label:n(`Buckets`),titleElement:`h1`,help:!0}),(0,X.jsxs)(ee,{children:[o&&(0,X.jsx)(at,{children:n(`Buckets`)}),(0,X.jsxs)(ot,{children:[(0,X.jsx)(`div`,{className:`bucketSearch`,children:(0,X.jsx)(Se,{id:`bucket-search`,placeholder:n(`Search buckets`),value:te,onChange:h,sx:{width:`100%`}})}),(0,X.jsxs)(`div`,{className:`bucketActions`,children:[(0,X.jsxs)(`div`,{className:`bucketView`,role:`group`,"aria-label":n(`Bucket view`),children:[(0,X.jsx)(u,{id:`buckets-view-table`,collapseOnSmall:!1,label:n(`Table`),variant:P===`table`?`secondary`:`ghost`,"aria-pressed":P===`table`,onClick:()=>I(`table`)}),(0,X.jsx)(u,{id:`buckets-view-cards`,collapseOnSmall:!1,label:n(`Cards`),variant:P===`cards`?`secondary`:`ghost`,"aria-pressed":P===`cards`,onClick:()=>I(`cards`)})]}),(0,X.jsx)(m,{id:`refresh-buckets`,"aria-label":n(`Refresh buckets`),size:`medium`,disabled:b||z.requesting,onClick:B,children:(0,X.jsx)(f,{})}),H&&(i?(0,X.jsx)(ye,{label:n(`Actions`),items:[{label:n(`Set replication`),icon:(0,X.jsx)(ue,{}),disabled:b||!w.length||!q,disabledReason:Y(q,[A.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>j({type:`replication`,names:[...w]})},{label:n(`Set lifecycle`),icon:(0,X.jsx)(de,{}),disabled:b||!w.length||!K,disabledReason:Y(K,O[E.BUCKET_LIFECYCLE]),onClick:()=>j({type:`lifecycle`,names:[...w]})}]}):(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(u,{id:`set-replication`,collapseOnSmall:!1,label:n(`Set replication`),icon:(0,X.jsx)(ue,{}),disabled:b||!w.length||!q,disabledReason:Y(q,[A.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>j({type:`replication`,names:[...w]})}),(0,X.jsx)(u,{id:`set-lifecycle`,collapseOnSmall:!1,label:n(`Set lifecycle`),icon:(0,X.jsx)(de,{}),disabled:b||!w.length||!K,disabledReason:Y(K,O[E.BUCKET_LIFECYCLE]),onClick:()=>j({type:`lifecycle`,names:[...w]})})]})),!o&&(0,X.jsx)(u,{id:`create-bucket`,label:n(`Create bucket`),icon:(0,X.jsx)(fe,{}),disabled:!l,disabledReason:l?void 0:be([A.S3_CREATE_BUCKET],n(`create a bucket`)),onClick:()=>t(k.ADD_BUCKETS),variant:`primary`,collapseOnSmall:!1})]})]}),(0,X.jsx)(Fe,{}),w.length>0&&(0,X.jsx)(ct,{role:`status`,children:s(n(w.length===1?`1 bucket selected`:`{count} buckets selected`),{count:w.length})}),b&&!y?(0,X.jsx)(lt,{children:(0,X.jsx)(we,{rows:5,columns:4})}):me&&!y?(0,X.jsx)(lt,{children:(0,X.jsx)(U,{compact:!0,icon:(0,X.jsx)(v,{}),title:n(`The bucket list could not be loaded.`),action:(0,X.jsx)(u,{id:`retry-buckets`,label:n(`Retry`),onClick:L})})}):V.length===0?(0,X.jsx)(lt,{children:p.q.trim()?(0,X.jsx)(U,{compact:!0,icon:(0,X.jsx)(v,{}),title:s(n(`No buckets match “{q}”`),{q:p.q.trim()}),action:(0,X.jsx)(u,{id:`clear-bucket-filter`,label:n(`Clear filter`),onClick:le})}):(0,X.jsx)(U,{icon:(0,X.jsx)(v,{}),title:n(`No buckets yet`),description:n(`Create a bucket to start storing objects.`),action:Ae})}):P===`table`?(0,X.jsx)(et,{...ke,records:V,query:p,onSort:_,selected:w,onSelectAll:G}):(0,X.jsx)(st,{role:`list`,"aria-label":n(`Buckets`),children:V.map(e=>(0,X.jsx)(Je,{...ke,bucket:e,selected:w.includes(e.name)},e.name))})]})]})};export{ut as default};