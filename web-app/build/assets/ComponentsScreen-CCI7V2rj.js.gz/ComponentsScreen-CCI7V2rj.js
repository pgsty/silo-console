const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./FluidHoverShowcase-Dt8I_RkE.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./mds-DIGH6qee.js","./DataTable-BYSboymT.js","./circle-slash--rXWxGP3.js","./hard-drive-3VTn43rb.js","./share-2-BdidIlRN.js","./pencil-C9uU-qzX.js","./shield-check-Ck7u_FdU.js","./trash-CLcijXUv.js","./circle-check-D_dLaEL9.js","./download-BcW4AzlU.js","./terminal-BntcYRTu.js","./Checkbox-PeexYhGw.js","./console-vendor-I3rSB1nD.js","./listPopup-D2sWpuy2.js","./useTableLayout-iKPn_-di.js","./Tabs-DBrkvLMv.js","./i18n-DR1ZnJgy.js","./lang-Cj6iPrRD.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,r as n,t as r}from"./react-vendor-UL3KVrSx.js";import{T as i}from"./shared-vendor-BQfq49S_.js";import{Cr as a,n as o}from"./store-CSj3S5xV.js";import{i as s,n as c}from"./lang-Cj6iPrRD.js";import{$ as l,H as u,Q as d,S as f,U as p,W as m,X as h,Z as ee,b as g,c as te,d as _,et as v,l as y,m as b,p as x,r as S,u as C,z as w}from"./mds-DIGH6qee.js";import{t as T}from"./database-C6KYMfNp.js";import{t as ne}from"./pencil-C9uU-qzX.js";import{t as E}from"./trash-CLcijXUv.js";import{t as D}from"./archive-tyuBBiTn.js";import{t as re}from"./info-Btc_5g7D.js";import{t as O}from"./Checkbox-PeexYhGw.js";import{n as k,t as ie}from"./HelpBox-DKSVhocj.js";import{t as ae}from"./SectionTitle-DUGS31lQ.js";import{t as A}from"./ModalBox-BmLHq9NK.js";import{t as j}from"./CommentBox-BP500OT4.js";import{t as M}from"./Autocomplete-LXxbIh7_.js";import{a as N,t as oe}from"./i18n-DR1ZnJgy.js";import{i as P,n as se,r as ce,t as F}from"./index-DS9oHWow.js";import{t as I}from"./typography-BkGdf5hc.js";import{t as le}from"./OverflowMenu-BXaJLHnS.js";import{t as L}from"./typography-asHlM3Pp.js";import{t as R}from"./StatusBadge-BENFvE6N.js";import{t as ue}from"./CliEquivalent-BI5vE9cH.js";import{t as de}from"./ConfirmDialog-CUxawWTz.js";import{A as fe,H as pe,J as z,K as B,U as me,V as he,W as V,X as ge,Y as H,Z as U,q as _e}from"./ConsoleKBar-DBHdlyUP.js";var W=e(t()),G=r(),K=i.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 280px), 1fr));
  gap: var(--space-16);
`,q=i.div`
  padding: var(--space-20);
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  color: var(--foreground);
  min-width: 0;
  h2 {
    ${I(`title`)} margin: 0 0 var(--space-16);
  }
`,ve=i.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--space-8);
`,ye=i.div`
  ${I(`caption`)}
  padding: var(--space-12) var(--space-4);
  text-align: center;
  border-radius: var(--radius-control);
  box-shadow: var(--shadow-1);
  background: ${({$color:e})=>e};
`,be=i.div`
  ${({$role:e})=>I(e)}
  padding: var(--space-8) 0;
  & + & {
    border-top: 1px solid var(--border);
  }
`,xe=i.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--space-24);
  padding: var(--space-16) 0;
`,Se=i(h)`
  ${I(`caption`)}
  padding: var(--space-16) var(--space-4);
  border-radius: var(--radius-control);
  text-align: center;
`,Ce=i.div`
  ${({$roleStyle:e})=>e}
  display: flex;
  align-items: center;
  height: var(--control-height);
  padding: 0 var(--control-padding);
  gap: var(--gap);
  border-radius: var(--radius-control);
  background: var(--hover);
  svg {
    width: var(--icon-size);
    height: var(--icon-size);
    color: var(--muted-foreground);
  }
`,J=()=>{let{compact:e,type:t,controlHeight:n}=l(),r=N();return(0,G.jsx)(`div`,{children:(0,G.jsxs)(Ce,{$roleStyle:t.body,children:[(0,G.jsx)(D,{}),(0,G.jsx)(`span`,{children:r(e?`Compact density`:`Default density`)}),(0,G.jsx)(`span`,{className:`silo-num`,children:c(r(`{height} px`),{height:n})})]})})},we=i.div`
  margin-top: var(--space-12);
  padding: var(--space-4);
  border-radius: var(--radius-control);
  background: var(--muted);
`,Te=i.div`
  width: 28px;
  height: 28px;
  border-radius: var(--radius-control);
  background: var(--foreground);
  transform: translateX(${({$moved:e})=>e?`140px`:`0`});
  opacity: ${({$moved:e})=>e?.6:1};
  transition:
    transform var(--dur-${({$tier:e})=>e})
      var(--ease-${({$tier:e})=>e}),
    opacity var(--dur-${({$tier:e})=>e})
      var(--ease-${({$tier:e})=>e});
  @media (prefers-reduced-motion: reduce) {
    transform: none;
  }
`,Ee=i.button`
  ${I(`body`,{weight:`semibold`})}
  padding: var(--space-8) var(--space-12);
  border: none;
  border-radius: var(--radius-control);
  color: var(--foreground);
  background: var(--tint);
  cursor: pointer;
  &:hover {
    background: var(--tint-hover);
  }
`,Y=({tier:e,label:t})=>{let[n,r]=(0,W.useState)(!1),i=N();return(0,G.jsxs)(`div`,{children:[(0,G.jsx)(Ee,{type:`button`,"aria-pressed":n,onClick:()=>r(!n),children:i(t)}),(0,G.jsx)(we,{children:(0,G.jsx)(Te,{"data-motion-tier":e,$tier:e,$moved:n})})]})},De={display:s(`Display type`),title:s(`Title type`),subtitle:s(`Subtitle type`),body:s(`Body type`),caption:s(`Caption type`),micro:s(`Micro type`)},Oe=()=>{let e=N();return(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(K,{children:[`light`,`dark`].map(t=>(0,G.jsxs)(q,{style:P(t===`light`?ce:se),children:[(0,G.jsx)(`h2`,{children:e(t===`light`?`Light palette`:`Dark palette`)}),(0,G.jsx)(ve,{children:Array.from({length:8},(t,n)=>(0,G.jsx)(ye,{$color:`var(--surface-${n+1})`,children:c(e(`Surface {level}`),{level:n+1})},n))}),(0,G.jsx)(`p`,{style:{marginTop:`var(--space-12)`,color:`var(--foreground)`},children:e(`Primary text`)}),(0,G.jsx)(`p`,{style:{color:`var(--muted-foreground)`},children:e(`Secondary text`)})]},t))}),(0,G.jsxs)(K,{children:[(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Typography roles`)}),Object.keys(S).map(t=>(0,G.jsxs)(be,{$role:t,children:[e(De[t]),` `,(0,G.jsxs)(`span`,{className:`silo-num`,children:[S[t].size,`/`,S[t].line]})]},t))]}),(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Shadow ladder`)}),(0,G.jsx)(xe,{children:Array.from({length:8},(e,t)=>(0,G.jsx)(Se,{offset:t,shadowLevel:t+1,children:t+1},t))}),(0,G.jsx)(`h2`,{children:e(`Density comparison`)}),(0,G.jsx)(d,{children:(0,G.jsx)(J,{})}),(0,G.jsx)(`div`,{style:{height:`var(--space-8)`}}),(0,G.jsx)(d,{density:`compact`,children:(0,G.jsx)(J,{})})]})]}),(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Motion tiers`)}),(0,G.jsxs)(K,{children:[(0,G.jsx)(Y,{tier:`fast`,label:s(`Fast · 80 ms`)}),(0,G.jsx)(Y,{tier:`moderate`,label:s(`Moderate · 160 ms`)}),(0,G.jsx)(Y,{tier:`slow`,label:s(`Slow · 240 ms`)})]})]})]})},X=i.section`
  display: grid;
  gap: 16px;
  padding: 24px;
  border-radius: 12px;
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  h2 {
    ${v(`title`)} margin: 0;
  }
  h3 {
    ${v(`subtitle`)} margin: 0;
  }
  .control-row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 12px;
  }
  .control-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 16px;
  }
  .inputItem {
    min-width: 0;
  }
  .inputLabel {
    margin-right: 8px;
  }
  .inputLabel > span {
    min-width: 0;
  }
`,ke=()=>{let e=N(),[t,n]=(0,W.useState)(!0),[r,i]=(0,W.useState)(`one`),[a,o]=(0,W.useState)(`one`),[s,c]=(0,W.useState)(null),[l,u]=(0,W.useState)(!1),[h,g]=(0,W.useState)(!1),[v,x]=(0,W.useState)(!1),S=[{label:e(`Default`),value:`one`},{label:e(`Compact`),value:`two`}];return(0,G.jsx)(ee,{level:3,children:(0,G.jsxs)(X,{id:`control-craft`,children:[(0,G.jsx)(`h2`,{children:e(`Control craft`)}),(0,G.jsx)(`p`,{children:e(`Hover, press or use Tab to inspect each control. All changes here are local demos.`)}),(0,G.jsx)(`h3`,{children:e(`Buttons and loading`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(p,{id:`press-80`,variant:`primary`,sx:{width:80},label:e(`Save`)}),(0,G.jsx)(p,{id:`press-400`,variant:`primary`,sx:{width:400,maxWidth:`100%`},label:e(`Create bucket`)}),(0,G.jsx)(p,{id:`control-secondary`,variant:`secondary`,label:e(`Secondary`)}),(0,G.jsx)(p,{id:`control-outline`,variant:`outline`,label:e(`Outline`)}),(0,G.jsx)(p,{id:`control-ghost`,variant:`ghost`,label:e(`Ghost`)}),(0,G.jsx)(p,{id:`control-danger`,variant:`danger`,label:e(`Delete`)}),(0,G.jsx)(p,{id:`control-disabled`,disabled:!0,disabledReason:e(`Select an object to download.`),label:e(`Disabled`)}),(0,G.jsx)(p,{id:`control-loading`,loading:!0,label:e(`Loading`)}),(0,G.jsx)(p,{id:`control-toggle-loading`,loading:v,label:e(`Save changes`),onClick:()=>{x(!0),setTimeout(()=>x(!1),1500)}}),(0,G.jsx)(f,{"aria-label":e(`Refresh`),children:(0,G.jsx)(w,{})})]}),(0,G.jsxs)(d,{density:`compact`,children:[(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(p,{id:`control-compact`,variant:`primary`,label:e(`Compact`)}),(0,G.jsx)(b,{id:`control-compact-input`,label:e(`Compact`),placeholder:e(`Name`)})]}),(0,G.jsx)(`div`,{id:`control-compact-help`,children:(0,G.jsx)(ie,{iconComponent:(0,G.jsx)(re,{}),title:e(`Compact`),help:e(`Usage is calculated by the server.`)})})]}),(0,G.jsx)(`h3`,{children:e(`Fields and validation`)}),(0,G.jsxs)(`div`,{className:`control-grid`,children:[(0,G.jsx)(b,{id:`control-input`,label:e(`Name`),placeholder:e(`Name`)}),(0,G.jsx)(b,{id:`control-password`,type:`password`,label:e(`Password`),defaultValue:`example`}),(0,G.jsx)(b,{id:`control-error`,label:e(`Name`),error:e(`A name is required.`)}),(0,G.jsx)(b,{id:`control-disabled-input`,label:e(`Disabled`),disabled:!0,value:e(`Unavailable`)}),(0,G.jsx)(b,{id:`control-disabled-empty`,label:e(`Disabled`),disabled:!0,placeholder:e(`Name`)}),(0,G.jsx)(b,{id:`control-number`,type:`number`,label:e(`Capacity`),defaultValue:20}),(0,G.jsx)(_,{id:`control-select`,label:e(`Density`),value:a,options:S,onChange:o}),(0,G.jsx)(_,{id:`control-disabled-select`,label:e(`Disabled`),value:`one`,options:S,onChange:()=>{},disabled:!0}),(0,G.jsx)(_,{id:`control-error-select`,label:e(`Density`),options:S,onChange:()=>{},error:e(`A name is required.`),placeholder:e(`Select`)}),(0,G.jsx)(_,{id:`control-disabled-placeholder`,label:e(`Disabled`),options:S,onChange:()=>{},disabled:!0,placeholder:e(`Select`)}),(0,G.jsx)(M,{id:`control-autocomplete`,label:e(`Search`),placeholder:e(`Select`),value:a,options:S,onChange:o}),(0,G.jsx)(M,{id:`control-error-autocomplete`,label:e(`Search`),placeholder:e(`Select`),options:S,onChange:()=>{},error:e(`A name is required.`)}),(0,G.jsx)(M,{id:`control-disabled-autocomplete`,label:e(`Disabled`),placeholder:e(`Select`),options:S,onChange:()=>{},disabled:!0}),(0,G.jsx)(j,{id:`control-disabled-textarea`,label:e(`Disabled`),disabled:!0,placeholder:e(`Description`)}),(0,G.jsx)(j,{id:`control-textarea`,label:e(`Description`),placeholder:e(`Description`)})]}),(0,G.jsx)(`h3`,{children:e(`Selection controls`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(O,{id:`control-checkbox`,label:e(`Enabled`),checked:t,onChange:e=>n(e.target.checked)}),(0,G.jsx)(O,{id:`control-disabled-checkbox`,label:e(`Disabled`),disabled:!0,checked:!0,readOnly:!0}),(0,G.jsx)(U,{id:`control-switch`,label:e(`Enabled`),checked:t,onChange:e=>n(e.target.checked)}),(0,G.jsx)(U,{id:`control-disabled-switch`,label:e(`Disabled`),checked:!0,disabled:!0}),(0,G.jsx)(ge,{id:`control-radio`,name:`control-radio`,label:e(`Density`),currentValue:r,selectorOptions:S,onChange:e=>i(e.target.value)})]}),(0,G.jsx)(`h3`,{children:e(`Status and feedback`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(C,{id:`control-tag`,label:e(`Enabled`),color:`ok`}),(0,G.jsx)(C,{id:`control-tag-dot`,label:e(`Warning`),color:`warn`,variant:`dot`}),(0,G.jsx)(R,{tone:`danger`,label:e(`Offline`)}),(0,G.jsx)(R,{tone:`info`,label:e(`Built-in`),dot:!1}),(0,G.jsx)(m,{tooltip:e(`First tooltip`),children:(0,G.jsx)(p,{id:`control-tip-one`,label:e(`First tooltip`)})}),(0,G.jsx)(m,{tooltip:e(`Second tooltip`),children:(0,G.jsx)(p,{id:`control-tip-two`,label:e(`Second tooltip`)})})]}),(0,G.jsx)(k,{title:e(`Information`),tone:`info`,children:e(`Usage is calculated by the server.`)}),(0,G.jsx)(k,{title:e(`Warning`),tone:`warning`,contrast:`high`,children:e(`Above the 85% warning threshold`)}),(0,G.jsx)(y,{value:65,variant:`determinate`,progressLabel:!0,notificationLabel:e(`Progress`)}),(0,G.jsx)(y,{notificationLabel:e(`Loading`)}),(0,G.jsx)(`h3`,{children:e(`Dialogs`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[[`sm`,`lg`,`xl`].map(t=>(0,G.jsx)(p,{id:`control-dialog-${t}`,label:`${e(`Open Dialog`)} · ${t===`sm`?`400`:t===`lg`?`540`:`880`}`,onClick:()=>c(t)},t)),(0,G.jsx)(p,{id:`control-snackbar`,label:e(`Show notification`),onClick:()=>g(!0)})]}),(0,G.jsxs)(A,{open:s!==null,size:s||`lg`,title:e(`Dialog controls`),onClose:()=>c(null),children:[(0,G.jsxs)(`div`,{className:`control-grid`,style:{display:`grid`,gap:16},children:[(0,G.jsx)(b,{id:`dialog-name`,label:e(`Name`)}),(0,G.jsx)(_,{id:`dialog-select`,label:e(`Density`),value:a,options:S,onChange:o})]}),(0,G.jsxs)(`div`,{className:`control-row`,style:{display:`flex`,flexWrap:`wrap`,gap:8,justifyContent:`flex-end`,marginTop:24},children:[(0,G.jsx)(p,{id:`control-nested-open`,label:e(`Nested dialog`),onClick:()=>u(!0)}),(0,G.jsx)(p,{id:`control-dialog-cancel`,label:e(`Cancel`),onClick:()=>c(null)}),(0,G.jsx)(p,{id:`control-dialog-save`,variant:`primary`,label:e(`Save`),onClick:()=>c(null)})]}),(0,G.jsx)(A,{open:l,size:`sm`,title:e(`Nested dialog`),onClose:()=>u(!1),children:(0,G.jsx)(p,{id:`control-nested-close`,variant:`primary`,label:e(`Close`),onClick:()=>u(!1)})})]}),(0,G.jsx)(te,{open:h,onClose:()=>g(!1),message:e(`Demo action completed.`),closeButton:!0})]})})},Ae=(0,W.lazy)(()=>x(()=>import(`./FluidHoverShowcase-Dt8I_RkE.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]),import.meta.url)),je=i.div`
  color: var(--silo-text);
  display: grid;
  gap: var(--silo-space-24);
  margin-bottom: var(--silo-space-32);
  h1 {
    ${L.title} margin: 0 0 var(--silo-space-8);
  }
  h2 {
    ${L.section} margin: 0 0 var(--silo-space-16);
  }
  p {
    ${L.body} color: var(--silo-text-secondary);
    margin: 0;
  }
  a {
    color: var(--silo-primary);
  }
  #root & button.button-regular,
  #root & button.button-callAction {
    border-radius: var(--silo-radius-button);
    letter-spacing: normal;
  }
`,Me=i.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--silo-space-16);
  @media (max-width: ${F.lg-1}px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: ${F.md-1}px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Z=i.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--silo-space-16);
  @media (max-width: ${F.md-1}px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Q=i.div`
  min-width: 0;
  padding: var(--silo-space-20);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  border-radius: var(--silo-radius-card);
`,$=i.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--silo-space-12);
  & + & {
    margin-top: var(--silo-space-16);
  }
`,Ne=i.span`
  ${L.small}
  display: inline-flex;
  align-items: center;
  padding: var(--silo-space-8) var(--silo-space-12);
  border: 1px dashed var(--silo-border-strong);
  border-radius: var(--silo-radius-input);
  color: var(--silo-text-muted);
`,Pe=()=>{let[e,t]=(0,W.useState)(!1),[r,i]=(0,W.useState)(!0),[c,l]=(0,W.useState)(``),[d]=(0,W.useState)(()=>new Date(Date.now()-18e4).toISOString()),f=o(),m=N();return(0,W.useEffect)(()=>{f(a(`components`))},[]),(0,G.jsxs)(W.Fragment,{children:[(0,G.jsx)(fe,{label:s(`Components`),help:!0}),(0,G.jsxs)(g,{sx:{padding:24,[`@media (max-width: ${F.lg-1}px)`]:{padding:16},[`@media (max-width: ${F.md-1}px)`]:{padding:12}},children:[(0,G.jsxs)(je,{children:[(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h1`,{children:m(`SILO primitives`)}),(0,G.jsx)(`p`,{children:m(`Shared building blocks for storage, identity and monitoring.`)})]}),(0,G.jsx)(ke,{}),(0,G.jsx)(Oe,{}),(0,G.jsx)(W.Suspense,{fallback:null,children:(0,G.jsx)(Ae,{})}),(0,G.jsxs)(Me,{children:[(0,G.jsx)(V,{label:m(`Capacity`),icon:(0,G.jsx)(T,{}),value:`7.2`,unit:`TiB`,subline:m(`Healthy capacity`),progress:{value:.72},footer:(0,G.jsx)(B,{at:d,prefix:`Calculated`})}),(0,G.jsx)(V,{label:m(`Capacity warning`),icon:(0,G.jsx)(T,{}),value:`8.7`,unit:`TiB`,subline:m(`Above the 85% warning threshold`),progress:{value:.87}}),(0,G.jsx)(V,{label:m(`Capacity critical`),icon:(0,G.jsx)(T,{}),value:`9.6`,unit:`TiB`,subline:m(`Above the 95% critical threshold`),progress:{value:.96}}),(0,G.jsx)(V,{label:m(`Buckets`),icon:(0,G.jsx)(D,{}),value:`28`,subline:m(`Usage is calculated by the server.`),footer:(0,G.jsx)(n,{to:`/buckets`,children:m(`View buckets`)})})]}),(0,G.jsxs)(Z,{children:[(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:m(`Status and values`)}),(0,G.jsxs)($,{children:[(0,G.jsx)(R,{tone:`success`,label:m(`Online`)}),(0,G.jsx)(R,{tone:`warning`,label:m(`Healing`)}),(0,G.jsx)(R,{tone:`danger`,label:m(`Offline`)}),(0,G.jsx)(R,{tone:`neutral`,label:m(`Disabled`)}),(0,G.jsx)(R,{tone:`info`,label:m(`Built-in`),dot:!1})]}),(0,G.jsxs)($,{children:[(0,G.jsx)(H,{label:m(`Versioning`),value:(0,G.jsx)(R,{tone:r?`success`:`neutral`,label:m(r?`Enabled`:`Disabled`)}),onEdit:()=>i(e=>!e)}),(0,G.jsx)(H,{label:m(`Objects`),value:(0,G.jsx)(`span`,{className:`silo-num`,children:`1,248`})})]})]}),(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:m(`Freshness and actions`)}),(0,G.jsxs)($,{children:[(0,G.jsx)(B,{at:d}),(0,G.jsx)(B,{}),(0,G.jsx)(B,{at:d,pending:!0})]}),(0,G.jsxs)($,{children:[(0,G.jsx)(_e,{reason:m(`Select an object to inspect its details.`),children:(0,G.jsx)(Ne,{children:m(`Object details`)})}),(0,G.jsx)(le,{items:[{label:m(`Delete`),icon:(0,G.jsx)(E,{}),danger:!0,onClick:()=>l(m(`Demo action completed.`))},{label:m(`Refresh`),icon:(0,G.jsx)(w,{}),onClick:()=>l(m(`Demo action completed.`))},{label:m(`Edit`),icon:(0,G.jsx)(ne,{}),onClick:()=>l(m(`Demo action completed.`))},{label:m(`Download`),disabled:!0,disabledReason:m(`Select an object to download.`),onClick:()=>{}}]})]}),(0,G.jsx)(`p`,{role:`status`,children:c})]})]}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{children:m(`Empty and unavailable states`)}),(0,G.jsxs)(Z,{children:[(0,G.jsx)(Q,{children:(0,G.jsx)(z,{icon:(0,G.jsx)(D,{}),title:m(`No buckets yet`),description:m(`Create a bucket to start storing objects.`),docsUrl:`https://silo.pgsty.com/`,action:(0,G.jsx)(p,{id:`showcase-create-bucket`,type:`button`,variant:`callAction`,label:m(`Create bucket`),onClick:()=>l(m(`Demo action completed.`))})})}),(0,G.jsx)(Q,{children:(0,G.jsx)(z,{compact:!0,icon:(0,G.jsx)(D,{}),title:m(`No matching objects`),description:m(`Try a different name or clear the search filter.`)})}),(0,G.jsx)(Q,{children:(0,G.jsx)(me,{title:m(`Metrics are unavailable`),description:m(`Connect a Prometheus endpoint to view monitoring metrics.`),docsUrl:`https://silo.pgsty.com/`})}),(0,G.jsx)(Q,{children:(0,G.jsx)(pe,{required:[`admin:ServerInfo`,`s3:ListAllMyBuckets`]})})]})]}),(0,G.jsxs)(Z,{children:[(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:m(`Loading rows`)}),(0,G.jsx)(he,{columns:3})]}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{children:m(`Command preview`)}),(0,G.jsx)(ue,{alias:`silo`,commands:[`mcli ls ALIAS`,`mcli version info ALIAS/demo-data`]})]})]})]}),(0,G.jsxs)(u,{container:!0,children:[(0,G.jsx)(u,{item:!0,xs:12,children:(0,G.jsx)(ae,{children:m(`Confirm Dialogs`)})}),(0,G.jsx)(u,{item:!0,xs:12,children:(0,G.jsx)(`p`,{children:m(`Used to confirm a non-idempotent action.`)})}),(0,G.jsxs)(u,{item:!0,xs:12,children:[(0,G.jsx)(p,{id:`open-dialog-test`,type:`button`,variant:`regular`,onClick:()=>{t(!0)},label:m(`Open Dialog`)}),(0,G.jsx)(de,{destructive:!0,title:m(`Delete Bucket`),confirmText:m(`Delete`),isOpen:e,titleIcon:(0,G.jsx)(E,{}),isLoading:!1,onConfirm:()=>{t(!1)},onClose:()=>{t(!1)},confirmationContent:(0,G.jsxs)(W.Fragment,{children:[oe(m(`Are you sure you want to delete bucket {bucket}?`),{bucket:(0,G.jsx)(`b`,{children:`bucket`})}),(0,G.jsx)(`br`,{}),m(`A bucket can only be deleted if it's empty.`)]})})]})]})]})]})};export{Pe as default};