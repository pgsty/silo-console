const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./FluidHoverShowcase-COg0j8y3.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./mds-BO2rKL5Q.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./DataTable-Da20uHg8.js","./circle-slash-CrvuLA9v.js","./hard-drive-iK-fG8nk.js","./share-2-Be4ZbRAZ.js","./pencil-DBbyLqGZ.js","./shield-check-BChGe80Z.js","./trash-Bfbr9RVQ.js","./circle-check-BITyuNum.js","./download-CTASypiU.js","./terminal-DZv0PdMU.js","./Checkbox-CkIkx1jU.js","./console-vendor-I3rSB1nD.js","./listPopup-D2sWpuy2.js","./useTableLayout-BqOhLQsu.js","./Tabs-DlsZw24K.js","./i18n-Bv0O4wSF.js","./lang-deC2ggFn.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,r as n,t as r}from"./react-vendor-UL3KVrSx.js";import{i,n as a}from"./lang-deC2ggFn.js";import{G as o,J as s,K as c,L as l,P as u,Q as d,R as f,Y as p,_ as ee,a as m,h,i as te,l as g,o as _,ot as v,q as y,s as b,z as x}from"./mds-BO2rKL5Q.js";import{T as S}from"./shared-vendor-BQfq49S_.js";import{Or as C,r as w}from"./store-BGxI9kEo.js";import{t as T}from"./database-DCJdnYKd.js";import{t as E}from"./pencil-DBbyLqGZ.js";import{t as D}from"./trash-Bfbr9RVQ.js";import{t as O}from"./archive-CTc9EA80.js";import{t as ne}from"./info-Bv343I8W.js";import{t as k}from"./Checkbox-CkIkx1jU.js";import{n as A,t as re}from"./HelpBox-DK62dRpK.js";import{t as ie}from"./SectionTitle-BVdhf7cL.js";import{t as j}from"./ModalBox-DT-uaPZI.js";import{t as M}from"./CommentBox-D6E6pjDC.js";import{t as N}from"./Autocomplete-CLLGeTw8.js";import{a as P,t as ae}from"./i18n-Bv0O4wSF.js";import{i as oe,n as se,r as ce,t as F}from"./index-UVRc8OT4.js";import{t as le}from"./OverflowMenu-DC4Ttstq.js";import{t as I}from"./typography-DqmBZROV.js";import{t as L}from"./StatusBadge-C5OEbTRh.js";import{t as ue}from"./CliEquivalent-BDBaceFv.js";import{t as de}from"./ConfirmDialog-DX63qcXf.js";import{A as fe,H as pe,J as R,K as z,U as B,V as me,W as V,X as he,Y as H,Z as U,q as ge}from"./ConsoleKBar-DWQBCirp.js";var W=e(t()),G=r(),K=S.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 280px), 1fr));
  gap: var(--space-16);
`,q=S.div`
  padding: var(--space-20);
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  color: var(--foreground);
  min-width: 0;
  h2 {
    ${p(`title`)} margin: 0 0 var(--space-16);
  }
`,_e=S.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--space-8);
`,ve=S.div`
  ${p(`caption`)}
  padding: var(--space-12) var(--space-4);
  text-align: center;
  border-radius: var(--radius-control);
  box-shadow: var(--shadow-1);
  background: ${({$color:e})=>e};
`,ye=S.div`
  ${({$role:e})=>p(e)}
  padding: var(--space-8) 0;
  & + & {
    border-top: 1px solid var(--border);
  }
`,be=S.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--space-24);
  padding: var(--space-16) 0;
`,xe=S(o)`
  ${p(`caption`)}
  padding: var(--space-16) var(--space-4);
  border-radius: var(--radius-control);
  text-align: center;
`,Se=S.div`
  ${({$roleStyle:e})=>e}
  display: flex;
  align-items: center;
  height: var(--control-height);
  padding: 0 var(--control-padding);
  gap: var(--gap);
  border-radius: var(--radius-control);
  background: var(--hover);
  svg {
    width: var(--icon-size);
    height: var(--icon-size);
    color: var(--muted-foreground);
  }
`,J=()=>{let{compact:e,type:t,controlHeight:n}=s(),r=P();return(0,G.jsx)(`div`,{children:(0,G.jsxs)(Se,{$roleStyle:t.body,children:[(0,G.jsx)(O,{}),(0,G.jsx)(`span`,{children:r(e?`Compact density`:`Default density`)}),(0,G.jsx)(`span`,{className:`silo-num`,children:a(r(`{height} px`),{height:n})})]})})},Ce=S.div`
  margin-top: var(--space-12);
  padding: var(--space-4);
  border-radius: var(--radius-control);
  background: var(--muted);
`,we=S.div`
  width: 28px;
  height: 28px;
  border-radius: var(--radius-control);
  background: var(--foreground);
  transform: translateX(${({$moved:e})=>e?`140px`:`0`});
  opacity: ${({$moved:e})=>e?.6:1};
  transition:
    transform var(--dur-${({$tier:e})=>e})
      var(--ease-${({$tier:e})=>e}),
    opacity var(--dur-${({$tier:e})=>e})
      var(--ease-${({$tier:e})=>e});
  @media (prefers-reduced-motion: reduce) {
    transform: none;
  }
`,Te=S.button`
  ${p(`body`,{weight:`semibold`})}
  padding: var(--space-8) var(--space-12);
  border: none;
  border-radius: var(--radius-control);
  color: var(--foreground);
  background: var(--tint);
  cursor: pointer;
  &:hover {
    background: var(--tint-hover);
  }
`,Y=({tier:e,label:t})=>{let[n,r]=(0,W.useState)(!1),i=P();return(0,G.jsxs)(`div`,{children:[(0,G.jsx)(Te,{type:`button`,"aria-pressed":n,onClick:()=>r(!n),children:i(t)}),(0,G.jsx)(Ce,{children:(0,G.jsx)(we,{"data-motion-tier":e,$tier:e,$moved:n})})]})},Ee={display:i(`Display type`),title:i(`Title type`),subtitle:i(`Subtitle type`),body:i(`Body type`),caption:i(`Caption type`),micro:i(`Micro type`)},De=()=>{let e=P();return(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(K,{children:[`light`,`dark`].map(t=>(0,G.jsxs)(q,{style:oe(t===`light`?ce:se),children:[(0,G.jsx)(`h2`,{children:e(t===`light`?`Light palette`:`Dark palette`)}),(0,G.jsx)(_e,{children:Array.from({length:8},(t,n)=>(0,G.jsx)(ve,{$color:`var(--surface-${n+1})`,children:a(e(`Surface {level}`),{level:n+1})},n))}),(0,G.jsx)(`p`,{style:{marginTop:`var(--space-12)`,color:`var(--foreground)`},children:e(`Primary text`)}),(0,G.jsx)(`p`,{style:{color:`var(--muted-foreground)`},children:e(`Secondary text`)})]},t))}),(0,G.jsxs)(K,{children:[(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Typography roles`)}),Object.keys(d).map(t=>(0,G.jsxs)(ye,{$role:t,children:[e(Ee[t]),` `,(0,G.jsxs)(`span`,{className:`silo-num`,children:[d[t].size,`/`,d[t].line]})]},t))]}),(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Shadow ladder`)}),(0,G.jsx)(be,{children:Array.from({length:8},(e,t)=>(0,G.jsx)(xe,{offset:t,shadowLevel:t+1,children:t+1},t))}),(0,G.jsx)(`h2`,{children:e(`Density comparison`)}),(0,G.jsx)(y,{children:(0,G.jsx)(J,{})}),(0,G.jsx)(`div`,{style:{height:`var(--space-8)`}}),(0,G.jsx)(y,{density:`compact`,children:(0,G.jsx)(J,{})})]})]}),(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Motion tiers`)}),(0,G.jsxs)(K,{children:[(0,G.jsx)(Y,{tier:`fast`,label:i(`Fast · 80 ms`)}),(0,G.jsx)(Y,{tier:`moderate`,label:i(`Moderate · 160 ms`)}),(0,G.jsx)(Y,{tier:`slow`,label:i(`Slow · 240 ms`)})]})]})]})},Oe=S.section`
  display: grid;
  gap: 16px;
  padding: 24px;
  border-radius: 12px;
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  h2 {
    ${p(`title`)} margin: 0;
  }
  h3 {
    ${p(`subtitle`)} margin: 0;
  }
  .control-row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 12px;
  }
  .control-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 16px;
  }
  .inputItem {
    min-width: 0;
  }
  .inputLabel {
    margin-right: 8px;
  }
  .inputLabel > span {
    min-width: 0;
  }
`,ke=()=>{let e=P(),[t,n]=(0,W.useState)(!0),[r,i]=(0,W.useState)(`one`),[a,o]=(0,W.useState)(`one`),[s,l]=(0,W.useState)(null),[d,p]=(0,W.useState)(!1),[h,v]=(0,W.useState)(!1),[S,C]=(0,W.useState)(!1),w=[{label:e(`Default`),value:`one`},{label:e(`Compact`),value:`two`}];return(0,G.jsx)(c,{level:3,children:(0,G.jsxs)(Oe,{id:`control-craft`,children:[(0,G.jsx)(`h2`,{children:e(`Control craft`)}),(0,G.jsx)(`p`,{children:e(`Hover, press or use Tab to inspect each control. All changes here are local demos.`)}),(0,G.jsx)(`h3`,{children:e(`Buttons and loading`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(f,{id:`press-80`,variant:`primary`,sx:{width:80},label:e(`Save`)}),(0,G.jsx)(f,{id:`press-400`,variant:`primary`,sx:{width:400,maxWidth:`100%`},label:e(`Create bucket`)}),(0,G.jsx)(f,{id:`control-secondary`,variant:`secondary`,label:e(`Secondary`)}),(0,G.jsx)(f,{id:`control-outline`,variant:`outline`,label:e(`Outline`)}),(0,G.jsx)(f,{id:`control-ghost`,variant:`ghost`,label:e(`Ghost`)}),(0,G.jsx)(f,{id:`control-danger`,variant:`danger`,label:e(`Delete`)}),(0,G.jsx)(f,{id:`control-disabled`,disabled:!0,disabledReason:e(`Select an object to download.`),label:e(`Disabled`)}),(0,G.jsx)(f,{id:`control-loading`,loading:!0,label:e(`Loading`)}),(0,G.jsx)(f,{id:`control-toggle-loading`,loading:S,label:e(`Save changes`),onClick:()=>{C(!0),setTimeout(()=>C(!1),1500)}}),(0,G.jsx)(ee,{"aria-label":e(`Refresh`),children:(0,G.jsx)(u,{})})]}),(0,G.jsxs)(y,{density:`compact`,children:[(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(f,{id:`control-compact`,variant:`primary`,label:e(`Compact`)}),(0,G.jsx)(g,{id:`control-compact-input`,label:e(`Compact`),placeholder:e(`Name`)})]}),(0,G.jsx)(`div`,{id:`control-compact-help`,children:(0,G.jsx)(re,{iconComponent:(0,G.jsx)(ne,{}),title:e(`Compact`),help:e(`Usage is calculated by the server.`)})})]}),(0,G.jsx)(`h3`,{children:e(`Fields and validation`)}),(0,G.jsxs)(`div`,{className:`control-grid`,children:[(0,G.jsx)(g,{id:`control-input`,label:e(`Name`),placeholder:e(`Name`)}),(0,G.jsx)(g,{id:`control-password`,type:`password`,label:e(`Password`),defaultValue:`example`}),(0,G.jsx)(g,{id:`control-error`,label:e(`Name`),error:e(`A name is required.`)}),(0,G.jsx)(g,{id:`control-disabled-input`,label:e(`Disabled`),disabled:!0,value:e(`Unavailable`)}),(0,G.jsx)(g,{id:`control-disabled-empty`,label:e(`Disabled`),disabled:!0,placeholder:e(`Name`)}),(0,G.jsx)(g,{id:`control-number`,type:`number`,label:e(`Capacity`),defaultValue:20}),(0,G.jsx)(b,{id:`control-select`,label:e(`Density`),value:a,options:w,onChange:o}),(0,G.jsx)(b,{id:`control-disabled-select`,label:e(`Disabled`),value:`one`,options:w,onChange:()=>{},disabled:!0}),(0,G.jsx)(b,{id:`control-error-select`,label:e(`Density`),options:w,onChange:()=>{},error:e(`A name is required.`),placeholder:e(`Select`)}),(0,G.jsx)(b,{id:`control-disabled-placeholder`,label:e(`Disabled`),options:w,onChange:()=>{},disabled:!0,placeholder:e(`Select`)}),(0,G.jsx)(N,{id:`control-autocomplete`,label:e(`Search`),placeholder:e(`Select`),value:a,options:w,onChange:o}),(0,G.jsx)(N,{id:`control-error-autocomplete`,label:e(`Search`),placeholder:e(`Select`),options:w,onChange:()=>{},error:e(`A name is required.`)}),(0,G.jsx)(N,{id:`control-disabled-autocomplete`,label:e(`Disabled`),placeholder:e(`Select`),options:w,onChange:()=>{},disabled:!0}),(0,G.jsx)(M,{id:`control-disabled-textarea`,label:e(`Disabled`),disabled:!0,placeholder:e(`Description`)}),(0,G.jsx)(M,{id:`control-textarea`,label:e(`Description`),placeholder:e(`Description`)})]}),(0,G.jsx)(`h3`,{children:e(`Selection controls`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(k,{id:`control-checkbox`,label:e(`Enabled`),checked:t,onChange:e=>n(e.target.checked)}),(0,G.jsx)(k,{id:`control-disabled-checkbox`,label:e(`Disabled`),disabled:!0,checked:!0,readOnly:!0}),(0,G.jsx)(U,{id:`control-switch`,label:e(`Enabled`),checked:t,onChange:e=>n(e.target.checked)}),(0,G.jsx)(U,{id:`control-disabled-switch`,label:e(`Disabled`),checked:!0,disabled:!0}),(0,G.jsx)(he,{id:`control-radio`,name:`control-radio`,label:e(`Density`),currentValue:r,selectorOptions:w,onChange:e=>i(e.target.value)})]}),(0,G.jsx)(`h3`,{children:e(`Status and feedback`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(_,{id:`control-tag`,label:e(`Enabled`),color:`ok`}),(0,G.jsx)(_,{id:`control-tag-dot`,label:e(`Warning`),color:`warn`,variant:`dot`}),(0,G.jsx)(L,{tone:`danger`,label:e(`Offline`)}),(0,G.jsx)(L,{tone:`info`,label:e(`Built-in`),dot:!1}),(0,G.jsx)(x,{tooltip:e(`First tooltip`),children:(0,G.jsx)(f,{id:`control-tip-one`,label:e(`First tooltip`)})}),(0,G.jsx)(x,{tooltip:e(`Second tooltip`),children:(0,G.jsx)(f,{id:`control-tip-two`,label:e(`Second tooltip`)})})]}),(0,G.jsx)(A,{title:e(`Information`),tone:`info`,children:e(`Usage is calculated by the server.`)}),(0,G.jsx)(A,{title:e(`Warning`),tone:`warning`,contrast:`high`,children:e(`Above the 85% warning threshold`)}),(0,G.jsx)(m,{value:65,variant:`determinate`,progressLabel:!0,notificationLabel:e(`Progress`)}),(0,G.jsx)(m,{notificationLabel:e(`Loading`)}),(0,G.jsx)(`h3`,{children:e(`Dialogs`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[[`sm`,`lg`,`xl`].map(t=>(0,G.jsx)(f,{id:`control-dialog-${t}`,label:`${e(`Open Dialog`)} · ${t===`sm`?`400`:t===`lg`?`540`:`880`}`,onClick:()=>l(t)},t)),(0,G.jsx)(f,{id:`control-snackbar`,label:e(`Show notification`),onClick:()=>v(!0)})]}),(0,G.jsxs)(j,{open:s!==null,size:s||`lg`,title:e(`Dialog controls`),onClose:()=>l(null),children:[(0,G.jsxs)(`div`,{className:`control-grid`,style:{display:`grid`,gap:16},children:[(0,G.jsx)(g,{id:`dialog-name`,label:e(`Name`)}),(0,G.jsx)(b,{id:`dialog-select`,label:e(`Density`),value:a,options:w,onChange:o})]}),(0,G.jsxs)(`div`,{className:`control-row`,style:{display:`flex`,flexWrap:`wrap`,gap:8,justifyContent:`flex-end`,marginTop:24},children:[(0,G.jsx)(f,{id:`control-nested-open`,label:e(`Nested dialog`),onClick:()=>p(!0)}),(0,G.jsx)(f,{id:`control-dialog-cancel`,label:e(`Cancel`),onClick:()=>l(null)}),(0,G.jsx)(f,{id:`control-dialog-save`,variant:`primary`,label:e(`Save`),onClick:()=>l(null)})]}),(0,G.jsx)(j,{open:d,size:`sm`,title:e(`Nested dialog`),onClose:()=>p(!1),children:(0,G.jsx)(f,{id:`control-nested-close`,variant:`primary`,label:e(`Close`),onClick:()=>p(!1)})})]}),(0,G.jsx)(te,{open:h,onClose:()=>v(!1),message:e(`Demo action completed.`),closeButton:!0})]})})},Ae=(0,W.lazy)(()=>v(()=>import(`./FluidHoverShowcase-COg0j8y3.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]),import.meta.url)),X=S.div`
  color: var(--silo-text);
  display: grid;
  gap: var(--silo-space-24);
  margin-bottom: var(--silo-space-32);
  h1 {
    ${I.title} margin: 0 0 var(--silo-space-8);
  }
  h2 {
    ${I.section} margin: 0 0 var(--silo-space-16);
  }
  p {
    ${I.body} color: var(--silo-text-secondary);
    margin: 0;
  }
  a {
    color: var(--silo-primary);
  }
  #root & button.button-regular,
  #root & button.button-callAction {
    border-radius: var(--silo-radius-button);
    letter-spacing: normal;
  }
`,je=S.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--silo-space-16);
  @media (max-width: ${F.lg-1}px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: ${F.md-1}px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Z=S.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--silo-space-16);
  @media (max-width: ${F.md-1}px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Q=S.div`
  min-width: 0;
  padding: var(--silo-space-20);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  border-radius: var(--silo-radius-card);
`,$=S.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--silo-space-12);
  & + & {
    margin-top: var(--silo-space-16);
  }
`,Me=S.span`
  ${I.small}
  display: inline-flex;
  align-items: center;
  padding: var(--silo-space-8) var(--silo-space-12);
  border: 1px dashed var(--silo-border-strong);
  border-radius: var(--silo-radius-input);
  color: var(--silo-text-muted);
`,Ne=()=>{let[e,t]=(0,W.useState)(!1),[r,a]=(0,W.useState)(!0),[o,s]=(0,W.useState)(``),[c]=(0,W.useState)(()=>new Date(Date.now()-18e4).toISOString()),d=w(),p=P();return(0,W.useEffect)(()=>{d(C(`components`))},[]),(0,G.jsxs)(W.Fragment,{children:[(0,G.jsx)(fe,{label:i(`Components`),help:!0}),(0,G.jsxs)(h,{sx:{padding:24,[`@media (max-width: ${F.lg-1}px)`]:{padding:16},[`@media (max-width: ${F.md-1}px)`]:{padding:12}},children:[(0,G.jsxs)(X,{children:[(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h1`,{children:p(`SILO primitives`)}),(0,G.jsx)(`p`,{children:p(`Shared building blocks for storage, identity and monitoring.`)})]}),(0,G.jsx)(ke,{}),(0,G.jsx)(De,{}),(0,G.jsx)(W.Suspense,{fallback:null,children:(0,G.jsx)(Ae,{})}),(0,G.jsxs)(je,{children:[(0,G.jsx)(V,{label:p(`Capacity`),icon:(0,G.jsx)(T,{}),value:`7.2`,unit:`TiB`,subline:p(`Healthy capacity`),progress:{value:.72},footer:(0,G.jsx)(z,{at:c,prefix:`Calculated`})}),(0,G.jsx)(V,{label:p(`Capacity warning`),icon:(0,G.jsx)(T,{}),value:`8.7`,unit:`TiB`,subline:p(`Above the 85% warning threshold`),progress:{value:.87}}),(0,G.jsx)(V,{label:p(`Capacity critical`),icon:(0,G.jsx)(T,{}),value:`9.6`,unit:`TiB`,subline:p(`Above the 95% critical threshold`),progress:{value:.96}}),(0,G.jsx)(V,{label:p(`Buckets`),icon:(0,G.jsx)(O,{}),value:`28`,subline:p(`Usage is calculated by the server.`),footer:(0,G.jsx)(n,{to:`/buckets`,children:p(`View buckets`)})})]}),(0,G.jsxs)(Z,{children:[(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:p(`Status and values`)}),(0,G.jsxs)($,{children:[(0,G.jsx)(L,{tone:`success`,label:p(`Online`)}),(0,G.jsx)(L,{tone:`warning`,label:p(`Healing`)}),(0,G.jsx)(L,{tone:`danger`,label:p(`Offline`)}),(0,G.jsx)(L,{tone:`neutral`,label:p(`Disabled`)}),(0,G.jsx)(L,{tone:`info`,label:p(`Built-in`),dot:!1})]}),(0,G.jsxs)($,{children:[(0,G.jsx)(H,{label:p(`Versioning`),value:(0,G.jsx)(L,{tone:r?`success`:`neutral`,label:p(r?`Enabled`:`Disabled`)}),onEdit:()=>a(e=>!e)}),(0,G.jsx)(H,{label:p(`Objects`),value:(0,G.jsx)(`span`,{className:`silo-num`,children:`1,248`})})]})]}),(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:p(`Freshness and actions`)}),(0,G.jsxs)($,{children:[(0,G.jsx)(z,{at:c}),(0,G.jsx)(z,{}),(0,G.jsx)(z,{at:c,pending:!0})]}),(0,G.jsxs)($,{children:[(0,G.jsx)(ge,{reason:p(`Select an object to inspect its details.`),children:(0,G.jsx)(Me,{children:p(`Object details`)})}),(0,G.jsx)(le,{items:[{label:p(`Delete`),icon:(0,G.jsx)(D,{}),danger:!0,onClick:()=>s(p(`Demo action completed.`))},{label:p(`Refresh`),icon:(0,G.jsx)(u,{}),onClick:()=>s(p(`Demo action completed.`))},{label:p(`Edit`),icon:(0,G.jsx)(E,{}),onClick:()=>s(p(`Demo action completed.`))},{label:p(`Download`),disabled:!0,disabledReason:p(`Select an object to download.`),onClick:()=>{}}]})]}),(0,G.jsx)(`p`,{role:`status`,children:o})]})]}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{children:p(`Empty and unavailable states`)}),(0,G.jsxs)(Z,{children:[(0,G.jsx)(Q,{children:(0,G.jsx)(R,{icon:(0,G.jsx)(O,{}),title:p(`No buckets yet`),description:p(`Create a bucket to start storing objects.`),docsUrl:`https://silo.pgsty.com/`,action:(0,G.jsx)(f,{id:`showcase-create-bucket`,type:`button`,variant:`callAction`,label:p(`Create bucket`),onClick:()=>s(p(`Demo action completed.`))})})}),(0,G.jsx)(Q,{children:(0,G.jsx)(R,{compact:!0,icon:(0,G.jsx)(O,{}),title:p(`No matching objects`),description:p(`Try a different name or clear the search filter.`)})}),(0,G.jsx)(Q,{children:(0,G.jsx)(B,{title:p(`Metrics are unavailable`),description:p(`Connect a Prometheus endpoint to view monitoring metrics.`),docsUrl:`https://silo.pgsty.com/`})}),(0,G.jsx)(Q,{children:(0,G.jsx)(pe,{required:[`admin:ServerInfo`,`s3:ListAllMyBuckets`]})})]})]}),(0,G.jsxs)(Z,{children:[(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:p(`Loading rows`)}),(0,G.jsx)(me,{columns:3})]}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{children:p(`Command preview`)}),(0,G.jsx)(ue,{alias:`silo`,commands:[`mcli ls ALIAS`,`mcli version info ALIAS/demo-data`]})]})]})]}),(0,G.jsxs)(l,{container:!0,children:[(0,G.jsx)(l,{item:!0,xs:12,children:(0,G.jsx)(ie,{children:p(`Confirm Dialogs`)})}),(0,G.jsx)(l,{item:!0,xs:12,children:(0,G.jsx)(`p`,{children:p(`Used to confirm a non-idempotent action.`)})}),(0,G.jsxs)(l,{item:!0,xs:12,children:[(0,G.jsx)(f,{id:`open-dialog-test`,type:`button`,variant:`regular`,onClick:()=>{t(!0)},label:p(`Open Dialog`)}),(0,G.jsx)(de,{destructive:!0,title:p(`Delete Bucket`),confirmText:p(`Delete`),isOpen:e,titleIcon:(0,G.jsx)(D,{}),isLoading:!1,onConfirm:()=>{t(!1)},onClose:()=>{t(!1)},confirmationContent:(0,G.jsxs)(W.Fragment,{children:[ae(p(`Are you sure you want to delete bucket {bucket}?`),{bucket:(0,G.jsx)(`b`,{children:`bucket`})}),(0,G.jsx)(`br`,{}),p(`A bucket can only be deleted if it's empty.`)]})})]})]})]})]})};export{Ne as default};