import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{N as t,P as n,t as r}from"./react-vendor-UL3KVrSx.js";import{G as i,Y as a}from"./mds-BO2rKL5Q.js";import{T as o}from"./shared-vendor-BQfq49S_.js";import{c as s,i as c,n as l,o as u,r as d,s as f,t as p}from"./listPopup-D2sWpuy2.js";var m=e(n()),h=e(t()),g=r(),_=o(i)`
  ${c}
  position: fixed;
  z-index: 10000;
  min-width: 150px;
  max-width: calc(100vw - 16px);
  overflow: auto;
  padding: 4px;
  border-radius: var(--radius-popover, 12px);
  isolation: isolate;
  [data-fluid-highlight] {
    z-index: -1;
  }
`,v=o.div`
  ${a(`body`)}
  position: relative;
  display: flex;
  align-items: center;
  gap: var(--gap, 8px);
  height: var(--control-height, 36px);
  padding: 0 var(--control-padding, 12px);
  border-radius: var(--radius-control, 8px);
  color: var(--muted-foreground, #737373);
  cursor: pointer;
  outline: none;
  white-space: nowrap;
  user-select: none;
  &&:focus-visible {
    outline: none;
  }
  &[data-fluid-hover],
  &[aria-selected="true"] {
    color: var(--foreground, #171717);
  }
  &[aria-selected="true"] {
    font-weight: var(--fw-semibold, 550);
  }
  &[aria-disabled="true"] {
    cursor: not-allowed;
  }
  svg {
    width: var(--icon-size, 16px);
    height: var(--icon-size, 16px);
    flex-shrink: 0;
  }
  .label {
    display: grid;
    flex: 1;
    min-width: 0;
  }
  .label > span {
    grid-area: 1 / 1;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .measure {
    visibility: hidden;
    font-weight: var(--fw-semibold, 550);
  }
`,y=({id:e,options:t,selectedOption:n=``,onSelect:r,hideTriggerAction:i,open:a,anchorEl:o=null,useAnchorWidth:c=!1,anchorOrigin:y=`start`,role:b=`listbox`,ariaLabel:x,ariaLabelledBy:S,autoFocus:C=!0})=>{let w=(0,m.useRef)(null),T=(0,m.useRef)(null),E=(0,m.useRef)(!1),D=u(a,o,w,i,y,c),O=s(w,{gapClick:{maxDistance:16},disabled:!a,onActiveChange:n=>{if(!a||n===null)return;T.current=t[n]?.value??null;let r=w.current?.querySelector(`[data-fluid-index="${n}"]`);C?r?.focus({preventScroll:!0}):o?.setAttribute(`aria-activedescendant`,`${e}-option-${n}`)}}),k=()=>{o?.isConnected&&(o.matches(`button,input,[tabindex]`)?o:o.querySelector(`button,input:not([type=hidden]),[tabindex]`))?.focus({preventScroll:!0})},A=e=>{let n=t[e];n&&a&&(i(),k(),n.disabled||r(n.value,n.extraValue??null,n.label,e))};return(0,m.useLayoutEffect)(()=>{if(!a||!D.mounted){E.current=!1,T.current=null,o?.removeAttribute(`aria-activedescendant`);return}let e=p(w.current),t=(E.current?e.find(e=>e.contains(document.activeElement))||e.find(e=>e.dataset.fluidKey===T.current):void 0)||(C?e[0]:void 0);return E.current=!0,T.current=t?.dataset.fluidKey??null,C?(t||w.current)?.focus({preventScroll:!0}):t?o?.setAttribute(`aria-activedescendant`,t.id):o?.removeAttribute(`aria-activedescendant`),O.refresh(),()=>o?.removeAttribute(`aria-activedescendant`)},[a,D.mounted,t,C,o,O]),(0,m.useLayoutEffect)(()=>{if(!a)return;let e=w.current,n=o,r=n=>{if(!(n.isComposing||n.keyCode===229)){if(n.key===`Escape`)n.preventDefault(),n.stopPropagation();else if(n.key===`Tab`)d(e,o,i);else if(!(C&&l(n,e))){if(!C&&[`ArrowDown`,`ArrowUp`,`Home`,`End`].includes(n.key)){n.preventDefault(),n.stopPropagation();let e=t.map((e,t)=>e.disabled?-1:t).filter(e=>e>=0),r=e.indexOf(t.findIndex(e=>e.value===T.current)),i=n.key===`Home`?0:n.key===`End`?e.length-1:(r+(n.key===`ArrowDown`?1:-1)+e.length)%e.length;O.setActiveIndex(e[i]??null)}else if(n.key===`Enter`||C&&n.key===` `){let r=C&&e?.contains(document.activeElement)?document.activeElement?.closest(`[data-fluid-index]`):null,i=r?Number(r.dataset.fluidIndex):t.findIndex(e=>e.value===T.current);i>=0&&(n.preventDefault(),n.stopPropagation(),A(i))}}}},s=e=>{e.key===`Escape`&&(e.preventDefault(),e.stopPropagation(),i(),k())};return e?.addEventListener(`keydown`,r),e?.addEventListener(`keyup`,s),n?.addEventListener(`keydown`,r),n?.addEventListener(`keyup`,s),()=>{e?.removeEventListener(`keydown`,r),e?.removeEventListener(`keyup`,s),n?.removeEventListener(`keydown`,r),n?.removeEventListener(`keyup`,s)}}),D.mounted?(0,h.createPortal)((0,g.jsxs)(_,{ref:w,id:e,role:b,tabIndex:-1,offset:2,shadowLevel:3,"aria-label":x||(S?void 0:o?.getAttribute(`aria-label`)||o?.textContent||void 0),"aria-labelledby":S,"data-silo-popup":`true`,"data-popup-anchor":o?.id,"data-side":D.side,"data-closing":!a,style:D.style,onMouseDown:e=>{C||e.preventDefault()},children:[(0,g.jsx)(f,{hover:O,selected:!0}),(0,g.jsx)(f,{hover:O}),t.map((t,r)=>(0,g.jsxs)(v,{id:`${e}-option-${r}`,role:b===`listbox`?`option`:`menuitem`,"aria-selected":b===`listbox`?n===t.value:void 0,"aria-disabled":t.disabled||void 0,"data-fluid-selected":n===t.value,"data-fluid-index":r,"data-fluid-key":t.value,tabIndex:-1,className:n===t.value?`selected`:``,label:t.label,onClick:()=>A(r),children:[t.icon,(0,g.jsxs)(`span`,{className:`label`,children:[typeof t.label==`string`&&(0,g.jsx)(`span`,{"aria-hidden":`true`,className:`measure`,children:t.label}),(0,g.jsx)(`span`,{children:t.label})]}),t.indicator]},t.value))]}),document.body):null};export{y as default};