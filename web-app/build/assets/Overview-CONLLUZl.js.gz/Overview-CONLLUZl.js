import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,f as n,r,t as i}from"./react-vendor-UL3KVrSx.js";import{D as a,T as o}from"./shared-vendor-BQfq49S_.js";import{Dr as s,Qt as c,ir as l,n as u,or as d,r as f,rn as p,wn as m}from"./store-u0LCkSUK.js";import{i as h,n as g}from"./lang-BxJGrDHW.js";import{F as _,J as v,K as y,X as b,g as ee,w as x,z as S}from"./mds-YaKHoCCJ.js";import{t as te}from"./hard-drive-0vZvUa8O.js";import{t as C}from"./server-D-UisgoJ.js";import{t as w}from"./chevron-right-DxUDv501.js";import{t as ne}from"./circle-check-PKb6fSYx.js";import{t as T}from"./boxes-Dqlyn8ch.js";import{t as re}from"./archive-swEOSDZm.js";import{t as E}from"./info-CNve3BGk.js";import{c as D,s as O}from"./listPopup-D2sWpuy2.js";import{a as k,n as A}from"./i18n-CkC2HRew.js";import{n as j,o as M,t as N}from"./permissions-BaYWxI8a.js";import{t as P}from"./StatusBadge-QSmH-cfD.js";import{n as F}from"./SecureComponent-BuNNF0Qr.js";import{A as I,G as L,J as R,K as ie,V as z,W as B,a as ae,d as oe,o as se}from"./ConsoleKBar-CBawwh4j.js";var V=e(t()),H=e=>typeof e==`number`&&Number.isFinite(e)&&e>=0?e:void 0,U=e=>{let t=Array.isArray(e),n=t?e:[],r=n.flatMap(e=>e.drives??[]),i=t&&n.every(e=>Array.isArray(e.drives));return{serversOnline:t?n.filter(e=>e.state===`online`).length:void 0,serversTotal:t?n.length:void 0,serversOffline:n.filter(e=>e.state&&e.state!==`online`).length,drivesOnline:i?r.filter(e=>e.state===`ok`).length:void 0,drivesTotal:i?r.length:void 0,drivesOffline:r.filter(e=>e.state&&e.state!==`ok`).length,healing:r.filter(e=>e.healing===!0).length,incomplete:!t||!n.length||!i||n.some(e=>!e.state)||r.some(e=>!e.state)}},W=e=>{let t=H(e.totalSpace),n=H(e.usedSpace),r=H(e.availableSpace);return t!==void 0&&t>0?{total:t,used:n,available:r,ratio:n===void 0?void 0:n/t}:{total:void 0,used:void 0,available:void 0,ratio:void 0}},G=e=>{let t=e??[],n=t.flatMap(e=>e.drives??[]),r=n.map(W).filter(e=>e.total!==void 0),i=e=>{if(r.length&&r.every(t=>t[e]!==void 0))return H(r.reduce((t,n)=>t+n[e],0))},a=i(`total`),o=i(`used`),s=i(`available`);return{rawTotal:a,rawUsed:o,rawAvailable:s,usedRatio:a&&o!==void 0?o/a:void 0,measuredDrives:r.length,incomplete:!Array.isArray(e)||!t.length||t.some(e=>!Array.isArray(e.drives))||r.length!==n.length||o===void 0||s===void 0}},K=e=>{let t=!!(e.usageUpdatedAt&&a.fromISO(e.usageUpdatedAt).isValid),n=e=>t?H(e===void 0?0:e):void 0;return{computed:t,objects:n(e.objects),bytes:n(e.usage),buckets:H(e.buckets)??(e.buckets===void 0&&t?0:void 0)}},ce=(e,t)=>{let n=[],r=U(e.servers);r.serversOffline&&n.push({id:`servers-offline`,severity:`danger`,message:h(`{count} server(s) offline`),values:{count:r.serversOffline},href:`#overview-servers`}),r.drivesOffline&&n.push({id:`drives-offline`,severity:`danger`,message:h(`{count} drive(s) offline`),values:{count:r.drivesOffline},href:`#overview-servers`});for(let[t,r]of(e.servers??[]).entries())for(let[e,i]of(r.drives??[]).entries()){let r=W(i).ratio;r===void 0||r<.85||n.push({id:`drive-capacity-${t}-${e}`,severity:r>=.95?`danger`:`warning`,message:h(r>=.95?`Drive {drive} is at least 95% full. The server may reject writes.`:`Drive {drive} is at least 85% full.`),values:{drive:i.drivePath||i.endpoint||`${t+1}/${e+1}`},href:`#overview-servers`})}r.healing&&n.push({id:`healing`,severity:`warning`,message:h(`{count} drive(s) healing`),values:{count:r.healing},href:`#overview-servers`}),t&&n.push({id:`restart`,severity:`warning`,message:h(`Configuration changes are waiting for a server restart.`),href:`#restart-server`}),r.incomplete&&n.push({id:`health-unknown`,severity:`info`,message:h(`Some server or drive health information is unavailable.`)}),G(e.servers).incomplete&&n.push({id:`capacity-unknown`,severity:`info`,message:h(`Capacity is incomplete. Only reported drive measurements are shown.`)}),K(e).computed||n.push({id:`usage-pending`,severity:`info`,message:h(`The server has not finished computing usage yet.`)});let i={danger:0,warning:1,info:2};return n.sort((e,t)=>i[e.severity]-i[t.severity])},le=(e,t,n)=>[{id:`bucket`,label:h(`Create bucket`),path:`/buckets/${j.ADD_BUCKETS}`,allowed:c(e)},{id:`user`,label:h(`Create user`),path:j.USER_ADD,allowed:!t.includes(`ldap-idp`)&&n(`console-ui`,[M.ADMIN_CREATE_USER,M.ADMIN_LIST_USER_POLICIES,M.ADMIN_LIST_GROUPS,M.ADMIN_ATTACH_USER_OR_GROUP_POLICY],!0)},{id:`access-key`,label:h(`Create access key`),path:j.ACCOUNT_ADD,allowed:n(N,[M.ADMIN_CREATE_SERVICEACCOUNT])},{id:`health`,label:h(`Generate health report`),path:j.TOOLS_DIAGNOSTICS,allowed:n(N,[M.ADMIN_HEALTH_INFO])}].filter(e=>e.allowed),ue=async e=>(await m.admin.adminInfo({defaultOnly:!0},{signal:e})).data,de=({refreshMs:e=6e4}={})=>{let[t,n]=(0,V.useState)({refreshing:!0,error:!1}),r=(0,V.useRef)(),i=(0,V.useRef)(0),a=(0,V.useRef)(!1),o=(0,V.useCallback)(async()=>{if(!a.current)return;let e=++i.current;r.current?.abort();let t=new AbortController;r.current=t,n(e=>({...e,refreshing:!0,error:!1}));let o=()=>a.current&&e===i.current&&!t.signal.aborted;try{let e=await ue(t.signal);if(!e||typeof e!=`object`)throw Error(`Invalid admin info response`);o()&&n({data:e,refreshing:!1,error:!1})}catch{o()&&n(e=>({...e,refreshing:!1,error:!0}))}finally{e===i.current&&(r.current=void 0)}},[]);return(0,V.useEffect)(()=>{a.current=!0,o();let t,n=()=>{t!==void 0&&clearInterval(t),t=void 0,document.visibilityState===`visible`&&e>0&&(t=setInterval(()=>{document.visibilityState===`visible`&&o()},e))},s=()=>{n(),document.visibilityState===`visible`&&o()};return n(),document.addEventListener(`visibilitychange`,s),()=>{a.current=!1,i.current++,r.current?.abort(),r.current=void 0,t!==void 0&&clearInterval(t),document.removeEventListener(`visibilitychange`,s)}},[o,e]),{...t,refresh:o}},fe=o.div`
  .page-header {
    min-height: 56px;
    flex-wrap: nowrap;
  }
  .page-header .page-header-label,
  .page-header .page-header-actions {
    flex: 0 1 auto;
    width: auto;
    max-width: none;
    margin: 0;
  }
  .page-header .page-header-actions {
    flex-shrink: 0;
  }
`,pe=o.h1`
  ${b(`title`)}
  margin: 0;
`,me=o.div`
  display: grid;
  grid-template-columns: repeat(12, minmax(0, 1fr));
  gap: 16px;
  font-variant-numeric: tabular-nums;
  > * {
    min-width: 0;
  }
`,he=o.div`
  grid-column: 1 / -1;
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 16px;
  @media (max-width: 1199px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: 767px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,q=o(y)`
  grid-column: span ${({$columns:e})=>e??12};
  border-radius: var(--radius-card);
  padding: 20px;
  min-width: 0;
  @media (max-width: 1199px) {
    grid-column: 1 / -1;
  }
  @media (max-width: 767px) {
    padding: 16px;
  }
`,J=o.h2`
  ${b(`title`)}
  margin: 0 0 16px;
  color: var(--foreground);
`,Y=o.span`
  ${b(`caption`)}
  color: var(--muted-foreground);
`,X=o.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,ge=o.div`
  ${b(`body`)}
  grid-column: 1 / -1;
  display: flex;
  gap: 12px;
  align-items: center;
  padding: 12px 16px;
  border-radius: var(--radius-control);
  background: var(--hover);
  color: var(--foreground);
  svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
    fill: currentColor;
  }
`,_e=o.ul`
  ${b(`body`)}
  list-style: none;
  padding: 0;
  margin: 0;
  li {
    display: flex;
    gap: 12px;
    padding: 12px 0;
    align-items: flex-start;
  }
  li + li {
    border-top: 1px solid var(--border);
  }
  && li::before {
    content: none;
  }
  a,
  span {
    overflow-wrap: anywhere;
  }
  a {
    color: var(--foreground);
    text-underline-offset: 3px;
  }
  svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
    fill: currentColor;
  }
`,ve=o.span`
  display: inline-flex;
  margin-top: 2px;
  color: ${({$severity:e})=>`var(--${e===`danger`?`destructive`:e})`};
`,ye=o.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
  @media (max-width: 767px) {
    grid-template-columns: minmax(0, 1fr);
  }
  button {
    justify-content: flex-start;
  }
`,be=o.span`
  display: inline-block;
  width: 96px;
  height: 28px;
  background: var(--muted);
  border-radius: var(--radius-control);
`,xe=o.div`
  grid-column: 1 / -1;
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 16px;
  @media (max-width: 1199px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: 767px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Se=o(y)`
  min-width: 0;
  border-radius: var(--radius-card);
  padding: 16px;
  h2 {
    margin: 0 8px 12px;
  }
  nav {
    display: grid;
    gap: 4px;
  }
`,Z=o(r)`
  ${b(`body`)}
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: var(--control-height);
  padding: 4px 8px;
  color: var(--foreground);
  text-decoration: none;
  border-radius: var(--radius-control);
  transition: background var(--dur-fast) var(--ease-fast);
  span {
    display: flex;
    flex: 0 0 16px;
    color: var(--muted-foreground);
  }
  svg {
    width: 16px;
    height: 16px;
  }
  &:hover {
    background: var(--hover);
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  @media (pointer: coarse) {
    min-height: 40px;
  }
`,Q=i(),Ce=o.div`
  position: relative;
  table {
    position: relative;
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
  }
  th,
  td {
    ${b(`body`,{compact:!0})} text-align: left;
    padding: 8px;
    vertical-align: top;
    overflow-wrap: anywhere;
    border-bottom: 1px solid var(--border);
  }
  th {
    font-weight: 550;
    color: var(--foreground);
  }
  td {
    color: var(--muted-foreground);
  }
  th:first-child {
    width: 30%;
  }
  .server-row {
    cursor: pointer;
  }
  .server-row[data-fluid-hover="true"] td,
  .server-row:focus-within td {
    color: var(--foreground);
  }
  .server-row[data-fluid-hover="true"] td,
  .server-row[data-fluid-before="true"] td {
    border-bottom-color: transparent;
  }
  .endpoint {
    display: flex;
    align-items: center;
    gap: 4px;
  }
  .endpoint button {
    flex-shrink: 0;
  }
  .version {
    width: 20%;
  }
  @media (max-width: 1199px) {
    table {
      table-layout: auto;
    }
    .version {
      display: none;
    }
    th:first-child {
      width: 35%;
    }
  }
  @media (max-width: 767px) {
    .network,
    .uptime {
      display: none;
    }
    th,
    td {
      padding: 8px 4px;
    }
    th:first-child {
      width: 48%;
    }
  }
`,we=o.div`
  padding: 8px;
  background: var(--hover);
  border-radius: var(--radius-control);
  min-width: 0;
  ${Y} {
    color: var(--foreground);
  }
`,Te=o.dl`
  ${b(`caption`)}
  display: none;
  margin: 0 0 12px;
  gap: 8px;
  dt {
    color: var(--foreground);
  }
  dd {
    color: var(--foreground);
    margin: 0;
    overflow-wrap: anywhere;
  }
  @media (max-width: 1199px) {
    display: grid;
    grid-template-columns: max-content minmax(0, 1fr);
  }
`,Ee=o.ul`
  list-style: none;
  margin: 0;
  padding: 0;
  li {
    display: grid;
    grid-template-columns: minmax(0, 2fr) auto minmax(0, 2fr);
    gap: 12px;
    align-items: center;
    padding: 12px 0;
  }
  li + li {
    border-top: 1px solid var(--border);
  }
  && li::before {
    content: none;
  }
  .path {
    overflow-wrap: anywhere;
    color: var(--foreground);
  }
  @media (max-width: 767px) {
    li {
      grid-template-columns: minmax(0, 1fr) auto;
    }
    .drive-usage {
      grid-column: 1 / -1;
    }
  }
`,De=o.div`
  height: 4px;
  margin-top: 8px;
  background: var(--border);
  border-radius: var(--radius-pill);
  &::after {
    content: "";
    display: block;
    height: 100%;
    width: ${({$ratio:e})=>Math.min(1,e)*100}%;
    background: ${({$tone:e})=>`var(--silo-${e})`};
    border-radius: inherit;
  }
`,$=e=>e===void 0?`—`:l(`${e}`);function Oe({servers:e}){let t=k(),n=(0,V.useId)(),r=(0,V.useRef)(null),i=D(r,{gapClick:!1}),[a,o]=(0,V.useState)([]),s=(e,n)=>(0,Q.jsx)(P,{tone:e?e===n?`success`:`danger`:`neutral`,label:t(e?e===n?`Online`:`Offline`:`Unknown`)});return e?.length?(0,Q.jsx)(v,{density:`compact`,children:(0,Q.jsxs)(Ce,{ref:r,children:[(0,Q.jsx)(O,{hover:i}),(0,Q.jsxs)(`table`,{"aria-label":t(`Servers`),children:[(0,Q.jsx)(`thead`,{children:(0,Q.jsxs)(`tr`,{children:[(0,Q.jsx)(`th`,{scope:`col`,children:t(`Server`)}),(0,Q.jsx)(`th`,{scope:`col`,children:t(`Status`)}),(0,Q.jsx)(`th`,{scope:`col`,children:t(`Drives`)}),(0,Q.jsx)(`th`,{scope:`col`,className:`network`,children:t(`Network`)}),(0,Q.jsx)(`th`,{scope:`col`,className:`uptime`,children:t(`Uptime`)}),(0,Q.jsx)(`th`,{scope:`col`,className:`version`,children:t(`Version`)})]})}),(0,Q.jsx)(`tbody`,{children:e.map((e,r)=>{let i=e.endpoint||String(r),c=a.includes(i),l=e.endpoint||t(`Unknown`),u=e.drives?.filter(e=>e.state===`ok`).length,f=e.network?Object.values(e.network):void 0,p=f?`${f.filter(e=>e===`online`).length}/${f.length}`:`—`,m=H(e.uptime)===void 0?`—`:e.uptime===0?t(`Just started`):d(`${e.uptime}`),h=()=>o(e=>c?e.filter(e=>e!==i):[...e,i]),_=`${n}-drives-${r}`;return(0,Q.jsxs)(V.Fragment,{children:[(0,Q.jsxs)(`tr`,{className:`server-row`,"data-fluid-index":r,onClick:h,children:[(0,Q.jsx)(`td`,{children:(0,Q.jsxs)(`div`,{className:`endpoint`,children:[(0,Q.jsx)(S,{id:`${n}-expand-${r}`,variant:`ghost`,"aria-expanded":c,"aria-controls":c?_:void 0,"aria-label":g(t(c?`Hide drives for {server}`:`Show drives for {server}`),{server:l}),icon:c?(0,Q.jsx)(x,{}):(0,Q.jsx)(w,{}),onClick:e=>{e.stopPropagation(),h()}}),(0,Q.jsx)(`span`,{children:l})]})}),(0,Q.jsx)(`td`,{children:s(e.state,`online`)}),(0,Q.jsx)(`td`,{children:u===void 0?`—`:`${u}/${e.drives.length}`}),(0,Q.jsx)(`td`,{className:`network`,children:p}),(0,Q.jsx)(`td`,{className:`uptime`,children:m}),(0,Q.jsx)(`td`,{className:`version`,children:e.version||`—`})]}),c&&(0,Q.jsx)(`tr`,{children:(0,Q.jsx)(`td`,{colSpan:6,children:(0,Q.jsxs)(we,{id:_,children:[(0,Q.jsxs)(Te,{children:[(0,Q.jsx)(`dt`,{children:t(`Network`)}),(0,Q.jsx)(`dd`,{children:p}),(0,Q.jsx)(`dt`,{children:t(`Uptime`)}),(0,Q.jsx)(`dd`,{children:m}),(0,Q.jsx)(`dt`,{children:t(`Version`)}),(0,Q.jsx)(`dd`,{children:e.version||`—`})]}),e.drives?.length?(0,Q.jsx)(Ee,{"aria-label":g(t(`Drives on {server}`),{server:l}),children:e.drives.map((e,n)=>{let r=W(e),i=e.drivePath||e.endpoint||t(`Unknown`);return(0,Q.jsxs)(`li`,{children:[(0,Q.jsx)(`span`,{className:`path`,children:i}),(0,Q.jsxs)(`div`,{children:[s(e.state,`ok`),e.healing&&(0,Q.jsx)(`div`,{children:(0,Q.jsx)(Y,{children:t(`Healing`)})})]}),(0,Q.jsxs)(`div`,{className:`drive-usage`,children:[(0,Q.jsx)(Y,{children:g(t(`{used} / {total} used`),{used:$(r.used),total:$(r.total)})}),r.ratio!==void 0&&(0,Q.jsx)(De,{role:`progressbar`,"aria-label":g(t(`Drive usage: {drive}`),{drive:i}),"aria-valuemin":0,"aria-valuemax":100,"aria-valuenow":Math.min(100,r.ratio*100),$ratio:r.ratio,$tone:L(r.ratio)})]})]},e.uuid||`${i}-${n}`)})}):(0,Q.jsx)(Y,{children:t(`No drive information available`)})]})})})]},i)})})]})]})}):(0,Q.jsx)(R,{compact:!0,icon:(0,Q.jsx)(C,{}),title:t(`No servers reported`)})}function ke(){let e=k(),t=A(),i=n(),a=f(p),o=u();(0,V.useEffect)(()=>{o(s(`overview`))},[o]);let c=oe(),d=ae(c),m=f(e=>e.system.serverNeedsRestart),{data:h,refreshing:v,error:y,refresh:b}=de({refreshMs:6e4}),x=e=>e===void 0?`—`:new Intl.NumberFormat(t===`zh`?`zh-CN`:`en`).format(e),w=e=>e===void 0?`—`:l(`${e}`),D=e=>{if(e===void 0)return`—`;let[t,n]=l(`${e}`).split(` `);return(0,Q.jsxs)(Q.Fragment,{children:[t,` `,(0,Q.jsx)(Y,{children:n})]})},O=U(h?.servers),j=G(h?.servers),M=h?K(h):void 0,N=h?ce(h,m):[],P=le(a.permissions,a.features??[],F),L=e=>!h&&v?(0,Q.jsx)(be,{"aria-hidden":`true`}):e,H=(e,t)=>e===void 0||t===void 0?`—`:`${x(e)}/${x(t)}`;return(0,Q.jsxs)(Q.Fragment,{children:[(0,Q.jsx)(fe,{children:(0,Q.jsx)(I,{label:(0,Q.jsx)(pe,{children:e(`Overview`)}),primaryAction:{id:`refresh-overview`,label:e(`Refresh`),icon:(0,Q.jsx)(_,{}),iconOnly:!0,loading:v,onClick:()=>void b()}})}),(0,Q.jsx)(ee,{children:(0,Q.jsxs)(me,{children:[y&&(0,Q.jsxs)(ge,{role:`alert`,children:[(0,Q.jsx)(E,{"aria-hidden":`true`}),e(h?`Refresh failed. The last received data is still shown.`:`Could not load deployment information. Try refreshing.`)]}),(0,Q.jsxs)(he,{role:`group`,"aria-busy":v,"aria-label":e(`Deployment statistics`),children:[(0,Q.jsx)(B,{label:e(`Cluster health`),icon:(0,Q.jsx)(C,{}),value:L(H(O.serversOnline,O.serversTotal)),unit:(0,Q.jsx)(Y,{children:e(`servers online`)}),subline:h&&(0,Q.jsxs)(X,{children:[(0,Q.jsx)(`span`,{children:g(e(`{count} drives online`),{count:H(O.drivesOnline,O.drivesTotal)})}),O.healing>0&&(0,Q.jsx)(`span`,{children:g(e(`{count} drive(s) healing`),{count:x(O.healing)})})]})}),(0,Q.jsx)(B,{label:e(`Capacity`),icon:(0,Q.jsx)(te,{}),value:L((0,Q.jsx)(`span`,{"data-testid":`overview-used`,"data-bytes":j.rawUsed,children:D(j.rawUsed)})),subline:h&&(0,Q.jsxs)(X,{children:[(0,Q.jsx)(`span`,{"data-testid":`overview-total`,"data-bytes":j.rawTotal,children:g(e(`of {total} raw capacity`),{total:w(j.rawTotal)})}),(0,Q.jsx)(Y,{"data-testid":`overview-available`,"data-bytes":j.rawAvailable,children:g(e(`{available} available`),{available:w(j.rawAvailable)})})]}),progress:h&&j.usedRatio!==void 0?{value:j.usedRatio}:void 0}),(0,Q.jsx)(B,{label:e(`Data`),icon:(0,Q.jsx)(T,{}),value:L(x(M?.objects)),unit:(0,Q.jsx)(Y,{children:e(`objects`)}),subline:h&&(0,Q.jsxs)(X,{children:[(0,Q.jsx)(`span`,{children:w(M?.bytes)}),(0,Q.jsx)(ie,{at:h.usageUpdatedAt,prefix:`Calculated`})]})}),(0,Q.jsx)(B,{label:e(`Buckets`),icon:(0,Q.jsx)(re,{}),value:L(x(M?.buckets)),footer:(0,Q.jsxs)(r,{to:`/buckets`,children:[e(`View buckets`),` →`]})})]}),(0,Q.jsxs)(q,{shadowLevel:2,id:`overview-servers`,tabIndex:-1,role:`group`,"aria-labelledby":`overview-servers-title`,children:[(0,Q.jsx)(J,{id:`overview-servers-title`,children:e(`Servers`)}),!h&&v?(0,Q.jsx)(z,{rows:3,columns:4}):(0,Q.jsx)(Oe,{servers:h?.servers})]}),(0,Q.jsxs)(q,{$columns:h&&!N.length?4:8,shadowLevel:2,role:`group`,"aria-labelledby":`overview-alerts-title`,children:[(0,Q.jsx)(J,{id:`overview-alerts-title`,children:e(`Alerts`)}),h?N.length?(0,Q.jsx)(_e,{children:N.map(t=>{let n=g(e(t.message),t.values??{});return(0,Q.jsxs)(`li`,{children:[(0,Q.jsx)(ve,{role:`img`,$severity:t.severity,"aria-label":t.severity===`danger`?e(`Error`):t.severity===`warning`?e(`Warning`):e(`Information`),children:(0,Q.jsx)(E,{})}),t.href?(0,Q.jsx)(`a`,{href:t.href,onClick:e=>{let n=document.getElementById(t.href.slice(1));n&&(e.preventDefault(),n.scrollIntoView({block:`nearest`}),n.focus())},children:n}):(0,Q.jsx)(`span`,{children:n})]},t.id)})}):(0,Q.jsxs)(X,{as:`p`,style:{margin:0,flexDirection:`row`,alignItems:`center`,color:`var(--muted-foreground)`},children:[(0,Q.jsx)(ne,{"aria-hidden":`true`,style:{width:20,height:20,color:`var(--success)`,flexShrink:0}}),e(`All systems normal`)]}):v?(0,Q.jsx)(z,{rows:3,columns:1}):(0,Q.jsx)(R,{compact:!0,title:e(`Health information unavailable`)})]}),(0,Q.jsxs)(q,{$columns:h&&!N.length?8:4,shadowLevel:2,role:`group`,"aria-labelledby":`overview-actions-title`,children:[(0,Q.jsx)(J,{id:`overview-actions-title`,children:e(`Quick actions`)}),(0,Q.jsx)(ye,{children:P.map(t=>(0,Q.jsx)(S,{id:`overview-${t.id}`,variant:`secondary`,label:e(t.label),onClick:()=>i(t.path)},t.id))}),!P.length&&(0,Q.jsx)(Y,{children:e(`No quick actions available for your permissions.`)})]}),(0,Q.jsx)(xe,{children:se.map(t=>{let n=d.filter(e=>e.section===t.id);return n.length?(0,Q.jsxs)(Se,{shadowLevel:2,role:`group`,"aria-labelledby":`overview-nav-${t.id}`,children:[(0,Q.jsx)(J,{id:`overview-nav-${t.id}`,children:e(t.title)}),(0,Q.jsx)(`nav`,{"aria-labelledby":`overview-nav-${t.id}`,children:n.map(t=>(0,Q.jsxs)(Z,{to:t.path,children:[(0,Q.jsx)(`span`,{"aria-hidden":`true`,children:t.menu.icon}),e(t.title)]},t.id))})]},t.id):null})})]})})]})}export{ke as default};