import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,t as n}from"./react-vendor-UL3KVrSx.js";import{T as r}from"./shared-vendor-BQfq49S_.js";import{E as i,V as a,q as o,rt as s}from"./mds-B28KNzw0.js";var c=e(t()),l=n(),u=r.div`
  ${s(`body`)}
  display: inline-flex;
  align-items: center;
  gap: var(--gap, 8px);
  min-height: var(--control-height, 36px);
  .checkbox-target {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 16px;
    height: 16px;
    flex-shrink: 0;
    cursor: pointer;
  }
  input {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    margin: 0;
    opacity: 0;
    cursor: inherit;
  }
  .checkbox {
    pointer-events: none;
    width: 16px;
    height: 16px;
    border: 1.5px solid var(--input);
    border-radius: 5px;
    box-sizing: border-box;
    color: var(--foreground);
  }
  input:checked + .checkbox {
    border-color: transparent;
    background: var(--foreground);
    color: var(--surface-1);
  }
  input:disabled:checked + .checkbox {
    background: var(--muted);
    color: var(--muted-foreground);
  }
  input:hover:not(:checked):not(:disabled) + .checkbox {
    border-color: var(--muted-foreground);
  }
  input:focus-visible + .checkbox {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }
  input:disabled + .checkbox {
    background: var(--muted);
    color: var(--muted-foreground);
  }
  svg {
    width: 16px;
    height: 16px;
    overflow: visible;
    display: block;
    margin: -1.5px;
  }
  path {
    stroke-dasharray: 1;
    stroke-dashoffset: 1;
    transition: stroke-dashoffset var(--dur-fast, 80ms) ease-out;
  }
  input:checked + .checkbox path {
    stroke-dashoffset: 0;
  }
  @media (prefers-reduced-motion: reduce) {
    path {
      transition: none;
    }
  }
  @media (pointer: coarse) {
    min-height: 40px;
    .checkbox-target {
      width: 40px;
      height: 40px;
    }
  }
  ${({$sx:e})=>e}
`,d=({tooltip:e,label:t,id:n,overrideLabelClasses:r,sx:s,className:d,helpTip:f,helpTipPlacement:p,...m})=>{let h=(0,c.useId)(),g=n??(t?`checkbox-${h}`:void 0);return(0,l.jsxs)(u,{$sx:s,className:`inputItem ${d||``}`,onClick:e=>e.stopPropagation(),children:[(0,l.jsxs)(`span`,{className:`checkbox-target`,onClick:e=>e.stopPropagation(),children:[(0,l.jsx)(`input`,{type:`checkbox`,id:g,...m}),(0,l.jsx)(`span`,{className:`checkbox`,"aria-hidden":`true`,children:(0,l.jsx)(`svg`,{viewBox:`0 0 16 16`,fill:`none`,children:(0,l.jsx)(`path`,{pathLength:`1`,d:`M3 8 6.5 11.5 13 4.5`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`})})})]}),t&&(0,l.jsxs)(i,{htmlFor:g,noMinWidth:!0,className:r,helpTip:f,helpTipPlacement:p,children:[t,e&&(0,l.jsx)(o,{tooltip:e,children:(0,l.jsx)(a,{})})]})]})};export{d as t};