const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./DropdownSelectorPopup-Bq6J-Bcq.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./listPopup-D2sWpuy2.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{N as t,P as n,t as r}from"./react-vendor-UL3KVrSx.js";import{C as i,O as a,S as o,T as s,b as c,x as l}from"./shared-vendor-BQfq49S_.js";var u=e(n()),d=e(a()),f={xs:0,sm:576,md:768,lg:992,xl:1200},p=[`B`,`KiB`,`MiB`,`GiB`,`TiB`,`PiB`,`EiB`,`ZiB`,`YiB`],m=e=>{if(e===`auto`||typeof e==`boolean`&&e)return`100%`;if(e===!1)return`initial`;let t=Math.floor(e);return t>12?(t=12,console.warn(`Grid fraction cannot be greater than 12`)):t<1&&(t=1,console.warn(`Grid fraction cannot be smaller than 1`)),`${t*100/12}%`},h=e=>{if(typeof e==`string`){if(!/^\+?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(e.trim()))return null}else if(typeof e!=`number`)return null;let t=Number(e);return Number.isFinite(t)&&t>=0?t:null},g=(e,t,n)=>{let r=0,i=e;for(;i>=1024&&r<t.length-1;)i/=1024,r++;return n(i)>=1024&&r<t.length-1&&(i/=1024,r++),{value:i,unit:r}},_=(e,t=!1,n=!0,r=p)=>{let i=h(e);if(i===null||r.length===0)return{total:null,unit:``};if(i===0)return{total:0,unit:r[0]};let a=+!!t,o=e=>Number((n?Math.floor(e):e).toFixed(a)),s=g(i,r,o);return{total:o(s.value),unit:r[s.unit]}},v={white:`#fff`,sectionOneBG:`#fff`,defaultFontColor:`#000`,bulletColor:`#2781B0`,borderColor:`#E2E2E2`,boxBackground:`#FBFAFA`,mainGrey:`#5B5C5C`,disabledGrey:`#E6EBEB`,hoverGrey:`#E6EAEB`,pressedGrey:`#D5D7D8`,actionDisabledGrey:`#E7EAEB`,mainBlue:`#07193E`,hoverBlue:`#0D2453`,pressedBlue:`#05132F`,mainRed:`#C51B3F`,hoverRed:`#FCF2F4`,lightRed:`#C83B51`,divisorColor:`#E3E3E3`,disabledBGGrey:`#D5D7D7`,disabledInnerGrey:`#B4B4B4`,logoLabel:`#000000`,logoLabelInverse:`#fff`,promoBlue:`#A6DFEF`,footerDivider:`#F2F2F2`,promoBG:`#000110`,loaderColor:`#113053`,headerBG:`#FFFFFF`,headerBorder:`#E5E5E5`,headerColor:`#000000`,tooltipBG:`#737373`,tooltipColor:`#FFFFFF`,labelColor:`#07193E`,mainGreen:`#4CCB92`,checkBoxBorder:`#c3c3c3`,iconButtonBG:`#F8F8F8`,iconButtonActive:`#5B5C5C80`,iconButtonHover:`#EFEFEF`,iconButtonDisabled:`#E6EBEB`,iconButtonColor:`#7C7C7C`,backLinkColor:`#073052`,backLinkArrow:`#081C42`,backLinkHover:`#eaedee`,commonLinkColor:`#969FA8`,breadcrumbsBackground:`#FCFCFD`,breadcrumbsBackBorder:`#EAEDEE`,breadcrumbsText:`#969FA8`,actionsListBorder:`#F1F1F1`,disabledActionsColor:`#EBEBEB`,optionTextColor:`#5E5E5E`,modalCloseColor:`#757575`,modalCloseHoverBG:`#EAEAEA`,modalOverlayBG:`#00000050`,bulletBGColor:`#F1F4F4`,placeholder:`#858585`,readBoxTextColor:`#696969`,secondAction:`#005C7E`,secondActionHover:`#1B779A`,secondActionActive:`#07506A`,mainOrange:`#FFBD62`,menuBackground:`linear-gradient(90deg, rgba(2,49,80,1) 0%, rgba(0,39,77,1) 50%, rgba(11,34,69,1) 100%)`,menuDropArrowColor:`#8399AB`,menuDropArrowBackground:`#0A1C3C`,menuSelectedOption:`linear-gradient(90deg, rgba(0,0,0,0) 0%, rgba(20,88,122,1) 100%)`,menuCommonColor:`#CADAE8`,menuColorDivider:`#0F446C`,menuCollapseColor:`#E8E8E8`,menuIconBG:`#06274E`,menuIconBorder:`#052148`,tabBorder:`#EAEAEA`,codeEditorComment:`#6e7781`,codeEditorEntityTag:`#116329`,codeEditorEntity:`#8250df`,codeEditorSublimelinterGutterMark:`#8c959f`,codeEditorConstant:`#0550ae`,codeEditorString:`#0a3069`,codeEditorKeyword:`#cf222e`,codeEditorMarkupBold:`#24292f`,codeEditorRegexp:`#ffaa00`,linkColor:`#2781B0`,mutedText:`#87888d`,disabledOnSwitchBG:`#a9d3c5`,sliderDisabledBG:`#dbdbdb`},y={dark:`#181F2A`,sectionOneBG:`#283140`,defaultFontColor:`#C4C9D0`,bulletColor:`#4B586A`,borderColor:`#8E98A9`,boxBackground:`#283140`,mainGrey:`#A2ADC0`,disabledGrey:`#494A4D`,hoverGrey:`#4B586A`,borderPressedGrey:`#707988`,pressedGrey:`#333D4B`,mainWhite:`#E6ECEC`,disabledWhite:`#B5BCBD`,hoverWhite:`#EFEDED`,pressedWhite:`#C3CBCB`,mainRed:`#FF3958`,hoverRed:`#4B586A`,divisorColor:`#E3E3E3`,disabledBGGrey:`#616A7C`,disabledInnerGrey:`#3A3F4A`,logoLabel:`#A3B7D9`,logoLabelInverse:`#fff`,footerDivider:`#545D6A`,footerColor:`#85B3EE`,promoBG:`#000106`,loaderColor:`#8E98A9`,headerBG:`#212936`,headerBorder:`#191E28`,headerColor:`#E9F5F6`,tooltipBG:`#8E98A9`,tooltipColor:`#161C24`,labelColor:`#A2ADC0`,mainGreen:`#58FAB1`,checkBoxBorder:`#8E98A9`,iconButtonBG:`#A2ADC0`,iconButtonActive:`#707988`,iconButtonHover:`#4B586A`,iconButtonDisabled:`#494A4D`,iconButtonColor:`#283140`,backLinkColor:`#8E98A9`,backLinkArrow:`#A2ADC0`,backLinkHover:`#3A3F4A`,modalCloseColor:`#4B586A`,modalCloseHoverBG:`#4B586A`,modalOverlayBG:`#00010650`,bulletBGColor:`#D5DEEF`,disabledSwitchBG:`#494A4C`,disabledOnSwitchBG:`#a2d7c3`,disabledBulletBG:`#4B586B`,placeholder:`#494A4D`,readBoxTextColor:`#707988`,secondAction:`#1B637E`,secondActionHover:`#297E9D`,secondActionActive:`#145B76`,mainOrange:`#fCCE9D`,menuBackground:`#242D3E`,menuDropArrowColor:`#8E98A9`,menuDropArrowBackground:`#1C2436`,menuSelectedOption:`linear-gradient(90deg, rgba(0,0,0,0) 0%, #1B212C 100%)`,menuCommonColor:`#8E98A9`,menuColorDivider:`#323C4E`,menuCollapseColor:`#E8E8E8`,menuIconBG:`#161F30`,menuIconBorder:`#151E2E`,menuHoverSelectedBorderIcon:`#0E1119`,menuHoverSelectedBG:`#909AAB`,codeEditorComment:`#8b949e`,codeEditorEntityTag:`#7ee787`,codeEditorEntity:`#d2a8ff`,codeEditorSublimelinterGutterMark:`#8E98A9`,codeEditorConstant:`#79c0ff`,codeEditorString:`#a5d6ff`,codeEditorKeyword:`#ff7b72`,codeEditorMarkupBold:`#c9d1d9`,codeEditorRegexp:`#ffd582`,linkColor:`#85B3EE`,mutedText:`#767a80`,disabledSliderBullet:`#939393`},b={bgColor:v.white,fontColor:v.defaultFontColor,borderColor:v.borderColor,bulletColor:v.bulletColor,logoColor:v.mainRed,logoLabelColor:v.logoLabel,logoLabelInverse:v.logoLabelInverse,logoContrast:v.white,logoContrastInverse:v.logoLabel,loaderColor:v.loaderColor,linkColor:v.linkColor,boxBackground:v.boxBackground,mutedText:v.mutedText,secondaryText:v.mainGrey,signalColors:{main:v.mainBlue,danger:v.mainRed,good:v.mainGreen,info:v.bulletColor,warning:v.mainOrange,disabled:v.disabledGrey,dark:v.defaultFontColor,clear:v.white},buttons:{regular:{enabled:{border:v.mainGrey,text:v.mainGrey,background:`transparent`,iconColor:v.mainGrey},disabled:{border:v.disabledInnerGrey,text:v.disabledInnerGrey,background:v.disabledBGGrey,iconColor:v.disabledInnerGrey},hover:{border:v.mainGrey,text:v.mainGrey,background:v.hoverGrey,iconColor:v.mainGrey},pressed:{border:v.mainGrey,text:v.mainGrey,background:v.pressedGrey,iconColor:v.mainGrey}},callAction:{enabled:{border:v.mainBlue,text:v.white,background:v.mainBlue,iconColor:v.white},disabled:{border:v.actionDisabledGrey,text:v.mainGrey,background:v.actionDisabledGrey,iconColor:v.mainGrey},hover:{border:v.hoverBlue,text:v.white,background:v.hoverBlue,iconColor:v.white},pressed:{border:v.pressedBlue,text:v.white,background:v.pressedBlue,iconColor:v.white}},secondary:{enabled:{border:v.mainRed,text:v.mainRed,background:`transparent`,iconColor:v.mainRed},disabled:{border:v.disabledInnerGrey,text:v.disabledInnerGrey,background:v.disabledBGGrey,iconColor:v.disabledInnerGrey},hover:{border:v.lightRed,text:v.mainRed,background:v.hoverRed,iconColor:v.mainRed},pressed:{border:v.mainRed,text:v.white,background:v.mainRed,iconColor:v.white}},text:{enabled:{border:`transparent`,text:v.mainGrey,background:`transparent`,iconColor:v.mainGrey},disabled:{border:`transparent`,text:v.disabledInnerGrey,background:`transparent`,iconColor:v.disabledInnerGrey},hover:{border:v.hoverGrey,text:v.mainGrey,background:v.hoverGrey,iconColor:v.mainGrey},pressed:{border:v.pressedGrey,text:v.mainGrey,background:v.pressedGrey,iconColor:v.mainGrey}},subAction:{enabled:{border:v.secondAction,text:v.white,background:v.secondAction,iconColor:v.white},disabled:{border:v.actionDisabledGrey,text:v.mainGrey,background:v.actionDisabledGrey,iconColor:v.mainGrey},hover:{border:v.secondActionHover,text:v.white,background:v.secondActionHover,iconColor:v.white},pressed:{border:v.secondActionActive,text:v.white,background:v.secondActionActive,iconColor:v.white}}},login:{formBG:v.sectionOneBG,bgFilter:`none`,promoBG:v.promoBG,promoHeader:v.white,promoText:v.promoBlue,footerElements:v.bulletColor,footerDivider:v.footerDivider},pageHeader:{background:v.headerBG,border:v.headerBorder,color:v.headerColor},tooltip:{background:v.tooltipBG,color:v.tooltipColor},commonInput:{labelColor:v.labelColor},checkbox:{checkBoxBorder:v.checkBoxBorder,checkBoxColor:v.mainGreen,disabledBorder:v.disabledBGGrey,disabledColor:v.disabledBGGrey},iconButton:{buttonBG:v.iconButtonBG,activeBG:v.iconButtonActive,hoverBG:v.iconButtonHover,disabledBG:v.iconButtonDisabled,color:v.iconButtonColor},dataTable:{border:v.borderColor,disabledBorder:v.disabledGrey,disabledBG:v.disabledBGGrey,selected:v.mainBlue,deletedDisabled:v.mainRed,hoverColor:v.hoverGrey},backLink:{color:v.backLinkColor,arrow:v.backLinkArrow,hover:v.backLinkHover},inputBox:{border:v.borderColor,hoverBorder:v.promoBG,color:v.mainBlue,backgroundColor:v.white,error:v.mainRed,placeholderColor:v.placeholder,disabledBorder:v.disabledInnerGrey,disabledBackground:v.disabledGrey,disabledPlaceholder:v.disabledGrey,disabledText:v.disabledInnerGrey},breadcrumbs:{border:v.borderColor,linksColor:v.commonLinkColor,textColor:v.breadcrumbsText,backgroundColor:v.breadcrumbsBackground,backButton:{border:v.breadcrumbsBackBorder,backgroundColor:v.white}},actionsList:{containerBorderColor:v.actionsListBorder,backgroundColor:v.iconButtonBG,disabledOptionsTextColor:v.disabledActionsColor,optionsBorder:v.headerBorder,optionsHoverTextColor:v.defaultFontColor,optionsTextColor:v.optionTextColor,titleColor:v.defaultFontColor},screenTitle:{border:v.borderColor,subtitleColor:v.commonLinkColor,iconColor:v.mainBlue},modalBox:{closeColor:v.modalCloseColor,closeHoverBG:v.modalCloseHoverBG,closeHoverColor:v.defaultFontColor,containerColor:v.white,overlayColor:v.modalOverlayBG,titleColor:v.defaultFontColor,iconColor:{default:v.mainBlue,accept:v.mainGreen,delete:v.mainRed}},switchButton:{bulletBGColor:v.bulletBGColor,bulletBorderColor:v.white,disabledBulletBGColor:v.hoverGrey,disabledBulletBorderColor:v.bulletBGColor,offLabelColor:v.disabledInnerGrey,onLabelColor:v.mainBlue,onBackgroundColor:v.mainGreen,switchBackground:v.hoverGrey,disabledBackground:v.hoverGrey,disabledOnBackground:v.disabledOnSwitchBG},dropdownSelector:{hoverText:v.defaultFontColor,backgroundColor:v.white,hoverBG:v.hoverGrey,selectedBGColor:v.pressedGrey,selectedTextColor:v.defaultFontColor,optionTextColor:v.defaultFontColor,disabledText:v.disabledGrey},readBox:{borderColor:v.headerBorder,backgroundColor:v.boxBackground,textColor:v.readBoxTextColor},menu:{vertical:{background:v.menuBackground,textColor:v.menuCommonColor,hoverSelectedIconBorder:v.white,iconBorderColor:v.menuIconBorder,iconBGColor:v.menuIconBG,dropArrowColor:v.menuDropArrowColor,dropArrowBackground:v.menuDropArrowBackground,hoverSelectedBackground:v.menuSelectedOption,hoverSelectedColor:v.white,notificationColor:v.mainRed,sectionDividerColor:v.menuColorDivider,sectionLabelColor:v.white,menuCollapseColor:v.menuCollapseColor},horizontal:{menuHeaderBackground:v.menuBackground,textColor:v.optionTextColor,hoverSelectedIconBorder:v.defaultFontColor,iconBorderColor:v.menuIconBorder,iconBGColor:v.boxBackground,dropArrowColor:v.menuDropArrowColor,dropArrowBackground:v.boxBackground,hoverSelectedBackground:v.mainBlue,hoverSelectedColor:v.defaultFontColor,notificationColor:v.lightRed,sectionDividerColor:v.menuColorDivider,barBackground:v.boxBackground,dropBackground:v.boxBackground,dropHoverSelectedColor:v.white,noOptionsBar:v.bulletColor}},tabs:{vertical:{buttons:{hoverLabelColor:v.mainBlue,hoverBackground:`transparent`,backgroundColor:v.iconButtonBG,labelColor:v.mainGrey,disabledBackgroundColor:v.disabledBGGrey,disabledColor:v.disabledInnerGrey,selectedBackground:v.headerBorder,selectedLabelColor:v.mainBlue},backgroundColor:v.iconButtonBG,borders:v.tabBorder},horizontal:{buttons:{hoverLabelColor:v.mainBlue,hoverBackground:`transparent`,backgroundColor:`transparent`,labelColor:v.mainGrey,disabledBackgroundColor:`transparent`,disabledColor:v.disabledInnerGrey,selectedBackground:`transparent`,selectedLabelColor:v.mainBlue},backgroundColor:v.boxBackground,selectedIndicatorColor:v.mainBlue}},codeEditor:{backgroundColor:v.white,textColor:v.defaultFontColor,helpToolsBarBG:v.boxBackground,comment:v.codeEditorComment,entityTag:v.codeEditorEntityTag,entity:v.codeEditorEntity,sublimelinterGutterMark:v.codeEditorSublimelinterGutterMark,constant:v.codeEditorConstant,string:v.codeEditorString,keyword:v.codeEditorKeyword,markupBold:v.codeEditorMarkupBold,codeEditorRegexp:v.codeEditorRegexp},tag:{alert:{background:v.mainRed,label:v.white,deleteColor:v.white},default:{background:v.mainBlue,label:v.white,deleteColor:v.white},secondary:{background:v.secondAction,label:v.white,deleteColor:v.white},warn:{background:v.mainOrange,label:v.defaultFontColor,deleteColor:v.defaultFontColor},ok:{background:v.mainGreen,label:v.defaultFontColor,deleteColor:v.defaultFontColor},grey:{background:v.actionDisabledGrey,label:v.defaultFontColor,deleteColor:v.defaultFontColor}},snackbar:{error:{backgroundColor:v.mainRed,labelColor:v.white},default:{backgroundColor:v.mainBlue,labelColor:v.white},success:{backgroundColor:v.mainGreen,labelColor:v.white},warning:{backgroundColor:v.mainOrange,labelColor:v.defaultFontColor}},informativeMessage:{error:{backgroundColor:v.mainRed,borderColor:v.mainRed,textColor:v.white},default:{backgroundColor:v.mainBlue,borderColor:v.mainBlue,textColor:v.white},success:{backgroundColor:v.mainGreen,borderColor:v.mainGreen,textColor:v.white},warning:{backgroundColor:v.mainOrange,borderColor:v.mainOrange,textColor:v.defaultFontColor}},badge:{alert:{backgroundColor:v.mainRed,textColor:v.white},default:{backgroundColor:v.mainBlue,textColor:v.white},secondary:{backgroundColor:v.secondAction,textColor:v.white},warn:{backgroundColor:v.mainOrange,textColor:v.defaultFontColor},ok:{backgroundColor:v.mainGreen,textColor:v.defaultFontColor},grey:{backgroundColor:v.actionDisabledGrey,textColor:v.defaultFontColor}},wizard:{stepsBackground:v.boxBackground,vertical:{stepLabelColor:v.defaultFontColor,selectedStepBG:v.borderColor,selectedStepLabelColor:v.defaultFontColor,disabledLabelColor:v.disabledInnerGrey},modal:{stepLabelColor:v.defaultFontColor,selectedStepBG:v.borderColor,selectedStepLabelColor:v.defaultFontColor,disabledLabelColor:v.disabledGrey}},slider:{bulletBG:v.bulletColor,railBG:v.borderColor,disabledRail:v.sliderDisabledBG,disabledBullet:v.disabledInnerGrey}},x={bgColor:y.dark,fontColor:y.defaultFontColor,borderColor:y.borderColor,bulletColor:y.bulletColor,logoColor:y.mainRed,logoLabelColor:y.logoLabel,logoLabelInverse:y.logoLabelInverse,logoContrast:y.dark,logoContrastInverse:y.dark,loaderColor:y.loaderColor,linkColor:y.linkColor,boxBackground:y.boxBackground,mutedText:y.mutedText,secondaryText:y.mainGrey,signalColors:{main:y.mainGrey,danger:y.mainRed,good:y.mainGreen,info:y.secondActionHover,warning:y.mainOrange,disabled:y.disabledGrey,dark:y.dark,clear:y.mainWhite},buttons:{regular:{enabled:{border:y.mainGrey,text:y.mainGrey,background:`transparent`,iconColor:y.mainGrey},disabled:{border:y.disabledInnerGrey,text:y.disabledInnerGrey,background:y.disabledBGGrey,iconColor:y.disabledInnerGrey},hover:{border:y.mainGrey,text:y.mainGrey,background:y.hoverGrey,iconColor:y.mainGrey},pressed:{border:y.borderPressedGrey,text:y.borderPressedGrey,background:y.pressedGrey,iconColor:y.borderPressedGrey}},callAction:{enabled:{border:y.mainWhite,text:y.dark,background:y.mainWhite,iconColor:y.dark},disabled:{border:y.disabledWhite,text:y.dark,background:y.disabledWhite,iconColor:y.dark},hover:{border:y.hoverWhite,text:y.dark,background:y.hoverWhite,iconColor:y.dark},pressed:{border:y.pressedWhite,text:y.dark,background:y.pressedWhite,iconColor:y.dark}},secondary:{enabled:{border:y.mainRed,text:y.mainRed,background:`transparent`,iconColor:y.mainRed},disabled:{border:y.disabledInnerGrey,text:y.disabledInnerGrey,background:y.disabledBGGrey,iconColor:y.disabledInnerGrey},hover:{border:y.mainRed,text:y.mainRed,background:y.hoverRed,iconColor:y.mainRed},pressed:{border:y.mainRed,text:y.dark,background:y.mainRed,iconColor:y.dark}},text:{enabled:{border:`transparent`,text:y.mainGrey,background:`transparent`,iconColor:y.mainGrey},disabled:{border:`transparent`,text:y.disabledInnerGrey,background:`transparent`,iconColor:y.disabledInnerGrey},hover:{border:y.hoverGrey,text:y.mainGrey,background:y.hoverGrey,iconColor:y.mainGrey},pressed:{border:y.pressedGrey,text:y.borderPressedGrey,background:y.pressedGrey,iconColor:y.borderPressedGrey}},subAction:{enabled:{border:y.secondAction,text:y.mainWhite,background:y.secondAction,iconColor:y.mainWhite},disabled:{border:y.disabledWhite,text:y.dark,background:y.disabledWhite,iconColor:y.dark},hover:{border:y.secondActionHover,text:y.mainWhite,background:y.secondActionHover,iconColor:y.mainWhite},pressed:{border:y.secondActionActive,text:y.mainWhite,background:y.secondActionActive,iconColor:y.mainWhite}}},login:{formBG:y.sectionOneBG,promoBG:y.promoBG,bgFilter:`grayscale(50%)`,promoHeader:y.logoLabel,promoText:y.logoLabel,footerElements:y.footerColor,footerDivider:y.footerDivider},pageHeader:{background:y.headerBG,border:y.headerBorder,color:y.headerColor},tooltip:{background:y.tooltipBG,color:y.tooltipColor},commonInput:{labelColor:y.labelColor},checkbox:{checkBoxBorder:y.checkBoxBorder,checkBoxColor:y.mainGreen,disabledBorder:y.disabledInnerGrey,disabledColor:y.disabledBGGrey},iconButton:{buttonBG:y.iconButtonBG,activeBG:y.iconButtonActive,hoverBG:y.iconButtonHover,disabledBG:y.iconButtonDisabled,color:y.iconButtonColor},dataTable:{border:y.borderColor,disabledBorder:y.disabledGrey,disabledBG:y.disabledBGGrey,selected:y.mainWhite,deletedDisabled:y.mainRed,hoverColor:y.hoverGrey},backLink:{color:y.backLinkColor,arrow:y.backLinkArrow,hover:y.backLinkHover},inputBox:{border:y.borderColor,hoverBorder:y.mainWhite,color:y.mainGrey,backgroundColor:y.dark,error:y.mainRed,placeholderColor:y.placeholder,disabledBorder:y.disabledGrey,disabledBackground:y.disabledInnerGrey,disabledPlaceholder:y.disabledGrey,disabledText:y.disabledBGGrey},breadcrumbs:{border:y.borderColor,linksColor:y.mainGrey,textColor:y.mainGrey,backgroundColor:y.sectionOneBG,backButton:{border:y.borderColor,backgroundColor:y.sectionOneBG}},actionsList:{containerBorderColor:y.bulletColor,backgroundColor:y.sectionOneBG,disabledOptionsTextColor:y.disabledGrey,optionsBorder:y.bulletColor,optionsHoverTextColor:y.hoverWhite,optionsTextColor:y.defaultFontColor,titleColor:y.defaultFontColor},screenTitle:{border:y.borderColor,subtitleColor:y.hoverGrey,iconColor:y.mainGrey},modalBox:{closeColor:y.modalCloseColor,closeHoverBG:y.modalCloseHoverBG,closeHoverColor:y.defaultFontColor,containerColor:y.boxBackground,overlayColor:y.modalOverlayBG,titleColor:y.defaultFontColor,iconColor:{default:y.mainGrey,accept:y.mainGreen,delete:y.mainRed}},switchButton:{bulletBGColor:y.bulletBGColor,bulletBorderColor:y.mainWhite,disabledBulletBGColor:y.disabledBulletBG,disabledBulletBorderColor:y.backLinkArrow,offLabelColor:y.hoverGrey,onLabelColor:y.hoverWhite,onBackgroundColor:y.mainGreen,switchBackground:y.backLinkArrow,disabledBackground:y.disabledSwitchBG,disabledOnBackground:y.disabledOnSwitchBG},dropdownSelector:{hoverText:y.dark,backgroundColor:y.sectionOneBG,hoverBG:y.mainGrey,selectedBGColor:y.bulletColor,selectedTextColor:y.mainWhite,optionTextColor:y.defaultFontColor,disabledText:y.disabledGrey},readBox:{borderColor:y.headerBorder,backgroundColor:y.boxBackground,textColor:y.readBoxTextColor},menu:{vertical:{background:y.menuBackground,textColor:y.menuCommonColor,hoverSelectedIconBorder:y.menuHoverSelectedBorderIcon,iconBorderColor:y.menuIconBorder,iconBGColor:y.menuIconBG,dropArrowColor:y.menuDropArrowColor,dropArrowBackground:y.menuDropArrowBackground,hoverSelectedBackground:y.menuSelectedOption,hoverSelectedColor:y.headerColor,notificationColor:y.mainRed,sectionDividerColor:y.menuColorDivider,sectionLabelColor:y.headerColor,menuCollapseColor:y.menuCollapseColor},horizontal:{menuHeaderBackground:y.menuBackground,textColor:y.defaultFontColor,hoverSelectedIconBorder:y.defaultFontColor,iconBorderColor:y.menuIconBorder,iconBGColor:y.boxBackground,dropArrowColor:y.menuDropArrowColor,dropArrowBackground:y.boxBackground,hoverSelectedBackground:y.mainGrey,hoverSelectedColor:y.headerColor,notificationColor:y.mainRed,sectionDividerColor:y.menuColorDivider,barBackground:y.boxBackground,dropBackground:y.boxBackground,dropHoverSelectedColor:y.dark,noOptionsBar:y.mainGrey}},tabs:{vertical:{buttons:{hoverLabelColor:y.mainWhite,hoverBackground:`transparent`,backgroundColor:y.boxBackground,labelColor:y.defaultFontColor,disabledBackgroundColor:y.disabledBGGrey,disabledColor:y.disabledInnerGrey,selectedBackground:y.iconButtonBG,selectedLabelColor:y.dark},backgroundColor:y.boxBackground,borders:y.borderColor},horizontal:{buttons:{hoverLabelColor:y.mainWhite,hoverBackground:`transparent`,backgroundColor:`transparent`,labelColor:y.defaultFontColor,disabledBackgroundColor:`transparent`,disabledColor:y.disabledInnerGrey,selectedBackground:`transparent`,selectedLabelColor:y.mainWhite},backgroundColor:y.boxBackground,selectedIndicatorColor:y.mainWhite}},codeEditor:{backgroundColor:y.boxBackground,textColor:y.mainWhite,helpToolsBarBG:y.boxBackground,comment:y.codeEditorComment,entityTag:y.codeEditorEntityTag,entity:y.codeEditorEntity,sublimelinterGutterMark:y.codeEditorSublimelinterGutterMark,constant:y.codeEditorConstant,string:y.codeEditorString,keyword:y.codeEditorKeyword,markupBold:y.codeEditorMarkupBold,codeEditorRegexp:y.codeEditorRegexp},tag:{alert:{background:y.mainRed,label:y.mainWhite,deleteColor:y.mainWhite},default:{background:y.mainGrey,label:y.dark,deleteColor:y.dark},secondary:{background:y.secondAction,label:y.mainWhite,deleteColor:y.mainWhite},warn:{background:y.mainOrange,label:y.dark,deleteColor:y.dark},ok:{background:y.mainGreen,label:y.dark,deleteColor:y.dark},grey:{background:y.disabledBGGrey,label:y.mainWhite,deleteColor:y.mainWhite}},snackbar:{error:{backgroundColor:y.mainRed,labelColor:y.mainWhite},default:{backgroundColor:y.mainGrey,labelColor:y.dark},success:{backgroundColor:y.mainGreen,labelColor:y.dark},warning:{backgroundColor:y.mainOrange,labelColor:y.dark}},informativeMessage:{error:{backgroundColor:y.mainRed,borderColor:y.mainRed,textColor:y.mainWhite},default:{backgroundColor:y.mainGrey,borderColor:y.mainGrey,textColor:y.dark},success:{backgroundColor:y.mainGreen,borderColor:y.mainGreen,textColor:y.dark},warning:{backgroundColor:y.mainOrange,borderColor:y.mainOrange,textColor:y.dark}},badge:{alert:{backgroundColor:y.mainRed,textColor:y.mainWhite},default:{backgroundColor:y.mainGrey,textColor:y.dark},secondary:{backgroundColor:y.secondAction,textColor:y.mainWhite},warn:{backgroundColor:y.mainOrange,textColor:y.dark},ok:{backgroundColor:y.mainGreen,textColor:y.dark},grey:{backgroundColor:y.disabledBGGrey,textColor:y.mainWhite}},wizard:{stepsBackground:y.boxBackground,vertical:{stepLabelColor:y.defaultFontColor,selectedStepBG:y.borderColor,selectedStepLabelColor:y.dark,disabledLabelColor:y.disabledGrey},modal:{stepLabelColor:y.defaultFontColor,selectedStepBG:y.borderColor,selectedStepLabelColor:y.mainWhite,disabledLabelColor:y.disabledGrey}},slider:{bulletBG:y.defaultFontColor,railBG:y.footerDivider,disabledRail:y.disabledSwitchBG,disabledBullet:y.disabledSliderBullet}},S=r(),C=({darkMode:e=!1,children:t,customTheme:n})=>{let r=e?x:b;return n&&(r=n),(0,S.jsx)(o,{theme:r,children:t})},w=c`
    ${({theme:e})=>`
    /* Main Page styling */
    
    *, *::before, *::after {
       box-sizing: inherit;
       outline:0;
    }
    
    html {
        box-sizing: border-box;
        -webkit-text-size-adjust: 100%;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
    
    body {
        background-color: ${(0,d.default)(e,`bgColor`,v.white)};
        color: ${(0,d.default)(e,`fontColor`,v.defaultFontColor)};
        height: 100vh;
        width: 100vw;
        font-family: var(--font-sans, system-ui, sans-serif);
        margin: 0;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        font-weight: 400;
        font-size: var(--fs-body, 13px);
        line-height: var(--lh-body, 20px);
        transition: background-color 0s
    }
    
    fieldset, section {
        border: 1px solid ${(0,d.default)(e,`borderColor`,v.borderColor)};
        border-radius: 3px;
        background-color: transparent;
        padding: 25px;
    }
    
    a {
        color: ${(0,d.default)(e,`linkColor`,v.linkColor)};
    }
    
    a { text-decoration: none; }
    a:hover {
        text-decoration: underline;
        color: ${(0,d.default)(e,`linkColor`,v.linkColor)};
    }
    
    hr {
        border-top: 0;
        border-left: 0;
        border-right: 0;
        border-color: ${(0,d.default)(e,`borderColor`,v.borderColor)};
        background-color: transparent;
    }
    
    ul {
        padding-left: 20px;
        list-style: none;
        
        li:not([class*="Mui"])::before {
          content: '￭';
          color: ${(0,d.default)(e,`bulletColor`,v.bulletColor)};
          font-size: 20px;
          display: inline-block;
          width: 1em;
          margin-left: -1em;
        }
        
        ul {
          list-style: none;
          li:not([class*="Mui"])::before {
            content: "￮";
            color: ${(0,d.default)(e,`bulletColor`,v.bulletColor)},
            font-size: 20px;
            display: inline-block;
            width: 1em;
            margin-left: -1em;
          }
        }
      }
      
    button:active, button:focus, input: active, input:focus {
        outline: revert;
    }
    
    .min-icon {
        width: 26px;
    }
    
    #root: {
        height: 100%;
        width: 100%;
        display: flex;
        flex-flow: column;
        align-items: stretch;
      }
    
    #preload {
      display: none;
    }
    
    #loader-block {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100vh;
      justify-content: center;
      align-items: center;
    }
    
    .muted {
        color: ${(0,d.default)(e,`mutedText`,v.mutedText)};
    }
    `}
`,T={normal:400,semibold:550,bold:700},E={display:{size:28,line:34,compactSize:24,compactLine:30,weight:T.bold},title:{size:16,line:22,compactSize:15,compactLine:20,weight:T.semibold},subtitle:{size:14,line:20,compactSize:13,compactLine:18,weight:T.semibold},body:{size:13,line:20,compactSize:12,compactLine:18,weight:T.normal},caption:{size:12,line:16,compactSize:11,compactLine:14,weight:T.normal},micro:{size:11,line:14,compactSize:10,compactLine:12,weight:T.normal}},D={default:{controlHeight:36,controlPadding:12,rowPadding:8,gap:8,iconSize:16},compact:{controlHeight:28,controlPadding:10,rowPadding:6,gap:4,iconSize:14}},O=(e,{compact:t=!1,weight:n}={})=>{let r=E[e],i=t?`-compact`:``;return l`
    font-family: var(--font-sans);
    font-size: var(
      --fs-${e}${i},
      ${t?r.compactSize:r.size}px
    );
    line-height: var(
      --lh-${e}${i},
      ${t?r.compactLine:r.line}px
    );
    font-weight: ${n?T[n]:r.weight};
  `},k=(0,u.createContext)(`default`),ee=e=>{let t={};for(let[n,r]of Object.entries(D[e])){let e=n.replace(/[A-Z]/g,e=>`-${e.toLowerCase()}`);t[`--${e}`]=`${r}px`}for(let[n,r]of Object.entries(E))t[`--fs-${n}`]=`${e===`compact`?r.compactSize:r.size}px`,t[`--lh-${n}`]=`${e===`compact`?r.compactLine:r.line}px`;return t},te=s.div`
  display: contents;
  ${({$density:e})=>ee(e)}
`,ne=({density:e=`default`,children:t})=>(0,S.jsx)(k.Provider,{value:e,children:(0,S.jsx)(te,{$density:e,"data-density":e,children:t})}),A=()=>{let e=(0,u.useContext)(k),t=e===`compact`;return{density:e,compact:t,...D[e],type:Object.fromEntries(Object.keys(E).map(e=>[e,O(e,{compact:t})]))}},j=e(t()),M=(e,t=0)=>Math.max(1,Math.min(Math.round(e+t),8)),re=e=>e>=7?`--muted-foreground-elevated`:`--muted-foreground-base`,ie=(e,t=!1)=>({"--muted-foreground":t?`var(--surface-1, #fafafa)`:`var(${re(e)}, #737373)`,"--silo-text-secondary":`var(--muted-foreground)`,"--silo-text-muted":`var(--muted-foreground)`}),ae=(0,u.createContext)(1),oe=()=>(0,u.useContext)(ae),N=({level:e,children:t})=>(0,S.jsx)(ae.Provider,{value:M(e),children:t}),se=s.div`
  ${({$density:e})=>ee(e)}
  ${({$level:e,$inverted:t})=>ie(e,t)}
  background: ${({$level:e,$inverted:t})=>t?`var(--foreground, #171717)`:`var(--surface-${e}, #fff)`};
  color: ${({$inverted:e})=>e?`var(--surface-1, #fafafa)`:`var(--foreground, #171717)`};
  box-shadow: ${({$shadow:e})=>`var(--shadow-${e}, none)`};
`,P=(0,u.forwardRef)(({offset:e=2,shadowLevel:t,inverted:n=!1,children:r,...i},a)=>{let o=M(oe(),e),{density:s}=A();return(0,S.jsx)(N,{level:o,children:(0,S.jsx)(se,{...i,ref:a,"data-surface-level":o,$level:o,$shadow:M(t??o),$inverted:n,$density:s,children:r})})});P.displayName=`Elevated`;var ce=(0,u.createContext)(!0),F=()=>(0,u.useContext)(ce),le=({open:e,children:t})=>{let n=F();return(0,S.jsx)(ce.Provider,{value:n&&e,children:t})},I=0,L=new Set,ue=e=>{e!==I&&(I=e,L.forEach(e=>e()))},de=e=>(L.add(e),()=>{L.delete(e)}),R=new Set,fe=e=>{(0,u.useLayoutEffect)(()=>{if(!e)return;let t=Symbol();return R.add(t),L.forEach(e=>e()),()=>{R.delete(t),L.forEach(e=>e())}},[e])},pe=()=>I>0||R.size>0,me=()=>(0,u.useSyncExternalStore)(de,pe,()=>!1),z=0,he=s.span`
  display: inline-flex;
  position: relative;
  max-width: 100%;
`,ge=s(P)`
  ${O(`caption`)}
  position: fixed;
  z-index: 10001;
  width: max-content;
  max-width: min(350px, calc(100vw - 16px));
  padding: 4px 8px;
  border-radius: 8px;
  pointer-events: ${({$interactive:e})=>e?`auto`:`none`};
  overflow-wrap: anywhere;
  // An invisible 8px bridge keeps the bubble reachable across its side offset.
  &::before {
    content: "";
    position: absolute;
    ${({$side:e})=>e===`top`?`left: 0; right: 0; top: 100%; height: 8px;`:e===`bottom`?`left: 0; right: 0; bottom: 100%; height: 8px;`:e===`left`?`top: 0; bottom: 0; left: 100%; width: 8px;`:`top: 0; bottom: 0; right: 100%; width: 8px;`}
  }
  opacity: ${({$shown:e})=>+!!e};
  transform: ${({$shown:e,$side:t})=>e?`translate(0,0)`:t===`top`?`translateY(4px)`:t===`bottom`?`translateY(-4px)`:t===`left`?`translateX(4px)`:`translateX(-4px)`};
  transition:
    opacity
      ${({$shown:e})=>e?`var(--dur-fast,80ms) var(--ease-fast,ease-out)`:`var(--dur-fast-exit,60ms) var(--ease-exit,ease-in)`},
    transform
      ${({$shown:e})=>e?`var(--dur-fast,80ms) var(--ease-fast,ease-out)`:`var(--dur-fast-exit,60ms) var(--ease-exit,ease-in)`};
  @media (prefers-reduced-motion: reduce) {
    transform: none;
    transition-property: opacity;
  }
`,B=({children:e,tooltip:t,errorProps:n,placement:r=`bottom`,wrapperProps:i})=>{let a=F(),o=e.props[`aria-expanded`]===!0,s=(0,u.useId)(),c=(0,u.useRef)(null),l=(0,u.useRef)(null),d=(0,u.useRef)(),[f,p]=(0,u.useState)(!1),[m,h]=(0,u.useState)(!1),[g,_]=(0,u.useState)(!1),[v,y]=(0,u.useState)({left:0,top:0,side:r}),b=(0,u.useRef)(!1),x=(0,u.useRef)(!1),C=(e=!1)=>{o||(clearTimeout(d.current),d.current=setTimeout(()=>{h(!0),p(!0)},e||Date.now()<z?0:200))},w=(e=!1)=>{(e||!b.current&&!x.current)&&(clearTimeout(d.current),f&&(z=Date.now()+300),p(!1))};if((0,u.useEffect)(()=>()=>clearTimeout(d.current),[]),(0,u.useEffect)(()=>{(!a||o)&&(clearTimeout(d.current),b.current=!1,x.current=!1,p(!1))},[a,o]),(0,u.useEffect)(()=>{if(!m)return;if(f){let e=requestAnimationFrame(()=>_(!0));return()=>cancelAnimationFrame(e)}_(!1);let e=setTimeout(()=>h(!1),60);return()=>clearTimeout(e)},[f,m]),(0,u.useLayoutEffect)(()=>{if(!m||o||!c.current||!l.current)return;let e=0,t,n=()=>{if(!c.current||!l.current)return;let i=c.current.getBoundingClientRect(),a=l.current.getBoundingClientRect(),o=r;o===`top`&&i.top<a.height+16&&(o=`bottom`),o===`bottom`&&i.bottom+a.height+16>innerHeight&&(o=`top`),o===`left`&&i.left<a.width+16&&(o=`right`),o===`right`&&i.right+a.width+16>innerWidth&&(o=`left`);let s=o===`left`?i.left-a.width-8:o===`right`?i.right+8:i.left+(i.width-a.width)/2,u=o===`top`?i.top-a.height-8:o===`bottom`?i.bottom+8:i.top+(i.height-a.height)/2,d=Math.max(8,Math.min(s,innerWidth-a.width-8)),f=Math.max(8,Math.min(u,innerHeight-a.height-8)),p=l.current.offsetParent;if(p instanceof HTMLElement){let e=p.getBoundingClientRect(),t=e.width/p.offsetWidth||1,n=e.height/p.offsetHeight||1;d=(d-e.left)/t-p.clientLeft+p.scrollLeft,f=(f-e.top)/n-p.clientTop+p.scrollTop}let m={left:d,top:f,side:o};(t?.left!==m.left||t?.top!==m.top||t?.side!==m.side)&&(t=m,y(m)),e=requestAnimationFrame(n)};return n(),()=>cancelAnimationFrame(e)},[m,o,r,t]),t===``||t==null)return n?(0,u.cloneElement)(e,n):e;let T=e.type===u.Fragment?e:(0,u.cloneElement)(e,{...n,"aria-describedby":[e.props[`aria-describedby`],s].filter(Boolean).join(` `)});return(0,S.jsxs)(he,{ref:c,...i,onPointerEnter:e=>{b.current=!0,C(),i?.onPointerEnter?.(e)},onPointerLeave:e=>{b.current=!1,w(),i?.onPointerLeave?.(e)},onFocus:e=>{x.current=!0,C(!0),i?.onFocus?.(e)},onBlur:e=>{e.currentTarget.contains(e.relatedTarget)||(x.current=!1,w()),i?.onBlur?.(e)},onKeyDown:e=>{e.key===`Escape`&&f&&(w(!0),e.stopPropagation()),i?.onKeyDown?.(e)},children:[T,(0,S.jsx)(`span`,{id:s,hidden:!0,children:t}),m&&!o&&(0,j.createPortal)((0,S.jsx)(ge,{ref:l,onPointerEnter:()=>{b.current=!0,C(!0)},onPointerLeave:()=>{b.current=!1,w()},inverted:!0,offset:2,shadowLevel:3,"aria-hidden":!a||!f||void 0,role:`tooltip`,$shown:g,$interactive:a,$side:v.side,style:{left:v.left,top:v.top},children:t}),c.current?.closest(`dialog`)||c.current?.closest(`[role="dialog"], [role="alertdialog"]`)||c.current?.closest(`main, nav, aside, [role="main"], [role="navigation"], [role="complementary"], [role="region"][aria-label], [role="region"][aria-labelledby], section[aria-label], section[aria-labelledby]`)||document.body)]})},_e=({children:e,reason:t,fullWidth:n})=>{let r=(0,u.useId)();return(0,S.jsx)(B,{tooltip:t,wrapperProps:{tabIndex:0,role:`group`,"aria-label":e.props[`aria-label`],"aria-describedby":r,style:{width:n?`100%`:void 0,cursor:`not-allowed`,pointerEvents:`auto`}},children:(0,S.jsxs)(S.Fragment,{children:[(0,u.cloneElement)(e,{style:{...e.props.style,pointerEvents:`none`}}),(0,S.jsx)(`span`,{id:r,hidden:!0,children:t})]})})},ve=e=>({regular:`outline`,callAction:`primary`,subAction:`secondary`,text:`ghost`})[e]||e||`outline`,ye=i`to { transform: rotate(360deg); }`,be=s.button`
  ${({$compact:e})=>O(`body`,{compact:e,weight:`semibold`})}
  position: relative;
  isolation: isolate;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  flex-shrink: 0;
  height: ${({$compact:e})=>e?28:36}px;
  @media (pointer: coarse) { min-height: 40px; }
  width: ${({$full:e})=>e?`100%`:`auto`};
  border: 0;
  border-radius: 8px;
  margin: 0;
  padding: 0 ${({$compact:e})=>e?12:16}px;
  gap: ${({$compact:e})=>e?4:8}px;
  cursor: pointer;
  text-transform: none;
  letter-spacing: normal;
  white-space: nowrap;
  background: transparent;
  --button-fill: var(--tint);
  --button-hover: var(--tint-hover);
  --button-press: var(--tint);
  color: var(--foreground);
  ${({$variant:e})=>e===`primary`&&l`
      --button-fill: var(--foreground);
      --button-hover: color-mix(
        in oklab,
        var(--foreground) 90%,
        var(--surface-1)
      );
      --button-press: color-mix(
        in oklab,
        var(--foreground) 80%,
        var(--surface-1)
      );
      color: var(--surface-1);
    `}
  ${({$variant:e})=>e===`danger`&&l`
      color: var(--destructive-text);
    `}
  ${({$variant:e})=>e===`danger-fill`&&l`
      --button-fill: var(--destructive-text);
      --button-hover: var(--destructive-text);
      --button-press: var(--destructive-text);
      color: var(--surface-1);
    `}
  ${({$variant:e})=>[`ghost`,`outline`].includes(e)&&l`
      --button-fill: transparent;
      --button-hover: var(--hover);
      --button-press: var(--active);
    `}
  ${({$icon:e,$side:t,$compact:n})=>e&&(t===`start`?l`
          padding-left: ${n?8:12}px;
        `:l`
          padding-right: ${n?8:12}px;
        `)}
  .button-surface {
    position: absolute;
    z-index: -1;
    inset: 1px;
    border-radius: 7px;
    pointer-events: none;
    background: var(--button-fill);
    box-shadow: 0 0 0 1px var(--button-fill);
    transition:
      box-shadow 180ms cubic-bezier(0.23, 1, 0.32, 1),
      background-color var(--dur-fast, 80ms) ease;
    ${({$variant:e})=>e===`outline`&&l`
        box-shadow:
          0 0 0 1px var(--border),
          inset 0 0 0 0 var(--border);
      `}
  }
  &:hover:not(:disabled) .button-surface {
    background: var(--button-hover);
    box-shadow: 0 0 0 1px var(--button-hover);
  }
  ${({$variant:e})=>e===`outline`&&l`
      &:hover:not(:disabled) .button-surface {
        box-shadow:
          0 0 0 1px var(--border),
          inset 0 0 0 0 var(--border);
      }
    `}
  ${({$held:e})=>e&&l`
      .button-surface {
        background: var(--button-press);
      }
    `}
  &:active:not(:disabled) .button-surface {
    background: var(--button-press);
    box-shadow: 0 0 0 0 var(--button-press);
    transition-duration: var(--dur-fast, 80ms);
  }
  ${({$variant:e})=>e===`outline`&&l`
      &:active:not(:disabled) .button-surface {
        box-shadow:
          0 0 0 0 var(--border),
          inset 0 0 0 1px var(--border);
      }
    `}
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }
  &:disabled {
    cursor: not-allowed;
    color: var(--foreground);
    --button-fill: var(--muted);
  }
  .button-content {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: inherit;
    opacity: ${({$loading:e})=>+!e};
  }
  .button-label {
    white-space: nowrap;
  }
  .buttonIcon {
    display: inline-flex;
  }
  .buttonIcon svg {
    width: ${({$compact:e})=>e?14:16}px;
    height: ${({$compact:e})=>e?14:16}px;
    fill: currentColor;
    color: inherit;
  }
  .button-spinner {
    position: absolute;
    width: 16px;
    height: 16px;
    border: 1.5px solid currentColor;
    border-right-color: transparent;
    border-radius: 50%;
    animation: ${ye} 800ms linear infinite;
  }
  @media (max-width: 767px) {
    ${({$collapse:e,$icon:t})=>e&&t&&l`
        .button-label {
          display: none;
        }
        padding: 0 12px;
      `}
  }
  @media (prefers-reduced-motion: reduce) {
    .button-surface {
      transition: background-color var(--dur-fast, 80ms) ease;
    }
    .button-spinner {
      animation: none;
    }
  }
  ${({$sx:e})=>e}
`,V=(0,u.forwardRef)(({label:e,variant:t=`regular`,icon:n,iconLocation:r=`end`,disabled:i,disabledReason:a,fullWidth:o=!1,collapseOnSmall:s=!0,children:c,className:l,sx:u,loading:d=!1,active:f=!1,...p},m)=>{let{compact:h}=A(),g=(0,S.jsxs)(be,{ref:m,...p,$variant:ve(t),$compact:h,$full:o,$collapse:s,$icon:!!n,$side:r,$loading:d,$held:f,$sx:u,disabled:i||d,"aria-busy":d||void 0,"aria-label":p[`aria-label`]||e,className:`${l||``} button-${t}`,children:[(0,S.jsx)(`span`,{className:`button-surface`,"aria-hidden":`true`}),(0,S.jsxs)(`span`,{className:`button-content`,children:[n&&r===`start`&&(0,S.jsx)(`span`,{className:`buttonIcon`,children:n}),(0,S.jsxs)(`span`,{className:`button-label`,children:[c,c&&e?` `:``,e]}),n&&r===`end`&&(0,S.jsx)(`span`,{className:`buttonIcon`,children:n})]}),d&&(0,S.jsx)(`span`,{className:`button-spinner`,"aria-hidden":`true`})]});return i&&a?(0,S.jsx)(_e,{reason:a,fullWidth:o,children:g}):g});V.displayName=`Button`;var xe=s.div(e=>{let t={boxSizing:`border-box`};if(e.container)t={display:`flex`,flexWrap:e.wrap||`wrap`,flexDirection:e.direction||`row`,columnGap:`${e.columnSpacing}px`||0,rowGap:`${e.rowSpacing}px`||0,boxSizing:`content-box`};else if(e.item){let n=Object.keys(f);n.forEach((r,i)=>{let a=(0,d.default)(e,r,!1);if(a){let o={};if(typeof a==`number`&&(o={flexBasis:m((0,d.default)(e,r,12)),width:m((0,d.default)(e,r,12))}),a===`hidden`){let e=``;n[i+1]&&(e=`and (max-width:  ${(0,d.default)(f,n[i+1],0)}px)`),t={...t,[`@media (min-width: ${(0,d.default)(f,r,0)}px) ${e}`]:{display:`none`}}}t={...t,[`@media (min-width: ${(0,d.default)(f,r,0)}px)`]:{flexGrow:`1`,...o}}}})}return{minWidth:0,...t,...e.sx}}),H=e=>(0,S.jsx)(xe,{...e,children:e.children}),Se=i`0% {
                                      transform: translate(139.785027px, 140.086989px) rotate(45.236493deg);
                                      animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
                                    }
                                      10% {
                                        transform: translate(139.785027px, 140.086989px) rotate(-197.740907deg);
                                        animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
                                      }
                                      20% {
                                        transform: translate(139.785027px, 140.086989px) rotate(-108.6deg);
                                        animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
                                      }
                                      30% {
                                        transform: translate(139.785027px, 140.086989px) rotate(-17.484014deg);
                                        animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
                                      }
                                      33.333333% {
                                        transform: translate(139.785027px, 140.086989px) rotate(-17.48deg);
                                        animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
                                      }
                                      43.333333% {
                                        transform: translate(139.785027px, 140.086989px) rotate(160.887995deg);
                                      }
                                      100% {
                                        transform: translate(139.785027px, 140.086989px) rotate(160.887995deg);
                                      }`,Ce=i`
  0% {
    transform: scale(1, 0.995019);
  }
  33.333333% {
    transform: scale(1, 0.995019);
    animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
  }
  43.333333% {
    transform: scale(0.101121, 0.102033);
    animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
  }
  50% {
    transform: scale(0.1, 0.1);
    animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
  }
  60% {
    transform: scale(1, 1);
  }
  100% {
    transform: scale(1, 1);
  }
`,we=i`
  0% {
    opacity: 1;
  }
  6.666667% {
    opacity: 1;
  }
  10% {
    opacity: 0;
  }
  13.333333% {
    opacity: 0;
  }
  20% {
    opacity: 1;
  }
  30% {
    opacity: 1;
  }
  36.666667% {
    opacity: 1;
  }
  40% {
    opacity: 0;
  }
  100% {
    opacity: 0;
  }
`,Te=i`
  0% {
    d: path("M85.4,249.8C109.08,255.3,133.72,257.37,157.65,252.14C181.65,246.89,202.95,233.55,219.27,215.35C227.84,205.79,213.74,191.6,205.13,201.21C190.9,217.1,173.27,228.26,152.34,232.86C132.03,237.32,110.79,235.19,90.73,230.52C78.19,227.61,72.85,246.88,85.4,249.8C85.4,249.8,85.4,249.8,85.4,249.8Z");
  }
  10% {
    d: path("M85.4,249.8C85.4,249.8,85.399999,249.800001,85.399999,249.800001C85.399999,249.800001,85.4,249.800002,85.4,249.800002C85.4,249.800002,90.484102,251.966034,95.043213,248.269966C100.484052,243.859082,98.694728,236.722769,97.073675,234.469349C95.517658,232.306335,94.559418,231.751273,90.73,230.52C78.19,227.61,72.85,246.88,85.4,249.8C85.4,249.8,85.4,249.8,85.4,249.8Z");
  }
  20% {
    d: path("M85.4,249.8C85.4,249.8,85.399999,249.800001,85.399999,249.800001C85.399999,249.800001,85.4,249.800002,85.4,249.800002C85.4,249.800002,90.484102,251.966034,95.043213,248.269966C100.484052,243.859082,98.694728,236.722769,97.073675,234.469349C95.517658,232.306335,94.559418,231.751273,90.73,230.52C78.19,227.61,72.85,246.88,85.4,249.8C85.4,249.8,85.4,249.8,85.4,249.8Z");
  }
  30% {
    d: path("M85.4,249.8C109.08,255.3,133.72,257.37,157.65,252.14C181.65,246.89,202.95,233.55,219.27,215.35C227.84,205.79,213.74,191.6,205.13,201.21C190.9,217.1,173.27,228.26,152.34,232.86C132.03,237.32,110.79,235.19,90.73,230.52C78.19,227.61,72.85,246.88,85.4,249.8C85.4,249.8,85.4,249.8,85.4,249.8Z");
  }
  33.333333% {
    d: path("M85.4,249.8C109.08,255.3,133.72,257.37,157.65,252.14C181.65,246.89,202.95,233.55,219.27,215.35C227.84,205.79,213.74,191.6,205.13,201.21C190.9,217.1,173.27,228.26,152.34,232.86C132.03,237.32,110.79,235.19,90.73,230.52C78.19,227.61,72.85,246.88,85.4,249.8C85.4,249.8,85.4,249.8,85.4,249.8Z");
  }
  43.333333% {
    d: path("M84.281285,246.076032C107.50521,254.051555,133.72,257.37,157.65,252.14C181.65,246.89,202.95,233.55,219.27,215.35C227.84,205.79,213.74,191.6,205.13,201.21C190.9,217.1,173.27,228.26,152.34,232.86C132.03,237.32,86.465691,239.82846,53.85604,207.193233C41.31604,204.283233,32.439249,213.928672,40.474905,219.54755C40.474905,219.54755,61.310295,238.187372,84.281285,246.076032Z");
  }
  100% {
    d: path("M84.281285,246.076032C107.50521,254.051555,133.72,257.37,157.65,252.14C181.65,246.89,202.95,233.55,219.27,215.35C227.84,205.79,213.74,191.6,205.13,201.21C190.9,217.1,173.27,228.26,152.34,232.86C132.03,237.32,86.465691,239.82846,53.85604,207.193233C41.31604,204.283233,32.439249,213.928672,40.474905,219.54755C40.474905,219.54755,61.310295,238.187372,84.281285,246.076032Z");
  }
`,Ee=i`
  0% {
    d: path("M249.74,169.63C255.24,145.95,257.31,121.31,252.08,97.38C246.83,73.38,233.49,52.08,215.29,35.76C205.73,27.19,191.54,41.29,201.15,49.9C217.04,64.13,228.2,81.76,232.8,102.69C237.26,123,235.13,144.24,230.46,164.3C227.54,176.84,246.82,182.18,249.74,169.63C249.74,169.63,249.74,169.63,249.74,169.63Z");
  }
  10% {
    d: path("M250.887564,168.08137C250.887564,168.081368,250.887563,168.081375,250.887563,168.081375C250.887563,168.081375,253.7831,157.676613,244.778825,154.781475C235.762034,151.882313,232.694053,158.881918,231.752888,162.486547C231.017121,165.304508,231.564293,168.517464,232.231509,169.666243C233.407087,171.690293,235.517449,173.828597,238.467701,174.606956C241.339242,175.364549,245.542656,175.427978,248.770823,172.704057C248.770823,172.704057,250.400569,171.202441,250.887564,168.08137Z");
  }
  20% {
    d: path("M250.887564,168.08137C250.887564,168.081368,250.887563,168.081375,250.887563,168.081375C250.887563,168.081375,253.7831,157.676613,244.778825,154.781475C235.762034,151.882313,232.694053,158.881918,231.752888,162.486547C231.017121,165.304508,231.564293,168.517464,232.231509,169.666243C233.407087,171.690293,235.517449,173.828597,238.467701,174.606956C241.339242,175.364549,245.542656,175.427978,248.770823,172.704057C248.770823,172.704057,250.400569,171.202441,250.887564,168.08137Z");
  }
  30% {
    d: path("M249.74,169.63C255.24,145.95,257.31,121.31,252.08,97.38C246.83,73.38,233.49,52.08,215.29,35.76C205.73,27.19,191.54,41.29,201.15,49.9C217.04,64.13,228.2,81.76,232.8,102.69C237.26,123,235.13,144.24,230.46,164.3C227.54,176.84,246.82,182.18,249.74,169.63C249.74,169.63,249.74,169.63,249.74,169.63Z");
  }
  33.333333% {
    d: path("M249.74,169.63C255.24,145.95,257.31,121.31,252.08,97.38C246.83,73.38,233.49,52.08,215.29,35.76C205.73,27.19,191.54,41.29,201.15,49.9C217.04,64.13,228.2,81.76,232.8,102.69C237.26,123,235.13,144.24,230.46,164.3C227.54,176.84,246.82,182.18,249.74,169.63C249.74,169.63,249.74,169.63,249.74,169.63Z");
  }
  43.333333% {
    d: path("M241.985702,180.287452C255.201364,145.393106,257.31,121.31,252.08,97.38C246.83,73.38,233.49,52.08,215.29,35.76C205.73,27.19,189.760952,38.146938,199.370952,46.756938C229.706596,66.855753,234.126292,101.544407,234.194759,127.574104C235.798839,155.047874,216.192342,185.901625,205.13,201.21C199.980012,208.336696,214.039151,220.128533,219.270001,215.35C219.270001,215.35,237.299554,192.660656,241.985702,180.287452Z");
  }
  100% {
    d: path("M241.985702,180.287452C255.201364,145.393106,257.31,121.31,252.08,97.38C246.83,73.38,233.49,52.08,215.29,35.76C205.73,27.19,189.760952,38.146938,199.370952,46.756938C229.706596,66.855753,234.126292,101.544407,234.194759,127.574104C235.798839,155.047874,216.192342,185.901625,205.13,201.21C199.980012,208.336696,214.039151,220.128533,219.270001,215.35C219.270001,215.35,237.299554,192.660656,241.985702,180.287452Z");
  }
`,De=i`
  0% {
    d: path("M171.68,7.71C148.17,1.51,123.61,-1.28,99.53,3.25C75.39,7.79,53.7,20.49,36.85,38.21C28.01,47.52,41.68,62.11,50.57,52.76C65.27,37.3,83.22,26.66,104.27,22.68C124.7,18.82,145.87,21.58,165.79,26.83C178.22,30.11,184.14,11,171.68,7.71C171.68,7.71,171.68,7.71,171.68,7.71Z");
  }
  10% {
    d: path("M171.58686,7.8192C164.834536,7.661923,162.882928,13.414575,162.613915,14.669774C162.613914,14.669774,161.858025,17.37084,162.366976,18.743708C162.782522,19.864622,163.527502,21.022768,164.723558,21.957074C165.842173,22.830886,168.859974,24.254302,168.859974,24.254302C168.859974,24.254302,168.859968,24.254306,168.859967,24.254304C181.289967,27.534304,184.046866,11.109212,171.586866,7.819212C171.586866,7.819212,171.58686,7.8192,171.58686,7.8192Z");
  }
  20% {
    d: path("M171.58686,7.8192C164.834536,7.661923,162.882928,13.414575,162.613915,14.669774C162.613914,14.669774,161.858025,17.37084,162.366976,18.743708C162.782522,19.864622,163.527502,21.022768,164.723558,21.957074C165.842173,22.830886,168.859974,24.254302,168.859974,24.254302C168.859974,24.254302,168.859968,24.254306,168.859967,24.254304C181.289967,27.534304,184.046866,11.109212,171.586866,7.819212C171.586866,7.819212,171.58686,7.8192,171.58686,7.8192Z");
  }
  30% {
    d: path("M171.68,7.71C148.17,1.51,123.61,-1.28,99.53,3.25C75.39,7.79,53.7,20.49,36.85,38.21C28.01,47.52,41.68,62.11,50.57,52.76C65.27,37.3,83.22,26.66,104.27,22.68C124.7,18.82,145.87,21.58,165.79,26.83C178.22,30.11,184.14,11,171.68,7.71C171.68,7.71,171.68,7.71,171.68,7.71Z");
  }
  33.333333% {
    d: path("M171.68,7.71C148.17,1.51,123.61,-1.28,99.53,3.25C75.39,7.79,53.7,20.49,36.85,38.21C28.01,47.52,41.68,62.11,50.57,52.76C65.27,37.3,83.22,26.66,104.27,22.68C124.7,18.82,145.87,21.58,165.79,26.83C178.22,30.11,184.14,11,171.68,7.71C171.68,7.71,171.68,7.71,171.68,7.71Z");
  }
  43.333333% {
    d: path("M154.601291,1.547478C127.732134,-3.659063,101.676041,0.16217,89.834975,4.047622C73.018778,9.565582,43.015709,29.967817,36.85,38.21C28.01,47.52,41.568561,62.002759,50.57,52.76C67.005248,35.884138,77.788003,22.937369,100.935291,18.024709C148.028227,8.029949,175.904245,24.591662,199.370952,46.756938C210.775532,51.88401,219.463487,39.878796,215.289997,35.759998C189.664787,10.470596,154.601291,1.547478,154.601291,1.547478Z");
  }
  100% {
    d: path("M154.601291,1.547478C127.732134,-3.659063,101.676041,0.16217,89.834975,4.047622C73.018778,9.565582,43.015709,29.967817,36.85,38.21C28.01,47.52,41.568561,62.002759,50.57,52.76C67.005248,35.884138,77.788003,22.937369,100.935291,18.024709C148.028227,8.029949,175.904245,24.591662,199.370952,46.756938C210.775532,51.88401,219.463487,39.878796,215.289997,35.759998C189.664787,10.470596,154.601291,1.547478,154.601291,1.547478Z");
  }
`,Oe=i`
  0% {
    d: path("M5.83,85.46C0.33,109.14,-1.74,133.78,3.49,157.71C8.74,181.71,22.08,203.01,40.28,219.33C49.84,227.9,64.03,213.8,54.42,205.19C38.53,190.96,27.37,173.33,22.77,152.4C18.31,132.09,20.44,110.85,25.11,90.79C28.03,78.25,8.75,72.91,5.83,85.46L5.83,85.46Z");
  }
  3.333333% {
    d: path("M4.90273,88.748028C1.236063,104.534694,0.694614,122.375568,4.181281,138.328902C7.119767,155.82704,18.329955,178.442148,31.722495,188.944182C39.448991,194.869945,48.960631,181.919808,35.808325,167.974185C27.053341,155.46954,26.778713,144.786038,23.180834,130.168643C19.139468,114.899686,18.114526,100.786543,20.952073,87.411869C21.572437,79.045425,6.897064,77.595457,4.916661,86.915441L4.90273,88.748028Z");
  }
  10% {
    d: path("M3.04819,95.324083C3.04819,95.324083,5.563842,99.566705,5.563842,99.566705C5.563842,99.566705,11.253926,104.287825,15.031546,103.153927C19.091035,103.791214,24.274539,98.764542,25.851733,95.404259C27.275674,92.370488,25.596139,87.698114,24.002501,85.705929C20.798403,80.519057,13.463578,80.659628,12.636219,80.655608C8.65731,80.636275,3.191193,86.96637,3.089982,89.826322L3.04819,95.324083Z");
  }
  20% {
    d: path("M3.04819,95.324083C3.04819,95.324083,5.563842,99.566705,5.563842,99.566705C5.563842,99.566705,11.253926,104.287825,15.031546,103.153927C19.091035,103.791214,24.274539,98.764542,25.851733,95.404259C27.275674,92.370488,25.596139,87.698114,24.002501,85.705929C20.798403,80.519057,13.463578,80.659628,12.636219,80.655608C8.65731,80.636275,3.191193,86.96637,3.089982,89.826322L3.04819,95.324083Z");
  }
  30% {
    d: path("M5.83,85.46C0.33,109.14,-1.74,133.78,3.49,157.71C8.74,181.71,22.08,203.01,40.28,219.33C49.84,227.9,64.03,213.8,54.42,205.19C38.53,190.96,27.37,173.33,22.77,152.4C18.31,132.09,20.44,110.85,25.11,90.79C28.03,78.25,8.75,72.91,5.83,85.46L5.83,85.46Z");
  }
  33.333333% {
    d: path("M5.83,85.46C0.33,109.14,-1.74,133.78,3.49,157.71C8.74,181.71,22.08,203.01,40.28,219.33C49.84,227.9,64.03,213.8,54.42,205.19C38.53,190.96,27.37,173.33,22.77,152.4C18.31,132.09,20.44,110.85,25.11,90.79C28.03,78.25,8.75,72.91,5.83,85.46L5.83,85.46Z");
  }
  43.333333% {
    d: path("M36.436007,38.11681C-7.498754,85.801617,-0.826469,134.911183,5.658972,158.164678C15.873566,192.855226,35.43893,215.965329,40.28,219.33C49.84,227.9,63.271136,215.585685,53.661136,206.975685C38.384036,191.128398,25.999041,166.121323,22.77,152.4C12.429986,121.009925,27.020185,73.061168,50.245766,52.61587C65.058304,39.576508,51.054205,23.186387,36.436019,38.116819L36.436007,38.11681Z");
  }
  100% {
    d: path("M36.436007,38.11681C-7.498754,85.801617,-0.826469,134.911183,5.658972,158.164678C15.873566,192.855226,35.43893,215.965329,40.28,219.33C49.84,227.9,63.271136,215.585685,53.661136,206.975685C38.384036,191.128398,25.999041,166.121323,22.77,152.4C12.429986,121.009925,27.020185,73.061168,50.245766,52.61587C65.058304,39.576508,51.054205,23.186387,36.436019,38.116819L36.436007,38.11681Z");
  }
`,ke=i`
  0% {
    transform: translate(139.784999px, 140.086986px) scale(1, 1);
  }
  30% {
    transform: translate(139.784999px, 140.086986px) scale(1, 1);
  }
  43.333333% {
    transform: translate(139.784999px, 140.086986px) scale(0.102813, 0.102813);
  }
  50% {
    transform: translate(139.784999px, 140.086986px) scale(0.102813, 0.102813);
  }
  60% {
    transform: translate(139.784999px, 140.086986px) scale(1.001075, 1.001075);
  }
  100% {
    transform: translate(139.784999px, 140.086986px) scale(1.001075, 1.001075);
  }
`,Ae=i`
  0% {
    opacity: 0;
  }
  30% {
    opacity: 0;
  }
  36.666667% {
    opacity: 0;
  }
  40% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
`,je=i`0% {
                                       transform: translate(139.785004px, 140.086979px) rotate(0deg);
                                     }
                                       10% {
                                         transform: translate(139.785004px, 140.086979px) rotate(0deg);
                                       }
                                       20% {
                                         transform: translate(139.785004px, 140.086979px) rotate(90.041277deg);
                                       }
                                       100% {
                                         transform: translate(139.785004px, 140.086979px) rotate(90.041277deg);
                                       }`,Me=i`
  0% {
    opacity: 0;
  }
  6.666667% {
    opacity: 0;
  }
  10% {
    opacity: 1;
  }
  13.333333% {
    opacity: 1;
  }
  20% {
    opacity: 0;
  }
  100% {
    opacity: 0;
  }
`,Ne=s.svg({width:40,height:40},l`
    color: var(--foreground);
    @media (prefers-reduced-motion: reduce) {
      g {
        animation: none !important;
      }
    }
    path {
      fill: currentColor;
    }
    #section1 {
      animation: ${Se} 3000ms linear infinite normal forwards;
    }
    #section2 {
      animation: ${Ce} 3000ms linear infinite normal forwards;
    }
    #section3 {
      animation: ${we} 3000ms linear infinite normal forwards;
    }
    #section4 {
      animation: ${Te} 3000ms linear infinite normal forwards;
    }
    #section5 {
      animation: ${Ee} 3000ms linear infinite normal forwards;
    }
    #section6 {
      animation: ${De} 3000ms linear infinite normal forwards;
    }
    #section7 {
      animation: ${Oe} 3000ms linear infinite normal forwards;
    }
    #section8 {
      animation: ${ke} 3000ms linear infinite normal forwards;
    }
    #section9 {
      animation: ${Ae} 3000ms linear infinite normal forwards;
    }
    #section10 {
      animation: ${je} 3000ms linear infinite normal forwards;
    }
    #section11 {
      animation: ${Me} 3000ms linear infinite normal forwards;
    }
  `),Pe=e=>(0,S.jsxs)(Ne,{viewBox:`0 0 280 280`,shapeRendering:`geometricPrecision`,textRendering:`geometricPrecision`,className:`min-loader`,...e,children:[(0,S.jsx)(`g`,{id:`section1`,transform:`translate(139.785027,140.086989) rotate(45.236493)`,children:(0,S.jsx)(`g`,{id:`section2`,transform:`scale(1,0.995019)`,children:(0,S.jsxs)(`g`,{id:`section3`,transform:`translate(-127.784998,-128.086989)`,children:[(0,S.jsx)(`g`,{children:(0,S.jsx)(`path`,{id:`section4`,d:`M85.4,249.8c23.68,5.5,48.32,7.57,72.25,2.34c24-5.25,45.3-18.59,61.62-36.79c8.57-9.56-5.53-23.75-14.14-14.14-14.23,15.89-31.86,27.05-52.79,31.65-20.31,4.46-41.55,2.33-61.61-2.34-12.54-2.91-17.88,16.36-5.33,19.28c0,0,0,0,0,0Z`})}),(0,S.jsx)(`g`,{children:(0,S.jsx)(`path`,{id:`section5`,d:`M249.74,169.63c5.5-23.68,7.57-48.32,2.34-72.25-5.25-24-18.59-45.3-36.79-61.62-9.56-8.57-23.75,5.53-14.14,14.14c15.89,14.23,27.05,31.86,31.65,52.79c4.46,20.31,2.33,41.55-2.34,61.61-2.92,12.54,16.36,17.88,19.28,5.33c0,0,0,0,0,0Z`})}),(0,S.jsx)(`g`,{children:(0,S.jsx)(`path`,{id:`section6`,d:`M171.68,7.71c-23.51-6.2-48.07-8.99-72.15-4.46C75.39,7.79,53.7,20.49,36.85,38.21c-8.84,9.31,4.83,23.9,13.72,14.55c14.7-15.46,32.65-26.1,53.7-30.08c20.43-3.86,41.6-1.1,61.52,4.15c12.43,3.28,18.35-15.83,5.89-19.12c0,0,0,0,0,0Z`})}),(0,S.jsx)(`g`,{children:(0,S.jsx)(`path`,{id:`section7`,d:`M5.83,85.46c-5.5,23.68-7.57,48.32-2.34,72.25c5.25,24,18.59,45.3,36.79,61.62c9.56,8.57,23.75-5.53,14.14-14.14-15.89-14.23-27.05-31.86-31.65-52.79-4.46-20.31-2.33-41.55,2.34-61.61C28.03,78.25,8.75,72.91,5.83,85.46v0Z`,transform:`translate(.194904 0.217549)`})})]})})}),(0,S.jsx)(`g`,{id:`section8`,transform:`translate(139.784999,140.086986) scale(1,1)`,children:(0,S.jsx)(`g`,{id:`section9`,transform:`translate(-127.999996,-128.000003)`,opacity:`0`,children:(0,S.jsx)(`path`,{d:`M234.23,128c0-58.67-47.56-106.23-106.23-106.23s-106.23,47.56-106.23,106.23s47.56,106.23,106.23,106.23c58.64-.06,106.17-47.59,106.23-106.23m21.25,0c0,70.4-57.07,127.48-127.48,127.48s-127.48-57.08-127.48-127.48s57.08-127.48,127.48-127.48s127.48,57.08,127.48,127.48Z`})})}),(0,S.jsx)(`g`,{id:`section10`,transform:`translate(139.785004,140.086979) rotate(0)`,children:(0,S.jsx)(`g`,{id:`section11`,transform:`translate(-127.999968,-127.995139)`,opacity:`0`,children:(0,S.jsx)(`path`,{d:`M128,0.47h.33c.36,0,.73,0,1.09.01h.17c5.45.09,9.79,4.57,9.73,10.02-.07,5.51-4.57,9.93-10.07,9.91h-1.24c-5.51-.04-9.96-4.51-9.96-10.02-.01-5.45,4.39-9.88,9.84-9.91h.11ZM245.62,118.39h.03c5.45.01,9.86,4.42,9.88,9.87c0,.04,0,.08,0,.12v0c0,.12,0,.24,0,.36v0c0,.01,0,.03,0,.04v.09c0,.37,0,.73-.01,1.09-.11,5.45-4.6,9.78-10.05,9.7-5.51-.08-9.92-4.6-9.88-10.1l.01-1.24c.06-5.49,4.52-9.92,10.02-9.93ZM126.01,235.58h.12l1.24.01c5.51.07,9.93,4.57,9.9,10.08-.04,5.48-4.51,9.89-9.99,9.85-.01,0-.02,0-.03,0h-.46-.19l-.82-.01h-.12c-5.45-.12-9.77-4.63-9.67-10.07.09-5.47,4.55-9.85,10.02-9.86ZM10.4,115.63h.2c5.51.12,9.89,4.65,9.82,10.16l-.02,1.24c-.09,5.5-4.59,9.91-10.1,9.88-5.45-.04-9.85-4.47-9.83-9.93c0-.04,0-.08,0-.12v0c0-.36,0-.73.01-1.09v-.09v0c0-.13,0-.27.01-.41.14-5.37,4.54-9.64,9.91-9.64Z`})})})]});function Fe(e){return u.Children.toArray(e).some(e=>u.isValidElement(e)&&(e.type===`title`||e.type===u.Fragment&&Fe(e.props.children)))}function U(e,t){let n=u.forwardRef(({className:e,children:n,title:r,role:i,"aria-hidden":a,...o},s)=>{let c=!!(o[`aria-label`]||o[`aria-labelledby`]||r||Fe(n)||i&&i!==`none`&&i!==`presentation`);return(0,S.jsxs)(`svg`,{xmlns:`http://www.w3.org/2000/svg`,width:24,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:2,strokeLinecap:`round`,strokeLinejoin:`round`,focusable:`false`,role:i??(c?`img`:void 0),"aria-hidden":a??(!c||void 0),...o,ref:s,className:[`min-icon`,`lucide-icon`,e].filter(Boolean).join(` `),children:[r&&(0,S.jsx)(`title`,{children:r}),n,(0,S.jsx)(`g`,{fill:`none`,children:t})]})});return n.displayName=e,n}var Ie=U(`LucideRefreshCw`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`path`,{d:`M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8`}),(0,S.jsx)(`path`,{d:`M21 3v5h-5`}),(0,S.jsx)(`path`,{d:`M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16`}),(0,S.jsx)(`path`,{d:`M8 16H3v5`})]})),W=U(`LucideCircleQuestionMark`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`circle`,{cx:`12`,cy:`12`,r:`10`}),(0,S.jsx)(`path`,{d:`M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3`}),(0,S.jsx)(`path`,{d:`M12 17h.01`})]})),Le=U(`LucideArrowRight`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`path`,{d:`M5 12h14`}),(0,S.jsx)(`path`,{d:`m12 5 7 7-7 7`})]})),Re=U(`LucideKeyRound`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`path`,{d:`M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z`}),(0,S.jsx)(`circle`,{cx:`16.5`,cy:`7.5`,r:`.5`,fill:`currentColor`})]})),ze=U(`LucideEye`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`path`,{d:`M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0`}),(0,S.jsx)(`circle`,{cx:`12`,cy:`12`,r:`3`})]})),Be=U(`LucideUserRound`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`circle`,{cx:`12`,cy:`8`,r:`5`}),(0,S.jsx)(`path`,{d:`M20 21a8 8 0 0 0-16 0`})]})),Ve=U(`LucideBookOpen`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`path`,{d:`M12 5v16`}),(0,S.jsx)(`path`,{d:`M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z`})]})),He=U(`LucideLogOut`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`path`,{d:`m16 17 5-5-5-5`}),(0,S.jsx)(`path`,{d:`M21 12H9`}),(0,S.jsx)(`path`,{d:`M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4`})]})),Ue=U(`LucideLockKeyhole`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`circle`,{cx:`12`,cy:`16`,r:`1`}),(0,S.jsx)(`rect`,{x:`3`,y:`10`,width:`18`,height:`12`,rx:`2`}),(0,S.jsx)(`path`,{d:`M7 10V7a5 5 0 0 1 10 0v3`})]})),G=U(`LucideX`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`path`,{d:`M18 6 6 18`}),(0,S.jsx)(`path`,{d:`m6 6 12 12`})]})),We=U(`LucideChevronUp`,(0,S.jsx)(S.Fragment,{children:(0,S.jsx)(`path`,{d:`m18 15-6-6-6 6`})})),Ge=U(`LucideChevronDown`,(0,S.jsx)(S.Fragment,{children:(0,S.jsx)(`path`,{d:`m6 9 6 6 6-6`})})),Ke=U(`LucideRss`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`path`,{d:`M4 11a9 9 0 0 1 9 9`}),(0,S.jsx)(`path`,{d:`M4 4a16 16 0 0 1 16 16`}),(0,S.jsx)(`circle`,{cx:`5`,cy:`19`,r:`1`})]})),qe=U(`LucideEyeOff`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`path`,{d:`M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49`}),(0,S.jsx)(`path`,{d:`M14.084 14.158a3 3 0 0 1-4.242-4.242`}),(0,S.jsx)(`path`,{d:`M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143`}),(0,S.jsx)(`path`,{d:`m2 2 20 20`})]})),Je=U(`LucideMoon`,(0,S.jsx)(S.Fragment,{children:(0,S.jsx)(`path`,{d:`M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401`})})),Ye=U(`LucideSun`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`circle`,{cx:`12`,cy:`12`,r:`4`}),(0,S.jsx)(`path`,{d:`M12 2v2`}),(0,S.jsx)(`path`,{d:`M12 20v2`}),(0,S.jsx)(`path`,{d:`m4.93 4.93 1.41 1.41`}),(0,S.jsx)(`path`,{d:`m17.66 17.66 1.41 1.41`}),(0,S.jsx)(`path`,{d:`M2 12h2`}),(0,S.jsx)(`path`,{d:`M20 12h2`}),(0,S.jsx)(`path`,{d:`m6.34 17.66-1.41 1.41`}),(0,S.jsx)(`path`,{d:`m19.07 4.93-1.41 1.41`})]})),Xe=i`
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
`,Ze=s.span({display:`inline-flex`,position:`relative`},l`
    &:hover {
      & .tooltipElement {
        display: block;
        animation: ${Xe} 1s;
      }
    }
  `),Qe=s.div(({theme:e,placement:t})=>{let n=(0,d.default)(e,`tooltip.background`,`#737373`),r=(0,d.default)(e,`tooltip.color`,`#FFFFFF`),i={},a={content:`' '`,left:`50%`,border:`solid transparent`,height:0,width:0,position:`absolute`,pointerEvents:`none`,borderWidth:`6px`,marginLeft:`calc(6px * -1);`};switch(t){case`top`:i={transform:`translateX(-50%) translateY(-50%)`,"&::before":{...a,top:`100%`,borderTopColor:n}};break;case`right`:i={transform:`translateX(0) translateY(-50%)`,"&::before":{...a,left:`calc(6px * -1)`,top:`50%`,transform:`translateX(0) translateY(-50%)`,borderRightColor:n}};break;case`left`:i={transform:`translateX(-100%) translateY(-50%)`,"&::before":{...a,left:`auto`,right:`calc(6px * -2)`,top:`50%`,transform:`translateX(0) translateY(-50%)`,borderLeftColor:n}};break;default:i={transform:`translateX(-50%)`,"&::before":{...a,bottom:`100%`,borderBottomColor:n}}}return{position:`fixed`,borderRadius:4,color:r,background:n,lineHeight:1,zIndex:10001,padding:2,fontSize:12,boxShadow:`#00000050 0px 3px 10px`,maxWidth:350,...i}}),$e=s.div(({theme:e,placement:t})=>{let n=(0,d.default)(e,`tooltip.background`,`#737373`),r={},i={content:`' '`,left:`50%`,height:0,width:0,position:`absolute`,pointerEvents:`none`,marginLeft:`calc(6px * -1);`};switch(t){case`top`:r={transform:`translateX(-50%) translateY(-50%)`,"&::before":{...i,top:`100%`,borderTopColor:n}};break;case`right`:r={transform:`translateX(0) translateY(-50%)`,"&::before":{...i,left:`calc(6px * -1)`,top:`50%`,transform:`translateX(0) translateY(-50%)`,borderRightColor:n}};break;case`left`:r={transform:`translateX(-100%) translateY(-50%)`,"&::before":{...i,left:`auto`,right:`calc(6px * -2)`,top:`50%`,transform:`translateX(0) translateY(-50%)`,borderLeftColor:n}};break;default:r={transform:`translateX(-50%)`,"&::before":{...i,bottom:`100%`,borderBottomColor:n}}}return{position:`fixed`,color:n,zIndex:10001,...r}}),et=s.div(({theme:e})=>({border:`1px solid ${(0,d.default)(e,`borderColor`,`#E2E2E2`)}`,borderRadius:2,backgroundColor:(0,d.default)(e,`boxBackground`,`#FBFAFA`),paddingLeft:10,paddingTop:5,paddingBottom:5,paddingRight:10,"& .leftItems":{fontSize:16,fontWeight:`bold`,display:`flex`,alignItems:`center`,"& .min-icon":{marginRight:5,height:28,width:38}},"& .helpText":{fontSize:10,paddingLeft:5,marginTop:5,color:`black`}})),tt=({children:e,content:t,placement:n})=>{let[r,i]=(0,u.useState)(null),[a,o]=(0,u.useState)(!1),[s,c]=(0,u.useState)(!1),l=()=>{s?setTimeout(()=>{o(!1),c(!1)},5e4):setTimeout(()=>{o(!1)},1e3)},d=()=>{s||(o(!1),c(!0))},f=({placement:e,content:t,anchorEl:n})=>{let r={},i=e;if(n){let t=n.getBoundingClientRect(),a=document.documentElement.offsetWidth,o=document.documentElement.offsetHeight;switch(e){case`bottom`:t.top+t.height+25>o&&(i=`top`);break;case`left`:t.left-175<0&&(i=`right`);break;case`right`:t.left+t.width+175>a&&(i=`left`);break;case`top`:t.top<25&&(i=`bottom`)}switch(i){case`bottom`:r={top:t.top+t.height+10,left:t.left+t.width/2};break;case`left`:r={top:t.top+t.height/2,left:t.left-12};break;case`right`:r={top:t.top+t.height/2,left:t.left+t.width+12};break;case`top`:r={top:t.top-t.height/2-10,left:t.left+t.width/2}}}return(0,S.jsx)(Qe,{placement:i,style:r,onClick:d,children:t})},p=({placement:e,anchorEl:t})=>{let n={},r=e;if(t){let i=t.getBoundingClientRect(),a=document.documentElement.offsetWidth,o=document.documentElement.offsetHeight;switch(e){case`bottom`:i.top+i.height+45>o&&(r=`top`);break;case`left`:i.left-175;break;case`right`:i.left+i.width+175>a&&(r=`left`);break;case`top`:i.top<45&&(r=`bottom`)}switch(r){case`bottom`:n={top:i.top+i.height+10,left:i.left+i.width/2};break;case`left`:n={top:i.top+i.height/2,left:i.left-12};break;case`right`:n={top:i.top+i.height/2,left:i.left+i.width+12};break;case`top`:n={top:i.top-i.height/2-10,left:i.left+i.width/2}}}return(0,S.jsx)($e,{placement:r,style:n,onClick:d,children:(0,S.jsx)(W,{style:{width:12,height:12}})})};function m(e){(0,u.useEffect)(()=>{function t(t){e.current&&!e.current.contains(t.target)&&c(!1)}return document.addEventListener(`mousedown`,t),()=>{document.removeEventListener(`mousedown`,t)}},[e])}let h=(0,u.useRef)(null);return m(h),n?(0,S.jsx)(u.Fragment,{children:(0,S.jsxs)(Ze,{ref:h,onPointerEnter:e=>{s||(i(e.currentTarget),o(!0))},onMouseLeave:l,children:[e,a&&!s&&(0,j.createPortal)((0,S.jsx)(p,{placement:n,content:(0,S.jsx)(W,{}),anchorEl:r}),document.body),s&&(0,j.createPortal)((0,S.jsx)(f,{placement:n,content:(0,S.jsx)(et,{className:`helpbox-container`,ref:h,children:(0,S.jsx)(H,{container:!0,children:(0,S.jsx)(H,{item:!0,xs:12,className:`helpText`,children:t})})}),anchorEl:r}),document.body)]})}):(0,S.jsx)(u.Fragment,{children:e})},nt=s.label(({sx:e})=>({fontWeight:400,marginRight:10,fontSize:`var(--fs-body,13px)`,lineHeight:`var(--lh-body,20px)`,color:`var(--foreground)`,textAlign:`left`,alignItems:`center`,display:`flex`,userSelect:`none`,minWidth:0,whiteSpace:`normal`,overflowWrap:`anywhere`,"& > span":{display:`flex`,alignItems:`center`,width:160,minWidth:0,"&.noMinWidthLabel":{minWidth:`initial`,width:`auto`}},"@media (max-width: 767.98px)":{marginRight:0,"& > span":{width:`auto`,minWidth:0}},'[data-field-layout="stacked"] &':{marginRight:0,"& > span":{width:`auto`,minWidth:0}},...e})),K=({children:e,sx:t,noMinWidth:n,htmlFor:r,helpTip:i,helpTipPlacement:a,...o})=>(0,S.jsx)(nt,{sx:t,htmlFor:r,...o,children:(0,S.jsx)(`span`,{className:`${n?`noMinWidthLabel`:``}`,children:i?(0,S.jsx)(tt,{placement:a,content:i,children:e}):e})}),rt=s(V)`
  padding: 0;
  width: ${({$size:e})=>e||`var(--control-height,36px)`};
  height: ${({$size:e})=>e||`var(--control-height,36px)`};
  @media (pointer: coarse) { min-width: 40px; min-height: 40px; }
  .button-label {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  svg {
    width: var(--icon-size, 16px);
    height: var(--icon-size, 16px);
    margin: 0;
    fill: currentColor;
  }
`,q=(0,u.forwardRef)(({children:e,label:t,size:n,id:r,sx:i,...a},o)=>{let s=a[`aria-label`]||t,c=n===`small`?`28px`:n===`medium`||n===`large`?`36px`:n,l=(0,S.jsx)(rt,{ref:o,id:r||``,type:`button`,...a,"aria-label":s,variant:`ghost`,collapseOnSmall:!1,$size:c,sx:i,children:e});return s&&!a.disabledReason&&!a[`aria-describedby`]?(0,S.jsx)(B,{tooltip:s,children:l}):l});q.displayName=`IconButton`;var it=s.div(({theme:e,sx:t,withBorders:n,customBorderPadding:r,useBackground:i})=>{let a={};return n&&(a={border:0,borderRadius:`var(--radius-card, 12px)`,boxShadow:`var(--shadow-2, none)`,backgroundColor:(0,d.default)(e,`boxBackground`,`#fff`),padding:r||15}),{...n||i?ie(3):{},backgroundColor:i?(0,d.default)(e,`boxBackground`,`#FBFAFA`):`transparent`,...a,...t}}),J=({sx:e,children:t,customBorderPadding:n,elementRef:r,...i})=>{let a=(0,S.jsx)(it,{ref:r,...i,sx:e,customBorderPadding:n,children:t});return i.withBorders||i.useBackground?(0,S.jsx)(N,{level:3,children:a}):a},at=s.div(({theme:e,sx:t,variant:n})=>({boxSizing:`border-box`,minWidth:0,maxWidth:n===`constrained`?1220:`initial`,padding:`var(--page-padding, 24px)`,background:`var(--surface-1)`,...t})),ot=({sx:e,children:t,variant:n,className:r,...i})=>(0,S.jsx)(at,{sx:e,variant:n,...i,children:(0,S.jsx)(H,{container:!0,children:(0,S.jsx)(H,{item:!0,xs:12,className:r,children:t})})}),st=(0,u.createContext)({close:`Close`,showPassword:`Show password`,hidePassword:`Hide password`,inputAction:`Input action`,chooseDate:`Choose date`,chooseDateTime:`Choose date and time`,calendarLocale:`en`,time:`Time`,hour:`Hour`,minute:`Minute`,second:`Second`,meridiem:`AM/PM`,am:`AM`,pm:`PM`,previousCalendarPeriod:`Previous calendar period`,nextCalendarPeriod:`Next calendar period`,progress:`Progress`,remove:`Remove`,on:`On`,off:`Off`}),ct=({labels:e,children:t})=>(0,S.jsx)(st.Provider,{value:e,children:t}),Y=()=>(0,u.useContext)(st),X={flexDirection:`column`,gap:8,"& > .inputLabel":{minHeight:`auto`,marginRight:0,marginBottom:0,alignSelf:`stretch`}},Z={"--field-height":`var(--control-height,36px)`,display:`flex`,alignItems:`flex-start`,flexGrow:1,width:`100%`,minWidth:0,"& > .inputLabel":{minHeight:`var(--field-height)`,marginBottom:0,flexShrink:0},"& .inputLabel .min-icon":{width:13,height:13,flexShrink:0},"& [id$='-error']":{overflowWrap:`anywhere`},"@media (pointer: coarse)":{"--field-height":`max(40px, var(--control-height,36px))`},"@media (max-width: 767.98px)":X,'&[data-field-layout="stacked"]':X,'[data-field-layout="stacked"] &':X},Q=l`
  ${O(`body`)}
  box-sizing: border-box;
  height: var(--field-height, var(--control-height, 36px));
  width: 100%;
  min-width: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--foreground);
  box-shadow: inset 0 0 0 1px var(--input);
  outline: none;
  padding: 0 var(--control-padding, 12px);
  font-variant-numeric: tabular-nums;
  &::placeholder,
  & .selectPlaceholder {
    color: var(--muted-foreground);
    opacity: 1;
  }
  &:hover:not(:disabled) {
    box-shadow: inset 0 0 0 1px var(--muted-foreground);
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
  }
  &[aria-invalid="true"] {
    box-shadow: inset 0 0 0 1px var(--destructive);
  }
  &:disabled {
    background: var(--muted);
    color: var(--foreground);
    cursor: not-allowed;
  }
  &:disabled::placeholder {
    color: var(--foreground);
  }
  &:disabled .selectPlaceholder {
    color: var(--foreground);
  }
  @media (pointer: coarse) {
    font-size: 16px;
  }
`,$=({text:e})=>(0,S.jsx)(q,{type:`button`,"data-field-help":`true`,size:`small`,label:e,sx:{marginLeft:4,flexShrink:0,"&& svg":{width:13,height:13}},children:(0,S.jsx)(W,{})}),lt=s.input`
  ${Q}
  padding-left: ${({startIcon:e})=>e?`36px`:`var(--control-padding,12px)`};
  padding-right: ${({overlayIcon:e,overlayObject:t,originType:n})=>e||t||n===`password`?`40px`:`var(--control-padding,12px)`};
`,ut=s.div(({theme:e,sx:t,$reserveErrorSpace:n})=>({...Z,"& .errorText":{fontSize:`var(--fs-caption,12px)`,lineHeight:`var(--lh-caption,16px)`,color:`var(--destructive-text)`,marginTop:3},"& .textBoxContainer":{width:`100%`,flexGrow:1,position:`relative`,minWidth:0,minHeight:n?`calc(var(--field-height, var(--control-height,36px)) + var(--lh-caption,16px) + 3px)`:void 0},"& .overlayAction":{position:`absolute`,right:5,top:`calc(var(--field-height, var(--control-height,36px)) / 2)`,transform:`translateY(-50%)`},"& .startOverlayIcon":{position:`absolute`,left:10,top:`calc((var(--field-height, var(--control-height,36px)) - var(--icon-size,16px)) / 2)`,"& svg":{width:14,height:14,fill:(0,d.default)(e,`inputBox.color`,`#07193E`),color:(0,d.default)(e,`inputBox.color`,`#07193E`)}},...t})),dt=u.forwardRef(({id:e,tooltip:t=``,index:n,type:r,overlayIcon:i,noLabelMinWidth:a,overlayId:o,overlayAction:s,overlayObject:c,label:l=``,required:d,startIcon:f,className:p,error:m,reserveErrorSpace:h=!1,sx:g,helpTip:_,helpTipPlacement:v,...y},b)=>{let x=Y(),[C,w]=(0,u.useState)(!1),T=i,E=r;return r===`password`&&!i&&(T=C?(0,S.jsx)(qe,{}):(0,S.jsx)(ze,{}),E=C?`text`:`password`),(0,S.jsxs)(ut,{$reserveErrorSpace:h,error:!!m&&m!==``,sx:g,className:`inputItem ${p}`,children:[l!==``&&(0,S.jsxs)(K,{htmlFor:e,noMinWidth:a,className:`inputLabel`,helpTip:_,helpTipPlacement:v,children:[l,d?`*`:``,t!==``&&(0,S.jsx)($,{text:t})]}),(0,S.jsxs)(J,{className:`textBoxContainer`,children:[f&&(0,S.jsx)(J,{className:`startOverlayIcon`,children:f}),(0,S.jsx)(lt,{id:e,fullWidth:!0,"aria-label":y[`aria-label`]||l||y.placeholder,type:E,error:m,"aria-invalid":!!m||void 0,"aria-describedby":m?`${e}-error`:y[`aria-describedby`],className:`inputRebase`,"data-index":n,startIcon:f,overlayObject:c,overlayIcon:i,originType:r,ref:b,...y}),T&&(0,S.jsx)(J,{className:`overlayAction`,children:(0,S.jsx)(q,{onClick:s?()=>{s()}:()=>w(!C),id:o,size:`25px`,type:`button`,disabled:y.disabled,"aria-label":r===`password`?C?x.hidePassword:x.showPassword:l||x.inputAction,children:T})}),c&&(0,S.jsx)(J,{className:`overlayAction`,children:c}),m&&(0,S.jsx)(J,{id:`${e}-error`,className:`errorText`,children:m})]})]})}),ft=`modulepreload`,pt=function(e,t){return new URL(e,t).href},mt={},ht=function(e){return e.pathname.endsWith(`.css`)},gt=function(e,t,n){if(t in e)return e[t];let r=n();if(!r){e[t]=void 0;return}let i=r.then(()=>{e[t]=void 0},n=>{throw e[t]=void 0,n});return e[t]=i,i},_t=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e,i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?new URL(import.meta.resolve(e)):new URL(e,import.meta.url)}r=o(t.map(t=>{t=pt(t,n);let r=s(t),i=ht(r);return gt(mt,r.href,()=>{if(e===void 0){e={all:new Set,styles:new Set};let t=document.getElementsByTagName(`link`);for(let n=t.length-1;n>=0;n--){let r=t[n];e.all.add(r.href),r.rel===`stylesheet`&&e.styles.add(r.href)}}if((i?e.styles:e.all).has(r.href))return;let t=document.createElement(`link`);if(t.rel=i?`stylesheet`:ft,i||(t.as=`script`),t.crossOrigin=``,t.href=r.href,a&&t.setAttribute(`nonce`,a),document.head.appendChild(t),i)return new Promise((e,n)=>{t.addEventListener(`load`,e),t.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${r}`)))})})}).filter(e=>e!==void 0))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},vt=(0,u.lazy)(()=>_t(()=>import(`./DropdownSelectorPopup-Bq6J-Bcq.js`),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url));function yt({open:e,anchorEl:t,hideTriggerAction:n}){return(0,u.useLayoutEffect)(()=>{if(!e||!t)return;let r=e=>{e.key===`Escape`&&(e.preventDefault(),e.stopPropagation()),e.key===`Tab`&&n()},i=e=>{e.key===`Escape`&&(e.preventDefault(),e.stopPropagation(),n())};return t.addEventListener(`keydown`,r),t.addEventListener(`keyup`,i),()=>{t.removeEventListener(`keydown`,r),t.removeEventListener(`keyup`,i)}},[e,t,n]),null}function bt(e){let t=F(),n=e.open&&t,[r,i]=(0,u.useState)(n);return(0,u.useEffect)(()=>{n&&i(!0)},[n]),n||r?(0,S.jsx)(u.Suspense,{fallback:(0,S.jsx)(yt,{...e,open:n}),children:(0,S.jsx)(vt,{...e,open:n})}):null}var xt=s.button`
  ${Q}
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  cursor: pointer;
  text-align: left;
  .truncate {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  svg {
    width: var(--icon-size, 16px);
    height: var(--icon-size, 16px);
    flex-shrink: 0;
    fill: currentColor;
  }
  .indicatorContainer {
    display: flex;
    align-items: center;
  }
`,St=s.div(({theme:e,sx:t})=>({...Z,position:`relative`,"& .selectContainer":{display:`flex`,width:`100%`,gap:8,alignItems:`center`,flexGrow:1,position:`relative`,minWidth:0},"& .overlayArrow":{position:`absolute`,top:`50%`,transform:`translateY(-50%)`,marginTop:`2px`,right:`5px`,"& svg":{width:26,height:26,fill:(0,d.default)(e,`inputBox.color`,`#07193E`),color:(0,d.default)(e,`inputBox.color`,`#07193E`)}},...t})),Ct=({id:e,label:t=``,"aria-label":n,required:r,className:i,tooltip:a=``,noLabelMinWidth:o=!1,value:s=``,sx:c,options:l,onChange:d,disabled:f=!1,fixedLabel:p=``,name:m,placeholder:h=``,helpTip:g,helpTipPlacement:_,error:v})=>{let y=F(),[b,x]=(0,u.useState)(!1),[C,w]=u.useState(null);(0,u.useEffect)(()=>{(!y||f)&&x(!1)},[y,f]);let T=b&&y&&!f,E=l.find(e=>e.value===s),D=n||t,O=`${e}-label`,k=`${e}-value`;return!E&&p===``&&h===``&&console.warn(`The selected value is not included in Options List`),(0,S.jsxs)(St,{error:!!v,sx:c,className:`inputItem ${i||``}`,children:[t!==``&&(0,S.jsxs)(K,{htmlFor:`${e}-select`,noMinWidth:o,className:`inputLabel`,helpTip:g,helpTipPlacement:_,children:[(0,S.jsx)(`span`,{id:n?void 0:O,children:t}),r?`*`:``,a!==``&&(0,S.jsx)($,{text:a})]}),n&&(0,S.jsx)(`span`,{id:O,hidden:!0,children:n}),(0,S.jsxs)(J,{className:`selectContainer`,sx:{flexDirection:`column`,alignItems:`stretch`},children:[(0,S.jsxs)(xt,{id:`${e}-select`,type:`button`,disabled:f,"aria-labelledby":D?`${O} ${k}`:k,"aria-haspopup":`listbox`,"aria-expanded":T,"aria-controls":T?`${e}-options-selector`:void 0,"aria-invalid":!!v||void 0,"aria-describedby":v?`${e}-error`:void 0,onClick:e=>{e.currentTarget.focus(),w(e.currentTarget),x(!T)},onKeyDown:e=>{(e.key===`ArrowDown`||e.key===`ArrowUp`)&&(e.preventDefault(),w(e.currentTarget),x(!0))},children:[(0,S.jsxs)(J,{sx:{display:`flex`,columnGap:8,width:`calc(100% - 16px)`},children:[E?.icon&&(0,S.jsx)(J,{className:`indicatorContainer`,children:E?.icon}),(0,S.jsx)(J,{id:k,sx:{whiteSpace:`nowrap`,overflow:`hidden`,textOverflow:`ellipsis`,minWidth:0},children:p&&p!==``?p:(0,S.jsx)(u.Fragment,{children:E?.label||(0,S.jsx)(`span`,{className:`selectPlaceholder`,children:h===``?``:h})})}),E?.indicator&&(0,S.jsx)(J,{className:`indicatorContainer`,children:E?.indicator})]}),(0,S.jsx)(J,{sx:{display:`flex`,width:16},children:T?(0,S.jsx)(We,{}):(0,S.jsx)(Ge,{})})]}),v&&(0,S.jsx)(`span`,{id:`${e}-error`,style:{color:`var(--destructive-text)`,fontSize:`var(--fs-caption)`,lineHeight:`var(--lh-caption)`},children:v}),(0,S.jsx)(`input`,{type:`hidden`,id:e,name:m,value:s})]}),(0,S.jsx)(bt,{id:`${e}-options-selector`,options:l,selectedOption:s,onSelect:(e,t)=>d(e,t),hideTriggerAction:()=>{x(!1)},ariaLabel:D?void 0:p||h||void 0,ariaLabelledBy:D?O:p||h?void 0:k,open:T,anchorEl:C,useAnchorWidth:!0})]})},wt={default:`var(--info)`,secondary:`var(--foreground)`,warn:`var(--warning)`,alert:`var(--destructive)`,ok:`var(--success)`,grey:`var(--muted-foreground)`},Tt=s.span`
  ${({$compact:e})=>O(`caption`,{compact:e})}
  display: inline-flex;
  align-items: center;
  max-width: 100%;
  box-sizing: border-box;
  white-space: nowrap;
  height: ${({$compact:e})=>e?20:24}px;
  padding: 0 ${({$compact:e})=>e?8:10}px;
  gap: ${({$compact:e})=>e?4:6}px;
  border-radius: 999px;
  color: var(--foreground);
  background: ${({$dot:e,$neutral:t,$tone:n})=>e?`transparent`:t?`var(--accent)`:`color-mix(in srgb, ${n} 15%, var(--background))`};
  border: 1px solid ${({$dot:e})=>e?`var(--border)`:`transparent`};
  .tag-dot {
    width: 6px;
    height: 6px;
    flex-shrink: 0;
    border-radius: 50%;
    background: ${({$tone:e})=>e};
  }
  svg {
    width: 12px;
    height: 12px;
    flex-shrink: 0;
    fill: currentColor;
  }
  .deleteTagButton {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    width: 16px;
    height: 16px;
    border: 0;
    border-radius: 4px;
    background: transparent;
    color: var(--foreground);
    cursor: pointer;
  }
  .deleteTagButton:hover {
    background: var(--hover);
  }
  .deleteTagButton:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
  }
  ${({$sx:e})=>e}
`,Et=({children:e,color:t=`default`,sx:n,onDelete:r,id:i,label:a,variant:o=`regular`,icon:s,square:c,deleteLabel:l,...u})=>{let d=Y(),{compact:f}=A(),p=o===`dot`||o===`outlined`;return(0,S.jsxs)(Tt,{id:i,$tone:wt[t],$dot:p,$neutral:t===`grey`||t===`secondary`,$compact:f,$sx:n,...u,children:[p&&!s&&(0,S.jsx)(`span`,{className:`tag-dot`,"aria-hidden":`true`}),s,(0,S.jsxs)(`span`,{children:[a,e]}),r&&(0,S.jsx)(`button`,{type:`button`,className:`deleteTagButton`,"aria-label":l||`${d.remove} ${a}`,onClick:()=>r(i),children:(0,S.jsx)(G,{})})]})},Dt={blue:`main`,red:`danger`,green:`good`,orange:`warning`,grey:`disabled`},Ot=s.div(({theme:e,sx:t,color:n,barHeight:r,transparentBG:i})=>({"& .progBlock":{display:`flex`,alignItems:`center`,gap:10},"& .progressContainer":{position:`relative`,width:`100%`,height:r,backgroundColor:i?`transparent`:`var(--muted)`,borderRadius:r,overflow:`hidden`},"& .notificationLabel":{fontSize:`var(--fs-caption,12px)`,lineHeight:`var(--lh-caption,16px)`,color:`var(--foreground)`},"& .percentageBar":{display:`block`,height:r,backgroundColor:n===`blue`?`var(--foreground)`:(0,d.default)(e,`signalColors.${Dt[n||`blue`]}`,v.mainBlue),width:`100%`,transformOrigin:`left`,transition:`transform var(--dur-moderate,160ms) var(--ease-moderate,ease-out)`,borderRadius:r},"@media (prefers-reduced-motion: reduce)":{"& .percentageBar":{transition:`none`}},...t})),kt=i`from { transform: translateX(-100%); } to { transform: translateX(400%); }`,At=s.div`
  width: 25%;
  height: ${e=>(0,d.default)(e,`barHeight`,8)}px;
  display: block;
  position: absolute;
  border-radius: ${e=>(0,d.default)(e,`barHeight`,8)}px;
  animation: ${kt} 1000ms linear infinite normal forwards;
  @media (prefers-reduced-motion: reduce) {
    animation: none;
    transform: translateX(150%);
  }
  background-color: ${e=>(e.color||`blue`)===`blue`?`var(--foreground)`:(0,d.default)(e.theme,`signalColors.${Dt[e.color||`blue`]}`,v.mainBlue)};
`,jt=({progressLabel:e=!1,sx:t,value:n=0,maxValue:r=100,variant:i=`indeterminate`,notificationLabel:a=``,color:o=`blue`,barHeight:s=6,transparentBG:c=!1})=>{let l=Y(),u=Number.isFinite(n)&&Number.isFinite(r)&&r>0?Math.max(0,Math.min(100,n/r*100)):0;return(0,S.jsxs)(Ot,{color:o,sx:t,barHeight:s,transparentBG:c,children:[(0,S.jsxs)(J,{className:`progBlock`,children:[(0,S.jsx)(J,{className:`progressContainer`,role:`progressbar`,"aria-valuemin":0,"aria-valuemax":100,"aria-valuenow":i===`determinate`?u:void 0,"aria-label":a||l.progress,children:i===`indeterminate`?(0,S.jsx)(At,{color:o,barHeight:s}):(0,S.jsx)(J,{className:`percentageBar`,style:{transform:`scaleX(${u/100})`}})}),e&&i!==`indeterminate`&&(0,S.jsxs)(`span`,{className:`progressPercentage`,children:[Math.floor(u),`%`]})]}),a!==``&&(0,S.jsx)(`span`,{className:`notificationLabel`,children:a})]})},Mt=s.div`
  ${({$condensed:e,$compact:t})=>O(e?`caption`:`body`,{compact:t})}
  position: ${({$inline:e})=>e?`relative`:`fixed`};
  z-index: 10000;
  ${({$inline:e})=>!e&&`top: 16px; left: 50%; translate: -50% 0;`}
  display: flex;
  align-items: center;
  gap: 12px;
  box-sizing: border-box;
  max-width: min(540px, calc(100vw - 32px));
  padding: ${({$condensed:e})=>e?`4px 12px`:`12px 16px`};
  border-radius: 8px;
  background: var(--foreground);
  color: var(--surface-1);
  box-shadow: var(--shadow-3);
  opacity: ${({$shown:e})=>+!!e};
  transform: ${({$shown:e})=>e?`translateY(0)`:`translateY(-4px)`};
  transition:
    opacity
      ${({$shown:e})=>e?`var(--dur-fast,80ms) var(--ease-fast,ease-out)`:`60ms var(--ease-exit,ease-in)`},
    transform
      ${({$shown:e})=>e?`var(--dur-fast,80ms) var(--ease-fast,ease-out)`:`60ms var(--ease-exit,ease-in)`};
  button {
    display: flex;
    width: 24px;
    height: 24px;
    border: 0;
    border-radius: 4px;
    background: transparent;
    color: inherit;
    cursor: pointer;
    flex-shrink: 0;
    padding: 6px;
  }
  button:hover {
    background: var(--tint);
  }
  button:focus-visible {
    outline: 2px solid var(--focus-ring);
  }
  svg {
    width: 12px;
    height: 12px;
    fill: currentColor;
  }
  @media (prefers-reduced-motion: reduce) {
    transform: none;
    transition-property: opacity;
  }
  ${({$sx:e})=>e}
`,Nt=({autoHideDuration:e=5,message:t=``,open:n,onClose:r,variant:i=`default`,condensed:a=!1,closeButton:o,sx:s,mode:c=`portal`})=>{let l=F(),d=n&&l,{compact:f}=A(),p=Y(),[m,h]=(0,u.useState)(!1),[g,_]=(0,u.useState)(d),[v,y]=(0,u.useState)(!1),b=(0,u.useRef)(r);if(b.current=r,(0,u.useEffect)(()=>{d&&_(!0)},[d]),(0,u.useEffect)(()=>{if(d&&g){let e=requestAnimationFrame(()=>y(!0));return()=>cancelAnimationFrame(e)}y(!1);let e=setTimeout(()=>_(!1),60);return()=>clearTimeout(e)},[d,g]),(0,u.useEffect)(()=>{if(!d||m||e<=0)return;let t=setTimeout(()=>b.current(),e*1e3);return()=>clearTimeout(t)},[d,m,e]),!g||!t)return null;let x=(0,S.jsxs)(Mt,{$compact:f,"aria-hidden":!d||void 0,style:{pointerEvents:d?void 0:`none`},$condensed:a,$inline:c===`inline`,$shown:v,$sx:s,role:i===`error`||i===`warning`?`alert`:`status`,onMouseEnter:()=>h(!0),onMouseLeave:()=>h(!1),onFocus:()=>h(!0),onBlur:()=>h(!1),children:[(0,S.jsx)(`span`,{children:t}),o&&(0,S.jsx)(`button`,{type:`button`,disabled:!d,"aria-label":p.close,onClick:r,children:(0,S.jsx)(G,{})})]});return c===`portal`?(0,j.createPortal)(x,document.body):x},Pt=U(`LucideFingerprintPattern`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`path`,{d:`M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4`}),(0,S.jsx)(`path`,{d:`M14 13.12c0 2.38 0 6.38-1 8.88`}),(0,S.jsx)(`path`,{d:`M17.29 21.02c.12-.6.43-2.3.5-3.02`}),(0,S.jsx)(`path`,{d:`M2 12a10 10 0 0 1 18-6`}),(0,S.jsx)(`path`,{d:`M2 16h.01`}),(0,S.jsx)(`path`,{d:`M21.8 16c.2-2 .131-5.354 0-6`}),(0,S.jsx)(`path`,{d:`M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2`}),(0,S.jsx)(`path`,{d:`M8.65 22c.21-.66.45-1.32.57-2`}),(0,S.jsx)(`path`,{d:`M9 6.8a6 6 0 0 1 9 5.2v2`})]})),Ft=U(`LucideFileVideoCamera`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`path`,{d:`M4 12V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2`}),(0,S.jsx)(`path`,{d:`M14 2v5a1 1 0 0 0 1 1h5`}),(0,S.jsx)(`path`,{d:`m10 17.843 3.033-1.755a.64.64 0 0 1 .967.56v4.704a.65.65 0 0 1-.967.56L10 20.157`}),(0,S.jsx)(`rect`,{width:`7`,height:`6`,x:`3`,y:`16`,rx:`1`})]})),It=U(`LucideLanguages`,(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`path`,{d:`m5 8 6 6`}),(0,S.jsx)(`path`,{d:`m4 14 6-6 2-3`}),(0,S.jsx)(`path`,{d:`M2 5h12`}),(0,S.jsx)(`path`,{d:`M7 2h1`}),(0,S.jsx)(`path`,{d:`m22 22-5-10-5 10`}),(0,S.jsx)(`path`,{d:`M14 18h6`})]}));export{E as $,Be as A,B,Ke as C,Ue as D,G as E,Ie as F,fe as G,ue as H,U as I,ne as J,P as K,Pe as L,Re as M,Le as N,He as O,W as P,T as Q,H as R,Je as S,We as T,me as U,le as V,F as W,O as X,A as Y,D as Z,J as _,jt as a,h as at,tt as b,bt as c,$ as d,w as et,Q as f,ot as g,Y as h,Nt as i,_ as it,ze as j,Ve as k,_t as l,ct as m,Ft as n,v as nt,Et as o,g as ot,Z as p,N as q,Pt as r,f as rt,Ct as s,It as t,C as tt,dt as u,q as v,Ge as w,Ye as x,K as y,V as z};