import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,t as n}from"./react-vendor-UL3KVrSx.js";import{T as r}from"./shared-vendor-BQfq49S_.js";import{wn as i}from"./store-DiSrkf12.js";import{i as a}from"./lang-C_0WK4Bf.js";import{h as o,rt as s}from"./mds-B28KNzw0.js";import{a as c,i as l,t as u}from"./i18n-CKF7kMSP.js";import{h as d}from"./index-I3FyEuJl.js";import{o as f,t as p}from"./permissions-BCt8lMfX.js";import{n as m}from"./SecureComponent-C2COUZhB.js";import{A as h,i as g,n as _,r as v}from"./ConsoleKBar-CuI4kA5a.js";var y=e(t()),b=`2.7.2`,x=n(),S=`https://silo.pgsty.com/`,C=`https://github.com/pgsty/silo`,w=`https://min.io/`,T=`https://github.com/minio/minio`,E=`https://www.gnu.org/licenses/agpl-3.0.html`,D=r.section`
  ${s(`body`)}
  max-width: 760px;
  margin: 0 auto;
  color: var(--foreground);
  & a {
    color: var(--foreground);
    text-decoration: underline;
    text-decoration-color: var(--border);
    text-underline-offset: 4px;
    overflow-wrap: anywhere;
  }
  & a:hover {
    text-decoration-color: currentColor;
  }
  & a:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 4px;
    border-radius: 4px;
  }
  & a[target="_blank"]::after {
    content: "↗";
    padding-inline-start: 4px;
    color: var(--muted-foreground);
    font-size: var(--fs-micro);
  }
`,O=r.a`
  width: 360px;
  max-width: 100%;
  margin: 8px auto 0;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
  text-decoration: none !important;
  &::after {
    display: none !important;
  }
  :root[data-theme="dark"] & .licenseWordmark {
    filter: brightness(1.5) saturate(0.85);
  }
`,k=r.p`
  ${s(`caption`)}
  margin: 16px 0 0;
  text-align: center;
  color: var(--muted-foreground);
  & .acr {
    color: var(--foreground);
    font-weight: 550;
  }
`,A=r.p`
  ${s(`subtitle`,{weight:`normal`})}
  margin: 32px 0 0;
  & a::after {
    display: none !important;
  }
  & strong {
    font-weight: 550;
  }
`,j=r.dl`
  margin: 32px 0 0;
  padding-top: 24px;
  border-top: 1px solid var(--border);
  display: grid;
  grid-template-columns: 112px minmax(0, 1fr);
  column-gap: 24px;
  row-gap: 24px;
  & dt {
    ${s(`body`,{weight:`semibold`})}
    padding-top: 4px;
    color: var(--muted-foreground);
  }
  & dd {
    margin: 0;
    min-width: 0;
  }
  & dd > * + * {
    margin-top: 8px;
  }
  & .chip {
    ${s(`caption`,{weight:`semibold`})}
    display: inline-block;
    max-width: 100%;
    box-sizing: border-box;
    padding: 4px 8px;
    border-radius: var(--radius-control);
    background: var(--muted);
    font-family: var(--font-mono);
    overflow-wrap: anywhere;
  }
  & .line {
    ${s(`body`)}
    font-family: var(--font-mono);
  }
  & .what {
    ${s(`caption`)}
    padding-inline-start: 8px;
    color: var(--muted-foreground);
  }
  & .prose {
    ${s(`body`)}
    margin: 0;
  }
  & .note {
    ${s(`caption`)}
    margin-bottom: 0;
    color: var(--muted-foreground);
  }
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
    row-gap: 8px;
    & dt:not(:first-of-type) {
      margin-top: 16px;
    }
  }
`,M=()=>{let e=l(),t=c(),n=`v${b}`,r=g(),[s,M]=(0,y.useState)(``),N=m(p,[f.ADMIN_SERVER_INFO]);return(0,y.useEffect)(()=>{N&&i.admin.adminInfo({defaultOnly:!1}).then(e=>{let t=Array.from(new Set((e.data?.servers||[]).map(e=>e.version).filter(Boolean)));M(t.join(` · `))}).catch(()=>{})},[N]),(0,x.jsxs)(y.Fragment,{children:[(0,x.jsx)(h,{label:a(`License`),titleElement:`h1`}),(0,x.jsx)(o,{children:(0,x.jsxs)(D,{children:[(0,x.jsxs)(O,{href:e(S),target:`_blank`,rel:`noopener noreferrer`,"aria-label":t(`Visit the SILO website`),children:[(0,x.jsx)(d,{variant:`emblem`,alt:`SILO emblem`,style:{display:`block`,width:`25%`,maxWidth:88}}),(0,x.jsx)(d,{className:`licenseWordmark`,style:{display:`block`,width:`60%`,maxWidth:200}})]}),(0,x.jsxs)(k,{children:[(0,x.jsx)(`span`,{className:`acr`,children:`S`}),`3 `,(0,x.jsx)(`span`,{className:`acr`,children:`I`}),`nterface · `,(0,x.jsx)(`span`,{className:`acr`,children:`L`}),`ibre`,` `,(0,x.jsx)(`span`,{className:`acr`,children:`O`}),`bject Store`]}),(0,x.jsx)(A,{children:u(t(`{silo} is an independently maintained continuation of the {minio} object storage project, carried forward by the {pigsty} community since 2026. Its {code} {incorporates} {upstream}, and the complete work remains licensed under the {agpl}.`),{silo:(0,x.jsx)(`a`,{href:e(S),target:`_blank`,rel:`noopener noreferrer`,children:`SILO`}),minio:(0,x.jsx)(`a`,{href:w,target:`_blank`,rel:`noopener noreferrer`,children:`MinIO`}),pigsty:(0,x.jsx)(`a`,{href:e(`https://pgsty.com/`),target:`_blank`,rel:`noopener noreferrer`,children:`PGSTY`}),code:(0,x.jsx)(`a`,{href:C,target:`_blank`,rel:`noopener noreferrer`,children:t(`code`)}),incorporates:(0,x.jsx)(`strong`,{children:t(`incorporates and modifies`)}),upstream:(0,x.jsx)(`a`,{href:T,target:`_blank`,rel:`noopener noreferrer`,children:t(`upstream MinIO code`)}),agpl:(0,x.jsx)(`a`,{href:E,target:`_blank`,rel:`license noopener noreferrer`,children:t(`GNU Affero General Public License, version 3`)})})}),(0,x.jsxs)(j,{children:[(0,x.jsx)(`dt`,{children:t(`Version`)}),(0,x.jsxs)(`dd`,{children:[s!==``&&(0,x.jsxs)(`div`,{className:`line`,children:[(0,x.jsx)(`span`,{className:`chip`,children:s}),(0,x.jsx)(`span`,{className:`what`,children:t(`connected server`)})]}),(0,x.jsxs)(`div`,{className:`line`,children:[(0,x.jsx)(`span`,{className:`chip`,children:n}),(0,x.jsx)(`span`,{className:`what`,children:t(`this Console`)})]})]}),(0,x.jsx)(`dt`,{children:t(`License`)}),(0,x.jsxs)(`dd`,{children:[(0,x.jsx)(`span`,{className:`chip`,children:`AGPL-3.0-or-later`}),(0,x.jsx)(`div`,{className:`line`,children:(0,x.jsx)(`a`,{href:E,target:`_blank`,rel:`license noopener noreferrer`,children:t(`GNU AGPL v3 full text`)})}),(0,x.jsx)(`div`,{className:`line`,children:(0,x.jsx)(`a`,{href:_.license,target:`_blank`,rel:`license noopener noreferrer`,children:t(`Console LICENSE`)})}),(0,x.jsx)(`p`,{className:`note`,children:u(t(`Server, client and Console are all AGPLv3. SILO's documentation is CC BY 4.0 — {licensing}.`),{licensing:(0,x.jsx)(`a`,{href:e(`https://silo.pgsty.com/about/license/`),target:`_blank`,rel:`noopener noreferrer`,children:t(`licensing in full`)})})})]}),(0,x.jsx)(`dt`,{children:t(`Source`)}),(0,x.jsxs)(`dd`,{children:[(0,x.jsxs)(`div`,{className:`line`,children:[(0,x.jsx)(`a`,{href:C,target:`_blank`,rel:`noopener noreferrer`,children:`pgsty/silo`}),(0,x.jsx)(`span`,{className:`what`,children:t(`server`)})]}),(0,x.jsxs)(`div`,{className:`line`,children:[(0,x.jsx)(`a`,{href:`https://github.com/pgsty/mc`,target:`_blank`,rel:`noopener noreferrer`,children:`pgsty/mc`}),(0,x.jsx)(`span`,{className:`what`,children:t(`client`)})]}),(0,x.jsxs)(`div`,{className:`line`,children:[(0,x.jsx)(`a`,{href:r.available?r.url:v,target:`_blank`,rel:`noopener noreferrer`,children:`pgsty/silo-console`}),(0,x.jsx)(`span`,{className:`what`,children:t(`this Console`)})]}),(0,x.jsx)(`div`,{className:`line`,"data-testid":`corresponding-source`,children:r.available?(0,x.jsx)(`a`,{href:r.url,target:`_blank`,rel:`noopener noreferrer`,children:t(`Corresponding source for this build`)}):(0,x.jsx)(`span`,{className:`what`,children:u(t(`The exact corresponding source is not available for this build: {reason}. See the NOTICE for how to obtain it.`),{reason:r.reason})})}),(0,x.jsxs)(`div`,{className:`line`,children:[(0,x.jsx)(`a`,{href:`https://github.com/georgmangold/console`,target:`_blank`,rel:`noopener noreferrer`,children:`georgmangold/console`}),(0,x.jsx)(`span`,{className:`what`,children:t(`Console predecessor`)})]}),(0,x.jsx)(`p`,{className:`note`,children:t(`Under section 13 of the AGPL, the corresponding source for this running version is offered to every user who interacts with it over a network, at no charge.`)})]}),(0,x.jsx)(`dt`,{children:t(`Copyright`)}),(0,x.jsxs)(`dd`,{children:[(0,x.jsxs)(`p`,{className:`prose`,children:[t(`© 2026 Ruohang Feng / PGSTY and the SILO contributors.`),(0,x.jsx)(`br`,{}),t(`Portions © 2015–2026 MinIO, Inc.`),(0,x.jsx)(`br`,{}),t(`Console portions © Georg Mangold and contributors.`)]}),(0,x.jsx)(`p`,{className:`note`,children:u(t(`Upstream copyright, authorship and license notices are retained in the repository's {credits} and {notice}. See the {attribution}.`),{credits:(0,x.jsx)(`a`,{href:_.credits,target:`_blank`,rel:`noopener noreferrer`,children:`CREDITS`}),notice:(0,x.jsx)(`a`,{href:_.notice,target:`_blank`,rel:`noopener noreferrer`,children:`NOTICE`}),attribution:(0,x.jsx)(`a`,{href:e(`https://silo.pgsty.com/about/attribution/`),target:`_blank`,rel:`noopener noreferrer`,children:t(`full attribution stack`)})})})]}),(0,x.jsx)(`dt`,{children:t(`Trademark`)}),(0,x.jsxs)(`dd`,{children:[(0,x.jsx)(`p`,{className:`prose`,children:u(t(`{minio} is a registered trademark of MinIO, Inc. {silo} is not a MinIO, Inc. product, and is not affiliated with, sponsored by, or endorsed by MinIO, Inc.`),{minio:(0,x.jsx)(`a`,{href:w,target:`_blank`,rel:`noopener noreferrer`,children:`MINIO®`}),silo:(0,x.jsx)(`a`,{href:e(S),target:`_blank`,rel:`noopener noreferrer`,children:`SILO`})})}),(0,x.jsx)(`p`,{className:`note`,children:u(t(`The MinIO name is used here solely to identify the origin of the source code and to describe compatibility — {notice}.`),{notice:(0,x.jsx)(`a`,{href:e(`https://silo.pgsty.com/about/trademark/`),target:`_blank`,rel:`noopener noreferrer`,children:t(`trademark notice`)})})})]})]})]})})]})};export{M as default};