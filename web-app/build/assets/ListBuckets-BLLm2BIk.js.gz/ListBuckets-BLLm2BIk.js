const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./BulkReplicationModal-D5o7REOq.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./store-CSj3S5xV.js","./lang-Cj6iPrRD.js","./mds-DIGH6qee.js","./triangle-alert-OJdFosrh.js","./circle-check-D_dLaEL9.js","./ReadBox-ChCQnby0.js","./Wizard-Dic1PICQ.js","./i18n-DR1ZnJgy.js","./ConsoleKBar-DBHdlyUP.js","./pencil-C9uU-qzX.js","./search-DcRoSu_i.js","./CircleIcon-BsXHTBH6.js","./trash-CLcijXUv.js","./clock-DpLPybsR.js","./plus-CIuWK0QD.js","./info-Btc_5g7D.js","./console-vendor-I3rSB1nD.js","./listPopup-D2sWpuy2.js","./SectionTitle-DUGS31lQ.js","./useAvailableWidth-COFYcObd.js","./ModalBox-BmLHq9NK.js","./ModalPresence-fpsC_efG.js","./index-DS9oHWow.js","./index-BFo1l52q.css","./typography-BkGdf5hc.js","./shared-FYQOZpEv.js","./OverflowMenu-BXaJLHnS.js","./typography-asHlM3Pp.js","./permissions-lxkQFTBB.js","./StatusBadge-BENFvE6N.js","./CliEquivalent-BI5vE9cH.js","./copy-47uxYBao.js","./code-B5r_64Bz.js","./lib-BVN4wEer.js","./SecureComponent-CcpMxLih.js","./BulkLifecycleModal-CMKWcyHJ.js","./QueryMultiSelector-DYef6h_c.js","./DeleteBucket-BqIqjc8l.js","./ConfirmDialog-CUxawWTz.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,d as n,f as r,h as i,r as a,t as o}from"./react-vendor-UL3KVrSx.js";import{D as s,T as c}from"./shared-vendor-BQfq49S_.js";import{$t as l,Cr as u,Jt as d,Sr as f,bn as p,n as ee,r as te,tr as m,xn as ne}from"./store-CSj3S5xV.js";import{n as h}from"./lang-Cj6iPrRD.js";import{O as g,S as re,U as _,b as ie,k as ae,p as v,z as oe}from"./mds-DIGH6qee.js";import{t as se}from"./trash-CLcijXUv.js";import{t as ce}from"./boxes-HjUgxrZC.js";import{t as le}from"./calendar-clock-obaK34Uz.js";import{t as ue}from"./plus-CIuWK0QD.js";import{t as y}from"./archive-tyuBBiTn.js";import{n as de,t as b}from"./folder-D70NPpER.js";import{t as x}from"./Checkbox-PeexYhGw.js";import{c as S,s as fe}from"./listPopup-D2sWpuy2.js";import{t as pe}from"./useTableLayout-iKPn_-di.js";import{a as C,n as w}from"./i18n-DR1ZnJgy.js";import{t as me}from"./ModalPresence-fpsC_efG.js";import{s as he}from"./index-DS9oHWow.js";import{n as T}from"./shared-FYQOZpEv.js";import{t as ge}from"./OverflowMenu-BXaJLHnS.js";import{t as E}from"./typography-asHlM3Pp.js";import{A as _e,a as D,g as O,i as k,n as A,o as j,p as M,r as N,t as ve}from"./permissions-lxkQFTBB.js";import{t as P}from"./StatusBadge-BENFvE6N.js";import{t as ye}from"./SearchBox-CjpAtsuH.js";import{t as F}from"./withSuspense-DTbtEWjP.js";import{n as I}from"./SecureComponent-CcpMxLih.js";import{n as L,r as R,t as z}from"./prefixUsage-CnsWbxUQ.js";import{t as B}from"./bucketMetadata-BAg0j77c.js";import{n as V}from"./react-window-0T2cJ04-.js";import{A as be,J as xe,V as Se,f as Ce}from"./ConsoleKBar-DBHdlyUP.js";var H=e(t()),U=(0,H.createContext)(void 0),we=U.Provider,W=()=>(0,H.useContext)(U),G=e=>e.state===`queued`||e.state===`running`;function Te(e){let t=JSON.stringify(e),n=R(),r=(0,H.useRef)(),[i,a]=(0,H.useState)(0),o=(0,H.useRef)(!1),[s,c]=(0,H.useState)({requesting:!1,records:{}}),l=(0,H.useCallback)(()=>{o.current=!0,a(e=>e+1)},[]);return(0,H.useEffect)(()=>{let e=JSON.parse(t),i=new AbortController;r.current?.abort(),r.current=i;let a,s=()=>!i.signal.aborted&&n(),l=o.current;o.current=!1,c(t=>({...t,records:Object.fromEntries(Object.entries(t.records).filter(([t])=>e.includes(t)))}));let u=async()=>{c(e=>({...e,requesting:!0}));let t=[...e],n=async()=>{for(;s()&&t.length;){let e=t.shift(),n=I(e,[j.S3_LIST_BUCKET_VERSIONS]),r={bucket:e,state:`running`,versions_visible:n},a=()=>s()&&c(t=>({...t,records:{...t.records,[e]:{...r}}}));a();try{let t=await p.buckets.prefixUsage(e,{prefix:``,versions:n,folders:!1},{signal:i.signal});await L(t,{bucket:e,prefix:``,mode:n?`versions`:`current`},e=>{let t={totals:{...e.totals,...n?{}:{retained_bytes:void 0,retained_versions:void 0,delete_markers:void 0}},scanned_entries:e.scanned_entries,started_at:e.started_at,updated_at:e.updated_at};r={...r,state:e.status===`scanning`?`running`:e.status===`failed`?`error`:e.status,progress:t,...e.status===`complete`?{last_good:t,last_completed_at:e.updated_at}:{}},a()})}catch{r={...r,state:`error`},a()}}};await Promise.all([n(),n()]),s()&&c(e=>({...e,requesting:!1}))},d=async t=>{if(s()){t&&c(e=>({...e,requesting:!0,error:!1}));try{let n=!1,r=2e3,o,l=[];for(let a=0;a<Math.max(e.length,1);a+=100){let s={buckets:e.slice(a,a+100)},c=t?await p.bucketUsage.bucketUsageRefresh(s,{signal:i.signal}):await p.bucketUsage.bucketUsageStatus(s,{signal:i.signal});if(n=c.data.enabled,r=c.data.poll_after_ms,o=c.data.coverage,l.push(...c.data.buckets),!n)break}if(!s())return;if(c({enabled:n,requesting:!1,records:Object.fromEntries(l.map(e=>[e.bucket,e])),coverage:o}),!n){t&&await u();return}let f=l.some(G);a=setTimeout(()=>void d(!1),Math.min(6e4,Math.max(250,r)*(f?1:10)))}catch{s()&&(c(e=>({...e,requesting:!1,error:!0})),a=setTimeout(()=>void d(!1),1e4))}}};return d(l),()=>{i.abort(),clearTimeout(a)}},[t,i,n]),{...s,refresh:l}}var K=o();function q({bucket:e}){let t=W(),n=t?.records[e],r=C();if(!t||!n&&!t.enabled)return null;let i={not_scanned:r(`Not scanned`),queued:r(`Update queued`),running:r(`Updating usage…`),complete:r(`Updated`),error:r(`Update failed — retry with Refresh`),limited:r(`Scan limit reached — operator action required`),forbidden:r(`Usage listing not permitted`),missing:r(`Bucket no longer exists`),unavailable:r(`Usage temporarily unavailable`)};return(0,K.jsxs)(`small`,{style:{display:`block`,fontWeight:400,overflow:`hidden`,textOverflow:`ellipsis`},title:n?.last_completed_at?new Date(n.last_completed_at).toLocaleString():void 0,children:[n?i[n.state]:r(`Checking usage…`),n?.state===`running`&&n.progress?` · ${h(r(`{count} entries scanned`),{count:n.progress.scanned_entries.toLocaleString()})}`:``,n?.last_completed_at?` · ${new Date(n.last_completed_at).toLocaleTimeString()}`:``]})}function Ee(){let e=W(),t=C();if(!e)return null;let n=Object.values(e.records),r=n.filter(e=>e.state===`queued`||e.state===`running`).length,i=n.filter(e=>[`error`,`limited`,`unavailable`].includes(e.state)).length,a=e.coverage?.observer_alive&&e.coverage.connected&&e.coverage.reconciled;return(0,K.jsxs)(`div`,{role:`status`,"aria-live":`polite`,style:{marginBottom:12},children:[e.requesting?t(`Requesting usage updates…`):r?h(t(`{count} usage updates queued or running. Last completed totals remain visible.`),{count:r}):t(`Refresh requests a new metadata scan of all listed buckets.`),` `,e.error?t(`Usage status is unavailable. Retrying…`):e.enabled?t(a?`Automatic change monitoring is active.`:`Automatic change monitoring is recovering; totals may be out of date.`):e.enabled===!1?t(`Automatic updates are not configured. Refresh calculates usage while this page is open.`):t(`Checking automatic updates…`),i>0&&(0,K.jsxs)(K.Fragment,{children:[` `,h(t(`{count} updates need attention. Use Refresh to retry.`),{count:i})]})]})}var De=[`name`,`objects`,`size`,`created`],Oe=e=>({sort:De.includes(e.get(`sort`)||``)?e.get(`sort`):`name`,dir:e.get(`dir`)===`desc`?`desc`:`asc`,q:e.get(`q`)||``}),J=(e,t)=>{let n=new URLSearchParams(e),r={...Oe(e),...t};for(let e of[`sort`,`dir`,`q`])!r[e]||e===`sort`&&r.sort===`name`||e===`dir`&&r.dir===`asc`?n.delete(e):n.set(e,r[e]);return n},ke=e=>e===`cards`?`cards`:`table`,Y=e=>!!(e&&Number.isFinite(Date.parse(e))),Ae=(e,t,n,r)=>{if(!(!e||n&&!Y(r)))return!n&&e[t]===void 0?0:B(e,t,r)},je=(e,t,n,r,i)=>{let a=t.q.trim().toLocaleLowerCase(),o=e=>{if(t.sort===`name`)return e.name;if(t.sort===`created`){let t=Date.parse(e.creation_date||``);return Number.isFinite(t)?t:void 0}if(i){let n=i[e.name]?.last_good?.totals;return n?t.sort===`size`?BigInt(n.current_bytes):n.current_objects:void 0}return Ae(e,t.sort,n,r)};return e.filter(e=>e.name.toLocaleLowerCase().includes(a)).sort((e,n)=>{let r=o(e),i=o(n);return r===void 0&&i!==void 0?1:i===void 0&&r!==void 0?-1:(r===i||r===void 0||i===void 0?0:r<i?-1:1)*(t.dir===`desc`?-1:1)||e.name.localeCompare(n.name)})},Me=(e,t)=>t.length>0&&t.every(t=>e.includes(t))?e.filter(e=>!t.includes(e)):Array.from(new Set([...e,...t])),X=(e,t)=>({browse:I(e,M),settings:!t&&I(e,N[A.BUCKETS_ADMIN_VIEW]),delete:!t&&I(e,O),select:!t&&I(e,[j.S3_PUT_LIFECYCLE_CONFIGURATION,j.S3_PUT_REPLICATION_CONFIGURATION,j.S3_PUT_ACTIONS])}),Z=({bucket:e,field:t,canReadUsage:n,usageUpdatedAt:r})=>{let i=C(),a=w(),o=W(),s=(o?.records[e.name])?.last_good?.totals;if(s)return t===`objects`?(0,K.jsx)(K.Fragment,{children:s.current_objects.toLocaleString(a)}):(0,K.jsxs)(K.Fragment,{children:[(0,K.jsx)(`span`,{title:`${s.current_bytes} B`,children:z(s.current_bytes)}),s.retained_bytes!=null&&(0,K.jsxs)(`small`,{style:{display:`block`},title:`${s.retained_bytes} B`,children:[i(`Retained`),`: `,z(s.retained_bytes)]})]});if(o)return(0,K.jsx)(`span`,{children:`—`});let c=Ae(e,t,n,r);return c===void 0?(0,K.jsx)(T,{text:n&&!Y(r)?i(`Calculating…`):i(`Unknown`),children:(0,K.jsx)(`span`,{tabIndex:0,children:`—`})}):(0,K.jsx)(K.Fragment,{children:t===`size`?m(c):c.toLocaleString(a)})},Q=({bucket:e})=>{let t=C();return(0,K.jsx)(K.Fragment,{children:e.rw_access?.read?e.rw_access.write?t(`Read & write`):t(`Read only`):e.rw_access?.write?t(`Write only`):t(`Unknown`)})},$=({enabled:e,suspended:t=!1})=>{let n=C();return(0,K.jsx)(P,{tone:t?`warning`:e?`success`:`neutral`,label:n(t?`Suspended`:e===void 0?`Unknown`:e?`Enabled`:`Disabled`)})},Ne=({at:e})=>{let t=w(),n=e?s.fromISO(e).setLocale(t===`zh`?`zh-CN`:`en`):void 0;return n?.isValid?(0,K.jsx)(T,{text:n.toLocaleString(s.DATETIME_FULL_WITH_SECONDS),children:(0,K.jsx)(`time`,{dateTime:e,tabIndex:0,children:n.toRelative()})}):(0,K.jsx)(K.Fragment,{children:`—`})},Pe=({bucket:e,obOnly:t,onDelete:n})=>{let i=C(),a=r(),o=X(e.name,t),s=encodeURIComponent(e.name),c=[...o.browse?[{label:i(`Browse`),icon:(0,K.jsx)(b,{}),onClick:()=>a(`/browser/${s}`)}]:[],...o.settings?[{label:i(`Settings`),icon:(0,K.jsx)(de,{}),onClick:()=>a(`/buckets/${s}/admin/summary`)}]:[],...o.delete?[{label:i(`Delete bucket`),icon:(0,K.jsx)(se,{}),danger:!0,onClick:()=>n(e.name)}]:[]];return c.length?(0,K.jsx)(`div`,{onClick:e=>e.stopPropagation(),onKeyDown:e=>e.stopPropagation(),children:(0,K.jsx)(ge,{label:h(i(`Actions for {bucket}`),{bucket:e.name}),tooltipPlacement:`left`,tooltipLabel:i(`Actions`),items:c})}):null},Fe=c.div`
  ${E.body}
  min-height: 148px;
  box-sizing: border-box;
  min-width: 0;
  padding: 8px 12px 12px;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  color: var(--muted-foreground);
  font-variant-numeric: tabular-nums;
  &[data-clickable="true"] {
    cursor: pointer;
  }
  &:hover,
  &[data-selected="true"] {
    color: var(--foreground);
    background: color-mix(in srgb, var(--hover) 100%, var(--surface-3));
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }
  .cardTitle {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;
    height: 36px;
  }
  .cardTitle > svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
  }
  h2 {
    ${E.section} margin: 0;
    min-width: 0;
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  a {
    color: inherit;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
  .cardMetrics {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    margin-top: 4px;
  }
  .metricLabel {
    ${E.caption} color: var(--muted-foreground);
  }
  .metricValue {
    display: block;
    color: var(--foreground);
  }
  .cardAccess {
    ${E.caption} text-align: right;
    align-self: end;
  }
`,Ie=e=>{let{bucket:t,onSelect:n,selected:i,obOnly:o}=e,s=C(),c=r(),l=X(t.name,o),u=()=>l.browse&&c(`/browser/${encodeURIComponent(t.name)}`);return(0,K.jsxs)(Fe,{className:`bucket-card`,role:`listitem`,"aria-label":t.name,"data-clickable":l.browse,"data-selected":n?i:void 0,tabIndex:l.browse?0:void 0,onClick:u,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),u())},children:[(0,K.jsxs)(`div`,{className:`cardTitle`,children:[n?(0,K.jsx)(`span`,{onClick:e=>e.stopPropagation(),children:(0,K.jsx)(x,{label:``,checked:i,disabled:!l.select,"aria-label":h(s(`Select {bucket}`),{bucket:t.name}),onChange:()=>n(t.name)})}):(0,K.jsx)(y,{"aria-hidden":`true`}),(0,K.jsx)(`h2`,{children:l.browse?(0,K.jsx)(a,{to:`/browser/${encodeURIComponent(t.name)}`,onClick:e=>e.stopPropagation(),children:t.name}):t.name}),(0,K.jsx)(Pe,{...e})]}),(0,K.jsx)(q,{bucket:t.name}),(0,K.jsxs)(`div`,{className:`cardMetrics`,children:[(0,K.jsxs)(`div`,{children:[(0,K.jsx)(`span`,{className:`metricLabel`,children:s(`Objects`)}),(0,K.jsx)(`span`,{className:`metricValue`,children:(0,K.jsx)(Z,{...e,field:`objects`})})]}),(0,K.jsxs)(`div`,{children:[(0,K.jsx)(`span`,{className:`metricLabel`,children:s(`Current size`)}),(0,K.jsx)(`span`,{className:`metricValue`,children:(0,K.jsx)(Z,{...e,field:`size`})})]}),(0,K.jsx)(`span`,{className:`cardAccess`,children:(0,K.jsx)(Q,{bucket:t})})]})]})},Le=c.div`
  ${E.body}
  min-width: 0;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  overflow: hidden;
  font-variant-numeric: tabular-nums;
  --bucket-select-width: 28px;
  --bucket-menu-width: 36px;
  .bucketGrid {
    display: grid;
    grid-template-columns:
      minmax(120px, 1.8fr)
      minmax(0, 0.8fr) minmax(0, 0.9fr) minmax(0, 1.1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    align-items: center;
    column-gap: 8px;
    padding: 0 12px;
    box-sizing: border-box;
    height: var(--bucket-row-height, var(--control-height));
  }
  &[data-selection="true"] .bucketGrid {
    grid-template-columns:
      var(--bucket-select-width) minmax(120px, 1.8fr)
      minmax(0, 0.8fr) minmax(0, 0.9fr) minmax(0, 1.1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
  }
  .bucketCell {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .bucketCell a {
    color: inherit;
    text-decoration: none;
  }
  .bucketCell a:hover {
    text-decoration: underline;
  }
  .bucketCell a:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  .bucketNumber {
    text-align: right;
  }
  @media (min-width: 1200px) {
    .bucketNumber {
      padding-right: 12px;
    }
  }
  .bucketCheck {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .bucketMenu {
    overflow: visible;
    display: flex;
    justify-content: end;
  }
  .bucketRow {
    border-bottom: 1px solid var(--border);
    color: var(--muted-foreground);
    transition:
      color var(--dur-fast) ease,
      border-color var(--dur-fast) ease;
  }
  .bucketRow[data-fluid-activator] {
    cursor: pointer;
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[aria-selected="true"] {
    color: var(--foreground);
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[data-fluid-before] {
    border-bottom-color: transparent;
  }
  .bucketRow[aria-selected="true"] {
    background: var(--active);
  }
  .bucketRow:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  @media (max-width: 1199.98px) {
    .bucketGrid {
      grid-template-columns:
        minmax(100px, 1.6fr) minmax(0, 0.7fr) minmax(0, 0.8fr)
        minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns:
        var(--bucket-select-width) minmax(100px, 1.6fr)
        minmax(0, 0.7fr) minmax(0, 0.8fr) minmax(0, 1fr) minmax(0, 1fr) var(
          --bucket-menu-width
        );
    }
    .bucketLow {
      display: none;
    }
  }
  @media (max-width: 767.98px) {
    .bucketGrid {
      grid-template-columns: minmax(0, 1fr) 76px var(--bucket-menu-width);
      padding: 0 8px;
      gap: 4px;
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns: var(--bucket-select-width) minmax(0, 1fr) 76px var(
          --bucket-menu-width
        );
    }
    .bucketMedium {
      display: none;
    }
  }
  @media (pointer: coarse) {
    --bucket-select-width: 40px;
    --bucket-menu-width: 40px;
  }
`,Re=c.div`
  position: sticky;
  top: 0;
  z-index: 1;
  background: var(--surface-3);
  color: var(--foreground);
  font-weight: var(--fw-semibold);
  border-bottom: 1px solid var(--border);
  button {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    border: 0;
    padding: 0;
    background: transparent;
    color: inherit;
    font: inherit;
    cursor: pointer;
    max-width: 100%;
  }
  @media (pointer: coarse) {
    button {
      min-height: 40px;
    }
  }
  button:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
  }
  button > svg {
    width: 12px;
    height: 12px;
    fill: currentColor;
  }
`,ze=c.div`
  position: relative;
  isolation: isolate;
  min-height: 0;
  [data-fluid-highlight] {
    z-index: -1;
  }
`;function Be({index:e,style:t,records:n,columns:r,selected:i,common:a}){let o=n[e];return(0,K.jsx)(Ve,{index:e,style:t,columns:r,...a,bucket:o,selected:i.includes(o.name)},o.name)}function Ve({index:e,style:t,columns:n,...i}){let a=r(),{bucket:o,selected:s,onSelect:c,obOnly:l}=i,u=C(),d=X(o.name,l),f=()=>d.browse&&a(`/browser/${encodeURIComponent(o.name)}`);return(0,K.jsxs)(`div`,{role:`row`,"aria-rowindex":e+2,"aria-label":o.name,"aria-selected":c?s:void 0,style:t,className:`bucketGrid bucketRow`,"data-fluid-index":d.browse?e:void 0,"data-fluid-key":o.name,"data-fluid-activator":d.browse?`true`:void 0,tabIndex:d.browse?0:void 0,onClick:f,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),f())},children:[c&&(0,K.jsx)(`div`,{role:`cell`,className:`bucketCheck`,onClick:e=>e.stopPropagation(),children:(0,K.jsx)(x,{label:``,"aria-label":h(u(`Select {bucket}`),{bucket:o.name}),checked:s,disabled:!d.select,onChange:()=>c(o.name)})}),n.map(e=>(0,K.jsx)(`div`,{role:`cell`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``} ${e.id===`actions`?`bucketMenu`:``}`,children:e.render(i)},e.id))]})}function He({records:e,query:t,onSort:n,selected:r,onSelectAll:i,...o}){let s=C(),c=pe(),l=(0,H.useRef)(null),u=S(l,{gapClick:!1}),d=[{id:`name`,label:s(`Name`),sort:`name`,render:({bucket:e,obOnly:t})=>(0,K.jsxs)(`div`,{children:[X(e.name,t).browse?(0,K.jsx)(a,{to:`/browser/${encodeURIComponent(e.name)}`,onClick:e=>e.stopPropagation(),children:e.name}):e.name,(0,K.jsx)(q,{bucket:e.name})]})},{id:`objects`,label:s(`Objects`),priority:`Medium`,number:!0,sort:`objects`,render:e=>(0,K.jsx)(Z,{...e,field:`objects`})},{id:`size`,label:s(`Current size`),number:!0,sort:`size`,render:e=>(0,K.jsx)(Z,{...e,field:`size`})},{id:`versioning`,label:s(`Versioning`),priority:`Medium`,render:({bucket:e})=>(0,K.jsx)($,{enabled:e.details?!!e.details.versioning:void 0,suspended:e.details?.versioningSuspended})},{id:`locking`,label:s(`Object lock`),priority:`Low`,render:({bucket:e})=>(0,K.jsx)($,{enabled:e.details?!!e.details.locking:void 0})},{id:`quota`,label:s(`Quota`),priority:`Low`,number:!0,render:({bucket:e})=>(e.details?.quota?.quota||0)>0?m(e.details.quota.quota):`—`},{id:`replication`,label:s(`Replication`),priority:`Low`,render:({bucket:e})=>(0,K.jsx)($,{enabled:e.details?!!e.details.replication:void 0})},{id:`access`,label:s(`Access`),priority:`Medium`,render:({bucket:e})=>(0,K.jsx)(Q,{bucket:e})},{id:`created`,label:s(`Created`),priority:`Low`,sort:`created`,render:({bucket:e})=>(0,K.jsx)(Ne,{at:e.creation_date})},{id:`actions`,label:s(`Actions`),render:e=>(0,K.jsx)(Pe,{...e})}],f=e.filter(e=>X(e.name,o.obOnly).select),p={records:e,columns:d,selected:r,common:o};return(0,K.jsxs)(Le,{role:`table`,"aria-label":s(`Buckets`),"aria-rowcount":e.length+1,"aria-colcount":d.length+ +!!o.onSelect,"data-selection":!!o.onSelect,style:{"--bucket-row-height":`${Math.max(c,64)}px`},children:[(0,K.jsxs)(Re,{role:`row`,className:`bucketGrid`,"aria-rowindex":1,children:[o.onSelect&&(0,K.jsx)(`div`,{role:`columnheader`,className:`bucketCheck`,children:(0,K.jsx)(x,{label:``,"aria-label":s(`Select all visible buckets`),checked:f.length>0&&f.every(e=>r.includes(e.name)),disabled:!f.length,onChange:i})}),d.map(e=>(0,K.jsx)(`div`,{role:`columnheader`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``}`,"aria-sort":e.sort?t.sort===e.sort?t.dir===`asc`?`ascending`:`descending`:`none`:void 0,children:e.sort?(0,K.jsxs)(`button`,{type:`button`,"aria-label":e.label,onClick:()=>n(e.sort),children:[e.label,t.sort===e.sort&&(t.dir===`asc`?(0,K.jsx)(ae,{}):(0,K.jsx)(g,{}))]}):e.id===`actions`?(0,K.jsx)(`span`,{className:`selectionHeaderLabel`,style:{position:`absolute`,clipPath:`inset(50%)`,width:1,height:1},children:e.label}):e.label},e.id))]}),(0,K.jsxs)(ze,{ref:l,children:[(0,K.jsx)(fe,{hover:u}),e.length>100?(0,K.jsx)(V,{role:`rowgroup`,"aria-label":s(`Bucket rows`),rowCount:e.length,rowHeight:Math.max(c,64),rowComponent:Be,rowProps:p,overscanCount:6,style:{height:`min(65vh, 720px)`,minHeight:c*4}}):(0,K.jsx)(`div`,{role:`rowgroup`,style:{maxHeight:`min(65vh, 720px)`,overflowY:`auto`},children:e.map((e,t)=>(0,K.jsx)(Ve,{...o,columns:d,bucket:e,index:t,selected:r.includes(e.name)},e.name))})]})]})}function Ue(){let e=n(),[t,r]=i(),a=Oe(t),[o,s]=(0,H.useState)(a.q);return(0,H.useEffect)(()=>s(a.q),[e.key,a.q]),(0,H.useEffect)(()=>{if(o===a.q)return;let e=window.location.href,t=window.setTimeout(()=>{window.location.href===e&&r(e=>J(e,{q:o}),{replace:!0})},150);return()=>window.clearTimeout(t)},[o,a.q,e.key,r]),{query:a,search:o,setSearch:s,sort:e=>r(t=>J(t,{sort:e,dir:a.sort===e&&a.dir===`asc`?`desc`:`asc`,q:o})),clear:()=>{s(``),r(e=>J(e,{q:``}))}}}var We=F(H.lazy(()=>v(()=>import(`./BulkReplicationModal-D5o7REOq.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39]),import.meta.url))),Ge=F(H.lazy(()=>v(()=>import(`./BulkLifecycleModal-CMKWcyHJ.js`),__vite__mapDeps([40,1,2,3,4,5,6,7,8,9,10,11,12,41,19,21,13,14,15,16,17,18,20,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39]),import.meta.url))),Ke=F(H.lazy(()=>v(()=>import(`./DeleteBucket-BqIqjc8l.js`),__vite__mapDeps([42,1,2,5,3,4,6,17,7,12,27,26,28,43,25]),import.meta.url))),qe=c.h1`
  ${E.title}
  margin: 0 0 16px;
`,Je=c.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 16px;
  .bucketSearch {
    min-width: 160px;
    flex: 1 1 190px;
  }
  .bucketActions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: flex-end;
    gap: 8px;
    margin-left: auto;
  }
  .bucketView {
    display: flex;
    gap: 4px;
  }
  @media (max-width: 767.98px) {
    .bucketFreshness {
      order: 3;
      flex-basis: 100%;
    }
    .bucketSearch {
      flex-basis: 100%;
    }
    .bucketActions {
      flex-basis: 100%;
      flex-wrap: nowrap;
      justify-content: flex-start;
      gap: 8px;
    }
    .bucketView {
      margin-right: auto;
    }
  }
`,Ye=c.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  @media (max-width: 1199.98px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: 767.98px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Xe=c.div`
  ${E.caption}
  color: var(--muted-foreground);
  margin-bottom: 8px;
`,Ze=c.div`
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  border-radius: var(--radius-card);
  min-height: 180px;
`,Qe=()=>{let e=ee(),t=r(),n=C(),i=he(),a=te(l),o=!!a.features?.includes(`object-browser-only`),s=I(ve,[j.ADMIN_DATA_USAGE_INFO]),c=!o&&d(a.permissions),{updateListing:m}=Ce(),{query:g,search:ae,setSearch:v,sort:se,clear:de}=Ue(),[b,x]=(0,H.useState)(),[S,fe]=(0,H.useState)(!0),[pe,w]=(0,H.useState)(!1),[T,E]=(0,H.useState)(0),[O,M]=(0,H.useState)([]),[N,P]=(0,H.useState)(null),[F,L]=(0,H.useState)(null),[R,z]=(0,H.useState)(()=>{try{return ke(localStorage.getItem(`silo.buckets.view`))}catch{return`table`}}),B=(0,H.useCallback)(()=>E(e=>e+1),[]);(0,H.useEffect)(()=>{e(u(`ob_bucket_list`))},[e]),(0,H.useEffect)(()=>{let t=new AbortController;return fe(!0),w(!1),p.buckets.listBuckets({signal:t.signal}).then(e=>{if(t.signal.aborted)return;if(!Array.isArray(e.data?.buckets))throw Error(n(`The bucket list could not be loaded.`));x(e.data),m(e.data);let r=new Set(e.data.buckets.map(e=>e.name));M(e=>e.filter(e=>r.has(e)))}).catch(n=>{t.signal.aborted||(w(!0),e(f(ne(n))))}).finally(()=>{t.signal.aborted||fe(!1)}),()=>t.abort()},[T,e,m,a.accountAccessKey,n]),(0,H.useEffect)(()=>{try{localStorage.setItem(`silo.buckets.view`,R)}catch{}},[R]);let V=b?.buckets||[],U=Te(V.map(e=>e.name)),W=()=>{B(),U.refresh()},G=(0,H.useMemo)(()=>je(V,g,s,b?.usageUpdatedAt,U.records),[V,g.sort,g.dir,g.q,s,b?.usageUpdatedAt,U.records]),q=!o&&I(`*`,[j.S3_PUT_LIFECYCLE_CONFIGURATION,j.S3_PUT_REPLICATION_CONFIGURATION,j.S3_PUT_ACTIONS]),De=e=>M(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e]),Oe=()=>M(e=>Me(e,G.filter(e=>X(e.name,o).select).map(e=>e.name))),J=O.every(e=>I(e,k[D.BUCKET_LIFECYCLE],!0)),Y=O.every(e=>I(e,[j.S3_PUT_REPLICATION_CONFIGURATION,j.S3_PUT_ACTIONS])),Ae=n(`Select one or more buckets first.`),Z=(e,t)=>O.length?e?void 0:_e(t,n(`configure the selected buckets`)):Ae,Q=e=>{P(null),e&&(M([]),B())},$={canReadUsage:s,usageUpdatedAt:b?.usageUpdatedAt,obOnly:o,onSelect:q?De:void 0,onDelete:L},Ne=c?(0,K.jsx)(_,{id:`empty-create-bucket`,variant:`callAction`,label:n(`Create bucket`),onClick:()=>t(A.ADD_BUCKETS)}):void 0;return(0,K.jsxs)(we,{value:U,children:[(0,K.jsx)(me,{open:N?.type===`replication`,children:N?.type===`replication`&&(0,K.jsx)(We,{open:!0,buckets:N.names,closeModalAndRefresh:Q})}),(0,K.jsx)(me,{open:N?.type===`lifecycle`,children:N?.type===`lifecycle`&&(0,K.jsx)(Ge,{open:!0,buckets:N.names,closeModalAndRefresh:Q})}),(0,K.jsx)(me,{open:F!==null,children:F!==null&&(0,K.jsx)(Ke,{deleteOpen:!0,selectedBucket:F,closeDeleteModalAndRefresh:e=>{L(null),e&&(M(e=>e.filter(e=>e!==F)),B())}})}),!o&&(0,K.jsx)(be,{label:n(`Buckets`),titleElement:`h1`,help:!0}),(0,K.jsxs)(ie,{children:[o&&(0,K.jsx)(qe,{children:n(`Buckets`)}),(0,K.jsxs)(Je,{children:[(0,K.jsx)(`div`,{className:`bucketSearch`,children:(0,K.jsx)(ye,{id:`bucket-search`,placeholder:n(`Search buckets`),value:ae,onChange:v,sx:{width:`100%`}})}),(0,K.jsxs)(`div`,{className:`bucketActions`,children:[(0,K.jsxs)(`div`,{className:`bucketView`,role:`group`,"aria-label":n(`Bucket view`),children:[(0,K.jsx)(_,{id:`buckets-view-table`,collapseOnSmall:!1,label:n(`Table`),variant:R===`table`?`secondary`:`ghost`,"aria-pressed":R===`table`,onClick:()=>z(`table`)}),(0,K.jsx)(_,{id:`buckets-view-cards`,collapseOnSmall:!1,label:n(`Cards`),variant:R===`cards`?`secondary`:`ghost`,"aria-pressed":R===`cards`,onClick:()=>z(`cards`)})]}),(0,K.jsx)(re,{id:`refresh-buckets`,"aria-label":n(`Refresh buckets`),size:`medium`,disabled:S||U.requesting,onClick:W,children:(0,K.jsx)(oe,{})}),q&&(i?(0,K.jsx)(ge,{label:n(`Actions`),items:[{label:n(`Set replication`),icon:(0,K.jsx)(ce,{}),disabled:S||!O.length||!Y,disabledReason:Z(Y,[j.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>P({type:`replication`,names:[...O]})},{label:n(`Set lifecycle`),icon:(0,K.jsx)(le,{}),disabled:S||!O.length||!J,disabledReason:Z(J,k[D.BUCKET_LIFECYCLE]),onClick:()=>P({type:`lifecycle`,names:[...O]})}]}):(0,K.jsxs)(K.Fragment,{children:[(0,K.jsx)(_,{id:`set-replication`,collapseOnSmall:!1,label:n(`Set replication`),icon:(0,K.jsx)(ce,{}),disabled:S||!O.length||!Y,disabledReason:Z(Y,[j.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>P({type:`replication`,names:[...O]})}),(0,K.jsx)(_,{id:`set-lifecycle`,collapseOnSmall:!1,label:n(`Set lifecycle`),icon:(0,K.jsx)(le,{}),disabled:S||!O.length||!J,disabledReason:Z(J,k[D.BUCKET_LIFECYCLE]),onClick:()=>P({type:`lifecycle`,names:[...O]})})]})),!o&&(0,K.jsx)(_,{id:`create-bucket`,label:n(`Create bucket`),icon:(0,K.jsx)(ue,{}),disabled:!c,disabledReason:c?void 0:_e([j.S3_CREATE_BUCKET],n(`create a bucket`)),onClick:()=>t(A.ADD_BUCKETS),variant:`primary`,collapseOnSmall:!1})]})]}),(0,K.jsx)(Ee,{}),O.length>0&&(0,K.jsx)(Xe,{role:`status`,children:h(n(O.length===1?`1 bucket selected`:`{count} buckets selected`),{count:O.length})}),S&&!b?(0,K.jsx)(Ze,{children:(0,K.jsx)(Se,{rows:5,columns:4})}):pe&&!b?(0,K.jsx)(Ze,{children:(0,K.jsx)(xe,{compact:!0,icon:(0,K.jsx)(y,{}),title:n(`The bucket list could not be loaded.`),action:(0,K.jsx)(_,{id:`retry-buckets`,label:n(`Retry`),onClick:B})})}):G.length===0?(0,K.jsx)(Ze,{children:g.q.trim()?(0,K.jsx)(xe,{compact:!0,icon:(0,K.jsx)(y,{}),title:h(n(`No buckets match “{q}”`),{q:g.q.trim()}),action:(0,K.jsx)(_,{id:`clear-bucket-filter`,label:n(`Clear filter`),onClick:de})}):(0,K.jsx)(xe,{icon:(0,K.jsx)(y,{}),title:n(`No buckets yet`),description:n(`Create a bucket to start storing objects.`),action:Ne})}):R===`table`?(0,K.jsx)(He,{...$,records:G,query:g,onSort:se,selected:O,onSelectAll:Oe}):(0,K.jsx)(Ye,{role:`list`,"aria-label":n(`Buckets`),children:G.map(e=>(0,K.jsx)(Ie,{...$,bucket:e,selected:O.includes(e.name)},e.name))})]})]})};export{Qe as default};