const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./BulkReplicationModal-C6r9O76x.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./store-u0LCkSUK.js","./lang-BxJGrDHW.js","./mds-YaKHoCCJ.js","./triangle-alert-D9tlQ26J.js","./circle-check-PKb6fSYx.js","./ReadBox-DULy_AY9.js","./Wizard-D1pat5MH.js","./i18n-CkC2HRew.js","./replicationValidation-BkrP-NJS.js","./ConsoleKBar-CIf1MkWB.js","./gauge-Bh9CGXUU.js","./pencil-C5sHQui2.js","./search-s4arL55O.js","./CircleIcon-BsXHTBH6.js","./shield-check-BL08EFCo.js","./chart-no-axes-column-DqyaIYUO.js","./heart-pulse-DOTeJtF_.js","./trash-D6JXtEqL.js","./clock-B460ppO7.js","./activity-DvAklQ8n.js","./plus-COPeXqMx.js","./users-BXqNZKYD.js","./shield-CnWfTxFw.js","./archive-swEOSDZm.js","./webhook-CmGBcvB_.js","./users-round-DxaoR33l.js","./layers-DalCoFYV.js","./rotate-ccw-v_NUsCZb.js","./settings-BGAESn0x.js","./logs-BSGTNiYu.js","./info-CNve3BGk.js","./scan-search-9Jn3MA3w.js","./console-vendor-I3rSB1nD.js","./listPopup-D2sWpuy2.js","./SectionTitle-jlaicNvQ.js","./useAvailableWidth-COFYcObd.js","./ModalBox-B1Mqh9LH.js","./ModalPresence-DpAARFPv.js","./index-BCJkkRQw.js","./index-BFo1l52q.css","./shared-Bg6N0Gs_.js","./OverflowMenu-D1aICRMe.js","./typography-DxndMn2P.js","./permissions-BaYWxI8a.js","./StatusBadge-QSmH-cfD.js","./CliEquivalent-BKW-DUIf.js","./copy-BTb-rWwy.js","./code-SqxiFqKS.js","./lib-BVN4wEer.js","./SecureComponent-BuNNF0Qr.js","./BulkLifecycleModal-BBmoOmJb.js","./QueryMultiSelector-B4O7DUIF.js","./DeleteBucket-BhG-DqhD.js","./ConfirmDialog-CEeXK5RZ.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,d as n,f as r,h as i,r as a,t as o}from"./react-vendor-UL3KVrSx.js";import{D as s,T as c}from"./shared-vendor-BQfq49S_.js";import{Dr as l,Er as u,Qt as d,Tn as f,ar as p,n as ee,r as te,rn as ne,wn as m}from"./store-u0LCkSUK.js";import{n as h}from"./lang-BxJGrDHW.js";import{F as re,T as g,g as ie,l as _,v as ae,w as oe,z as v}from"./mds-YaKHoCCJ.js";import{t as se}from"./trash-D6JXtEqL.js";import{t as ce}from"./boxes-Dqlyn8ch.js";import{t as le}from"./calendar-clock-YYO3wcTQ.js";import{t as ue}from"./plus-COPeXqMx.js";import{t as y}from"./archive-swEOSDZm.js";import{t as de}from"./settings-BGAESn0x.js";import{t as b}from"./folder-DGc8Lwwm.js";import{t as x}from"./Checkbox-FHttryja.js";import{c as S,s as fe}from"./listPopup-D2sWpuy2.js";import{t as pe}from"./useTableLayout-uQiMFybd.js";import{a as C,n as w,t as me}from"./i18n-CkC2HRew.js";import{t as T}from"./ModalPresence-DpAARFPv.js";import{c as he}from"./index-BCJkkRQw.js";import{n as E}from"./shared-Bg6N0Gs_.js";import{t as ge}from"./OverflowMenu-D1aICRMe.js";import{t as D}from"./typography-DxndMn2P.js";import{A as _e,a as O,g as k,i as A,n as j,o as M,p as N,r as P,t as ve}from"./permissions-BaYWxI8a.js";import{t as F}from"./StatusBadge-QSmH-cfD.js";import{t as ye}from"./SearchBox-7UY-GAbx.js";import{t as I}from"./withSuspense-DTbtEWjP.js";import{n as L}from"./SecureComponent-BuNNF0Qr.js";import{a as R,i as z,n as B,r as V,t as H}from"./prefixUsage-DSm2EKd3.js";import{t as be}from"./bucketMetadata-BAg0j77c.js";import{n as U}from"./react-window-0T2cJ04-.js";import{A as xe,J as Se,V as Ce,f as we}from"./ConsoleKBar-CIf1MkWB.js";var W=e(t()),G=(0,W.createContext)(void 0),Te=G.Provider,K=()=>(0,W.useContext)(G),Ee=e=>e.state===`queued`||e.state===`running`,q=[`not_scanned`,`queued`,`running`,`complete`,`error`,`limited`,`forbidden`,`missing`,`unavailable`],J=(e,t)=>e==null||t(e),De=e=>{if(typeof e!=`object`||!e)return!1;let t=e,n=t.totals;return!!n&&V(n.current_bytes)&&z(n.current_objects)&&J(n.retained_bytes,V)&&J(n.retained_versions,z)&&J(n.delete_markers,z)&&z(t.scanned_entries)},Y=e=>{if(e&&typeof e.bucket==`string`)return q.includes(e.state)?{...e,last_good:De(e.last_good)?e.last_good:void 0,progress:De(e.progress)?e.progress:void 0}:{bucket:e.bucket,state:`unavailable`,versions_visible:!1}},Oe=e=>({...e,totals:{current_bytes:e.totals.current_bytes,current_objects:e.totals.current_objects}}),ke=(e,t)=>e.state===`unavailable`&&!e.last_good&&t?.last_good?{...e,last_good:e.versions_visible?t.last_good:Oe(t.last_good),last_completed_at:t.last_completed_at}:e;function Ae(e){let t=JSON.stringify(e),n=R(),r=(0,W.useRef)(),[i,a]=(0,W.useState)(0),o=(0,W.useRef)(!1),[s,c]=(0,W.useState)({requesting:!1,records:{}}),l=(0,W.useCallback)(()=>{o.current=!0,a(e=>e+1)},[]);return(0,W.useEffect)(()=>{let e=JSON.parse(t),i=new AbortController;r.current?.abort(),r.current=i;let a,s=()=>!i.signal.aborted&&n(),l=o.current;o.current=!1;let u=!l;c(t=>({...t,records:Object.fromEntries(Object.entries(t.records).filter(([t])=>e.includes(t)).flatMap(([e,n])=>t.enabled===!1&&n.state===`running`?n.last_good?[[e,{...n,state:`complete`,progress:void 0}]]:[]:[[e,n]]))}));let d=async()=>{c(e=>({...e,requesting:!0}));let t=[...e],n=async()=>{for(;s()&&t.length;){let e=t.shift(),n=L(e,[M.S3_LIST_BUCKET_VERSIONS]),r={bucket:e,state:`running`,versions_visible:n},a=()=>s()&&c(t=>{let i=t.records[e],a=i?.versions_visible===n&&r.state!==`forbidden`&&r.state!==`missing`;return{...t,records:{...t.records,[e]:{...r,last_good:r.last_good??(a?i?.last_good:void 0),last_completed_at:r.last_completed_at??(a?i?.last_completed_at:void 0)}}}});a();try{let t,o=await m.buckets.prefixUsage(e,{prefix:``,versions:n,folders:!1},{signal:i.signal});await B(o,{bucket:e,prefix:``,mode:n?`versions`:`current`},e=>{let i={totals:{...e.totals,...n?{}:{retained_bytes:void 0,retained_versions:void 0,delete_markers:void 0}},scanned_entries:e.scanned_entries,started_at:e.started_at,updated_at:e.updated_at};r={...r,state:e.status===`scanning`||e.status===`complete`?`running`:e.status===`failed`?`error`:e.status,progress:i},e.status===`complete`&&(t=i),a()}),t&&(r={...r,state:`complete`,last_good:t,last_completed_at:t.updated_at},a())}catch(e){let t=e instanceof Response?e.status:0;r={...r,state:t===401||t===403?`forbidden`:t===404?`missing`:`error`},a()}}};await Promise.all([n(),n()]),s()&&c(e=>({...e,requesting:!1}))},f=async t=>{if(s()){t&&c(e=>({...e,requesting:!0,error:!1}));try{let n=!1,r=2e3,o,l=[];for(let a=0;a<Math.max(e.length,1);a+=100){let s={buckets:e.slice(a,a+100)},c=t?await m.bucketUsage.bucketUsageRefresh(s,{signal:i.signal}):await m.bucketUsage.bucketUsageStatus(s,{signal:i.signal});if(n=c.data.enabled,r=c.data.poll_after_ms,o=c.data.coverage,l.push(...c.data.buckets),!n)break}if(!s())return;if(n&&t&&(u=!0),c(e=>({enabled:n,requesting:!1,records:n?Object.fromEntries(l.flatMap(t=>{let n=Y(t);return n?[[n.bucket,ke(n,e.records[n.bucket])]]:[]})):e.enabled===!1?e.records:{},coverage:o})),!n){t&&(await d(),s()&&(u=!0));return}let p=l.some(Ee);a=setTimeout(()=>void f(!1),Math.min(6e4,Math.max(250,r)*(p?1:10)))}catch{s()&&(u=!0,c(e=>({...e,requesting:!1,error:!0})),a=setTimeout(()=>void f(!1),1e4))}}};return f(l),()=>{!u&&n()&&(o.current=!0),i.abort(),clearTimeout(a)}},[t,i,n]),{...s,refresh:l}}var X=o(),je=c.small`
  ${D.caption}
  display: block;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--muted-foreground);
`,Me=c(je)`
  white-space: normal;
  text-overflow: clip;
  .usageValue {
    white-space: nowrap;
  }
`;function Ne({bucket:e}){let t=K(),n=t?.records[e],r=C(),i=w()===`zh`?`zh-CN`:`en`;if(!t||!n&&!t.enabled)return null;let a={not_scanned:r(`Not scanned`),queued:r(`Update queued`),running:r(`Updating usage…`),complete:r(`Updated`),error:r(`Update failed — retry with Refresh`),limited:r(`Scan limit reached — operator action required`),forbidden:r(`Usage listing not permitted`),missing:r(`Bucket no longer exists`),unavailable:r(`Usage temporarily unavailable`)},o=n?.last_completed_at?new Date(n.last_completed_at):void 0,s=[n?a[n.state]:r(`Checking usage…`),n?.state===`running`&&n.progress?h(r(`{count} entries scanned`),{count:n.progress.scanned_entries.toLocaleString(i)}):``,o&&Number.isFinite(o.getTime())?o.toLocaleTimeString(i):``].filter(Boolean).join(` · `);return(0,X.jsx)(je,{title:o&&Number.isFinite(o.getTime())?`${s} (${o.toLocaleString(i)})`:s,children:s})}function Pe(){let e=K(),t=C(),n=w()===`zh`?``:` `;if(!e)return null;let r=Object.values(e.records),i=r.filter(e=>e.state===`queued`||e.state===`running`).length,a=r.filter(e=>[`error`,`limited`,`unavailable`].includes(e.state)).length,o=e.coverage?.observer_alive&&e.coverage.connected&&e.coverage.reconciled;return(0,X.jsxs)(`div`,{role:`status`,"aria-live":`polite`,style:{marginBottom:12},children:[e.requesting?t(`Requesting usage updates…`):i?h(t(`{count} usage updates queued or running. Last completed totals remain visible.`),{count:i}):t(`Refresh requests a new metadata scan of all listed buckets.`),n,e.error?t(`Usage status is unavailable. Retrying…`):e.enabled?t(o?`Automatic change monitoring is active.`:`Automatic change monitoring is recovering; totals may be out of date.`):e.enabled===!1?t(`Automatic updates are not configured. Refresh calculates usage while this page is open.`):t(`Checking automatic updates…`),a>0&&(0,X.jsxs)(X.Fragment,{children:[n,h(t(`{count} updates need attention. Use Refresh to retry.`),{count:a})]})]})}var Fe=[`name`,`objects`,`size`,`created`],Ie=e=>({sort:Fe.includes(e.get(`sort`)||``)?e.get(`sort`):`name`,dir:e.get(`dir`)===`desc`?`desc`:`asc`,q:e.get(`q`)||``}),Le=(e,t)=>{let n=new URLSearchParams(e),r={...Ie(e),...t};for(let e of[`sort`,`dir`,`q`])!r[e]||e===`sort`&&r.sort===`name`||e===`dir`&&r.dir===`asc`?n.delete(e):n.set(e,r[e]);return n},Re=e=>e===`cards`?`cards`:`table`,ze=e=>!!(e&&Number.isFinite(Date.parse(e))),Be=(e,t,n,r)=>{if(!(!e||n&&!ze(r)))return!n&&e[t]===void 0?0:be(e,t,r)},Ve=(e,t,n,r,i)=>{let a=t.q.trim().toLocaleLowerCase(),o=e=>{if(t.sort===`name`)return e.name;if(t.sort===`created`){let t=Date.parse(e.creation_date||``);return Number.isFinite(t)?t:void 0}if(i){let n=i[e.name]?.last_good?.totals;return n?t.sort===`size`?BigInt(n.current_bytes):n.current_objects:void 0}return Be(e,t.sort,n,r)};return e.filter(e=>e.name.toLocaleLowerCase().includes(a)).sort((e,n)=>{let r=o(e),i=o(n);return r===void 0&&i!==void 0?1:i===void 0&&r!==void 0?-1:(r===i||r===void 0||i===void 0?0:r<i?-1:1)*(t.dir===`desc`?-1:1)||e.name.localeCompare(n.name)})},He=(e,t)=>t.length>0&&t.every(t=>e.includes(t))?e.filter(e=>!t.includes(e)):Array.from(new Set([...e,...t])),Z=(e,t)=>({browse:L(e,N),settings:!t&&L(e,P[j.BUCKETS_ADMIN_VIEW]),delete:!t&&L(e,k),select:!t&&L(e,[M.S3_PUT_LIFECYCLE_CONFIGURATION,M.S3_PUT_REPLICATION_CONFIGURATION,M.S3_PUT_ACTIONS])}),Q=({bucket:e,field:t,canReadUsage:n,usageUpdatedAt:r})=>{let i=C(),a=w(),o=K(),s=(o?.records[e.name])?.last_good?.totals;if(s)return t===`objects`?(0,X.jsx)(X.Fragment,{children:s.current_objects.toLocaleString(a)}):(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`span`,{title:`${s.current_bytes} B`,children:H(s.current_bytes)}),s.retained_bytes!=null&&(0,X.jsx)(Me,{title:`${s.retained_bytes} B`,children:me(i(`Retained: {size}`),{size:(0,X.jsx)(`span`,{className:`usageValue`,children:H(s.retained_bytes)})})})]});if(o)return(0,X.jsx)(`span`,{children:`—`});let c=Be(e,t,n,r);return c===void 0?(0,X.jsx)(E,{text:n&&!ze(r)?i(`Calculating…`):i(`Unknown`),children:(0,X.jsx)(`span`,{tabIndex:0,children:`—`})}):(0,X.jsx)(X.Fragment,{children:t===`size`?p(c):c.toLocaleString(a)})},Ue=({bucket:e})=>{let t=C();return(0,X.jsx)(X.Fragment,{children:e.rw_access?.read?e.rw_access.write?t(`Read & write`):t(`Read only`):e.rw_access?.write?t(`Write only`):t(`Unknown`)})},We=({enabled:e,suspended:t=!1})=>{let n=C();return(0,X.jsx)(F,{tone:t?`warning`:e?`success`:`neutral`,label:n(t?`Suspended`:e===void 0?`Unknown`:e?`Enabled`:`Disabled`)})},Ge=({at:e})=>{let t=w(),n=e?s.fromISO(e).setLocale(t===`zh`?`zh-CN`:`en`):void 0;return n?.isValid?(0,X.jsx)(E,{text:n.toLocaleString(s.DATETIME_FULL_WITH_SECONDS),children:(0,X.jsx)(`time`,{dateTime:e,tabIndex:0,children:n.toRelative()})}):(0,X.jsx)(X.Fragment,{children:`—`})},Ke=({bucket:e,obOnly:t,onDelete:n})=>{let i=C(),a=r(),o=Z(e.name,t),s=encodeURIComponent(e.name),c=[...o.browse?[{label:i(`Browse`),icon:(0,X.jsx)(b,{}),onClick:()=>a(`/browser/${s}`)}]:[],...o.settings?[{label:i(`Settings`),icon:(0,X.jsx)(de,{}),onClick:()=>a(`/buckets/${s}/admin/summary`)}]:[],...o.delete?[{label:i(`Delete bucket`),icon:(0,X.jsx)(se,{}),danger:!0,onClick:()=>n(e.name)}]:[]];return c.length?(0,X.jsx)(`div`,{onClick:e=>e.stopPropagation(),onKeyDown:e=>e.stopPropagation(),children:(0,X.jsx)(ge,{label:h(i(`Actions for {bucket}`),{bucket:e.name}),tooltipPlacement:`left`,tooltipLabel:i(`Actions`),items:c})}):null},qe=c.div`
  ${D.body}
  min-height: 148px;
  box-sizing: border-box;
  min-width: 0;
  padding: 8px 12px 12px;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  color: var(--muted-foreground);
  font-variant-numeric: tabular-nums;
  &[data-clickable="true"] {
    cursor: pointer;
  }
  &:hover,
  &[data-selected="true"] {
    color: var(--foreground);
    background: color-mix(in srgb, var(--hover) 100%, var(--surface-3));
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }
  .cardTitle {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;
    height: 36px;
  }
  .cardTitle > svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
  }
  h2 {
    ${D.section} margin: 0;
    min-width: 0;
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  a {
    color: inherit;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
  .cardMetrics {
    /* Fixed tracks keep each metric aligned across every card. */
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) auto;
    gap: 12px;
    margin-top: 4px;
  }
  .cardMetrics > div {
    min-width: 0;
  }
  .metricLabel {
    ${D.caption} color: var(--muted-foreground);
  }
  .metricValue {
    display: block;
    color: var(--foreground);
  }
  .cardAccess {
    ${D.caption} text-align: right;
    align-self: end;
  }
`,Je=e=>{let{bucket:t,onSelect:n,selected:i,obOnly:o}=e,s=C(),c=r(),l=Z(t.name,o),u=()=>l.browse&&c(`/browser/${encodeURIComponent(t.name)}`);return(0,X.jsxs)(qe,{className:`bucket-card`,role:`listitem`,"aria-label":t.name,"data-clickable":l.browse,"data-selected":n?i:void 0,tabIndex:l.browse?0:void 0,onClick:u,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),u())},children:[(0,X.jsxs)(`div`,{className:`cardTitle`,children:[n?(0,X.jsx)(`span`,{onClick:e=>e.stopPropagation(),children:(0,X.jsx)(x,{label:``,checked:i,disabled:!l.select,"aria-label":h(s(`Select {bucket}`),{bucket:t.name}),onChange:()=>n(t.name)})}):(0,X.jsx)(y,{"aria-hidden":`true`}),(0,X.jsx)(`h2`,{children:l.browse?(0,X.jsx)(a,{to:`/browser/${encodeURIComponent(t.name)}`,onClick:e=>e.stopPropagation(),children:t.name}):t.name}),(0,X.jsx)(Ke,{...e})]}),(0,X.jsx)(Ne,{bucket:t.name}),(0,X.jsxs)(`div`,{className:`cardMetrics`,children:[(0,X.jsxs)(`div`,{children:[(0,X.jsx)(`span`,{className:`metricLabel`,children:s(`Objects`)}),(0,X.jsx)(`span`,{className:`metricValue`,children:(0,X.jsx)(Q,{...e,field:`objects`})})]}),(0,X.jsxs)(`div`,{children:[(0,X.jsx)(`span`,{className:`metricLabel`,children:s(`Current size`)}),(0,X.jsx)(`span`,{className:`metricValue`,children:(0,X.jsx)(Q,{...e,field:`size`})})]}),(0,X.jsx)(`span`,{className:`cardAccess`,children:(0,X.jsx)(Ue,{bucket:t})})]})]})},Ye=c.div`
  ${D.body}
  min-width: 0;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  overflow: hidden;
  font-variant-numeric: tabular-nums;
  --bucket-select-width: 28px;
  --bucket-menu-width: 36px;
  /* Font-relative, so "Retained: 9.5 MiB" fits with wider fallback fonts
     (e.g. DejaVu Sans on Linux); longer values wrap rather than clip. */
  --bucket-size-min: 15ch;
  .bucketGrid {
    display: grid;
    grid-template-columns:
      minmax(120px, 1.8fr)
      minmax(0, 0.7fr) minmax(var(--bucket-size-min), 1.1fr) minmax(0, 1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    align-items: center;
    column-gap: 8px;
    padding: 0 12px;
    box-sizing: border-box;
    height: var(--bucket-row-height, var(--control-height));
  }
  &[data-selection="true"] .bucketGrid {
    grid-template-columns:
      var(--bucket-select-width) minmax(120px, 1.8fr)
      minmax(0, 0.7fr) minmax(var(--bucket-size-min), 1.1fr) minmax(0, 1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
  }
  .bucketCell {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .bucketCell a {
    color: inherit;
    text-decoration: none;
  }
  /* Text overflow applies per line; the name and its usage caption are blocks. */
  .bucketName {
    display: block;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .bucketCell a:hover {
    text-decoration: underline;
  }
  .bucketCell a:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  .bucketNumber {
    text-align: right;
  }
  @media (min-width: 1200px) {
    .bucketNumber {
      padding-right: 12px;
    }
  }
  .bucketCheck {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .bucketMenu {
    overflow: visible;
    display: flex;
    justify-content: end;
  }
  .bucketRow {
    border-bottom: 1px solid var(--border);
    color: var(--muted-foreground);
    transition:
      color var(--dur-fast) ease,
      border-color var(--dur-fast) ease;
  }
  .bucketRow[data-fluid-activator] {
    cursor: pointer;
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[aria-selected="true"] {
    color: var(--foreground);
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[data-fluid-before] {
    border-bottom-color: transparent;
  }
  .bucketRow[aria-selected="true"] {
    background: var(--active);
  }
  .bucketRow:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  @media (max-width: 1199.98px) {
    .bucketGrid {
      grid-template-columns:
        minmax(100px, 1.6fr) minmax(0, 0.6fr) minmax(
          var(--bucket-size-min),
          1fr
        )
        minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns:
        var(--bucket-select-width) minmax(100px, 1.6fr)
        minmax(0, 0.6fr) minmax(var(--bucket-size-min), 1fr) minmax(0, 1fr)
        minmax(0, 1fr) var(--bucket-menu-width);
    }
    .bucketLow {
      display: none;
    }
  }
  @media (max-width: 767.98px) {
    .bucketGrid {
      grid-template-columns: minmax(0, 1fr) var(--bucket-size-min) var(
          --bucket-menu-width
        );
      padding: 0 8px;
      gap: 4px;
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns:
        var(--bucket-select-width) minmax(0, 1fr)
        var(--bucket-size-min) var(--bucket-menu-width);
    }
    .bucketMedium {
      display: none;
    }
  }
  @media (pointer: coarse) {
    --bucket-select-width: 40px;
    --bucket-menu-width: 40px;
  }
`,Xe=c.div`
  position: sticky;
  top: 0;
  z-index: 1;
  background: var(--surface-3);
  color: var(--foreground);
  border-bottom: 1px solid var(--border);
  /* Weight the cells, not the grid row: font-relative tracks (ch) must
     resolve against the same font as body rows to keep columns aligned. */
  & > * {
    font-weight: var(--fw-semibold);
  }
  button {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    border: 0;
    padding: 0;
    background: transparent;
    color: inherit;
    font: inherit;
    cursor: pointer;
    max-width: 100%;
  }
  @media (pointer: coarse) {
    button {
      min-height: 40px;
    }
  }
  button:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
  }
  button > svg {
    width: 12px;
    height: 12px;
    flex-shrink: 0;
    fill: currentColor;
  }
  /* A narrow column truncates its label, never the sort direction. */
  .sortLabel {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`,Ze=c.div`
  position: relative;
  isolation: isolate;
  min-height: 0;
  [data-fluid-highlight] {
    z-index: -1;
  }
`;function Qe({index:e,style:t,records:n,columns:r,selected:i,common:a}){let o=n[e];return(0,X.jsx)($e,{index:e,style:t,columns:r,...a,bucket:o,selected:i.includes(o.name)},o.name)}function $e({index:e,style:t,columns:n,...i}){let a=r(),{bucket:o,selected:s,onSelect:c,obOnly:l}=i,u=C(),d=Z(o.name,l),f=()=>d.browse&&a(`/browser/${encodeURIComponent(o.name)}`);return(0,X.jsxs)(`div`,{role:`row`,"aria-rowindex":e+2,"aria-label":o.name,"aria-selected":c?s:void 0,style:t,className:`bucketGrid bucketRow`,"data-fluid-index":d.browse?e:void 0,"data-fluid-key":o.name,"data-fluid-activator":d.browse?`true`:void 0,tabIndex:d.browse?0:void 0,onClick:f,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),f())},children:[c&&(0,X.jsx)(`div`,{role:`cell`,className:`bucketCheck`,onClick:e=>e.stopPropagation(),children:(0,X.jsx)(x,{label:``,"aria-label":h(u(`Select {bucket}`),{bucket:o.name}),checked:s,disabled:!d.select,onChange:()=>c(o.name)})}),n.map(e=>(0,X.jsx)(`div`,{role:`cell`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``} ${e.id===`actions`?`bucketMenu`:``}`,children:e.render(i)},e.id))]})}function et({records:e,query:t,onSort:n,selected:r,onSelectAll:i,...o}){let s=C(),c=pe(),l=(0,W.useRef)(null),u=S(l,{gapClick:!1}),d=[{id:`name`,label:s(`Name`),sort:`name`,render:({bucket:e,obOnly:t})=>(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`span`,{className:`bucketName`,title:e.name,children:Z(e.name,t).browse?(0,X.jsx)(a,{to:`/browser/${encodeURIComponent(e.name)}`,onClick:e=>e.stopPropagation(),children:e.name}):e.name}),(0,X.jsx)(Ne,{bucket:e.name})]})},{id:`objects`,label:s(`Objects`),priority:`Medium`,number:!0,sort:`objects`,render:e=>(0,X.jsx)(Q,{...e,field:`objects`})},{id:`size`,label:s(`Current size`),number:!0,sort:`size`,render:e=>(0,X.jsx)(Q,{...e,field:`size`})},{id:`versioning`,label:s(`Versioning`),priority:`Medium`,render:({bucket:e})=>(0,X.jsx)(We,{enabled:e.details?!!e.details.versioning:void 0,suspended:e.details?.versioningSuspended})},{id:`locking`,label:s(`Object lock`),priority:`Low`,render:({bucket:e})=>(0,X.jsx)(We,{enabled:e.details?!!e.details.locking:void 0})},{id:`quota`,label:s(`Quota`),priority:`Low`,number:!0,render:({bucket:e})=>(e.details?.quota?.quota||0)>0?p(e.details.quota.quota):`—`},{id:`replication`,label:s(`Replication`),priority:`Low`,render:({bucket:e})=>(0,X.jsx)(We,{enabled:e.details?!!e.details.replication:void 0})},{id:`access`,label:s(`Access`),priority:`Medium`,render:({bucket:e})=>(0,X.jsx)(Ue,{bucket:e})},{id:`created`,label:s(`Created`),priority:`Low`,sort:`created`,render:({bucket:e})=>(0,X.jsx)(Ge,{at:e.creation_date})},{id:`actions`,label:s(`Actions`),render:e=>(0,X.jsx)(Ke,{...e})}],f=e.filter(e=>Z(e.name,o.obOnly).select),ee={records:e,columns:d,selected:r,common:o};return(0,X.jsxs)(Ye,{role:`table`,"aria-label":s(`Buckets`),"aria-rowcount":e.length+1,"aria-colcount":d.length+ +!!o.onSelect,"data-selection":!!o.onSelect,style:{"--bucket-row-height":`${Math.max(c,64)}px`},children:[(0,X.jsxs)(Xe,{role:`row`,className:`bucketGrid`,"aria-rowindex":1,style:{"--bucket-row-height":`${c}px`},children:[o.onSelect&&(0,X.jsx)(`div`,{role:`columnheader`,className:`bucketCheck`,children:(0,X.jsx)(x,{label:``,"aria-label":s(`Select all visible buckets`),checked:f.length>0&&f.every(e=>r.includes(e.name)),disabled:!f.length,onChange:i})}),d.map(e=>(0,X.jsx)(`div`,{role:`columnheader`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``}`,"aria-sort":e.sort?t.sort===e.sort?t.dir===`asc`?`ascending`:`descending`:`none`:void 0,children:e.sort?(0,X.jsxs)(`button`,{type:`button`,"aria-label":e.label,onClick:()=>n(e.sort),children:[(0,X.jsx)(`span`,{className:`sortLabel`,children:e.label}),t.sort===e.sort&&(t.dir===`asc`?(0,X.jsx)(g,{}):(0,X.jsx)(oe,{}))]}):e.id===`actions`?(0,X.jsx)(`span`,{className:`selectionHeaderLabel`,style:{position:`absolute`,clipPath:`inset(50%)`,width:1,height:1},children:e.label}):e.label},e.id))]}),(0,X.jsxs)(Ze,{ref:l,children:[(0,X.jsx)(fe,{hover:u}),e.length>100?(0,X.jsx)(U,{role:`rowgroup`,"aria-label":s(`Bucket rows`),rowCount:e.length,rowHeight:Math.max(c,64),rowComponent:Qe,rowProps:ee,overscanCount:6,style:{height:`min(65vh, 720px)`,minHeight:c*4}}):(0,X.jsx)(`div`,{role:`rowgroup`,style:{maxHeight:`min(65vh, 720px)`,overflowY:`auto`},children:e.map((e,t)=>(0,X.jsx)($e,{...o,columns:d,bucket:e,index:t,selected:r.includes(e.name)},e.name))})]})]})}function tt(){let e=n(),[t,r]=i(),a=Ie(t),[o,s]=(0,W.useState)(a.q);return(0,W.useEffect)(()=>s(a.q),[e.key,a.q]),(0,W.useEffect)(()=>{if(o===a.q)return;let e=window.location.href,t=window.setTimeout(()=>{window.location.href===e&&r(e=>Le(e,{q:o}),{replace:!0})},150);return()=>window.clearTimeout(t)},[o,a.q,e.key,r]),{query:a,search:o,setSearch:s,sort:e=>r(t=>Le(t,{sort:e,dir:a.sort===e&&a.dir===`asc`?`desc`:`asc`,q:o})),clear:()=>{s(``),r(e=>Le(e,{q:``}))}}}var nt=I(W.lazy(()=>_(()=>import(`./BulkReplicationModal-C6r9O76x.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54]),import.meta.url))),rt=I(W.lazy(()=>_(()=>import(`./BulkLifecycleModal-BBmoOmJb.js`),__vite__mapDeps([55,1,2,3,4,5,6,7,8,9,10,11,12,56,25,37,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,31,32,33,34,35,36,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54]),import.meta.url))),it=I(W.lazy(()=>_(()=>import(`./DeleteBucket-BhG-DqhD.js`),__vite__mapDeps([57,1,2,5,3,4,6,7,22,12,43,42,44,58,41]),import.meta.url))),at=c.h1`
  ${D.title}
  margin: 0 0 16px;
`,ot=c.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 16px;
  .bucketSearch {
    min-width: 160px;
    flex: 1 1 190px;
  }
  .bucketActions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: flex-end;
    gap: 8px;
    margin-left: auto;
  }
  .bucketView {
    display: flex;
    gap: 4px;
  }
  @media (max-width: 767.98px) {
    .bucketFreshness {
      order: 3;
      flex-basis: 100%;
    }
    .bucketSearch {
      flex-basis: 100%;
    }
    .bucketActions {
      flex-basis: 100%;
      /* Touch-sized controls and longer labels can exceed a phone's width;
         wrap the primary action instead of scrolling the page sideways. */
      flex-wrap: wrap;
      justify-content: flex-start;
      gap: 8px;
    }
    .bucketView {
      margin-right: auto;
    }
    .bucketActions > #create-bucket {
      margin-left: auto;
    }
  }
`,st=c.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  @media (max-width: 1199.98px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: 767.98px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,ct=c.div`
  ${D.caption}
  color: var(--muted-foreground);
  margin-bottom: 8px;
`,$=c.div`
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  border-radius: var(--radius-card);
  min-height: 180px;
`,lt=()=>{let e=ee(),t=r(),n=C(),i=he(),a=te(ne),o=!!a.features?.includes(`object-browser-only`),s=L(ve,[M.ADMIN_DATA_USAGE_INFO]),c=!o&&d(a.permissions),{updateListing:p}=we(),{query:g,search:_,setSearch:oe,sort:se,clear:de}=tt(),[b,x]=(0,W.useState)(),[S,fe]=(0,W.useState)(!0),[pe,w]=(0,W.useState)(!1),[me,E]=(0,W.useState)(0),[D,k]=(0,W.useState)([]),[N,P]=(0,W.useState)(null),[F,I]=(0,W.useState)(null),[R,z]=(0,W.useState)(()=>{try{return Re(localStorage.getItem(`silo.buckets.view`))}catch{return`table`}}),B=(0,W.useCallback)(()=>E(e=>e+1),[]);(0,W.useEffect)(()=>{e(l(`ob_bucket_list`))},[e]),(0,W.useEffect)(()=>{let t=new AbortController;return fe(!0),w(!1),m.buckets.listBuckets({signal:t.signal}).then(e=>{if(t.signal.aborted)return;if(!Array.isArray(e.data?.buckets))throw Error(n(`The bucket list could not be loaded.`));x(e.data),p(e.data);let r=new Set(e.data.buckets.map(e=>e.name));k(e=>e.filter(e=>r.has(e)))}).catch(n=>{t.signal.aborted||(w(!0),e(u(f(n))))}).finally(()=>{t.signal.aborted||fe(!1)}),()=>t.abort()},[me,e,p,a.accountAccessKey,n]),(0,W.useEffect)(()=>{try{localStorage.setItem(`silo.buckets.view`,R)}catch{}},[R]);let V=b?.buckets||[],H=Ae(V.map(e=>e.name)),be=()=>{B(),H.refresh()},U=(0,W.useMemo)(()=>Ve(V,g,s,b?.usageUpdatedAt,H.records),[V,g.sort,g.dir,g.q,s,b?.usageUpdatedAt,H.records]),G=!o&&L(`*`,[M.S3_PUT_LIFECYCLE_CONFIGURATION,M.S3_PUT_REPLICATION_CONFIGURATION,M.S3_PUT_ACTIONS]),K=e=>k(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e]),Ee=()=>k(e=>He(e,U.filter(e=>Z(e.name,o).select).map(e=>e.name))),q=D.every(e=>L(e,A[O.BUCKET_LIFECYCLE],!0)),J=D.every(e=>L(e,[M.S3_PUT_REPLICATION_CONFIGURATION,M.S3_PUT_ACTIONS])),De=n(`Select one or more buckets first.`),Y=(e,t)=>D.length?e?void 0:_e(t,n(`configure the selected buckets`)):De,Oe=e=>{P(null),e&&(k([]),B())},ke={canReadUsage:s,usageUpdatedAt:b?.usageUpdatedAt,obOnly:o,onSelect:G?K:void 0,onDelete:I},je=c?(0,X.jsx)(v,{id:`empty-create-bucket`,variant:`callAction`,label:n(`Create bucket`),onClick:()=>t(j.ADD_BUCKETS)}):void 0;return(0,X.jsxs)(Te,{value:H,children:[(0,X.jsx)(T,{open:N?.type===`replication`,children:N?.type===`replication`&&(0,X.jsx)(nt,{open:!0,buckets:N.names,closeModalAndRefresh:Oe})}),(0,X.jsx)(T,{open:N?.type===`lifecycle`,children:N?.type===`lifecycle`&&(0,X.jsx)(rt,{open:!0,buckets:N.names,closeModalAndRefresh:Oe})}),(0,X.jsx)(T,{open:F!==null,children:F!==null&&(0,X.jsx)(it,{deleteOpen:!0,selectedBucket:F,closeDeleteModalAndRefresh:e=>{I(null),e&&(k(e=>e.filter(e=>e!==F)),B())}})}),!o&&(0,X.jsx)(xe,{label:n(`Buckets`),titleElement:`h1`,help:!0}),(0,X.jsxs)(ie,{children:[o&&(0,X.jsx)(at,{children:n(`Buckets`)}),(0,X.jsxs)(ot,{children:[(0,X.jsx)(`div`,{className:`bucketSearch`,children:(0,X.jsx)(ye,{id:`bucket-search`,placeholder:n(`Search buckets`),value:_,onChange:oe,sx:{width:`100%`}})}),(0,X.jsxs)(`div`,{className:`bucketActions`,children:[(0,X.jsxs)(`div`,{className:`bucketView`,role:`group`,"aria-label":n(`Bucket view`),children:[(0,X.jsx)(v,{id:`buckets-view-table`,collapseOnSmall:!1,label:n(`Table`),variant:R===`table`?`secondary`:`ghost`,"aria-pressed":R===`table`,onClick:()=>z(`table`)}),(0,X.jsx)(v,{id:`buckets-view-cards`,collapseOnSmall:!1,label:n(`Cards`),variant:R===`cards`?`secondary`:`ghost`,"aria-pressed":R===`cards`,onClick:()=>z(`cards`)})]}),(0,X.jsx)(ae,{id:`refresh-buckets`,"aria-label":n(`Refresh buckets`),size:`medium`,disabled:S||H.requesting,onClick:be,children:(0,X.jsx)(re,{})}),G&&(i?(0,X.jsx)(ge,{label:n(`Actions`),items:[{label:n(`Set replication`),icon:(0,X.jsx)(ce,{}),disabled:S||!D.length||!J,disabledReason:Y(J,[M.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>P({type:`replication`,names:[...D]})},{label:n(`Set lifecycle`),icon:(0,X.jsx)(le,{}),disabled:S||!D.length||!q,disabledReason:Y(q,A[O.BUCKET_LIFECYCLE]),onClick:()=>P({type:`lifecycle`,names:[...D]})}]}):(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(v,{id:`set-replication`,collapseOnSmall:!1,label:n(`Set replication`),icon:(0,X.jsx)(ce,{}),disabled:S||!D.length||!J,disabledReason:Y(J,[M.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>P({type:`replication`,names:[...D]})}),(0,X.jsx)(v,{id:`set-lifecycle`,collapseOnSmall:!1,label:n(`Set lifecycle`),icon:(0,X.jsx)(le,{}),disabled:S||!D.length||!q,disabledReason:Y(q,A[O.BUCKET_LIFECYCLE]),onClick:()=>P({type:`lifecycle`,names:[...D]})})]})),!o&&(0,X.jsx)(v,{id:`create-bucket`,label:n(`Create bucket`),icon:(0,X.jsx)(ue,{}),disabled:!c,disabledReason:c?void 0:_e([M.S3_CREATE_BUCKET],n(`create a bucket`)),onClick:()=>t(j.ADD_BUCKETS),variant:`primary`,collapseOnSmall:!1})]})]}),(0,X.jsx)(Pe,{}),D.length>0&&(0,X.jsx)(ct,{role:`status`,children:h(n(D.length===1?`1 bucket selected`:`{count} buckets selected`),{count:D.length})}),S&&!b?(0,X.jsx)($,{children:(0,X.jsx)(Ce,{rows:5,columns:4})}):pe&&!b?(0,X.jsx)($,{children:(0,X.jsx)(Se,{compact:!0,icon:(0,X.jsx)(y,{}),title:n(`The bucket list could not be loaded.`),action:(0,X.jsx)(v,{id:`retry-buckets`,label:n(`Retry`),onClick:B})})}):U.length===0?(0,X.jsx)($,{children:g.q.trim()?(0,X.jsx)(Se,{compact:!0,icon:(0,X.jsx)(y,{}),title:h(n(`No buckets match “{q}”`),{q:g.q.trim()}),action:(0,X.jsx)(v,{id:`clear-bucket-filter`,label:n(`Clear filter`),onClick:de})}):(0,X.jsx)(Se,{icon:(0,X.jsx)(y,{}),title:n(`No buckets yet`),description:n(`Create a bucket to start storing objects.`),action:je})}):R===`table`?(0,X.jsx)(et,{...ke,records:U,query:g,onSort:se,selected:D,onSelectAll:Ee}):(0,X.jsx)(st,{role:`list`,"aria-label":n(`Buckets`),children:U.map(e=>(0,X.jsx)(Je,{...ke,bucket:e,selected:D.includes(e.name)},e.name))})]})]})};export{lt as default};