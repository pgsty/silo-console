const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./FluidHoverShowcase-DzilScb4.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./mds-Hm6-garf.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./DataTable-BrIhz8Fd.js","./circle-slash-1gFVvbJq.js","./hard-drive-BD3AgkvR.js","./share-2-CbIVY2ca.js","./pencil-CwNxaxuc.js","./shield-check-khB6crTd.js","./trash-BB_JaxBi.js","./circle-check-BZP-AfIi.js","./download-Bj3FrdXp.js","./terminal-B2BCWeyP.js","./Checkbox-D6PaAoo8.js","./console-vendor-I3rSB1nD.js","./listPopup-D2sWpuy2.js","./useTableLayout-B19JFDSA.js","./Tabs-mWs_oG0V.js","./i18n-Drk-M_7X.js","./lang-DMKw_tbl.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,r as n,t as r}from"./react-vendor-UL3KVrSx.js";import{i,n as a}from"./lang-DMKw_tbl.js";import{$ as o,H as s,Q as c,R as l,U as u,V as d,X as f,Y as p,Z as m,c as ee,ct as h,d as g,l as _,p as v,r as y,u as b,x as te,y as x}from"./mds-Hm6-garf.js";import{T as S}from"./shared-vendor-BQfq49S_.js";import{Or as C,r as w}from"./store-C9Mm53c2.js";import{t as T}from"./database-lhyGsjdT.js";import{t as ne}from"./pencil-CwNxaxuc.js";import{t as E}from"./trash-BB_JaxBi.js";import{t as D}from"./archive-OuPIyv4o.js";import{t as re}from"./info-SZqCz3Nv.js";import{t as O}from"./Checkbox-D6PaAoo8.js";import{n as k,t as A}from"./HelpBox-D5XbgQ9Y.js";import{t as ie}from"./SectionTitle-fTvk06tJ.js";import{t as j}from"./ModalBox-CgAJAa_u.js";import{t as M}from"./CommentBox-Dn-MSXhB.js";import{t as N}from"./Autocomplete-DpfK7cZd.js";import{a as P,t as ae}from"./i18n-Drk-M_7X.js";import{i as oe,n as se,r as ce,t as F}from"./index-DALAjBvJ.js";import{t as I}from"./typography-CvHJfn8U.js";import{t as le}from"./OverflowMenu-uk7R8BYl.js";import{t as L}from"./typography-BO7lxH25.js";import{t as R}from"./StatusBadge-BzPAjqeM.js";import{t as ue}from"./CliEquivalent-_icu06lc.js";import{t as de}from"./ConfirmDialog-yG250qEO.js";import{A as fe,H as pe,J as z,K as B,U as me,V as he,W as V,X as ge,Y as H,Z as U,q as _e}from"./ConsoleKBar-Dxo3YH9b.js";var W=e(t()),G=r(),K=S.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 280px), 1fr));
  gap: var(--space-16);
`,q=S.div`
  padding: var(--space-20);
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  color: var(--foreground);
  min-width: 0;
  h2 {
    ${I(`title`)} margin: 0 0 var(--space-16);
  }
`,ve=S.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--space-8);
`,ye=S.div`
  ${I(`caption`)}
  padding: var(--space-12) var(--space-4);
  text-align: center;
  border-radius: var(--radius-control);
  box-shadow: var(--shadow-1);
  background: ${({$color:e})=>e};
`,be=S.div`
  ${({$role:e})=>I(e)}
  padding: var(--space-8) 0;
  & + & {
    border-top: 1px solid var(--border);
  }
`,xe=S.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--space-24);
  padding: var(--space-16) 0;
`,Se=S(p)`
  ${I(`caption`)}
  padding: var(--space-16) var(--space-4);
  border-radius: var(--radius-control);
  text-align: center;
`,Ce=S.div`
  ${({$roleStyle:e})=>e}
  display: flex;
  align-items: center;
  height: var(--control-height);
  padding: 0 var(--control-padding);
  gap: var(--gap);
  border-radius: var(--radius-control);
  background: var(--hover);
  svg {
    width: var(--icon-size);
    height: var(--icon-size);
    color: var(--muted-foreground);
  }
`,J=()=>{let{compact:e,type:t,controlHeight:n}=c(),r=P();return(0,G.jsx)(`div`,{children:(0,G.jsxs)(Ce,{$roleStyle:t.body,children:[(0,G.jsx)(D,{}),(0,G.jsx)(`span`,{children:r(e?`Compact density`:`Default density`)}),(0,G.jsx)(`span`,{className:`silo-num`,children:a(r(`{height} px`),{height:n})})]})})},we=S.div`
  margin-top: var(--space-12);
  padding: var(--space-4);
  border-radius: var(--radius-control);
  background: var(--muted);
`,Te=S.div`
  width: 28px;
  height: 28px;
  border-radius: var(--radius-control);
  background: var(--foreground);
  transform: translateX(${({$moved:e})=>e?`140px`:`0`});
  opacity: ${({$moved:e})=>e?.6:1};
  transition:
    transform var(--dur-${({$tier:e})=>e})
      var(--ease-${({$tier:e})=>e}),
    opacity var(--dur-${({$tier:e})=>e})
      var(--ease-${({$tier:e})=>e});
  @media (prefers-reduced-motion: reduce) {
    transform: none;
  }
`,Ee=S.button`
  ${I(`body`,{weight:`semibold`})}
  padding: var(--space-8) var(--space-12);
  border: none;
  border-radius: var(--radius-control);
  color: var(--foreground);
  background: var(--tint);
  cursor: pointer;
  &:hover {
    background: var(--tint-hover);
  }
`,Y=({tier:e,label:t})=>{let[n,r]=(0,W.useState)(!1),i=P();return(0,G.jsxs)(`div`,{children:[(0,G.jsx)(Ee,{type:`button`,"aria-pressed":n,onClick:()=>r(!n),children:i(t)}),(0,G.jsx)(we,{children:(0,G.jsx)(Te,{"data-motion-tier":e,$tier:e,$moved:n})})]})},De={display:i(`Display type`),title:i(`Title type`),subtitle:i(`Subtitle type`),body:i(`Body type`),caption:i(`Caption type`),micro:i(`Micro type`)},Oe=()=>{let e=P();return(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(K,{children:[`light`,`dark`].map(t=>(0,G.jsxs)(q,{style:oe(t===`light`?ce:se),children:[(0,G.jsx)(`h2`,{children:e(t===`light`?`Light palette`:`Dark palette`)}),(0,G.jsx)(ve,{children:Array.from({length:8},(t,n)=>(0,G.jsx)(ye,{$color:`var(--surface-${n+1})`,children:a(e(`Surface {level}`),{level:n+1})},n))}),(0,G.jsx)(`p`,{style:{marginTop:`var(--space-12)`,color:`var(--foreground)`},children:e(`Primary text`)}),(0,G.jsx)(`p`,{style:{color:`var(--muted-foreground)`},children:e(`Secondary text`)})]},t))}),(0,G.jsxs)(K,{children:[(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Typography roles`)}),Object.keys(y).map(t=>(0,G.jsxs)(be,{$role:t,children:[e(De[t]),` `,(0,G.jsxs)(`span`,{className:`silo-num`,children:[y[t].size,`/`,y[t].line]})]},t))]}),(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Shadow ladder`)}),(0,G.jsx)(xe,{children:Array.from({length:8},(e,t)=>(0,G.jsx)(Se,{offset:t,shadowLevel:t+1,children:t+1},t))}),(0,G.jsx)(`h2`,{children:e(`Density comparison`)}),(0,G.jsx)(m,{children:(0,G.jsx)(J,{})}),(0,G.jsx)(`div`,{style:{height:`var(--space-8)`}}),(0,G.jsx)(m,{density:`compact`,children:(0,G.jsx)(J,{})})]})]}),(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Motion tiers`)}),(0,G.jsxs)(K,{children:[(0,G.jsx)(Y,{tier:`fast`,label:i(`Fast · 80 ms`)}),(0,G.jsx)(Y,{tier:`moderate`,label:i(`Moderate · 160 ms`)}),(0,G.jsx)(Y,{tier:`slow`,label:i(`Slow · 240 ms`)})]})]})]})},X=S.section`
  display: grid;
  gap: 16px;
  padding: 24px;
  border-radius: 12px;
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  h2 {
    ${o(`title`)} margin: 0;
  }
  h3 {
    ${o(`subtitle`)} margin: 0;
  }
  .control-row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 12px;
  }
  .control-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 16px;
  }
  .inputItem {
    min-width: 0;
  }
  .inputLabel {
    margin-right: 8px;
  }
  .inputLabel > span {
    min-width: 0;
  }
`,ke=()=>{let e=P(),[t,n]=(0,W.useState)(!0),[r,i]=(0,W.useState)(`one`),[a,o]=(0,W.useState)(`one`),[c,d]=(0,W.useState)(null),[p,h]=(0,W.useState)(!1),[y,x]=(0,W.useState)(!1),[S,C]=(0,W.useState)(!1),w=[{label:e(`Default`),value:`one`},{label:e(`Compact`),value:`two`}];return(0,G.jsx)(f,{level:3,children:(0,G.jsxs)(X,{id:`control-craft`,children:[(0,G.jsx)(`h2`,{children:e(`Control craft`)}),(0,G.jsx)(`p`,{children:e(`Hover, press or use Tab to inspect each control. All changes here are local demos.`)}),(0,G.jsx)(`h3`,{children:e(`Buttons and loading`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(s,{id:`press-80`,variant:`primary`,sx:{width:80},label:e(`Save`)}),(0,G.jsx)(s,{id:`press-400`,variant:`primary`,sx:{width:400,maxWidth:`100%`},label:e(`Create bucket`)}),(0,G.jsx)(s,{id:`control-secondary`,variant:`secondary`,label:e(`Secondary`)}),(0,G.jsx)(s,{id:`control-outline`,variant:`outline`,label:e(`Outline`)}),(0,G.jsx)(s,{id:`control-ghost`,variant:`ghost`,label:e(`Ghost`)}),(0,G.jsx)(s,{id:`control-danger`,variant:`danger`,label:e(`Delete`)}),(0,G.jsx)(s,{id:`control-disabled`,disabled:!0,disabledReason:e(`Select an object to download.`),label:e(`Disabled`)}),(0,G.jsx)(s,{id:`control-loading`,loading:!0,label:e(`Loading`)}),(0,G.jsx)(s,{id:`control-toggle-loading`,loading:S,label:e(`Save changes`),onClick:()=>{C(!0),setTimeout(()=>C(!1),1500)}}),(0,G.jsx)(te,{"aria-label":e(`Refresh`),children:(0,G.jsx)(l,{})})]}),(0,G.jsxs)(m,{density:`compact`,children:[(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(s,{id:`control-compact`,variant:`primary`,label:e(`Compact`)}),(0,G.jsx)(v,{id:`control-compact-input`,label:e(`Compact`),placeholder:e(`Name`)})]}),(0,G.jsx)(`div`,{id:`control-compact-help`,children:(0,G.jsx)(A,{iconComponent:(0,G.jsx)(re,{}),title:e(`Compact`),help:e(`Usage is calculated by the server.`)})})]}),(0,G.jsx)(`h3`,{children:e(`Fields and validation`)}),(0,G.jsxs)(`div`,{className:`control-grid`,children:[(0,G.jsx)(v,{id:`control-input`,label:e(`Name`),placeholder:e(`Name`)}),(0,G.jsx)(v,{id:`control-password`,type:`password`,label:e(`Password`),defaultValue:`example`}),(0,G.jsx)(v,{id:`control-error`,label:e(`Name`),error:e(`A name is required.`)}),(0,G.jsx)(v,{id:`control-disabled-input`,label:e(`Disabled`),disabled:!0,value:e(`Unavailable`)}),(0,G.jsx)(v,{id:`control-disabled-empty`,label:e(`Disabled`),disabled:!0,placeholder:e(`Name`)}),(0,G.jsx)(v,{id:`control-number`,type:`number`,label:e(`Capacity`),defaultValue:20}),(0,G.jsx)(g,{id:`control-select`,label:e(`Density`),value:a,options:w,onChange:o}),(0,G.jsx)(g,{id:`control-disabled-select`,label:e(`Disabled`),value:`one`,options:w,onChange:()=>{},disabled:!0}),(0,G.jsx)(g,{id:`control-error-select`,label:e(`Density`),options:w,onChange:()=>{},error:e(`A name is required.`),placeholder:e(`Select`)}),(0,G.jsx)(g,{id:`control-disabled-placeholder`,label:e(`Disabled`),options:w,onChange:()=>{},disabled:!0,placeholder:e(`Select`)}),(0,G.jsx)(N,{id:`control-autocomplete`,label:e(`Search`),placeholder:e(`Select`),value:a,options:w,onChange:o}),(0,G.jsx)(N,{id:`control-error-autocomplete`,label:e(`Search`),placeholder:e(`Select`),options:w,onChange:()=>{},error:e(`A name is required.`)}),(0,G.jsx)(N,{id:`control-disabled-autocomplete`,label:e(`Disabled`),placeholder:e(`Select`),options:w,onChange:()=>{},disabled:!0}),(0,G.jsx)(M,{id:`control-disabled-textarea`,label:e(`Disabled`),disabled:!0,placeholder:e(`Description`)}),(0,G.jsx)(M,{id:`control-textarea`,label:e(`Description`),placeholder:e(`Description`)})]}),(0,G.jsx)(`h3`,{children:e(`Selection controls`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(O,{id:`control-checkbox`,label:e(`Enabled`),checked:t,onChange:e=>n(e.target.checked)}),(0,G.jsx)(O,{id:`control-disabled-checkbox`,label:e(`Disabled`),disabled:!0,checked:!0,readOnly:!0}),(0,G.jsx)(U,{id:`control-switch`,label:e(`Enabled`),checked:t,onChange:e=>n(e.target.checked)}),(0,G.jsx)(U,{id:`control-disabled-switch`,label:e(`Disabled`),checked:!0,disabled:!0}),(0,G.jsx)(ge,{id:`control-radio`,name:`control-radio`,label:e(`Density`),currentValue:r,selectorOptions:w,onChange:e=>i(e.target.value)})]}),(0,G.jsx)(`h3`,{children:e(`Status and feedback`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(b,{id:`control-tag`,label:e(`Enabled`),color:`ok`}),(0,G.jsx)(b,{id:`control-tag-dot`,label:e(`Warning`),color:`warn`,variant:`dot`}),(0,G.jsx)(R,{tone:`danger`,label:e(`Offline`)}),(0,G.jsx)(R,{tone:`info`,label:e(`Built-in`),dot:!1}),(0,G.jsx)(u,{tooltip:e(`First tooltip`),children:(0,G.jsx)(s,{id:`control-tip-one`,label:e(`First tooltip`)})}),(0,G.jsx)(u,{tooltip:e(`Second tooltip`),children:(0,G.jsx)(s,{id:`control-tip-two`,label:e(`Second tooltip`)})})]}),(0,G.jsx)(k,{title:e(`Information`),tone:`info`,children:e(`Usage is calculated by the server.`)}),(0,G.jsx)(k,{title:e(`Warning`),tone:`warning`,contrast:`high`,children:e(`Above the 85% warning threshold`)}),(0,G.jsx)(_,{value:65,variant:`determinate`,progressLabel:!0,notificationLabel:e(`Progress`)}),(0,G.jsx)(_,{notificationLabel:e(`Loading`)}),(0,G.jsx)(`h3`,{children:e(`Dialogs`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[[`sm`,`lg`,`xl`].map(t=>(0,G.jsx)(s,{id:`control-dialog-${t}`,label:`${e(`Open Dialog`)} · ${t===`sm`?`400`:t===`lg`?`540`:`880`}`,onClick:()=>d(t)},t)),(0,G.jsx)(s,{id:`control-snackbar`,label:e(`Show notification`),onClick:()=>x(!0)})]}),(0,G.jsxs)(j,{open:c!==null,size:c||`lg`,title:e(`Dialog controls`),onClose:()=>d(null),children:[(0,G.jsxs)(`div`,{className:`control-grid`,style:{display:`grid`,gap:16},children:[(0,G.jsx)(v,{id:`dialog-name`,label:e(`Name`)}),(0,G.jsx)(g,{id:`dialog-select`,label:e(`Density`),value:a,options:w,onChange:o})]}),(0,G.jsxs)(`div`,{className:`control-row`,style:{display:`flex`,flexWrap:`wrap`,gap:8,justifyContent:`flex-end`,marginTop:24},children:[(0,G.jsx)(s,{id:`control-nested-open`,label:e(`Nested dialog`),onClick:()=>h(!0)}),(0,G.jsx)(s,{id:`control-dialog-cancel`,label:e(`Cancel`),onClick:()=>d(null)}),(0,G.jsx)(s,{id:`control-dialog-save`,variant:`primary`,label:e(`Save`),onClick:()=>d(null)})]}),(0,G.jsx)(j,{open:p,size:`sm`,title:e(`Nested dialog`),onClose:()=>h(!1),children:(0,G.jsx)(s,{id:`control-nested-close`,variant:`primary`,label:e(`Close`),onClick:()=>h(!1)})})]}),(0,G.jsx)(ee,{open:y,onClose:()=>x(!1),message:e(`Demo action completed.`),closeButton:!0})]})})},Ae=(0,W.lazy)(()=>h(()=>import(`./FluidHoverShowcase-DzilScb4.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]),import.meta.url)),je=S.div`
  color: var(--silo-text);
  display: grid;
  gap: var(--silo-space-24);
  margin-bottom: var(--silo-space-32);
  h1 {
    ${L.title} margin: 0 0 var(--silo-space-8);
  }
  h2 {
    ${L.section} margin: 0 0 var(--silo-space-16);
  }
  p {
    ${L.body} color: var(--silo-text-secondary);
    margin: 0;
  }
  a {
    color: var(--silo-primary);
  }
  #root & button.button-regular,
  #root & button.button-callAction {
    border-radius: var(--silo-radius-button);
    letter-spacing: normal;
  }
`,Me=S.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--silo-space-16);
  @media (max-width: ${F.lg-1}px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: ${F.md-1}px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Z=S.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--silo-space-16);
  @media (max-width: ${F.md-1}px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Q=S.div`
  min-width: 0;
  padding: var(--silo-space-20);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  border-radius: var(--silo-radius-card);
`,$=S.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--silo-space-12);
  & + & {
    margin-top: var(--silo-space-16);
  }
`,Ne=S.span`
  ${L.small}
  display: inline-flex;
  align-items: center;
  padding: var(--silo-space-8) var(--silo-space-12);
  border: 1px dashed var(--silo-border-strong);
  border-radius: var(--silo-radius-input);
  color: var(--silo-text-muted);
`,Pe=()=>{let[e,t]=(0,W.useState)(!1),[r,a]=(0,W.useState)(!0),[o,c]=(0,W.useState)(``),[u]=(0,W.useState)(()=>new Date(Date.now()-18e4).toISOString()),f=w(),p=P();return(0,W.useEffect)(()=>{f(C(`components`))},[]),(0,G.jsxs)(W.Fragment,{children:[(0,G.jsx)(fe,{label:i(`Components`),help:!0}),(0,G.jsxs)(x,{sx:{padding:24,[`@media (max-width: ${F.lg-1}px)`]:{padding:16},[`@media (max-width: ${F.md-1}px)`]:{padding:12}},children:[(0,G.jsxs)(je,{children:[(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h1`,{children:p(`SILO primitives`)}),(0,G.jsx)(`p`,{children:p(`Shared building blocks for storage, identity and monitoring.`)})]}),(0,G.jsx)(ke,{}),(0,G.jsx)(Oe,{}),(0,G.jsx)(W.Suspense,{fallback:null,children:(0,G.jsx)(Ae,{})}),(0,G.jsxs)(Me,{children:[(0,G.jsx)(V,{label:p(`Capacity`),icon:(0,G.jsx)(T,{}),value:`7.2`,unit:`TiB`,subline:p(`Healthy capacity`),progress:{value:.72},footer:(0,G.jsx)(B,{at:u,prefix:`Calculated`})}),(0,G.jsx)(V,{label:p(`Capacity warning`),icon:(0,G.jsx)(T,{}),value:`8.7`,unit:`TiB`,subline:p(`Above the 85% warning threshold`),progress:{value:.87}}),(0,G.jsx)(V,{label:p(`Capacity critical`),icon:(0,G.jsx)(T,{}),value:`9.6`,unit:`TiB`,subline:p(`Above the 95% critical threshold`),progress:{value:.96}}),(0,G.jsx)(V,{label:p(`Buckets`),icon:(0,G.jsx)(D,{}),value:`28`,subline:p(`Usage is calculated by the server.`),footer:(0,G.jsx)(n,{to:`/buckets`,children:p(`View buckets`)})})]}),(0,G.jsxs)(Z,{children:[(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:p(`Status and values`)}),(0,G.jsxs)($,{children:[(0,G.jsx)(R,{tone:`success`,label:p(`Online`)}),(0,G.jsx)(R,{tone:`warning`,label:p(`Healing`)}),(0,G.jsx)(R,{tone:`danger`,label:p(`Offline`)}),(0,G.jsx)(R,{tone:`neutral`,label:p(`Disabled`)}),(0,G.jsx)(R,{tone:`info`,label:p(`Built-in`),dot:!1})]}),(0,G.jsxs)($,{children:[(0,G.jsx)(H,{label:p(`Versioning`),value:(0,G.jsx)(R,{tone:r?`success`:`neutral`,label:p(r?`Enabled`:`Disabled`)}),onEdit:()=>a(e=>!e)}),(0,G.jsx)(H,{label:p(`Objects`),value:(0,G.jsx)(`span`,{className:`silo-num`,children:`1,248`})})]})]}),(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:p(`Freshness and actions`)}),(0,G.jsxs)($,{children:[(0,G.jsx)(B,{at:u}),(0,G.jsx)(B,{}),(0,G.jsx)(B,{at:u,pending:!0})]}),(0,G.jsxs)($,{children:[(0,G.jsx)(_e,{reason:p(`Select an object to inspect its details.`),children:(0,G.jsx)(Ne,{children:p(`Object details`)})}),(0,G.jsx)(le,{items:[{label:p(`Delete`),icon:(0,G.jsx)(E,{}),danger:!0,onClick:()=>c(p(`Demo action completed.`))},{label:p(`Refresh`),icon:(0,G.jsx)(l,{}),onClick:()=>c(p(`Demo action completed.`))},{label:p(`Edit`),icon:(0,G.jsx)(ne,{}),onClick:()=>c(p(`Demo action completed.`))},{label:p(`Download`),disabled:!0,disabledReason:p(`Select an object to download.`),onClick:()=>{}}]})]}),(0,G.jsx)(`p`,{role:`status`,children:o})]})]}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{children:p(`Empty and unavailable states`)}),(0,G.jsxs)(Z,{children:[(0,G.jsx)(Q,{children:(0,G.jsx)(z,{icon:(0,G.jsx)(D,{}),title:p(`No buckets yet`),description:p(`Create a bucket to start storing objects.`),docsUrl:`https://silo.pgsty.com/`,action:(0,G.jsx)(s,{id:`showcase-create-bucket`,type:`button`,variant:`callAction`,label:p(`Create bucket`),onClick:()=>c(p(`Demo action completed.`))})})}),(0,G.jsx)(Q,{children:(0,G.jsx)(z,{compact:!0,icon:(0,G.jsx)(D,{}),title:p(`No matching objects`),description:p(`Try a different name or clear the search filter.`)})}),(0,G.jsx)(Q,{children:(0,G.jsx)(me,{title:p(`Metrics are unavailable`),description:p(`Connect a Prometheus endpoint to view monitoring metrics.`),docsUrl:`https://silo.pgsty.com/`})}),(0,G.jsx)(Q,{children:(0,G.jsx)(pe,{required:[`admin:ServerInfo`,`s3:ListAllMyBuckets`]})})]})]}),(0,G.jsxs)(Z,{children:[(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:p(`Loading rows`)}),(0,G.jsx)(he,{columns:3})]}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{children:p(`Command preview`)}),(0,G.jsx)(ue,{alias:`silo`,commands:[`mcli ls ALIAS`,`mcli version info ALIAS/demo-data`]})]})]})]}),(0,G.jsxs)(d,{container:!0,children:[(0,G.jsx)(d,{item:!0,xs:12,children:(0,G.jsx)(ie,{children:p(`Confirm Dialogs`)})}),(0,G.jsx)(d,{item:!0,xs:12,children:(0,G.jsx)(`p`,{children:p(`Used to confirm a non-idempotent action.`)})}),(0,G.jsxs)(d,{item:!0,xs:12,children:[(0,G.jsx)(s,{id:`open-dialog-test`,type:`button`,variant:`regular`,onClick:()=>{t(!0)},label:p(`Open Dialog`)}),(0,G.jsx)(de,{destructive:!0,title:p(`Delete Bucket`),confirmText:p(`Delete`),isOpen:e,titleIcon:(0,G.jsx)(E,{}),isLoading:!1,onConfirm:()=>{t(!1)},onClose:()=>{t(!1)},confirmationContent:(0,G.jsxs)(W.Fragment,{children:[ae(p(`Are you sure you want to delete bucket {bucket}?`),{bucket:(0,G.jsx)(`b`,{children:`bucket`})}),(0,G.jsx)(`br`,{}),p(`A bucket can only be deleted if it's empty.`)]})})]})]})]})]})};export{Pe as default};