import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,t as n}from"./react-vendor-UL3KVrSx.js";import{T as r}from"./shared-vendor-BQfq49S_.js";import{wn as i}from"./store-u0LCkSUK.js";import{i as a}from"./lang-BxJGrDHW.js";import{X as o,g as s}from"./mds-YaKHoCCJ.js";import{a as c,i as l,n as u,t as d}from"./i18n-CkC2HRew.js";import{g as f}from"./index-BCJkkRQw.js";import{o as p,t as m}from"./permissions-BaYWxI8a.js";import{n as h}from"./SecureComponent-BuNNF0Qr.js";import{A as g,i as _,n as v,r as y}from"./ConsoleKBar-CIf1MkWB.js";var b=e(t()),x=`2.5.1`,S=n(),C=`https://silo.pgsty.com/`,w=`https://github.com/pgsty/silo`,T=`https://min.io/`,E=`https://github.com/minio/minio`,D=`https://www.gnu.org/licenses/agpl-3.0.html`,O=r.section`
  ${o(`body`)}
  max-width: 760px;
  margin: 0 auto;
  color: var(--foreground);
  & a {
    color: var(--foreground);
    text-decoration: underline;
    text-decoration-color: var(--border);
    text-underline-offset: 4px;
    overflow-wrap: anywhere;
  }
  & a:hover {
    text-decoration-color: currentColor;
  }
  & a:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 4px;
    border-radius: 4px;
  }
  & a[target="_blank"]::after {
    content: "↗";
    padding-left: 4px;
    color: var(--muted-foreground);
    font-size: var(--fs-micro);
  }
`,k=r.a`
  width: 360px;
  max-width: 100%;
  margin: 8px auto 0;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
  text-decoration: none !important;
  &::after {
    display: none !important;
  }
  :root[data-theme="dark"] & .licenseWordmark {
    filter: brightness(1.5) saturate(0.85);
  }
`,A=r.p`
  ${o(`caption`)}
  margin: 16px 0 0;
  text-align: center;
  color: var(--muted-foreground);
  & .acr {
    color: var(--foreground);
    font-weight: 550;
  }
`,j=r.p`
  ${o(`subtitle`,{weight:`normal`})}
  margin: 32px 0 0;
  & a::after {
    display: none !important;
  }
  & strong {
    font-weight: 550;
  }
`,M=r.dl`
  margin: 32px 0 0;
  padding-top: 24px;
  border-top: 1px solid var(--border);
  display: grid;
  grid-template-columns: 112px minmax(0, 1fr);
  column-gap: 24px;
  row-gap: 24px;
  & dt {
    ${o(`body`,{weight:`semibold`})}
    padding-top: 4px;
    color: var(--muted-foreground);
  }
  & dd {
    margin: 0;
    min-width: 0;
  }
  & dd > * + * {
    margin-top: 8px;
  }
  & .chip {
    ${o(`caption`,{weight:`semibold`})}
    display: inline-block;
    max-width: 100%;
    box-sizing: border-box;
    padding: 4px 8px;
    border-radius: var(--radius-control);
    background: var(--muted);
    font-family: var(--font-mono);
    overflow-wrap: anywhere;
  }
  & .line {
    ${o(`body`)}
    font-family: var(--font-mono);
  }
  & .what {
    ${o(`caption`)}
    padding-left: 8px;
    color: var(--muted-foreground);
  }
  & .prose {
    ${o(`body`)}
    margin: 0;
  }
  & .note {
    ${o(`caption`)}
    margin-bottom: 0;
    color: var(--muted-foreground);
  }
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
    row-gap: 8px;
    & dt:not(:first-of-type) {
      margin-top: 16px;
    }
  }
`,N=()=>{let e=l(),t=c(),n=u(),r=`v${x}`,o=_(),[N,P]=(0,b.useState)(``),F=h(m,[p.ADMIN_SERVER_INFO]);return(0,b.useEffect)(()=>{F&&i.admin.adminInfo({defaultOnly:!1}).then(e=>{let t=Array.from(new Set((e.data?.servers||[]).map(e=>e.version).filter(Boolean)));P(t.join(` · `))}).catch(()=>{})},[F]),(0,S.jsxs)(b.Fragment,{children:[(0,S.jsx)(g,{label:a(`License`),titleElement:`h1`}),(0,S.jsx)(s,{children:(0,S.jsxs)(O,{children:[(0,S.jsxs)(k,{href:e(C),target:`_blank`,rel:`noopener noreferrer`,"aria-label":t(`Visit the SILO website`),children:[(0,S.jsx)(f,{variant:`emblem`,alt:`SILO emblem`,style:{display:`block`,width:`25%`,maxWidth:88}}),(0,S.jsx)(f,{className:`licenseWordmark`,style:{display:`block`,width:`60%`,maxWidth:200}})]}),(0,S.jsxs)(A,{children:[(0,S.jsx)(`span`,{className:`acr`,children:`S`}),`3 `,(0,S.jsx)(`span`,{className:`acr`,children:`I`}),`nterface · `,(0,S.jsx)(`span`,{className:`acr`,children:`L`}),`ibre`,` `,(0,S.jsx)(`span`,{className:`acr`,children:`O`}),`bject Store`]}),(0,S.jsx)(j,{children:d(t(`{silo} is an independently maintained continuation of the {minio} object storage project, carried forward by the {pigsty} community since 2026. Its {code} {incorporates} {upstream}, and the complete work remains licensed under the {agpl}.`),{silo:(0,S.jsx)(`a`,{href:e(C),target:`_blank`,rel:`noopener noreferrer`,children:`SILO`}),minio:(0,S.jsx)(`a`,{href:T,target:`_blank`,rel:`noopener noreferrer`,children:`MinIO`}),pigsty:(0,S.jsx)(`a`,{href:n===`zh`?`https://pgsty.com/zh`:`https://pgsty.com/`,target:`_blank`,rel:`noopener noreferrer`,children:`PGSTY`}),code:(0,S.jsx)(`a`,{href:w,target:`_blank`,rel:`noopener noreferrer`,children:t(`code`)}),incorporates:(0,S.jsx)(`strong`,{children:t(`incorporates and modifies`)}),upstream:(0,S.jsx)(`a`,{href:E,target:`_blank`,rel:`noopener noreferrer`,children:t(`upstream MinIO code`)}),agpl:(0,S.jsx)(`a`,{href:D,target:`_blank`,rel:`license noopener noreferrer`,children:t(`GNU Affero General Public License, version 3`)})})}),(0,S.jsxs)(M,{children:[(0,S.jsx)(`dt`,{children:t(`Version`)}),(0,S.jsxs)(`dd`,{children:[N!==``&&(0,S.jsxs)(`div`,{className:`line`,children:[(0,S.jsx)(`span`,{className:`chip`,children:N}),(0,S.jsx)(`span`,{className:`what`,children:t(`connected server`)})]}),(0,S.jsxs)(`div`,{className:`line`,children:[(0,S.jsx)(`span`,{className:`chip`,children:r}),(0,S.jsx)(`span`,{className:`what`,children:t(`this Console`)})]})]}),(0,S.jsx)(`dt`,{children:t(`License`)}),(0,S.jsxs)(`dd`,{children:[(0,S.jsx)(`span`,{className:`chip`,children:`AGPL-3.0-or-later`}),(0,S.jsx)(`div`,{className:`line`,children:(0,S.jsx)(`a`,{href:D,target:`_blank`,rel:`license noopener noreferrer`,children:t(`GNU AGPL v3 full text`)})}),(0,S.jsx)(`div`,{className:`line`,children:(0,S.jsx)(`a`,{href:v.license,target:`_blank`,rel:`license noopener noreferrer`,children:t(`Console LICENSE`)})}),(0,S.jsx)(`p`,{className:`note`,children:d(t(`Server, client and Console are all AGPLv3. SILO's documentation is CC BY 4.0 — {licensing}.`),{licensing:(0,S.jsx)(`a`,{href:e(`https://silo.pgsty.com/about/license/`),target:`_blank`,rel:`noopener noreferrer`,children:t(`licensing in full`)})})})]}),(0,S.jsx)(`dt`,{children:t(`Source`)}),(0,S.jsxs)(`dd`,{children:[(0,S.jsxs)(`div`,{className:`line`,children:[(0,S.jsx)(`a`,{href:w,target:`_blank`,rel:`noopener noreferrer`,children:`pgsty/silo`}),(0,S.jsx)(`span`,{className:`what`,children:t(`server`)})]}),(0,S.jsxs)(`div`,{className:`line`,children:[(0,S.jsx)(`a`,{href:`https://github.com/pgsty/mc`,target:`_blank`,rel:`noopener noreferrer`,children:`pgsty/mc`}),(0,S.jsx)(`span`,{className:`what`,children:t(`client`)})]}),(0,S.jsxs)(`div`,{className:`line`,children:[(0,S.jsx)(`a`,{href:o.available?o.url:y,target:`_blank`,rel:`noopener noreferrer`,children:`pgsty/silo-console`}),(0,S.jsx)(`span`,{className:`what`,children:t(`this Console`)})]}),(0,S.jsx)(`div`,{className:`line`,"data-testid":`corresponding-source`,children:o.available?(0,S.jsx)(`a`,{href:o.url,target:`_blank`,rel:`noopener noreferrer`,children:t(`Corresponding source for this build`)}):(0,S.jsx)(`span`,{className:`what`,children:d(t(`The exact corresponding source is not available for this build: {reason}. See the NOTICE for how to obtain it.`),{reason:o.reason})})}),(0,S.jsxs)(`div`,{className:`line`,children:[(0,S.jsx)(`a`,{href:`https://github.com/georgmangold/console`,target:`_blank`,rel:`noopener noreferrer`,children:`georgmangold/console`}),(0,S.jsx)(`span`,{className:`what`,children:t(`Console predecessor`)})]}),(0,S.jsx)(`p`,{className:`note`,children:t(`Under section 13 of the AGPL, the corresponding source for this running version is offered to every user who interacts with it over a network, at no charge.`)})]}),(0,S.jsx)(`dt`,{children:t(`Copyright`)}),(0,S.jsxs)(`dd`,{children:[(0,S.jsxs)(`p`,{className:`prose`,children:[t(`© 2026 Ruohang Feng / PGSTY and the SILO contributors.`),(0,S.jsx)(`br`,{}),t(`Portions © 2015–2026 MinIO, Inc.`),(0,S.jsx)(`br`,{}),t(`Console portions © Georg Mangold and contributors.`)]}),(0,S.jsx)(`p`,{className:`note`,children:d(t(`Upstream copyright, authorship and license notices are retained in the repository's {credits} and {notice}. See the {attribution}.`),{credits:(0,S.jsx)(`a`,{href:v.credits,target:`_blank`,rel:`noopener noreferrer`,children:`CREDITS`}),notice:(0,S.jsx)(`a`,{href:v.notice,target:`_blank`,rel:`noopener noreferrer`,children:`NOTICE`}),attribution:(0,S.jsx)(`a`,{href:e(`https://silo.pgsty.com/about/attribution/`),target:`_blank`,rel:`noopener noreferrer`,children:t(`full attribution stack`)})})})]}),(0,S.jsx)(`dt`,{children:t(`Trademark`)}),(0,S.jsxs)(`dd`,{children:[(0,S.jsx)(`p`,{className:`prose`,children:d(t(`{minio} is a registered trademark of MinIO, Inc. {silo} is not a MinIO, Inc. product, and is not affiliated with, sponsored by, or endorsed by MinIO, Inc.`),{minio:(0,S.jsx)(`a`,{href:T,target:`_blank`,rel:`noopener noreferrer`,children:`MINIO®`}),silo:(0,S.jsx)(`a`,{href:e(C),target:`_blank`,rel:`noopener noreferrer`,children:`SILO`})})}),(0,S.jsx)(`p`,{className:`note`,children:d(t(`The MinIO name is used here solely to identify the origin of the source code and to describe compatibility — {notice}.`),{notice:(0,S.jsx)(`a`,{href:e(`https://silo.pgsty.com/about/trademark/`),target:`_blank`,rel:`noopener noreferrer`,children:t(`trademark notice`)})})})]})]})]})})]})};export{N as default};