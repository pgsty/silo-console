import"./rolldown-runtime-BWaJ3C7D.js";import{P as e,t}from"./react-vendor-UL3KVrSx.js";import{$ as n,Q as r}from"./mds-Hm6-garf.js";import{T as i}from"./shared-vendor-BQfq49S_.js";import{t as a}from"./info-SZqCz3Nv.js";e();var o=t(),s={neutral:`var(--foreground)`,info:`var(--info)`,success:`var(--success)`,warning:`var(--warning)`,danger:`var(--destructive)`},c=i.div`
  ${n(`body`)}
  color: var(--foreground);
  background: ${({$high:e,$tone:t})=>e?`color-mix(in oklab, ${t} 12%, transparent)`:`var(--hover)`};
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  gap: 12px;
  align-items: start;
  border: 0;
  border-radius: 8px;
  padding: ${({$compact:e})=>e?12:16}px;
  .banner-icon {
    color: ${({$tone:e,$high:t})=>t?`var(--foreground)`:e};
    display: flex;
    align-items: center;
    height: var(--lh-body, 20px);
  }
  .banner-icon svg {
    width: var(--icon-size, 16px);
    height: var(--icon-size, 16px);
    fill: currentColor;
  }
  .banner-title {
    font-weight: 550;
    margin-bottom: 4px;
  }
  .banner-description {
    color: var(--foreground);
  }
`,l=({title:e,children:t,icon:n,tone:i=`neutral`,contrast:l=`low`,actions:u,...d})=>{let{compact:f}=r();return(0,o.jsxs)(c,{$tone:s[i],$high:l===`high`,$compact:f,role:i===`danger`||i===`warning`?`alert`:`status`,...d,children:[(0,o.jsx)(`span`,{className:`banner-icon`,"aria-hidden":`true`,children:n||(0,o.jsx)(a,{})}),(0,o.jsxs)(`div`,{children:[e&&(0,o.jsx)(`div`,{className:`banner-title`,children:e}),(0,o.jsx)(`div`,{className:`banner-description`,children:t})]}),u]})},u=({iconComponent:e,title:t,help:n})=>(0,o.jsx)(l,{className:`helpbox-container`,icon:e,title:t,children:n});export{l as n,u as t};