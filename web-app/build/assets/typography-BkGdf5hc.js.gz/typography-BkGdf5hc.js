import{x as e}from"./shared-vendor-BQfq49S_.js";import{n as t,r as n}from"./mds-DIGH6qee.js";var r=(r,{compact:i=!1,weight:a}={})=>{let o=n[r],s=i?`-compact`:``;return e`
    font-family: var(--font-sans);
    font-size: var(
      --fs-${r}${s},
      ${i?o.compactSize:o.size}px
    );
    line-height: var(
      --lh-${r}${s},
      ${i?o.compactLine:o.line}px
    );
    font-weight: ${a?t[a]:o.weight};
  `};export{r as t};