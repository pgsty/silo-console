import"./rolldown-runtime-BWaJ3C7D.js";import{P as e,t}from"./react-vendor-UL3KVrSx.js";import{T as n}from"./shared-vendor-BQfq49S_.js";import{nt as r,rt as i}from"./mds-B7pDlMNU.js";e();var a=t(),o=n.span`
  ${({$compact:e})=>i(`caption`,{compact:e})}
  display: inline-flex;
  align-items: center;
  gap: var(--silo-space-8);
  box-sizing: border-box;
  height: ${({$compact:e})=>e?20:24}px;
  padding: 0 ${({$compact:e})=>e?8:10}px;
  border-radius: var(--silo-radius-pill);
  color: var(--foreground);
  border: 1px solid ${({$dot:e})=>e?`var(--border)`:`transparent`};
  background: ${({$tone:e,$dot:t})=>t?`transparent`:`color-mix(in srgb, var(--silo-${e===`neutral`?`text-muted`:e}) 15%, var(--background))`};
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
`,s=n.span`
  width: 6px;
  height: 6px;
  border-radius: var(--silo-radius-pill);
  background: ${({$tone:e})=>`var(--silo-${e===`neutral`?`text-muted`:e})`};
  flex-shrink: 0;
`,c=({tone:e,label:t,dot:n=!0})=>{let{compact:i}=r();return(0,a.jsxs)(o,{$tone:e,$dot:n,$compact:i,children:[n&&(0,a.jsx)(s,{$tone:e,"aria-hidden":`true`}),t]})};export{c as t};