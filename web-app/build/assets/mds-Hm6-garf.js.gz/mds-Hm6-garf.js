const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./DropdownSelectorPopup-qGKCmTTo.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./listPopup-D2sWpuy2.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{N as t,P as n,t as r}from"./react-vendor-UL3KVrSx.js";import{C as i,O as a,S as o,T as s,b as c,x as l}from"./shared-vendor-BQfq49S_.js";var u=e(n()),d=e(t()),f=`modulepreload`,p=function(e,t){return new URL(e,t).href},m={},h=function(e){return e.pathname.endsWith(`.css`)},g=function(e,t,n){if(t in e)return e[t];let r=n();if(!r){e[t]=void 0;return}let i=r.then(()=>{e[t]=void 0},n=>{throw e[t]=void 0,n});return e[t]=i,i},_=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e,i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?new URL(import.meta.resolve(e)):new URL(e,import.meta.url)}r=o(t.map(t=>{t=p(t,n);let r=s(t),i=h(r);return g(m,r.href,()=>{if(e===void 0){e={all:new Set,styles:new Set};let t=document.getElementsByTagName(`link`);for(let n=t.length-1;n>=0;n--){let r=t[n];e.all.add(r.href),r.rel===`stylesheet`&&e.styles.add(r.href)}}if((i?e.styles:e.all).has(r.href))return;let t=document.createElement(`link`);if(t.rel=i?`stylesheet`:f,i||(t.as=`script`),t.crossOrigin=``,t.href=r.href,a&&t.setAttribute(`nonce`,a),document.head.appendChild(t),i)return new Promise((e,n)=>{t.addEventListener(`load`,e),t.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${r}`)))})})}).filter(e=>e!==void 0))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},v=[`B`,`KiB`,`MiB`,`GiB`,`TiB`,`PiB`,`EiB`,`ZiB`,`YiB`],y=e=>{if(typeof e==`string`){if(!/^\+?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(e.trim()))return null}else if(typeof e!=`number`)return null;let t=Number(e);return Number.isFinite(t)&&t>=0?t:null},b=(e,t,n)=>{let r=0,i=e;for(;i>=1024&&r<t.length-1;)i/=1024,r++;return n(i)>=1024&&r<t.length-1&&(i/=1024,r++),{value:i,unit:r}},x=(e,t=!1,n=!0,r=v)=>{let i=y(e);if(i===null||r.length===0)return{total:null,unit:``};if(i===0)return{total:0,unit:r[0]};let a=+!!t,o=e=>Number((n?Math.floor(e):e).toFixed(a)),s=b(i,r,o);return{total:o(s.value),unit:r[s.unit]}},S=e(a()),C={xs:0,sm:576,md:768,lg:992,xl:1200},w=[`B`,`KiB`,`MiB`,`GiB`,`TiB`,`PiB`,`EiB`,`ZiB`,`YiB`],T=e=>{if(e===`auto`||typeof e==`boolean`&&e)return`100%`;if(e===!1)return`initial`;let t=Math.floor(e);return t>12?(t=12,console.warn(`Grid fraction cannot be greater than 12`)):t<1&&(t=1,console.warn(`Grid fraction cannot be smaller than 1`)),`${t*100/12}%`},E=e=>{if(typeof e==`string`){if(!/^\+?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(e.trim()))return null}else if(typeof e!=`number`)return null;let t=Number(e);return Number.isFinite(t)&&t>=0?t:null},D=(e,t,n)=>{let r=0,i=e;for(;i>=1024&&r<t.length-1;)i/=1024,r++;return n(i)>=1024&&r<t.length-1&&(i/=1024,r++),{value:i,unit:r}},O=(e,t=!1,n=!0,r=w)=>{let i=E(e);if(i===null||r.length===0)return{total:null,unit:``};if(i===0)return{total:0,unit:r[0]};let a=+!!t,o=e=>Number((n?Math.floor(e):e).toFixed(a)),s=D(i,r,o);return{total:o(s.value),unit:r[s.unit]}},k={white:`#fff`,sectionOneBG:`#fff`,defaultFontColor:`#000`,bulletColor:`#2781B0`,borderColor:`#E2E2E2`,boxBackground:`#FBFAFA`,mainGrey:`#5B5C5C`,disabledGrey:`#E6EBEB`,hoverGrey:`#E6EAEB`,pressedGrey:`#D5D7D8`,actionDisabledGrey:`#E7EAEB`,mainBlue:`#07193E`,hoverBlue:`#0D2453`,pressedBlue:`#05132F`,mainRed:`#C51B3F`,hoverRed:`#FCF2F4`,lightRed:`#C83B51`,divisorColor:`#E3E3E3`,disabledBGGrey:`#D5D7D7`,disabledInnerGrey:`#B4B4B4`,logoLabel:`#000000`,logoLabelInverse:`#fff`,promoBlue:`#A6DFEF`,footerDivider:`#F2F2F2`,promoBG:`#000110`,loaderColor:`#113053`,headerBG:`#FFFFFF`,headerBorder:`#E5E5E5`,headerColor:`#000000`,tooltipBG:`#737373`,tooltipColor:`#FFFFFF`,labelColor:`#07193E`,mainGreen:`#4CCB92`,checkBoxBorder:`#c3c3c3`,iconButtonBG:`#F8F8F8`,iconButtonActive:`#5B5C5C80`,iconButtonHover:`#EFEFEF`,iconButtonDisabled:`#E6EBEB`,iconButtonColor:`#7C7C7C`,backLinkColor:`#073052`,backLinkArrow:`#081C42`,backLinkHover:`#eaedee`,commonLinkColor:`#969FA8`,breadcrumbsBackground:`#FCFCFD`,breadcrumbsBackBorder:`#EAEDEE`,breadcrumbsText:`#969FA8`,actionsListBorder:`#F1F1F1`,disabledActionsColor:`#EBEBEB`,optionTextColor:`#5E5E5E`,modalCloseColor:`#757575`,modalCloseHoverBG:`#EAEAEA`,modalOverlayBG:`#00000050`,bulletBGColor:`#F1F4F4`,placeholder:`#858585`,readBoxTextColor:`#696969`,secondAction:`#005C7E`,secondActionHover:`#1B779A`,secondActionActive:`#07506A`,mainOrange:`#FFBD62`,menuBackground:`linear-gradient(90deg, rgba(2,49,80,1) 0%, rgba(0,39,77,1) 50%, rgba(11,34,69,1) 100%)`,menuDropArrowColor:`#8399AB`,menuDropArrowBackground:`#0A1C3C`,menuSelectedOption:`linear-gradient(90deg, rgba(0,0,0,0) 0%, rgba(20,88,122,1) 100%)`,menuCommonColor:`#CADAE8`,menuColorDivider:`#0F446C`,menuCollapseColor:`#E8E8E8`,menuIconBG:`#06274E`,menuIconBorder:`#052148`,tabBorder:`#EAEAEA`,codeEditorComment:`#6e7781`,codeEditorEntityTag:`#116329`,codeEditorEntity:`#8250df`,codeEditorSublimelinterGutterMark:`#8c959f`,codeEditorConstant:`#0550ae`,codeEditorString:`#0a3069`,codeEditorKeyword:`#cf222e`,codeEditorMarkupBold:`#24292f`,codeEditorRegexp:`#ffaa00`,linkColor:`#2781B0`,mutedText:`#87888d`,disabledOnSwitchBG:`#a9d3c5`,sliderDisabledBG:`#dbdbdb`},A={dark:`#181F2A`,sectionOneBG:`#283140`,defaultFontColor:`#C4C9D0`,bulletColor:`#4B586A`,borderColor:`#8E98A9`,boxBackground:`#283140`,mainGrey:`#A2ADC0`,disabledGrey:`#494A4D`,hoverGrey:`#4B586A`,borderPressedGrey:`#707988`,pressedGrey:`#333D4B`,mainWhite:`#E6ECEC`,disabledWhite:`#B5BCBD`,hoverWhite:`#EFEDED`,pressedWhite:`#C3CBCB`,mainRed:`#FF3958`,hoverRed:`#4B586A`,divisorColor:`#E3E3E3`,disabledBGGrey:`#616A7C`,disabledInnerGrey:`#3A3F4A`,logoLabel:`#A3B7D9`,logoLabelInverse:`#fff`,footerDivider:`#545D6A`,footerColor:`#85B3EE`,promoBG:`#000106`,loaderColor:`#8E98A9`,headerBG:`#212936`,headerBorder:`#191E28`,headerColor:`#E9F5F6`,tooltipBG:`#8E98A9`,tooltipColor:`#161C24`,labelColor:`#A2ADC0`,mainGreen:`#58FAB1`,checkBoxBorder:`#8E98A9`,iconButtonBG:`#A2ADC0`,iconButtonActive:`#707988`,iconButtonHover:`#4B586A`,iconButtonDisabled:`#494A4D`,iconButtonColor:`#283140`,backLinkColor:`#8E98A9`,backLinkArrow:`#A2ADC0`,backLinkHover:`#3A3F4A`,modalCloseColor:`#4B586A`,modalCloseHoverBG:`#4B586A`,modalOverlayBG:`#00010650`,bulletBGColor:`#D5DEEF`,disabledSwitchBG:`#494A4C`,disabledOnSwitchBG:`#a2d7c3`,disabledBulletBG:`#4B586B`,placeholder:`#494A4D`,readBoxTextColor:`#707988`,secondAction:`#1B637E`,secondActionHover:`#297E9D`,secondActionActive:`#145B76`,mainOrange:`#fCCE9D`,menuBackground:`#242D3E`,menuDropArrowColor:`#8E98A9`,menuDropArrowBackground:`#1C2436`,menuSelectedOption:`linear-gradient(90deg, rgba(0,0,0,0) 0%, #1B212C 100%)`,menuCommonColor:`#8E98A9`,menuColorDivider:`#323C4E`,menuCollapseColor:`#E8E8E8`,menuIconBG:`#161F30`,menuIconBorder:`#151E2E`,menuHoverSelectedBorderIcon:`#0E1119`,menuHoverSelectedBG:`#909AAB`,codeEditorComment:`#8b949e`,codeEditorEntityTag:`#7ee787`,codeEditorEntity:`#d2a8ff`,codeEditorSublimelinterGutterMark:`#8E98A9`,codeEditorConstant:`#79c0ff`,codeEditorString:`#a5d6ff`,codeEditorKeyword:`#ff7b72`,codeEditorMarkupBold:`#c9d1d9`,codeEditorRegexp:`#ffd582`,linkColor:`#85B3EE`,mutedText:`#767a80`,disabledSliderBullet:`#939393`},ee={bgColor:k.white,fontColor:k.defaultFontColor,borderColor:k.borderColor,bulletColor:k.bulletColor,logoColor:k.mainRed,logoLabelColor:k.logoLabel,logoLabelInverse:k.logoLabelInverse,logoContrast:k.white,logoContrastInverse:k.logoLabel,loaderColor:k.loaderColor,linkColor:k.linkColor,boxBackground:k.boxBackground,mutedText:k.mutedText,secondaryText:k.mainGrey,signalColors:{main:k.mainBlue,danger:k.mainRed,good:k.mainGreen,info:k.bulletColor,warning:k.mainOrange,disabled:k.disabledGrey,dark:k.defaultFontColor,clear:k.white},buttons:{regular:{enabled:{border:k.mainGrey,text:k.mainGrey,background:`transparent`,iconColor:k.mainGrey},disabled:{border:k.disabledInnerGrey,text:k.disabledInnerGrey,background:k.disabledBGGrey,iconColor:k.disabledInnerGrey},hover:{border:k.mainGrey,text:k.mainGrey,background:k.hoverGrey,iconColor:k.mainGrey},pressed:{border:k.mainGrey,text:k.mainGrey,background:k.pressedGrey,iconColor:k.mainGrey}},callAction:{enabled:{border:k.mainBlue,text:k.white,background:k.mainBlue,iconColor:k.white},disabled:{border:k.actionDisabledGrey,text:k.mainGrey,background:k.actionDisabledGrey,iconColor:k.mainGrey},hover:{border:k.hoverBlue,text:k.white,background:k.hoverBlue,iconColor:k.white},pressed:{border:k.pressedBlue,text:k.white,background:k.pressedBlue,iconColor:k.white}},secondary:{enabled:{border:k.mainRed,text:k.mainRed,background:`transparent`,iconColor:k.mainRed},disabled:{border:k.disabledInnerGrey,text:k.disabledInnerGrey,background:k.disabledBGGrey,iconColor:k.disabledInnerGrey},hover:{border:k.lightRed,text:k.mainRed,background:k.hoverRed,iconColor:k.mainRed},pressed:{border:k.mainRed,text:k.white,background:k.mainRed,iconColor:k.white}},text:{enabled:{border:`transparent`,text:k.mainGrey,background:`transparent`,iconColor:k.mainGrey},disabled:{border:`transparent`,text:k.disabledInnerGrey,background:`transparent`,iconColor:k.disabledInnerGrey},hover:{border:k.hoverGrey,text:k.mainGrey,background:k.hoverGrey,iconColor:k.mainGrey},pressed:{border:k.pressedGrey,text:k.mainGrey,background:k.pressedGrey,iconColor:k.mainGrey}},subAction:{enabled:{border:k.secondAction,text:k.white,background:k.secondAction,iconColor:k.white},disabled:{border:k.actionDisabledGrey,text:k.mainGrey,background:k.actionDisabledGrey,iconColor:k.mainGrey},hover:{border:k.secondActionHover,text:k.white,background:k.secondActionHover,iconColor:k.white},pressed:{border:k.secondActionActive,text:k.white,background:k.secondActionActive,iconColor:k.white}}},login:{formBG:k.sectionOneBG,bgFilter:`none`,promoBG:k.promoBG,promoHeader:k.white,promoText:k.promoBlue,footerElements:k.bulletColor,footerDivider:k.footerDivider},pageHeader:{background:k.headerBG,border:k.headerBorder,color:k.headerColor},tooltip:{background:k.tooltipBG,color:k.tooltipColor},commonInput:{labelColor:k.labelColor},checkbox:{checkBoxBorder:k.checkBoxBorder,checkBoxColor:k.mainGreen,disabledBorder:k.disabledBGGrey,disabledColor:k.disabledBGGrey},iconButton:{buttonBG:k.iconButtonBG,activeBG:k.iconButtonActive,hoverBG:k.iconButtonHover,disabledBG:k.iconButtonDisabled,color:k.iconButtonColor},dataTable:{border:k.borderColor,disabledBorder:k.disabledGrey,disabledBG:k.disabledBGGrey,selected:k.mainBlue,deletedDisabled:k.mainRed,hoverColor:k.hoverGrey},backLink:{color:k.backLinkColor,arrow:k.backLinkArrow,hover:k.backLinkHover},inputBox:{border:k.borderColor,hoverBorder:k.promoBG,color:k.mainBlue,backgroundColor:k.white,error:k.mainRed,placeholderColor:k.placeholder,disabledBorder:k.disabledInnerGrey,disabledBackground:k.disabledGrey,disabledPlaceholder:k.disabledGrey,disabledText:k.disabledInnerGrey},breadcrumbs:{border:k.borderColor,linksColor:k.commonLinkColor,textColor:k.breadcrumbsText,backgroundColor:k.breadcrumbsBackground,backButton:{border:k.breadcrumbsBackBorder,backgroundColor:k.white}},actionsList:{containerBorderColor:k.actionsListBorder,backgroundColor:k.iconButtonBG,disabledOptionsTextColor:k.disabledActionsColor,optionsBorder:k.headerBorder,optionsHoverTextColor:k.defaultFontColor,optionsTextColor:k.optionTextColor,titleColor:k.defaultFontColor},screenTitle:{border:k.borderColor,subtitleColor:k.commonLinkColor,iconColor:k.mainBlue},modalBox:{closeColor:k.modalCloseColor,closeHoverBG:k.modalCloseHoverBG,closeHoverColor:k.defaultFontColor,containerColor:k.white,overlayColor:k.modalOverlayBG,titleColor:k.defaultFontColor,iconColor:{default:k.mainBlue,accept:k.mainGreen,delete:k.mainRed}},switchButton:{bulletBGColor:k.bulletBGColor,bulletBorderColor:k.white,disabledBulletBGColor:k.hoverGrey,disabledBulletBorderColor:k.bulletBGColor,offLabelColor:k.disabledInnerGrey,onLabelColor:k.mainBlue,onBackgroundColor:k.mainGreen,switchBackground:k.hoverGrey,disabledBackground:k.hoverGrey,disabledOnBackground:k.disabledOnSwitchBG},dropdownSelector:{hoverText:k.defaultFontColor,backgroundColor:k.white,hoverBG:k.hoverGrey,selectedBGColor:k.pressedGrey,selectedTextColor:k.defaultFontColor,optionTextColor:k.defaultFontColor,disabledText:k.disabledGrey},readBox:{borderColor:k.headerBorder,backgroundColor:k.boxBackground,textColor:k.readBoxTextColor},menu:{vertical:{background:k.menuBackground,textColor:k.menuCommonColor,hoverSelectedIconBorder:k.white,iconBorderColor:k.menuIconBorder,iconBGColor:k.menuIconBG,dropArrowColor:k.menuDropArrowColor,dropArrowBackground:k.menuDropArrowBackground,hoverSelectedBackground:k.menuSelectedOption,hoverSelectedColor:k.white,notificationColor:k.mainRed,sectionDividerColor:k.menuColorDivider,sectionLabelColor:k.white,menuCollapseColor:k.menuCollapseColor},horizontal:{menuHeaderBackground:k.menuBackground,textColor:k.optionTextColor,hoverSelectedIconBorder:k.defaultFontColor,iconBorderColor:k.menuIconBorder,iconBGColor:k.boxBackground,dropArrowColor:k.menuDropArrowColor,dropArrowBackground:k.boxBackground,hoverSelectedBackground:k.mainBlue,hoverSelectedColor:k.defaultFontColor,notificationColor:k.lightRed,sectionDividerColor:k.menuColorDivider,barBackground:k.boxBackground,dropBackground:k.boxBackground,dropHoverSelectedColor:k.white,noOptionsBar:k.bulletColor}},tabs:{vertical:{buttons:{hoverLabelColor:k.mainBlue,hoverBackground:`transparent`,backgroundColor:k.iconButtonBG,labelColor:k.mainGrey,disabledBackgroundColor:k.disabledBGGrey,disabledColor:k.disabledInnerGrey,selectedBackground:k.headerBorder,selectedLabelColor:k.mainBlue},backgroundColor:k.iconButtonBG,borders:k.tabBorder},horizontal:{buttons:{hoverLabelColor:k.mainBlue,hoverBackground:`transparent`,backgroundColor:`transparent`,labelColor:k.mainGrey,disabledBackgroundColor:`transparent`,disabledColor:k.disabledInnerGrey,selectedBackground:`transparent`,selectedLabelColor:k.mainBlue},backgroundColor:k.boxBackground,selectedIndicatorColor:k.mainBlue}},codeEditor:{backgroundColor:k.white,textColor:k.defaultFontColor,helpToolsBarBG:k.boxBackground,comment:k.codeEditorComment,entityTag:k.codeEditorEntityTag,entity:k.codeEditorEntity,sublimelinterGutterMark:k.codeEditorSublimelinterGutterMark,constant:k.codeEditorConstant,string:k.codeEditorString,keyword:k.codeEditorKeyword,markupBold:k.codeEditorMarkupBold,codeEditorRegexp:k.codeEditorRegexp},tag:{alert:{background:k.mainRed,label:k.white,deleteColor:k.white},default:{background:k.mainBlue,label:k.white,deleteColor:k.white},secondary:{background:k.secondAction,label:k.white,deleteColor:k.white},warn:{background:k.mainOrange,label:k.defaultFontColor,deleteColor:k.defaultFontColor},ok:{background:k.mainGreen,label:k.defaultFontColor,deleteColor:k.defaultFontColor},grey:{background:k.actionDisabledGrey,label:k.defaultFontColor,deleteColor:k.defaultFontColor}},snackbar:{error:{backgroundColor:k.mainRed,labelColor:k.white},default:{backgroundColor:k.mainBlue,labelColor:k.white},success:{backgroundColor:k.mainGreen,labelColor:k.white},warning:{backgroundColor:k.mainOrange,labelColor:k.defaultFontColor}},informativeMessage:{error:{backgroundColor:k.mainRed,borderColor:k.mainRed,textColor:k.white},default:{backgroundColor:k.mainBlue,borderColor:k.mainBlue,textColor:k.white},success:{backgroundColor:k.mainGreen,borderColor:k.mainGreen,textColor:k.white},warning:{backgroundColor:k.mainOrange,borderColor:k.mainOrange,textColor:k.defaultFontColor}},badge:{alert:{backgroundColor:k.mainRed,textColor:k.white},default:{backgroundColor:k.mainBlue,textColor:k.white},secondary:{backgroundColor:k.secondAction,textColor:k.white},warn:{backgroundColor:k.mainOrange,textColor:k.defaultFontColor},ok:{backgroundColor:k.mainGreen,textColor:k.defaultFontColor},grey:{backgroundColor:k.actionDisabledGrey,textColor:k.defaultFontColor}},wizard:{stepsBackground:k.boxBackground,vertical:{stepLabelColor:k.defaultFontColor,selectedStepBG:k.borderColor,selectedStepLabelColor:k.defaultFontColor,disabledLabelColor:k.disabledInnerGrey},modal:{stepLabelColor:k.defaultFontColor,selectedStepBG:k.borderColor,selectedStepLabelColor:k.defaultFontColor,disabledLabelColor:k.disabledGrey}},slider:{bulletBG:k.bulletColor,railBG:k.borderColor,disabledRail:k.sliderDisabledBG,disabledBullet:k.disabledInnerGrey}},te={bgColor:A.dark,fontColor:A.defaultFontColor,borderColor:A.borderColor,bulletColor:A.bulletColor,logoColor:A.mainRed,logoLabelColor:A.logoLabel,logoLabelInverse:A.logoLabelInverse,logoContrast:A.dark,logoContrastInverse:A.dark,loaderColor:A.loaderColor,linkColor:A.linkColor,boxBackground:A.boxBackground,mutedText:A.mutedText,secondaryText:A.mainGrey,signalColors:{main:A.mainGrey,danger:A.mainRed,good:A.mainGreen,info:A.secondActionHover,warning:A.mainOrange,disabled:A.disabledGrey,dark:A.dark,clear:A.mainWhite},buttons:{regular:{enabled:{border:A.mainGrey,text:A.mainGrey,background:`transparent`,iconColor:A.mainGrey},disabled:{border:A.disabledInnerGrey,text:A.disabledInnerGrey,background:A.disabledBGGrey,iconColor:A.disabledInnerGrey},hover:{border:A.mainGrey,text:A.mainGrey,background:A.hoverGrey,iconColor:A.mainGrey},pressed:{border:A.borderPressedGrey,text:A.borderPressedGrey,background:A.pressedGrey,iconColor:A.borderPressedGrey}},callAction:{enabled:{border:A.mainWhite,text:A.dark,background:A.mainWhite,iconColor:A.dark},disabled:{border:A.disabledWhite,text:A.dark,background:A.disabledWhite,iconColor:A.dark},hover:{border:A.hoverWhite,text:A.dark,background:A.hoverWhite,iconColor:A.dark},pressed:{border:A.pressedWhite,text:A.dark,background:A.pressedWhite,iconColor:A.dark}},secondary:{enabled:{border:A.mainRed,text:A.mainRed,background:`transparent`,iconColor:A.mainRed},disabled:{border:A.disabledInnerGrey,text:A.disabledInnerGrey,background:A.disabledBGGrey,iconColor:A.disabledInnerGrey},hover:{border:A.mainRed,text:A.mainRed,background:A.hoverRed,iconColor:A.mainRed},pressed:{border:A.mainRed,text:A.dark,background:A.mainRed,iconColor:A.dark}},text:{enabled:{border:`transparent`,text:A.mainGrey,background:`transparent`,iconColor:A.mainGrey},disabled:{border:`transparent`,text:A.disabledInnerGrey,background:`transparent`,iconColor:A.disabledInnerGrey},hover:{border:A.hoverGrey,text:A.mainGrey,background:A.hoverGrey,iconColor:A.mainGrey},pressed:{border:A.pressedGrey,text:A.borderPressedGrey,background:A.pressedGrey,iconColor:A.borderPressedGrey}},subAction:{enabled:{border:A.secondAction,text:A.mainWhite,background:A.secondAction,iconColor:A.mainWhite},disabled:{border:A.disabledWhite,text:A.dark,background:A.disabledWhite,iconColor:A.dark},hover:{border:A.secondActionHover,text:A.mainWhite,background:A.secondActionHover,iconColor:A.mainWhite},pressed:{border:A.secondActionActive,text:A.mainWhite,background:A.secondActionActive,iconColor:A.mainWhite}}},login:{formBG:A.sectionOneBG,promoBG:A.promoBG,bgFilter:`grayscale(50%)`,promoHeader:A.logoLabel,promoText:A.logoLabel,footerElements:A.footerColor,footerDivider:A.footerDivider},pageHeader:{background:A.headerBG,border:A.headerBorder,color:A.headerColor},tooltip:{background:A.tooltipBG,color:A.tooltipColor},commonInput:{labelColor:A.labelColor},checkbox:{checkBoxBorder:A.checkBoxBorder,checkBoxColor:A.mainGreen,disabledBorder:A.disabledInnerGrey,disabledColor:A.disabledBGGrey},iconButton:{buttonBG:A.iconButtonBG,activeBG:A.iconButtonActive,hoverBG:A.iconButtonHover,disabledBG:A.iconButtonDisabled,color:A.iconButtonColor},dataTable:{border:A.borderColor,disabledBorder:A.disabledGrey,disabledBG:A.disabledBGGrey,selected:A.mainWhite,deletedDisabled:A.mainRed,hoverColor:A.hoverGrey},backLink:{color:A.backLinkColor,arrow:A.backLinkArrow,hover:A.backLinkHover},inputBox:{border:A.borderColor,hoverBorder:A.mainWhite,color:A.mainGrey,backgroundColor:A.dark,error:A.mainRed,placeholderColor:A.placeholder,disabledBorder:A.disabledGrey,disabledBackground:A.disabledInnerGrey,disabledPlaceholder:A.disabledGrey,disabledText:A.disabledBGGrey},breadcrumbs:{border:A.borderColor,linksColor:A.mainGrey,textColor:A.mainGrey,backgroundColor:A.sectionOneBG,backButton:{border:A.borderColor,backgroundColor:A.sectionOneBG}},actionsList:{containerBorderColor:A.bulletColor,backgroundColor:A.sectionOneBG,disabledOptionsTextColor:A.disabledGrey,optionsBorder:A.bulletColor,optionsHoverTextColor:A.hoverWhite,optionsTextColor:A.defaultFontColor,titleColor:A.defaultFontColor},screenTitle:{border:A.borderColor,subtitleColor:A.hoverGrey,iconColor:A.mainGrey},modalBox:{closeColor:A.modalCloseColor,closeHoverBG:A.modalCloseHoverBG,closeHoverColor:A.defaultFontColor,containerColor:A.boxBackground,overlayColor:A.modalOverlayBG,titleColor:A.defaultFontColor,iconColor:{default:A.mainGrey,accept:A.mainGreen,delete:A.mainRed}},switchButton:{bulletBGColor:A.bulletBGColor,bulletBorderColor:A.mainWhite,disabledBulletBGColor:A.disabledBulletBG,disabledBulletBorderColor:A.backLinkArrow,offLabelColor:A.hoverGrey,onLabelColor:A.hoverWhite,onBackgroundColor:A.mainGreen,switchBackground:A.backLinkArrow,disabledBackground:A.disabledSwitchBG,disabledOnBackground:A.disabledOnSwitchBG},dropdownSelector:{hoverText:A.dark,backgroundColor:A.sectionOneBG,hoverBG:A.mainGrey,selectedBGColor:A.bulletColor,selectedTextColor:A.mainWhite,optionTextColor:A.defaultFontColor,disabledText:A.disabledGrey},readBox:{borderColor:A.headerBorder,backgroundColor:A.boxBackground,textColor:A.readBoxTextColor},menu:{vertical:{background:A.menuBackground,textColor:A.menuCommonColor,hoverSelectedIconBorder:A.menuHoverSelectedBorderIcon,iconBorderColor:A.menuIconBorder,iconBGColor:A.menuIconBG,dropArrowColor:A.menuDropArrowColor,dropArrowBackground:A.menuDropArrowBackground,hoverSelectedBackground:A.menuSelectedOption,hoverSelectedColor:A.headerColor,notificationColor:A.mainRed,sectionDividerColor:A.menuColorDivider,sectionLabelColor:A.headerColor,menuCollapseColor:A.menuCollapseColor},horizontal:{menuHeaderBackground:A.menuBackground,textColor:A.defaultFontColor,hoverSelectedIconBorder:A.defaultFontColor,iconBorderColor:A.menuIconBorder,iconBGColor:A.boxBackground,dropArrowColor:A.menuDropArrowColor,dropArrowBackground:A.boxBackground,hoverSelectedBackground:A.mainGrey,hoverSelectedColor:A.headerColor,notificationColor:A.mainRed,sectionDividerColor:A.menuColorDivider,barBackground:A.boxBackground,dropBackground:A.boxBackground,dropHoverSelectedColor:A.dark,noOptionsBar:A.mainGrey}},tabs:{vertical:{buttons:{hoverLabelColor:A.mainWhite,hoverBackground:`transparent`,backgroundColor:A.boxBackground,labelColor:A.defaultFontColor,disabledBackgroundColor:A.disabledBGGrey,disabledColor:A.disabledInnerGrey,selectedBackground:A.iconButtonBG,selectedLabelColor:A.dark},backgroundColor:A.boxBackground,borders:A.borderColor},horizontal:{buttons:{hoverLabelColor:A.mainWhite,hoverBackground:`transparent`,backgroundColor:`transparent`,labelColor:A.defaultFontColor,disabledBackgroundColor:`transparent`,disabledColor:A.disabledInnerGrey,selectedBackground:`transparent`,selectedLabelColor:A.mainWhite},backgroundColor:A.boxBackground,selectedIndicatorColor:A.mainWhite}},codeEditor:{backgroundColor:A.boxBackground,textColor:A.mainWhite,helpToolsBarBG:A.boxBackground,comment:A.codeEditorComment,entityTag:A.codeEditorEntityTag,entity:A.codeEditorEntity,sublimelinterGutterMark:A.codeEditorSublimelinterGutterMark,constant:A.codeEditorConstant,string:A.codeEditorString,keyword:A.codeEditorKeyword,markupBold:A.codeEditorMarkupBold,codeEditorRegexp:A.codeEditorRegexp},tag:{alert:{background:A.mainRed,label:A.mainWhite,deleteColor:A.mainWhite},default:{background:A.mainGrey,label:A.dark,deleteColor:A.dark},secondary:{background:A.secondAction,label:A.mainWhite,deleteColor:A.mainWhite},warn:{background:A.mainOrange,label:A.dark,deleteColor:A.dark},ok:{background:A.mainGreen,label:A.dark,deleteColor:A.dark},grey:{background:A.disabledBGGrey,label:A.mainWhite,deleteColor:A.mainWhite}},snackbar:{error:{backgroundColor:A.mainRed,labelColor:A.mainWhite},default:{backgroundColor:A.mainGrey,labelColor:A.dark},success:{backgroundColor:A.mainGreen,labelColor:A.dark},warning:{backgroundColor:A.mainOrange,labelColor:A.dark}},informativeMessage:{error:{backgroundColor:A.mainRed,borderColor:A.mainRed,textColor:A.mainWhite},default:{backgroundColor:A.mainGrey,borderColor:A.mainGrey,textColor:A.dark},success:{backgroundColor:A.mainGreen,borderColor:A.mainGreen,textColor:A.dark},warning:{backgroundColor:A.mainOrange,borderColor:A.mainOrange,textColor:A.dark}},badge:{alert:{backgroundColor:A.mainRed,textColor:A.mainWhite},default:{backgroundColor:A.mainGrey,textColor:A.dark},secondary:{backgroundColor:A.secondAction,textColor:A.mainWhite},warn:{backgroundColor:A.mainOrange,textColor:A.dark},ok:{backgroundColor:A.mainGreen,textColor:A.dark},grey:{backgroundColor:A.disabledBGGrey,textColor:A.mainWhite}},wizard:{stepsBackground:A.boxBackground,vertical:{stepLabelColor:A.defaultFontColor,selectedStepBG:A.borderColor,selectedStepLabelColor:A.dark,disabledLabelColor:A.disabledGrey},modal:{stepLabelColor:A.defaultFontColor,selectedStepBG:A.borderColor,selectedStepLabelColor:A.mainWhite,disabledLabelColor:A.disabledGrey}},slider:{bulletBG:A.defaultFontColor,railBG:A.footerDivider,disabledRail:A.disabledSwitchBG,disabledBullet:A.disabledSliderBullet}},j=r(),ne=({darkMode:e=!1,children:t,customTheme:n})=>{let r=e?te:ee;return n&&(r=n),(0,j.jsx)(o,{theme:r,children:t})},re=c`
    ${({theme:e})=>`
    /* Main Page styling */
    
    *, *::before, *::after {
       box-sizing: inherit;
       outline:0;
    }
    
    html {
        box-sizing: border-box;
        -webkit-text-size-adjust: 100%;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
    
    body {
        background-color: ${(0,S.default)(e,`bgColor`,k.white)};
        color: ${(0,S.default)(e,`fontColor`,k.defaultFontColor)};
        height: 100vh;
        width: 100vw;
        font-family: var(--font-sans, system-ui, sans-serif);
        margin: 0;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        font-weight: 400;
        font-size: var(--fs-body, 13px);
        line-height: var(--lh-body, 20px);
        transition: background-color 0s
    }
    
    fieldset, section {
        border: 1px solid ${(0,S.default)(e,`borderColor`,k.borderColor)};
        border-radius: 3px;
        background-color: transparent;
        padding: 25px;
    }
    
    a {
        color: ${(0,S.default)(e,`linkColor`,k.linkColor)};
    }
    
    a { text-decoration: none; }
    a:hover {
        text-decoration: underline;
        color: ${(0,S.default)(e,`linkColor`,k.linkColor)};
    }
    
    hr {
        border-top: 0;
        border-left: 0;
        border-right: 0;
        border-color: ${(0,S.default)(e,`borderColor`,k.borderColor)};
        background-color: transparent;
    }
    
    ul {
        padding-left: 20px;
        list-style: none;
        
        li:not([class*="Mui"])::before {
          content: '￭';
          color: ${(0,S.default)(e,`bulletColor`,k.bulletColor)};
          font-size: 20px;
          display: inline-block;
          width: 1em;
          margin-left: -1em;
        }
        
        ul {
          list-style: none;
          li:not([class*="Mui"])::before {
            content: "￮";
            color: ${(0,S.default)(e,`bulletColor`,k.bulletColor)},
            font-size: 20px;
            display: inline-block;
            width: 1em;
            margin-left: -1em;
          }
        }
      }
      
    button:active, button:focus, input: active, input:focus {
        outline: revert;
    }
    
    .min-icon {
        width: 26px;
    }
    
    #root: {
        height: 100%;
        width: 100%;
        display: flex;
        flex-flow: column;
        align-items: stretch;
      }
    
    #preload {
      display: none;
    }
    
    #loader-block {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100vh;
      justify-content: center;
      align-items: center;
    }
    
    .muted {
        color: ${(0,S.default)(e,`mutedText`,k.mutedText)};
    }
    `}
`,M={normal:400,semibold:550,bold:700},N={display:{size:28,line:34,compactSize:24,compactLine:30,weight:M.bold},title:{size:16,line:22,compactSize:15,compactLine:20,weight:M.semibold},subtitle:{size:14,line:20,compactSize:13,compactLine:18,weight:M.semibold},body:{size:13,line:20,compactSize:12,compactLine:18,weight:M.normal},caption:{size:12,line:16,compactSize:11,compactLine:14,weight:M.normal},micro:{size:11,line:14,compactSize:10,compactLine:12,weight:M.normal}},ie={default:{controlHeight:36,controlPadding:12,rowPadding:8,gap:8,iconSize:16},compact:{controlHeight:28,controlPadding:10,rowPadding:6,gap:4,iconSize:14}},P=(e,{compact:t=!1,weight:n}={})=>{let r=N[e],i=t?`-compact`:``;return l`
    font-family: var(--font-sans);
    font-size: var(
      --fs-${e}${i},
      ${t?r.compactSize:r.size}px
    );
    line-height: var(
      --lh-${e}${i},
      ${t?r.compactLine:r.line}px
    );
    font-weight: ${n?M[n]:r.weight};
  `},ae=(0,u.createContext)(`default`),oe=e=>{let t={};for(let[n,r]of Object.entries(ie[e])){let e=n.replace(/[A-Z]/g,e=>`-${e.toLowerCase()}`);t[`--${e}`]=`${r}px`}for(let[n,r]of Object.entries(N))t[`--fs-${n}`]=`${e===`compact`?r.compactSize:r.size}px`,t[`--lh-${n}`]=`${e===`compact`?r.compactLine:r.line}px`;return t},se=s.div`
  display: contents;
  ${({$density:e})=>oe(e)}
`,ce=({density:e=`default`,children:t})=>(0,j.jsx)(ae.Provider,{value:e,children:(0,j.jsx)(se,{$density:e,"data-density":e,children:t})}),F=()=>{let e=(0,u.useContext)(ae),t=e===`compact`;return{density:e,compact:t,...ie[e],type:Object.fromEntries(Object.keys(N).map(e=>[e,P(e,{compact:t})]))}},I=(e,t=0)=>Math.max(1,Math.min(Math.round(e+t),8)),le=e=>e>=7?`--muted-foreground-elevated`:`--muted-foreground-base`,ue=(e,t=!1)=>({"--muted-foreground":t?`var(--surface-1, #fafafa)`:`var(${le(e)}, #737373)`,"--silo-text-secondary":`var(--muted-foreground)`,"--silo-text-muted":`var(--muted-foreground)`}),de=(0,u.createContext)(1),fe=()=>(0,u.useContext)(de),L=({level:e,children:t})=>(0,j.jsx)(de.Provider,{value:I(e),children:t}),pe=s.div`
  ${({$density:e})=>oe(e)}
  ${({$level:e,$inverted:t})=>ue(e,t)}
  background: ${({$level:e,$inverted:t})=>t?`var(--foreground, #171717)`:`var(--surface-${e}, #fff)`};
  color: ${({$inverted:e})=>e?`var(--surface-1, #fafafa)`:`var(--foreground, #171717)`};
  box-shadow: ${({$shadow:e})=>`var(--shadow-${e}, none)`};
`,R=(0,u.forwardRef)(({offset:e=2,shadowLevel:t,inverted:n=!1,children:r,...i},a)=>{let o=I(fe(),e),{density:s}=F();return(0,j.jsx)(L,{level:o,children:(0,j.jsx)(pe,{...i,ref:a,"data-surface-level":o,$level:o,$shadow:I(t??o),$inverted:n,$density:s,children:r})})});R.displayName=`Elevated`;var me=(0,u.createContext)(!0),z=()=>(0,u.useContext)(me),he=({open:e,children:t})=>{let n=z();return(0,j.jsx)(me.Provider,{value:n&&e,children:t})},B=0,V=new Set,ge=e=>{e!==B&&(B=e,V.forEach(e=>e()))},_e=e=>(V.add(e),()=>{V.delete(e)}),H=new Set,ve=e=>{(0,u.useLayoutEffect)(()=>{if(!e)return;let t=Symbol();return H.add(t),V.forEach(e=>e()),()=>{H.delete(t),V.forEach(e=>e())}},[e])},ye=()=>B>0||H.size>0,be=()=>(0,u.useSyncExternalStore)(_e,ye,()=>!1),xe=0,Se=s.span`
  display: inline-flex;
  position: relative;
  max-width: 100%;
`,Ce=s(R)`
  ${P(`caption`)}
  position: fixed;
  z-index: 10001;
  width: max-content;
  max-width: min(350px, calc(100vw - 16px));
  padding: 4px 8px;
  border-radius: 8px;
  pointer-events: ${({$interactive:e})=>e?`auto`:`none`};
  overflow-wrap: anywhere;
  // An invisible 8px bridge keeps the bubble reachable across its side offset.
  &::before {
    content: "";
    position: absolute;
    ${({$side:e})=>e===`top`?`left: 0; right: 0; top: 100%; height: 8px;`:e===`bottom`?`left: 0; right: 0; bottom: 100%; height: 8px;`:e===`left`?`top: 0; bottom: 0; left: 100%; width: 8px;`:`top: 0; bottom: 0; right: 100%; width: 8px;`}
  }
  opacity: ${({$shown:e})=>+!!e};
  transform: ${({$shown:e,$side:t})=>e?`translate(0,0)`:t===`top`?`translateY(4px)`:t===`bottom`?`translateY(-4px)`:t===`left`?`translateX(4px)`:`translateX(-4px)`};
  transition:
    opacity
      ${({$shown:e})=>e?`var(--dur-fast,80ms) var(--ease-fast,ease-out)`:`var(--dur-fast-exit,60ms) var(--ease-exit,ease-in)`},
    transform
      ${({$shown:e})=>e?`var(--dur-fast,80ms) var(--ease-fast,ease-out)`:`var(--dur-fast-exit,60ms) var(--ease-exit,ease-in)`};
  @media (prefers-reduced-motion: reduce) {
    transform: none;
    transition-property: opacity;
  }
`,U=({children:e,tooltip:t,errorProps:n,placement:r=`bottom`,wrapperProps:i})=>{let a=z(),o=e.props[`aria-expanded`]===!0,s=(0,u.useId)(),c=(0,u.useRef)(null),l=(0,u.useRef)(null),f=(0,u.useRef)(),[p,m]=(0,u.useState)(!1),[h,g]=(0,u.useState)(!1),[_,v]=(0,u.useState)(!1),[y,b]=(0,u.useState)({left:0,top:0,side:r}),x=(0,u.useRef)(!1),S=(0,u.useRef)(!1),C=(e=!1)=>{o||(clearTimeout(f.current),f.current=setTimeout(()=>{g(!0),m(!0)},e||Date.now()<xe?0:200))},w=(e=!1)=>{(e||!x.current&&!S.current)&&(clearTimeout(f.current),p&&(xe=Date.now()+300),m(!1))};if((0,u.useEffect)(()=>()=>clearTimeout(f.current),[]),(0,u.useEffect)(()=>{(!a||o)&&(clearTimeout(f.current),x.current=!1,S.current=!1,m(!1))},[a,o]),(0,u.useEffect)(()=>{if(!h)return;if(p){let e=requestAnimationFrame(()=>v(!0));return()=>cancelAnimationFrame(e)}v(!1);let e=setTimeout(()=>g(!1),60);return()=>clearTimeout(e)},[p,h]),(0,u.useLayoutEffect)(()=>{if(!h||o||!c.current||!l.current)return;let e=0,t,n=()=>{if(!c.current||!l.current)return;let i=c.current.getBoundingClientRect(),a=l.current.getBoundingClientRect(),o=r;o===`top`&&i.top<a.height+16&&(o=`bottom`),o===`bottom`&&i.bottom+a.height+16>innerHeight&&(o=`top`),o===`left`&&i.left<a.width+16&&(o=`right`),o===`right`&&i.right+a.width+16>innerWidth&&(o=`left`);let s=o===`left`?i.left-a.width-8:o===`right`?i.right+8:i.left+(i.width-a.width)/2,u=o===`top`?i.top-a.height-8:o===`bottom`?i.bottom+8:i.top+(i.height-a.height)/2,d=Math.max(8,Math.min(s,innerWidth-a.width-8)),f=Math.max(8,Math.min(u,innerHeight-a.height-8)),p=l.current.offsetParent;if(p instanceof HTMLElement){let e=p.getBoundingClientRect(),t=e.width/p.offsetWidth||1,n=e.height/p.offsetHeight||1;d=(d-e.left)/t-p.clientLeft+p.scrollLeft,f=(f-e.top)/n-p.clientTop+p.scrollTop}let m={left:d,top:f,side:o};(t?.left!==m.left||t?.top!==m.top||t?.side!==m.side)&&(t=m,b(m)),e=requestAnimationFrame(n)};return n(),()=>cancelAnimationFrame(e)},[h,o,r,t]),t===``||t==null)return n?(0,u.cloneElement)(e,n):e;let T=e.type===u.Fragment?e:(0,u.cloneElement)(e,{...n,"aria-describedby":[e.props[`aria-describedby`],s].filter(Boolean).join(` `)});return(0,j.jsxs)(Se,{ref:c,...i,onPointerEnter:e=>{x.current=!0,C(),i?.onPointerEnter?.(e)},onPointerLeave:e=>{x.current=!1,w(),i?.onPointerLeave?.(e)},onFocus:e=>{S.current=!0,C(!0),i?.onFocus?.(e)},onBlur:e=>{e.currentTarget.contains(e.relatedTarget)||(S.current=!1,w()),i?.onBlur?.(e)},onKeyDown:e=>{e.key===`Escape`&&p&&(w(!0),e.stopPropagation()),i?.onKeyDown?.(e)},children:[T,(0,j.jsx)(`span`,{id:s,hidden:!0,children:t}),h&&!o&&(0,d.createPortal)((0,j.jsx)(Ce,{ref:l,onPointerEnter:()=>{x.current=!0,C(!0)},onPointerLeave:()=>{x.current=!1,w()},inverted:!0,offset:2,shadowLevel:3,"aria-hidden":!a||!p||void 0,role:`tooltip`,$shown:_,$interactive:a,$side:y.side,style:{left:y.left,top:y.top},children:t}),c.current?.closest(`dialog`)||c.current?.closest(`[role="dialog"], [role="alertdialog"]`)||c.current?.closest(`main, nav, aside, [role="main"], [role="navigation"], [role="complementary"], [role="region"][aria-label], [role="region"][aria-labelledby], section[aria-label], section[aria-labelledby]`)||document.body)]})},we=({children:e,reason:t,fullWidth:n})=>{let r=(0,u.useId)();return(0,j.jsx)(U,{tooltip:t,wrapperProps:{tabIndex:0,role:`group`,"aria-label":e.props[`aria-label`],"aria-describedby":r,style:{width:n?`100%`:void 0,cursor:`not-allowed`,pointerEvents:`auto`}},children:(0,j.jsxs)(j.Fragment,{children:[(0,u.cloneElement)(e,{style:{...e.props.style,pointerEvents:`none`}}),(0,j.jsx)(`span`,{id:r,hidden:!0,children:t})]})})},Te=e=>({regular:`outline`,callAction:`primary`,subAction:`secondary`,text:`ghost`})[e]||e||`outline`,Ee=i`to { transform: rotate(360deg); }`,De=s.button`
  ${({$compact:e})=>P(`body`,{compact:e,weight:`semibold`})}
  position: relative;
  isolation: isolate;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  flex-shrink: 0;
  height: ${({$compact:e})=>e?28:36}px;
  @media (pointer: coarse) { min-height: 40px; }
  width: ${({$full:e})=>e?`100%`:`auto`};
  border: 0;
  border-radius: 8px;
  margin: 0;
  padding: 0 ${({$compact:e})=>e?12:16}px;
  gap: ${({$compact:e})=>e?4:8}px;
  cursor: pointer;
  text-transform: none;
  letter-spacing: normal;
  white-space: nowrap;
  background: transparent;
  --button-fill: var(--tint);
  --button-hover: var(--tint-hover);
  --button-press: var(--tint);
  color: var(--foreground);
  ${({$variant:e})=>e===`primary`&&l`
      --button-fill: var(--foreground);
      --button-hover: color-mix(
        in oklab,
        var(--foreground) 90%,
        var(--surface-1)
      );
      --button-press: color-mix(
        in oklab,
        var(--foreground) 80%,
        var(--surface-1)
      );
      color: var(--surface-1);
    `}
  ${({$variant:e})=>e===`danger`&&l`
      color: var(--destructive-text);
    `}
  ${({$variant:e})=>e===`danger-fill`&&l`
      --button-fill: var(--destructive-text);
      --button-hover: var(--destructive-text);
      --button-press: var(--destructive-text);
      color: var(--surface-1);
    `}
  ${({$variant:e})=>[`ghost`,`outline`].includes(e)&&l`
      --button-fill: transparent;
      --button-hover: var(--hover);
      --button-press: var(--active);
    `}
  ${({$icon:e,$side:t,$compact:n})=>e&&(t===`start`?l`
          padding-left: ${n?8:12}px;
        `:l`
          padding-right: ${n?8:12}px;
        `)}
  .button-surface {
    position: absolute;
    z-index: -1;
    inset: 1px;
    border-radius: 7px;
    pointer-events: none;
    background: var(--button-fill);
    box-shadow: 0 0 0 1px var(--button-fill);
    transition:
      box-shadow 180ms cubic-bezier(0.23, 1, 0.32, 1),
      background-color var(--dur-fast, 80ms) ease;
    ${({$variant:e})=>e===`outline`&&l`
        box-shadow:
          0 0 0 1px var(--border),
          inset 0 0 0 0 var(--border);
      `}
  }
  &:hover:not(:disabled) .button-surface {
    background: var(--button-hover);
    box-shadow: 0 0 0 1px var(--button-hover);
  }
  ${({$variant:e})=>e===`outline`&&l`
      &:hover:not(:disabled) .button-surface {
        box-shadow:
          0 0 0 1px var(--border),
          inset 0 0 0 0 var(--border);
      }
    `}
  ${({$held:e})=>e&&l`
      .button-surface {
        background: var(--button-press);
      }
    `}
  &:active:not(:disabled) .button-surface {
    background: var(--button-press);
    box-shadow: 0 0 0 0 var(--button-press);
    transition-duration: var(--dur-fast, 80ms);
  }
  ${({$variant:e})=>e===`outline`&&l`
      &:active:not(:disabled) .button-surface {
        box-shadow:
          0 0 0 0 var(--border),
          inset 0 0 0 1px var(--border);
      }
    `}
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }
  &:disabled {
    cursor: not-allowed;
    color: var(--foreground);
    --button-fill: var(--muted);
  }
  .button-content {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: inherit;
    opacity: ${({$loading:e})=>+!e};
  }
  .button-label {
    white-space: nowrap;
  }
  .buttonIcon {
    display: inline-flex;
  }
  .buttonIcon svg {
    width: ${({$compact:e})=>e?14:16}px;
    height: ${({$compact:e})=>e?14:16}px;
    fill: currentColor;
    color: inherit;
  }
  .button-spinner {
    position: absolute;
    width: 16px;
    height: 16px;
    border: 1.5px solid currentColor;
    border-right-color: transparent;
    border-radius: 50%;
    animation: ${Ee} 800ms linear infinite;
  }
  @media (max-width: 767px) {
    ${({$collapse:e,$icon:t})=>e&&t&&l`
        .button-label {
          display: none;
        }
        padding: 0 12px;
      `}
  }
  @media (prefers-reduced-motion: reduce) {
    .button-surface {
      transition: background-color var(--dur-fast, 80ms) ease;
    }
    .button-spinner {
      animation: none;
    }
  }
  ${({$sx:e})=>e}
`,W=(0,u.forwardRef)(({label:e,variant:t=`regular`,icon:n,iconLocation:r=`end`,disabled:i,disabledReason:a,fullWidth:o=!1,collapseOnSmall:s=!0,children:c,className:l,sx:u,loading:d=!1,active:f=!1,...p},m)=>{let{compact:h}=F(),g=(0,j.jsxs)(De,{ref:m,...p,$variant:Te(t),$compact:h,$full:o,$collapse:s,$icon:!!n,$side:r,$loading:d,$held:f,$sx:u,disabled:i||d,"aria-busy":d||void 0,"aria-label":p[`aria-label`]||e,className:`${l||``} button-${t}`,children:[(0,j.jsx)(`span`,{className:`button-surface`,"aria-hidden":`true`}),(0,j.jsxs)(`span`,{className:`button-content`,children:[n&&r===`start`&&(0,j.jsx)(`span`,{className:`buttonIcon`,children:n}),(0,j.jsxs)(`span`,{className:`button-label`,children:[c,c&&e?` `:``,e]}),n&&r===`end`&&(0,j.jsx)(`span`,{className:`buttonIcon`,children:n})]}),d&&(0,j.jsx)(`span`,{className:`button-spinner`,"aria-hidden":`true`})]});return i&&a?(0,j.jsx)(we,{reason:a,fullWidth:o,children:g}):g});W.displayName=`Button`;var Oe=s.div(e=>{let t={boxSizing:`border-box`};if(e.container)t={display:`flex`,flexWrap:e.wrap||`wrap`,flexDirection:e.direction||`row`,columnGap:`${e.columnSpacing}px`||0,rowGap:`${e.rowSpacing}px`||0,boxSizing:`content-box`};else if(e.item){let n=Object.keys(C);n.forEach((r,i)=>{let a=(0,S.default)(e,r,!1);if(a){let o={};if(typeof a==`number`&&(o={flexBasis:T((0,S.default)(e,r,12)),width:T((0,S.default)(e,r,12))}),a===`hidden`){let e=``;n[i+1]&&(e=`and (max-width:  ${(0,S.default)(C,n[i+1],0)}px)`),t={...t,[`@media (min-width: ${(0,S.default)(C,r,0)}px) ${e}`]:{display:`none`}}}t={...t,[`@media (min-width: ${(0,S.default)(C,r,0)}px)`]:{flexGrow:`1`,...o}}}})}return{minWidth:0,...t,...e.sx}}),G=e=>(0,j.jsx)(Oe,{...e,children:e.children}),ke=i`0% {
                                      transform: translate(139.785027px, 140.086989px) rotate(45.236493deg);
                                      animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
                                    }
                                      10% {
                                        transform: translate(139.785027px, 140.086989px) rotate(-197.740907deg);
                                        animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
                                      }
                                      20% {
                                        transform: translate(139.785027px, 140.086989px) rotate(-108.6deg);
                                        animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
                                      }
                                      30% {
                                        transform: translate(139.785027px, 140.086989px) rotate(-17.484014deg);
                                        animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
                                      }
                                      33.333333% {
                                        transform: translate(139.785027px, 140.086989px) rotate(-17.48deg);
                                        animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
                                      }
                                      43.333333% {
                                        transform: translate(139.785027px, 140.086989px) rotate(160.887995deg);
                                      }
                                      100% {
                                        transform: translate(139.785027px, 140.086989px) rotate(160.887995deg);
                                      }`,Ae=i`
  0% {
    transform: scale(1, 0.995019);
  }
  33.333333% {
    transform: scale(1, 0.995019);
    animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
  }
  43.333333% {
    transform: scale(0.101121, 0.102033);
    animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
  }
  50% {
    transform: scale(0.1, 0.1);
    animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1);
  }
  60% {
    transform: scale(1, 1);
  }
  100% {
    transform: scale(1, 1);
  }
`,je=i`
  0% {
    opacity: 1;
  }
  6.666667% {
    opacity: 1;
  }
  10% {
    opacity: 0;
  }
  13.333333% {
    opacity: 0;
  }
  20% {
    opacity: 1;
  }
  30% {
    opacity: 1;
  }
  36.666667% {
    opacity: 1;
  }
  40% {
    opacity: 0;
  }
  100% {
    opacity: 0;
  }
`,Me=i`
  0% {
    d: path("M85.4,249.8C109.08,255.3,133.72,257.37,157.65,252.14C181.65,246.89,202.95,233.55,219.27,215.35C227.84,205.79,213.74,191.6,205.13,201.21C190.9,217.1,173.27,228.26,152.34,232.86C132.03,237.32,110.79,235.19,90.73,230.52C78.19,227.61,72.85,246.88,85.4,249.8C85.4,249.8,85.4,249.8,85.4,249.8Z");
  }
  10% {
    d: path("M85.4,249.8C85.4,249.8,85.399999,249.800001,85.399999,249.800001C85.399999,249.800001,85.4,249.800002,85.4,249.800002C85.4,249.800002,90.484102,251.966034,95.043213,248.269966C100.484052,243.859082,98.694728,236.722769,97.073675,234.469349C95.517658,232.306335,94.559418,231.751273,90.73,230.52C78.19,227.61,72.85,246.88,85.4,249.8C85.4,249.8,85.4,249.8,85.4,249.8Z");
  }
  20% {
    d: path("M85.4,249.8C85.4,249.8,85.399999,249.800001,85.399999,249.800001C85.399999,249.800001,85.4,249.800002,85.4,249.800002C85.4,249.800002,90.484102,251.966034,95.043213,248.269966C100.484052,243.859082,98.694728,236.722769,97.073675,234.469349C95.517658,232.306335,94.559418,231.751273,90.73,230.52C78.19,227.61,72.85,246.88,85.4,249.8C85.4,249.8,85.4,249.8,85.4,249.8Z");
  }
  30% {
    d: path("M85.4,249.8C109.08,255.3,133.72,257.37,157.65,252.14C181.65,246.89,202.95,233.55,219.27,215.35C227.84,205.79,213.74,191.6,205.13,201.21C190.9,217.1,173.27,228.26,152.34,232.86C132.03,237.32,110.79,235.19,90.73,230.52C78.19,227.61,72.85,246.88,85.4,249.8C85.4,249.8,85.4,249.8,85.4,249.8Z");
  }
  33.333333% {
    d: path("M85.4,249.8C109.08,255.3,133.72,257.37,157.65,252.14C181.65,246.89,202.95,233.55,219.27,215.35C227.84,205.79,213.74,191.6,205.13,201.21C190.9,217.1,173.27,228.26,152.34,232.86C132.03,237.32,110.79,235.19,90.73,230.52C78.19,227.61,72.85,246.88,85.4,249.8C85.4,249.8,85.4,249.8,85.4,249.8Z");
  }
  43.333333% {
    d: path("M84.281285,246.076032C107.50521,254.051555,133.72,257.37,157.65,252.14C181.65,246.89,202.95,233.55,219.27,215.35C227.84,205.79,213.74,191.6,205.13,201.21C190.9,217.1,173.27,228.26,152.34,232.86C132.03,237.32,86.465691,239.82846,53.85604,207.193233C41.31604,204.283233,32.439249,213.928672,40.474905,219.54755C40.474905,219.54755,61.310295,238.187372,84.281285,246.076032Z");
  }
  100% {
    d: path("M84.281285,246.076032C107.50521,254.051555,133.72,257.37,157.65,252.14C181.65,246.89,202.95,233.55,219.27,215.35C227.84,205.79,213.74,191.6,205.13,201.21C190.9,217.1,173.27,228.26,152.34,232.86C132.03,237.32,86.465691,239.82846,53.85604,207.193233C41.31604,204.283233,32.439249,213.928672,40.474905,219.54755C40.474905,219.54755,61.310295,238.187372,84.281285,246.076032Z");
  }
`,Ne=i`
  0% {
    d: path("M249.74,169.63C255.24,145.95,257.31,121.31,252.08,97.38C246.83,73.38,233.49,52.08,215.29,35.76C205.73,27.19,191.54,41.29,201.15,49.9C217.04,64.13,228.2,81.76,232.8,102.69C237.26,123,235.13,144.24,230.46,164.3C227.54,176.84,246.82,182.18,249.74,169.63C249.74,169.63,249.74,169.63,249.74,169.63Z");
  }
  10% {
    d: path("M250.887564,168.08137C250.887564,168.081368,250.887563,168.081375,250.887563,168.081375C250.887563,168.081375,253.7831,157.676613,244.778825,154.781475C235.762034,151.882313,232.694053,158.881918,231.752888,162.486547C231.017121,165.304508,231.564293,168.517464,232.231509,169.666243C233.407087,171.690293,235.517449,173.828597,238.467701,174.606956C241.339242,175.364549,245.542656,175.427978,248.770823,172.704057C248.770823,172.704057,250.400569,171.202441,250.887564,168.08137Z");
  }
  20% {
    d: path("M250.887564,168.08137C250.887564,168.081368,250.887563,168.081375,250.887563,168.081375C250.887563,168.081375,253.7831,157.676613,244.778825,154.781475C235.762034,151.882313,232.694053,158.881918,231.752888,162.486547C231.017121,165.304508,231.564293,168.517464,232.231509,169.666243C233.407087,171.690293,235.517449,173.828597,238.467701,174.606956C241.339242,175.364549,245.542656,175.427978,248.770823,172.704057C248.770823,172.704057,250.400569,171.202441,250.887564,168.08137Z");
  }
  30% {
    d: path("M249.74,169.63C255.24,145.95,257.31,121.31,252.08,97.38C246.83,73.38,233.49,52.08,215.29,35.76C205.73,27.19,191.54,41.29,201.15,49.9C217.04,64.13,228.2,81.76,232.8,102.69C237.26,123,235.13,144.24,230.46,164.3C227.54,176.84,246.82,182.18,249.74,169.63C249.74,169.63,249.74,169.63,249.74,169.63Z");
  }
  33.333333% {
    d: path("M249.74,169.63C255.24,145.95,257.31,121.31,252.08,97.38C246.83,73.38,233.49,52.08,215.29,35.76C205.73,27.19,191.54,41.29,201.15,49.9C217.04,64.13,228.2,81.76,232.8,102.69C237.26,123,235.13,144.24,230.46,164.3C227.54,176.84,246.82,182.18,249.74,169.63C249.74,169.63,249.74,169.63,249.74,169.63Z");
  }
  43.333333% {
    d: path("M241.985702,180.287452C255.201364,145.393106,257.31,121.31,252.08,97.38C246.83,73.38,233.49,52.08,215.29,35.76C205.73,27.19,189.760952,38.146938,199.370952,46.756938C229.706596,66.855753,234.126292,101.544407,234.194759,127.574104C235.798839,155.047874,216.192342,185.901625,205.13,201.21C199.980012,208.336696,214.039151,220.128533,219.270001,215.35C219.270001,215.35,237.299554,192.660656,241.985702,180.287452Z");
  }
  100% {
    d: path("M241.985702,180.287452C255.201364,145.393106,257.31,121.31,252.08,97.38C246.83,73.38,233.49,52.08,215.29,35.76C205.73,27.19,189.760952,38.146938,199.370952,46.756938C229.706596,66.855753,234.126292,101.544407,234.194759,127.574104C235.798839,155.047874,216.192342,185.901625,205.13,201.21C199.980012,208.336696,214.039151,220.128533,219.270001,215.35C219.270001,215.35,237.299554,192.660656,241.985702,180.287452Z");
  }
`,Pe=i`
  0% {
    d: path("M171.68,7.71C148.17,1.51,123.61,-1.28,99.53,3.25C75.39,7.79,53.7,20.49,36.85,38.21C28.01,47.52,41.68,62.11,50.57,52.76C65.27,37.3,83.22,26.66,104.27,22.68C124.7,18.82,145.87,21.58,165.79,26.83C178.22,30.11,184.14,11,171.68,7.71C171.68,7.71,171.68,7.71,171.68,7.71Z");
  }
  10% {
    d: path("M171.58686,7.8192C164.834536,7.661923,162.882928,13.414575,162.613915,14.669774C162.613914,14.669774,161.858025,17.37084,162.366976,18.743708C162.782522,19.864622,163.527502,21.022768,164.723558,21.957074C165.842173,22.830886,168.859974,24.254302,168.859974,24.254302C168.859974,24.254302,168.859968,24.254306,168.859967,24.254304C181.289967,27.534304,184.046866,11.109212,171.586866,7.819212C171.586866,7.819212,171.58686,7.8192,171.58686,7.8192Z");
  }
  20% {
    d: path("M171.58686,7.8192C164.834536,7.661923,162.882928,13.414575,162.613915,14.669774C162.613914,14.669774,161.858025,17.37084,162.366976,18.743708C162.782522,19.864622,163.527502,21.022768,164.723558,21.957074C165.842173,22.830886,168.859974,24.254302,168.859974,24.254302C168.859974,24.254302,168.859968,24.254306,168.859967,24.254304C181.289967,27.534304,184.046866,11.109212,171.586866,7.819212C171.586866,7.819212,171.58686,7.8192,171.58686,7.8192Z");
  }
  30% {
    d: path("M171.68,7.71C148.17,1.51,123.61,-1.28,99.53,3.25C75.39,7.79,53.7,20.49,36.85,38.21C28.01,47.52,41.68,62.11,50.57,52.76C65.27,37.3,83.22,26.66,104.27,22.68C124.7,18.82,145.87,21.58,165.79,26.83C178.22,30.11,184.14,11,171.68,7.71C171.68,7.71,171.68,7.71,171.68,7.71Z");
  }
  33.333333% {
    d: path("M171.68,7.71C148.17,1.51,123.61,-1.28,99.53,3.25C75.39,7.79,53.7,20.49,36.85,38.21C28.01,47.52,41.68,62.11,50.57,52.76C65.27,37.3,83.22,26.66,104.27,22.68C124.7,18.82,145.87,21.58,165.79,26.83C178.22,30.11,184.14,11,171.68,7.71C171.68,7.71,171.68,7.71,171.68,7.71Z");
  }
  43.333333% {
    d: path("M154.601291,1.547478C127.732134,-3.659063,101.676041,0.16217,89.834975,4.047622C73.018778,9.565582,43.015709,29.967817,36.85,38.21C28.01,47.52,41.568561,62.002759,50.57,52.76C67.005248,35.884138,77.788003,22.937369,100.935291,18.024709C148.028227,8.029949,175.904245,24.591662,199.370952,46.756938C210.775532,51.88401,219.463487,39.878796,215.289997,35.759998C189.664787,10.470596,154.601291,1.547478,154.601291,1.547478Z");
  }
  100% {
    d: path("M154.601291,1.547478C127.732134,-3.659063,101.676041,0.16217,89.834975,4.047622C73.018778,9.565582,43.015709,29.967817,36.85,38.21C28.01,47.52,41.568561,62.002759,50.57,52.76C67.005248,35.884138,77.788003,22.937369,100.935291,18.024709C148.028227,8.029949,175.904245,24.591662,199.370952,46.756938C210.775532,51.88401,219.463487,39.878796,215.289997,35.759998C189.664787,10.470596,154.601291,1.547478,154.601291,1.547478Z");
  }
`,Fe=i`
  0% {
    d: path("M5.83,85.46C0.33,109.14,-1.74,133.78,3.49,157.71C8.74,181.71,22.08,203.01,40.28,219.33C49.84,227.9,64.03,213.8,54.42,205.19C38.53,190.96,27.37,173.33,22.77,152.4C18.31,132.09,20.44,110.85,25.11,90.79C28.03,78.25,8.75,72.91,5.83,85.46L5.83,85.46Z");
  }
  3.333333% {
    d: path("M4.90273,88.748028C1.236063,104.534694,0.694614,122.375568,4.181281,138.328902C7.119767,155.82704,18.329955,178.442148,31.722495,188.944182C39.448991,194.869945,48.960631,181.919808,35.808325,167.974185C27.053341,155.46954,26.778713,144.786038,23.180834,130.168643C19.139468,114.899686,18.114526,100.786543,20.952073,87.411869C21.572437,79.045425,6.897064,77.595457,4.916661,86.915441L4.90273,88.748028Z");
  }
  10% {
    d: path("M3.04819,95.324083C3.04819,95.324083,5.563842,99.566705,5.563842,99.566705C5.563842,99.566705,11.253926,104.287825,15.031546,103.153927C19.091035,103.791214,24.274539,98.764542,25.851733,95.404259C27.275674,92.370488,25.596139,87.698114,24.002501,85.705929C20.798403,80.519057,13.463578,80.659628,12.636219,80.655608C8.65731,80.636275,3.191193,86.96637,3.089982,89.826322L3.04819,95.324083Z");
  }
  20% {
    d: path("M3.04819,95.324083C3.04819,95.324083,5.563842,99.566705,5.563842,99.566705C5.563842,99.566705,11.253926,104.287825,15.031546,103.153927C19.091035,103.791214,24.274539,98.764542,25.851733,95.404259C27.275674,92.370488,25.596139,87.698114,24.002501,85.705929C20.798403,80.519057,13.463578,80.659628,12.636219,80.655608C8.65731,80.636275,3.191193,86.96637,3.089982,89.826322L3.04819,95.324083Z");
  }
  30% {
    d: path("M5.83,85.46C0.33,109.14,-1.74,133.78,3.49,157.71C8.74,181.71,22.08,203.01,40.28,219.33C49.84,227.9,64.03,213.8,54.42,205.19C38.53,190.96,27.37,173.33,22.77,152.4C18.31,132.09,20.44,110.85,25.11,90.79C28.03,78.25,8.75,72.91,5.83,85.46L5.83,85.46Z");
  }
  33.333333% {
    d: path("M5.83,85.46C0.33,109.14,-1.74,133.78,3.49,157.71C8.74,181.71,22.08,203.01,40.28,219.33C49.84,227.9,64.03,213.8,54.42,205.19C38.53,190.96,27.37,173.33,22.77,152.4C18.31,132.09,20.44,110.85,25.11,90.79C28.03,78.25,8.75,72.91,5.83,85.46L5.83,85.46Z");
  }
  43.333333% {
    d: path("M36.436007,38.11681C-7.498754,85.801617,-0.826469,134.911183,5.658972,158.164678C15.873566,192.855226,35.43893,215.965329,40.28,219.33C49.84,227.9,63.271136,215.585685,53.661136,206.975685C38.384036,191.128398,25.999041,166.121323,22.77,152.4C12.429986,121.009925,27.020185,73.061168,50.245766,52.61587C65.058304,39.576508,51.054205,23.186387,36.436019,38.116819L36.436007,38.11681Z");
  }
  100% {
    d: path("M36.436007,38.11681C-7.498754,85.801617,-0.826469,134.911183,5.658972,158.164678C15.873566,192.855226,35.43893,215.965329,40.28,219.33C49.84,227.9,63.271136,215.585685,53.661136,206.975685C38.384036,191.128398,25.999041,166.121323,22.77,152.4C12.429986,121.009925,27.020185,73.061168,50.245766,52.61587C65.058304,39.576508,51.054205,23.186387,36.436019,38.116819L36.436007,38.11681Z");
  }
`,Ie=i`
  0% {
    transform: translate(139.784999px, 140.086986px) scale(1, 1);
  }
  30% {
    transform: translate(139.784999px, 140.086986px) scale(1, 1);
  }
  43.333333% {
    transform: translate(139.784999px, 140.086986px) scale(0.102813, 0.102813);
  }
  50% {
    transform: translate(139.784999px, 140.086986px) scale(0.102813, 0.102813);
  }
  60% {
    transform: translate(139.784999px, 140.086986px) scale(1.001075, 1.001075);
  }
  100% {
    transform: translate(139.784999px, 140.086986px) scale(1.001075, 1.001075);
  }
`,Le=i`
  0% {
    opacity: 0;
  }
  30% {
    opacity: 0;
  }
  36.666667% {
    opacity: 0;
  }
  40% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
`,Re=i`0% {
                                       transform: translate(139.785004px, 140.086979px) rotate(0deg);
                                     }
                                       10% {
                                         transform: translate(139.785004px, 140.086979px) rotate(0deg);
                                       }
                                       20% {
                                         transform: translate(139.785004px, 140.086979px) rotate(90.041277deg);
                                       }
                                       100% {
                                         transform: translate(139.785004px, 140.086979px) rotate(90.041277deg);
                                       }`,ze=i`
  0% {
    opacity: 0;
  }
  6.666667% {
    opacity: 0;
  }
  10% {
    opacity: 1;
  }
  13.333333% {
    opacity: 1;
  }
  20% {
    opacity: 0;
  }
  100% {
    opacity: 0;
  }
`,Be=s.svg({width:40,height:40},l`
    color: var(--foreground);
    @media (prefers-reduced-motion: reduce) {
      g {
        animation: none !important;
      }
    }
    path {
      fill: currentColor;
    }
    #section1 {
      animation: ${ke} 3000ms linear infinite normal forwards;
    }
    #section2 {
      animation: ${Ae} 3000ms linear infinite normal forwards;
    }
    #section3 {
      animation: ${je} 3000ms linear infinite normal forwards;
    }
    #section4 {
      animation: ${Me} 3000ms linear infinite normal forwards;
    }
    #section5 {
      animation: ${Ne} 3000ms linear infinite normal forwards;
    }
    #section6 {
      animation: ${Pe} 3000ms linear infinite normal forwards;
    }
    #section7 {
      animation: ${Fe} 3000ms linear infinite normal forwards;
    }
    #section8 {
      animation: ${Ie} 3000ms linear infinite normal forwards;
    }
    #section9 {
      animation: ${Le} 3000ms linear infinite normal forwards;
    }
    #section10 {
      animation: ${Re} 3000ms linear infinite normal forwards;
    }
    #section11 {
      animation: ${ze} 3000ms linear infinite normal forwards;
    }
  `),Ve=e=>(0,j.jsxs)(Be,{viewBox:`0 0 280 280`,shapeRendering:`geometricPrecision`,textRendering:`geometricPrecision`,className:`min-loader`,...e,children:[(0,j.jsx)(`g`,{id:`section1`,transform:`translate(139.785027,140.086989) rotate(45.236493)`,children:(0,j.jsx)(`g`,{id:`section2`,transform:`scale(1,0.995019)`,children:(0,j.jsxs)(`g`,{id:`section3`,transform:`translate(-127.784998,-128.086989)`,children:[(0,j.jsx)(`g`,{children:(0,j.jsx)(`path`,{id:`section4`,d:`M85.4,249.8c23.68,5.5,48.32,7.57,72.25,2.34c24-5.25,45.3-18.59,61.62-36.79c8.57-9.56-5.53-23.75-14.14-14.14-14.23,15.89-31.86,27.05-52.79,31.65-20.31,4.46-41.55,2.33-61.61-2.34-12.54-2.91-17.88,16.36-5.33,19.28c0,0,0,0,0,0Z`})}),(0,j.jsx)(`g`,{children:(0,j.jsx)(`path`,{id:`section5`,d:`M249.74,169.63c5.5-23.68,7.57-48.32,2.34-72.25-5.25-24-18.59-45.3-36.79-61.62-9.56-8.57-23.75,5.53-14.14,14.14c15.89,14.23,27.05,31.86,31.65,52.79c4.46,20.31,2.33,41.55-2.34,61.61-2.92,12.54,16.36,17.88,19.28,5.33c0,0,0,0,0,0Z`})}),(0,j.jsx)(`g`,{children:(0,j.jsx)(`path`,{id:`section6`,d:`M171.68,7.71c-23.51-6.2-48.07-8.99-72.15-4.46C75.39,7.79,53.7,20.49,36.85,38.21c-8.84,9.31,4.83,23.9,13.72,14.55c14.7-15.46,32.65-26.1,53.7-30.08c20.43-3.86,41.6-1.1,61.52,4.15c12.43,3.28,18.35-15.83,5.89-19.12c0,0,0,0,0,0Z`})}),(0,j.jsx)(`g`,{children:(0,j.jsx)(`path`,{id:`section7`,d:`M5.83,85.46c-5.5,23.68-7.57,48.32-2.34,72.25c5.25,24,18.59,45.3,36.79,61.62c9.56,8.57,23.75-5.53,14.14-14.14-15.89-14.23-27.05-31.86-31.65-52.79-4.46-20.31-2.33-41.55,2.34-61.61C28.03,78.25,8.75,72.91,5.83,85.46v0Z`,transform:`translate(.194904 0.217549)`})})]})})}),(0,j.jsx)(`g`,{id:`section8`,transform:`translate(139.784999,140.086986) scale(1,1)`,children:(0,j.jsx)(`g`,{id:`section9`,transform:`translate(-127.999996,-128.000003)`,opacity:`0`,children:(0,j.jsx)(`path`,{d:`M234.23,128c0-58.67-47.56-106.23-106.23-106.23s-106.23,47.56-106.23,106.23s47.56,106.23,106.23,106.23c58.64-.06,106.17-47.59,106.23-106.23m21.25,0c0,70.4-57.07,127.48-127.48,127.48s-127.48-57.08-127.48-127.48s57.08-127.48,127.48-127.48s127.48,57.08,127.48,127.48Z`})})}),(0,j.jsx)(`g`,{id:`section10`,transform:`translate(139.785004,140.086979) rotate(0)`,children:(0,j.jsx)(`g`,{id:`section11`,transform:`translate(-127.999968,-127.995139)`,opacity:`0`,children:(0,j.jsx)(`path`,{d:`M128,0.47h.33c.36,0,.73,0,1.09.01h.17c5.45.09,9.79,4.57,9.73,10.02-.07,5.51-4.57,9.93-10.07,9.91h-1.24c-5.51-.04-9.96-4.51-9.96-10.02-.01-5.45,4.39-9.88,9.84-9.91h.11ZM245.62,118.39h.03c5.45.01,9.86,4.42,9.88,9.87c0,.04,0,.08,0,.12v0c0,.12,0,.24,0,.36v0c0,.01,0,.03,0,.04v.09c0,.37,0,.73-.01,1.09-.11,5.45-4.6,9.78-10.05,9.7-5.51-.08-9.92-4.6-9.88-10.1l.01-1.24c.06-5.49,4.52-9.92,10.02-9.93ZM126.01,235.58h.12l1.24.01c5.51.07,9.93,4.57,9.9,10.08-.04,5.48-4.51,9.89-9.99,9.85-.01,0-.02,0-.03,0h-.46-.19l-.82-.01h-.12c-5.45-.12-9.77-4.63-9.67-10.07.09-5.47,4.55-9.85,10.02-9.86ZM10.4,115.63h.2c5.51.12,9.89,4.65,9.82,10.16l-.02,1.24c-.09,5.5-4.59,9.91-10.1,9.88-5.45-.04-9.85-4.47-9.83-9.93c0-.04,0-.08,0-.12v0c0-.36,0-.73.01-1.09v-.09v0c0-.13,0-.27.01-.41.14-5.37,4.54-9.64,9.91-9.64Z`})})})]});function He(e){return u.Children.toArray(e).some(e=>u.isValidElement(e)&&(e.type===`title`||e.type===u.Fragment&&He(e.props.children)))}function K(e,t){let n=u.forwardRef(({className:e,children:n,title:r,role:i,"aria-hidden":a,...o},s)=>{let c=!!(o[`aria-label`]||o[`aria-labelledby`]||r||He(n)||i&&i!==`none`&&i!==`presentation`);return(0,j.jsxs)(`svg`,{xmlns:`http://www.w3.org/2000/svg`,width:24,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:2,strokeLinecap:`round`,strokeLinejoin:`round`,focusable:`false`,role:i??(c?`img`:void 0),"aria-hidden":a??(!c||void 0),...o,ref:s,className:[`min-icon`,`lucide-icon`,e].filter(Boolean).join(` `),children:[r&&(0,j.jsx)(`title`,{children:r}),n,(0,j.jsx)(`g`,{fill:`none`,children:t})]})});return n.displayName=e,n}var Ue=K(`LucideRefreshCw`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`path`,{d:`M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8`}),(0,j.jsx)(`path`,{d:`M21 3v5h-5`}),(0,j.jsx)(`path`,{d:`M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16`}),(0,j.jsx)(`path`,{d:`M8 16H3v5`})]})),q=K(`LucideCircleQuestionMark`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`circle`,{cx:`12`,cy:`12`,r:`10`}),(0,j.jsx)(`path`,{d:`M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3`}),(0,j.jsx)(`path`,{d:`M12 17h.01`})]})),We=K(`LucideArrowRight`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`path`,{d:`M5 12h14`}),(0,j.jsx)(`path`,{d:`m12 5 7 7-7 7`})]})),Ge=K(`LucideKeyRound`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`path`,{d:`M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z`}),(0,j.jsx)(`circle`,{cx:`16.5`,cy:`7.5`,r:`.5`,fill:`currentColor`})]})),Ke=K(`LucideEye`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`path`,{d:`M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0`}),(0,j.jsx)(`circle`,{cx:`12`,cy:`12`,r:`3`})]})),qe=K(`LucideUserRound`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`circle`,{cx:`12`,cy:`8`,r:`5`}),(0,j.jsx)(`path`,{d:`M20 21a8 8 0 0 0-16 0`})]})),Je=K(`LucideBookOpen`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`path`,{d:`M12 5v16`}),(0,j.jsx)(`path`,{d:`M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z`})]})),Ye=K(`LucideLogOut`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`path`,{d:`m16 17 5-5-5-5`}),(0,j.jsx)(`path`,{d:`M21 12H9`}),(0,j.jsx)(`path`,{d:`M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4`})]})),Xe=K(`LucideLockKeyhole`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`circle`,{cx:`12`,cy:`16`,r:`1`}),(0,j.jsx)(`rect`,{x:`3`,y:`10`,width:`18`,height:`12`,rx:`2`}),(0,j.jsx)(`path`,{d:`M7 10V7a5 5 0 0 1 10 0v3`})]})),J=K(`LucideX`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`path`,{d:`M18 6 6 18`}),(0,j.jsx)(`path`,{d:`m6 6 12 12`})]})),Ze=K(`LucideChevronUp`,(0,j.jsx)(j.Fragment,{children:(0,j.jsx)(`path`,{d:`m18 15-6-6-6 6`})})),Qe=K(`LucideChevronDown`,(0,j.jsx)(j.Fragment,{children:(0,j.jsx)(`path`,{d:`m6 9 6 6 6-6`})})),$e=K(`LucideRss`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`path`,{d:`M4 11a9 9 0 0 1 9 9`}),(0,j.jsx)(`path`,{d:`M4 4a16 16 0 0 1 16 16`}),(0,j.jsx)(`circle`,{cx:`5`,cy:`19`,r:`1`})]})),et=K(`LucideEyeOff`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`path`,{d:`M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49`}),(0,j.jsx)(`path`,{d:`M14.084 14.158a3 3 0 0 1-4.242-4.242`}),(0,j.jsx)(`path`,{d:`M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143`}),(0,j.jsx)(`path`,{d:`m2 2 20 20`})]})),tt=K(`LucideMoon`,(0,j.jsx)(j.Fragment,{children:(0,j.jsx)(`path`,{d:`M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401`})})),nt=K(`LucideSun`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`circle`,{cx:`12`,cy:`12`,r:`4`}),(0,j.jsx)(`path`,{d:`M12 2v2`}),(0,j.jsx)(`path`,{d:`M12 20v2`}),(0,j.jsx)(`path`,{d:`m4.93 4.93 1.41 1.41`}),(0,j.jsx)(`path`,{d:`m17.66 17.66 1.41 1.41`}),(0,j.jsx)(`path`,{d:`M2 12h2`}),(0,j.jsx)(`path`,{d:`M20 12h2`}),(0,j.jsx)(`path`,{d:`m6.34 17.66-1.41 1.41`}),(0,j.jsx)(`path`,{d:`m19.07 4.93-1.41 1.41`})]})),rt=i`
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
`,it=s.span({display:`inline-flex`,position:`relative`},l`
    &:hover {
      & .tooltipElement {
        display: block;
        animation: ${rt} 1s;
      }
    }
  `),at=s.div(({theme:e,placement:t})=>{let n=(0,S.default)(e,`tooltip.background`,`#737373`),r=(0,S.default)(e,`tooltip.color`,`#FFFFFF`),i={},a={content:`' '`,left:`50%`,border:`solid transparent`,height:0,width:0,position:`absolute`,pointerEvents:`none`,borderWidth:`6px`,marginLeft:`calc(6px * -1);`};switch(t){case`top`:i={transform:`translateX(-50%) translateY(-50%)`,"&::before":{...a,top:`100%`,borderTopColor:n}};break;case`right`:i={transform:`translateX(0) translateY(-50%)`,"&::before":{...a,left:`calc(6px * -1)`,top:`50%`,transform:`translateX(0) translateY(-50%)`,borderRightColor:n}};break;case`left`:i={transform:`translateX(-100%) translateY(-50%)`,"&::before":{...a,left:`auto`,right:`calc(6px * -2)`,top:`50%`,transform:`translateX(0) translateY(-50%)`,borderLeftColor:n}};break;default:i={transform:`translateX(-50%)`,"&::before":{...a,bottom:`100%`,borderBottomColor:n}}}return{position:`fixed`,borderRadius:4,color:r,background:n,lineHeight:1,zIndex:10001,padding:2,fontSize:12,boxShadow:`#00000050 0px 3px 10px`,maxWidth:350,...i}}),ot=s.div(({theme:e,placement:t})=>{let n=(0,S.default)(e,`tooltip.background`,`#737373`),r={},i={content:`' '`,left:`50%`,height:0,width:0,position:`absolute`,pointerEvents:`none`,marginLeft:`calc(6px * -1);`};switch(t){case`top`:r={transform:`translateX(-50%) translateY(-50%)`,"&::before":{...i,top:`100%`,borderTopColor:n}};break;case`right`:r={transform:`translateX(0) translateY(-50%)`,"&::before":{...i,left:`calc(6px * -1)`,top:`50%`,transform:`translateX(0) translateY(-50%)`,borderRightColor:n}};break;case`left`:r={transform:`translateX(-100%) translateY(-50%)`,"&::before":{...i,left:`auto`,right:`calc(6px * -2)`,top:`50%`,transform:`translateX(0) translateY(-50%)`,borderLeftColor:n}};break;default:r={transform:`translateX(-50%)`,"&::before":{...i,bottom:`100%`,borderBottomColor:n}}}return{position:`fixed`,color:n,zIndex:10001,...r}}),st=s.div(({theme:e})=>({border:`1px solid ${(0,S.default)(e,`borderColor`,`#E2E2E2`)}`,borderRadius:2,backgroundColor:(0,S.default)(e,`boxBackground`,`#FBFAFA`),paddingLeft:10,paddingTop:5,paddingBottom:5,paddingRight:10,"& .leftItems":{fontSize:16,fontWeight:`bold`,display:`flex`,alignItems:`center`,"& .min-icon":{marginRight:5,height:28,width:38}},"& .helpText":{fontSize:10,paddingLeft:5,marginTop:5,color:`black`}})),ct=({children:e,content:t,placement:n})=>{let[r,i]=(0,u.useState)(null),[a,o]=(0,u.useState)(!1),[s,c]=(0,u.useState)(!1),l=()=>{s?setTimeout(()=>{o(!1),c(!1)},5e4):setTimeout(()=>{o(!1)},1e3)},f=()=>{s||(o(!1),c(!0))},p=({placement:e,content:t,anchorEl:n})=>{let r={},i=e;if(n){let t=n.getBoundingClientRect(),a=document.documentElement.offsetWidth,o=document.documentElement.offsetHeight;switch(e){case`bottom`:t.top+t.height+25>o&&(i=`top`);break;case`left`:t.left-175<0&&(i=`right`);break;case`right`:t.left+t.width+175>a&&(i=`left`);break;case`top`:t.top<25&&(i=`bottom`)}switch(i){case`bottom`:r={top:t.top+t.height+10,left:t.left+t.width/2};break;case`left`:r={top:t.top+t.height/2,left:t.left-12};break;case`right`:r={top:t.top+t.height/2,left:t.left+t.width+12};break;case`top`:r={top:t.top-t.height/2-10,left:t.left+t.width/2}}}return(0,j.jsx)(at,{placement:i,style:r,onClick:f,children:t})},m=({placement:e,anchorEl:t})=>{let n={},r=e;if(t){let i=t.getBoundingClientRect(),a=document.documentElement.offsetWidth,o=document.documentElement.offsetHeight;switch(e){case`bottom`:i.top+i.height+45>o&&(r=`top`);break;case`left`:i.left-175;break;case`right`:i.left+i.width+175>a&&(r=`left`);break;case`top`:i.top<45&&(r=`bottom`)}switch(r){case`bottom`:n={top:i.top+i.height+10,left:i.left+i.width/2};break;case`left`:n={top:i.top+i.height/2,left:i.left-12};break;case`right`:n={top:i.top+i.height/2,left:i.left+i.width+12};break;case`top`:n={top:i.top-i.height/2-10,left:i.left+i.width/2}}}return(0,j.jsx)(ot,{placement:r,style:n,onClick:f,children:(0,j.jsx)(q,{style:{width:12,height:12}})})};function h(e){(0,u.useEffect)(()=>{function t(t){e.current&&!e.current.contains(t.target)&&c(!1)}return document.addEventListener(`mousedown`,t),()=>{document.removeEventListener(`mousedown`,t)}},[e])}let g=(0,u.useRef)(null);return h(g),n?(0,j.jsx)(u.Fragment,{children:(0,j.jsxs)(it,{ref:g,onPointerEnter:e=>{s||(i(e.currentTarget),o(!0))},onMouseLeave:l,children:[e,a&&!s&&(0,d.createPortal)((0,j.jsx)(m,{placement:n,content:(0,j.jsx)(q,{}),anchorEl:r}),document.body),s&&(0,d.createPortal)((0,j.jsx)(p,{placement:n,content:(0,j.jsx)(st,{className:`helpbox-container`,ref:g,children:(0,j.jsx)(G,{container:!0,children:(0,j.jsx)(G,{item:!0,xs:12,className:`helpText`,children:t})})}),anchorEl:r}),document.body)]})}):(0,j.jsx)(u.Fragment,{children:e})},lt=s.label(({sx:e})=>({fontWeight:400,marginRight:10,fontSize:`var(--fs-body,13px)`,lineHeight:`var(--lh-body,20px)`,color:`var(--foreground)`,textAlign:`left`,alignItems:`center`,display:`flex`,userSelect:`none`,minWidth:0,whiteSpace:`normal`,overflowWrap:`anywhere`,"& > span":{display:`flex`,alignItems:`center`,width:160,minWidth:0,"&.noMinWidthLabel":{minWidth:`initial`,width:`auto`}},"@media (max-width: 767.98px)":{marginRight:0,"& > span":{width:`auto`,minWidth:0}},'[data-field-layout="stacked"] &':{marginRight:0,"& > span":{width:`auto`,minWidth:0}},...e})),Y=({children:e,sx:t,noMinWidth:n,htmlFor:r,helpTip:i,helpTipPlacement:a,...o})=>(0,j.jsx)(lt,{sx:t,htmlFor:r,...o,children:(0,j.jsx)(`span`,{className:`${n?`noMinWidthLabel`:``}`,children:i?(0,j.jsx)(ct,{placement:a,content:i,children:e}):e})}),ut=s(W)`
  padding: 0;
  width: ${({$size:e})=>e||`var(--control-height,36px)`};
  height: ${({$size:e})=>e||`var(--control-height,36px)`};
  @media (pointer: coarse) { min-width: 40px; min-height: 40px; }
  .button-label {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  svg {
    width: var(--icon-size, 16px);
    height: var(--icon-size, 16px);
    margin: 0;
    fill: currentColor;
  }
`,X=(0,u.forwardRef)(({children:e,label:t,size:n,id:r,sx:i,...a},o)=>{let s=a[`aria-label`]||t,c=n===`small`?`28px`:n===`medium`||n===`large`?`36px`:n,l=(0,j.jsx)(ut,{ref:o,id:r||``,type:`button`,...a,"aria-label":s,variant:`ghost`,collapseOnSmall:!1,$size:c,sx:i,children:e});return s&&!a.disabledReason&&!a[`aria-describedby`]?(0,j.jsx)(U,{tooltip:s,children:l}):l});X.displayName=`IconButton`;var dt=s.div(({theme:e,sx:t,withBorders:n,customBorderPadding:r,useBackground:i})=>{let a={};return n&&(a={border:0,borderRadius:`var(--radius-card, 12px)`,boxShadow:`var(--shadow-2, none)`,backgroundColor:(0,S.default)(e,`boxBackground`,`#fff`),padding:r||15}),{...n||i?ue(3):{},backgroundColor:i?(0,S.default)(e,`boxBackground`,`#FBFAFA`):`transparent`,...a,...t}}),Z=({sx:e,children:t,customBorderPadding:n,elementRef:r,...i})=>{let a=(0,j.jsx)(dt,{ref:r,...i,sx:e,customBorderPadding:n,children:t});return i.withBorders||i.useBackground?(0,j.jsx)(L,{level:3,children:a}):a},ft=s.div(({theme:e,sx:t,variant:n})=>({boxSizing:`border-box`,minWidth:0,maxWidth:n===`constrained`?1220:`initial`,padding:`var(--page-padding, 24px)`,background:`var(--surface-1)`,...t})),pt=({sx:e,children:t,variant:n,className:r,...i})=>(0,j.jsx)(ft,{sx:e,variant:n,...i,children:(0,j.jsx)(G,{container:!0,children:(0,j.jsx)(G,{item:!0,xs:12,className:r,children:t})})}),mt=(0,u.createContext)({close:`Close`,showPassword:`Show password`,hidePassword:`Hide password`,inputAction:`Input action`,chooseDate:`Choose date`,chooseDateTime:`Choose date and time`,calendarLocale:`en`,time:`Time`,hour:`Hour`,minute:`Minute`,second:`Second`,meridiem:`AM/PM`,am:`AM`,pm:`PM`,previousCalendarPeriod:`Previous calendar period`,nextCalendarPeriod:`Next calendar period`,progress:`Progress`,remove:`Remove`,on:`On`,off:`Off`}),ht=({labels:e,children:t})=>(0,j.jsx)(mt.Provider,{value:e,children:t}),Q=()=>(0,u.useContext)(mt),gt={flexDirection:`column`,gap:8,"& > .inputLabel":{minHeight:`auto`,marginRight:0,marginBottom:0,alignSelf:`stretch`}},_t={"--field-height":`var(--control-height,36px)`,display:`flex`,alignItems:`flex-start`,flexGrow:1,width:`100%`,minWidth:0,"& > .inputLabel":{minHeight:`var(--field-height)`,marginBottom:0,flexShrink:0},"& .inputLabel .min-icon":{width:13,height:13,flexShrink:0},"& [id$='-error']":{overflowWrap:`anywhere`},"@media (pointer: coarse)":{"--field-height":`max(40px, var(--control-height,36px))`},"@media (max-width: 767.98px)":gt,'&[data-field-layout="stacked"]':gt,'[data-field-layout="stacked"] &':gt},vt=l`
  ${P(`body`)}
  box-sizing: border-box;
  height: var(--field-height, var(--control-height, 36px));
  width: 100%;
  min-width: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--foreground);
  box-shadow: inset 0 0 0 1px var(--input);
  outline: none;
  padding: 0 var(--control-padding, 12px);
  font-variant-numeric: tabular-nums;
  &::placeholder,
  & .selectPlaceholder {
    color: var(--muted-foreground);
    opacity: 1;
  }
  &:hover:not(:disabled) {
    box-shadow: inset 0 0 0 1px var(--muted-foreground);
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
  }
  &[aria-invalid="true"] {
    box-shadow: inset 0 0 0 1px var(--destructive);
  }
  &:disabled {
    background: var(--muted);
    color: var(--foreground);
    cursor: not-allowed;
  }
  &:disabled::placeholder {
    color: var(--foreground);
  }
  &:disabled .selectPlaceholder {
    color: var(--foreground);
  }
  @media (pointer: coarse) {
    font-size: 16px;
  }
`,yt=({text:e})=>(0,j.jsx)(X,{type:`button`,"data-field-help":`true`,size:`small`,label:e,sx:{marginLeft:4,flexShrink:0,"&& svg":{width:13,height:13}},children:(0,j.jsx)(q,{})}),bt=s.input`
  ${vt}
  padding-left: ${({startIcon:e})=>e?`36px`:`var(--control-padding,12px)`};
  padding-right: ${({overlayIcon:e,overlayObject:t,originType:n})=>e||t||n===`password`?`40px`:`var(--control-padding,12px)`};
`,xt=s.div(({theme:e,sx:t,$reserveErrorSpace:n})=>({..._t,"& .errorText":{fontSize:`var(--fs-caption,12px)`,lineHeight:`var(--lh-caption,16px)`,color:`var(--destructive-text)`,marginTop:3},"& .textBoxContainer":{width:`100%`,flexGrow:1,position:`relative`,minWidth:0,minHeight:n?`calc(var(--field-height, var(--control-height,36px)) + var(--lh-caption,16px) + 3px)`:void 0},"& .overlayAction":{position:`absolute`,right:5,top:`calc(var(--field-height, var(--control-height,36px)) / 2)`,transform:`translateY(-50%)`},"& .startOverlayIcon":{position:`absolute`,left:10,top:`calc((var(--field-height, var(--control-height,36px)) - var(--icon-size,16px)) / 2)`,"& svg":{width:14,height:14,fill:(0,S.default)(e,`inputBox.color`,`#07193E`),color:(0,S.default)(e,`inputBox.color`,`#07193E`)}},...t})),St=u.forwardRef(({id:e,tooltip:t=``,index:n,type:r,overlayIcon:i,noLabelMinWidth:a,overlayId:o,overlayAction:s,overlayObject:c,label:l=``,required:d,startIcon:f,className:p,error:m,reserveErrorSpace:h=!1,sx:g,helpTip:_,helpTipPlacement:v,...y},b)=>{let x=Q(),[S,C]=(0,u.useState)(!1),w=i,T=r;return r===`password`&&!i&&(w=S?(0,j.jsx)(et,{}):(0,j.jsx)(Ke,{}),T=S?`text`:`password`),(0,j.jsxs)(xt,{$reserveErrorSpace:h,error:!!m&&m!==``,sx:g,className:`inputItem ${p}`,children:[l!==``&&(0,j.jsxs)(Y,{htmlFor:e,noMinWidth:a,className:`inputLabel`,helpTip:_,helpTipPlacement:v,children:[l,d?`*`:``,t!==``&&(0,j.jsx)(yt,{text:t})]}),(0,j.jsxs)(Z,{className:`textBoxContainer`,children:[f&&(0,j.jsx)(Z,{className:`startOverlayIcon`,children:f}),(0,j.jsx)(bt,{id:e,fullWidth:!0,"aria-label":y[`aria-label`]||l||y.placeholder,type:T,error:m,"aria-invalid":!!m||void 0,"aria-describedby":m?`${e}-error`:y[`aria-describedby`],className:`inputRebase`,"data-index":n,startIcon:f,overlayObject:c,overlayIcon:i,originType:r,ref:b,...y}),w&&(0,j.jsx)(Z,{className:`overlayAction`,children:(0,j.jsx)(X,{onClick:s?()=>{s()}:()=>C(!S),id:o,size:`25px`,type:`button`,disabled:y.disabled,"aria-label":r===`password`?S?x.hidePassword:x.showPassword:l||x.inputAction,children:w})}),c&&(0,j.jsx)(Z,{className:`overlayAction`,children:c}),m&&(0,j.jsx)(Z,{id:`${e}-error`,className:`errorText`,children:m})]})]})}),Ct=(0,u.lazy)(()=>_(()=>import(`./DropdownSelectorPopup-qGKCmTTo.js`),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url));function wt({open:e,anchorEl:t,hideTriggerAction:n}){return(0,u.useLayoutEffect)(()=>{if(!e||!t)return;let r=e=>{e.key===`Escape`&&(e.preventDefault(),e.stopPropagation()),e.key===`Tab`&&n()},i=e=>{e.key===`Escape`&&(e.preventDefault(),e.stopPropagation(),n())};return t.addEventListener(`keydown`,r),t.addEventListener(`keyup`,i),()=>{t.removeEventListener(`keydown`,r),t.removeEventListener(`keyup`,i)}},[e,t,n]),null}function Tt(e){let t=z(),n=e.open&&t,[r,i]=(0,u.useState)(n);return(0,u.useEffect)(()=>{n&&i(!0)},[n]),n||r?(0,j.jsx)(u.Suspense,{fallback:(0,j.jsx)(wt,{...e,open:n}),children:(0,j.jsx)(Ct,{...e,open:n})}):null}var Et=s.button`
  ${vt}
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  cursor: pointer;
  text-align: left;
  .truncate {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  svg {
    width: var(--icon-size, 16px);
    height: var(--icon-size, 16px);
    flex-shrink: 0;
    fill: currentColor;
  }
  .indicatorContainer {
    display: flex;
    align-items: center;
  }
`,Dt=s.div(({theme:e,sx:t})=>({..._t,position:`relative`,"& .selectContainer":{display:`flex`,width:`100%`,gap:8,alignItems:`center`,flexGrow:1,position:`relative`,minWidth:0},"& .overlayArrow":{position:`absolute`,top:`50%`,transform:`translateY(-50%)`,marginTop:`2px`,right:`5px`,"& svg":{width:26,height:26,fill:(0,S.default)(e,`inputBox.color`,`#07193E`),color:(0,S.default)(e,`inputBox.color`,`#07193E`)}},...t})),Ot=({id:e,label:t=``,"aria-label":n,required:r,className:i,tooltip:a=``,noLabelMinWidth:o=!1,value:s=``,sx:c,options:l,onChange:d,disabled:f=!1,fixedLabel:p=``,name:m,placeholder:h=``,helpTip:g,helpTipPlacement:_,error:v})=>{let y=z(),[b,x]=(0,u.useState)(!1),[S,C]=u.useState(null);(0,u.useEffect)(()=>{(!y||f)&&x(!1)},[y,f]);let w=b&&y&&!f,T=l.find(e=>e.value===s),E=n||t,D=`${e}-label`,O=`${e}-value`;return!T&&p===``&&h===``&&console.warn(`The selected value is not included in Options List`),(0,j.jsxs)(Dt,{error:!!v,sx:c,className:`inputItem ${i||``}`,children:[t!==``&&(0,j.jsxs)(Y,{htmlFor:`${e}-select`,noMinWidth:o,className:`inputLabel`,helpTip:g,helpTipPlacement:_,children:[(0,j.jsx)(`span`,{id:n?void 0:D,children:t}),r?`*`:``,a!==``&&(0,j.jsx)(yt,{text:a})]}),n&&(0,j.jsx)(`span`,{id:D,hidden:!0,children:n}),(0,j.jsxs)(Z,{className:`selectContainer`,sx:{flexDirection:`column`,alignItems:`stretch`},children:[(0,j.jsxs)(Et,{id:`${e}-select`,type:`button`,disabled:f,"aria-labelledby":E?`${D} ${O}`:O,"aria-haspopup":`listbox`,"aria-expanded":w,"aria-controls":w?`${e}-options-selector`:void 0,"aria-invalid":!!v||void 0,"aria-describedby":v?`${e}-error`:void 0,onClick:e=>{e.currentTarget.focus(),C(e.currentTarget),x(!w)},onKeyDown:e=>{(e.key===`ArrowDown`||e.key===`ArrowUp`)&&(e.preventDefault(),C(e.currentTarget),x(!0))},children:[(0,j.jsxs)(Z,{sx:{display:`flex`,columnGap:8,width:`calc(100% - 16px)`},children:[T?.icon&&(0,j.jsx)(Z,{className:`indicatorContainer`,children:T?.icon}),(0,j.jsx)(Z,{id:O,sx:{whiteSpace:`nowrap`,overflow:`hidden`,textOverflow:`ellipsis`,minWidth:0},children:p&&p!==``?p:(0,j.jsx)(u.Fragment,{children:T?.label||(0,j.jsx)(`span`,{className:`selectPlaceholder`,children:h===``?``:h})})}),T?.indicator&&(0,j.jsx)(Z,{className:`indicatorContainer`,children:T?.indicator})]}),(0,j.jsx)(Z,{sx:{display:`flex`,width:16},children:w?(0,j.jsx)(Ze,{}):(0,j.jsx)(Qe,{})})]}),v&&(0,j.jsx)(`span`,{id:`${e}-error`,style:{color:`var(--destructive-text)`,fontSize:`var(--fs-caption)`,lineHeight:`var(--lh-caption)`},children:v}),(0,j.jsx)(`input`,{type:`hidden`,id:e,name:m,value:s})]}),(0,j.jsx)(Tt,{id:`${e}-options-selector`,options:l,selectedOption:s,onSelect:(e,t)=>d(e,t),hideTriggerAction:()=>{x(!1)},ariaLabel:E?void 0:p||h||void 0,ariaLabelledBy:E?D:p||h?void 0:O,open:w,anchorEl:S,useAnchorWidth:!0})]})},kt={default:`var(--info)`,secondary:`var(--foreground)`,warn:`var(--warning)`,alert:`var(--destructive)`,ok:`var(--success)`,grey:`var(--muted-foreground)`},At=s.span`
  ${({$compact:e})=>P(`caption`,{compact:e})}
  display: inline-flex;
  align-items: center;
  max-width: 100%;
  box-sizing: border-box;
  white-space: nowrap;
  height: ${({$compact:e})=>e?20:24}px;
  padding: 0 ${({$compact:e})=>e?8:10}px;
  gap: ${({$compact:e})=>e?4:6}px;
  border-radius: 999px;
  color: var(--foreground);
  background: ${({$dot:e,$neutral:t,$tone:n})=>e?`transparent`:t?`var(--accent)`:`color-mix(in srgb, ${n} 15%, var(--background))`};
  border: 1px solid ${({$dot:e})=>e?`var(--border)`:`transparent`};
  .tag-dot {
    width: 6px;
    height: 6px;
    flex-shrink: 0;
    border-radius: 50%;
    background: ${({$tone:e})=>e};
  }
  svg {
    width: 12px;
    height: 12px;
    flex-shrink: 0;
    fill: currentColor;
  }
  .deleteTagButton {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    width: 16px;
    height: 16px;
    border: 0;
    border-radius: 4px;
    background: transparent;
    color: var(--foreground);
    cursor: pointer;
  }
  .deleteTagButton:hover {
    background: var(--hover);
  }
  .deleteTagButton:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
  }
  ${({$sx:e})=>e}
`,jt=({children:e,color:t=`default`,sx:n,onDelete:r,id:i,label:a,variant:o=`regular`,icon:s,square:c,deleteLabel:l,...u})=>{let d=Q(),{compact:f}=F(),p=o===`dot`||o===`outlined`;return(0,j.jsxs)(At,{id:i,$tone:kt[t],$dot:p,$neutral:t===`grey`||t===`secondary`,$compact:f,$sx:n,...u,children:[p&&!s&&(0,j.jsx)(`span`,{className:`tag-dot`,"aria-hidden":`true`}),s,(0,j.jsxs)(`span`,{children:[a,e]}),r&&(0,j.jsx)(`button`,{type:`button`,className:`deleteTagButton`,"aria-label":l||`${d.remove} ${a}`,onClick:()=>r(i),children:(0,j.jsx)(J,{})})]})},Mt={blue:`main`,red:`danger`,green:`good`,orange:`warning`,grey:`disabled`},Nt=s.div(({theme:e,sx:t,color:n,barHeight:r,transparentBG:i})=>({"& .progBlock":{display:`flex`,alignItems:`center`,gap:10},"& .progressContainer":{position:`relative`,width:`100%`,height:r,backgroundColor:i?`transparent`:`var(--muted)`,borderRadius:r,overflow:`hidden`},"& .notificationLabel":{fontSize:`var(--fs-caption,12px)`,lineHeight:`var(--lh-caption,16px)`,color:`var(--foreground)`},"& .percentageBar":{display:`block`,height:r,backgroundColor:n===`blue`?`var(--foreground)`:(0,S.default)(e,`signalColors.${Mt[n||`blue`]}`,k.mainBlue),width:`100%`,transformOrigin:`left`,transition:`transform var(--dur-moderate,160ms) var(--ease-moderate,ease-out)`,borderRadius:r},"@media (prefers-reduced-motion: reduce)":{"& .percentageBar":{transition:`none`}},...t})),Pt=i`from { transform: translateX(-100%); } to { transform: translateX(400%); }`,Ft=s.div`
  width: 25%;
  height: ${e=>(0,S.default)(e,`barHeight`,8)}px;
  display: block;
  position: absolute;
  border-radius: ${e=>(0,S.default)(e,`barHeight`,8)}px;
  animation: ${Pt} 1000ms linear infinite normal forwards;
  @media (prefers-reduced-motion: reduce) {
    animation: none;
    transform: translateX(150%);
  }
  background-color: ${e=>(e.color||`blue`)===`blue`?`var(--foreground)`:(0,S.default)(e.theme,`signalColors.${Mt[e.color||`blue`]}`,k.mainBlue)};
`,It=({progressLabel:e=!1,sx:t,value:n=0,maxValue:r=100,variant:i=`indeterminate`,notificationLabel:a=``,color:o=`blue`,barHeight:s=6,transparentBG:c=!1})=>{let l=Q(),u=Number.isFinite(n)&&Number.isFinite(r)&&r>0?Math.max(0,Math.min(100,n/r*100)):0;return(0,j.jsxs)(Nt,{color:o,sx:t,barHeight:s,transparentBG:c,children:[(0,j.jsxs)(Z,{className:`progBlock`,children:[(0,j.jsx)(Z,{className:`progressContainer`,role:`progressbar`,"aria-valuemin":0,"aria-valuemax":100,"aria-valuenow":i===`determinate`?u:void 0,"aria-label":a||l.progress,children:i===`indeterminate`?(0,j.jsx)(Ft,{color:o,barHeight:s}):(0,j.jsx)(Z,{className:`percentageBar`,style:{transform:`scaleX(${u/100})`}})}),e&&i!==`indeterminate`&&(0,j.jsxs)(`span`,{className:`progressPercentage`,children:[Math.floor(u),`%`]})]}),a!==``&&(0,j.jsx)(`span`,{className:`notificationLabel`,children:a})]})},Lt=s.div`
  ${({$condensed:e,$compact:t})=>P(e?`caption`:`body`,{compact:t})}
  position: ${({$inline:e})=>e?`relative`:`fixed`};
  z-index: 10000;
  ${({$inline:e})=>!e&&`top: 16px; left: 50%; translate: -50% 0;`}
  display: flex;
  align-items: center;
  gap: 12px;
  box-sizing: border-box;
  max-width: min(540px, calc(100vw - 32px));
  padding: ${({$condensed:e})=>e?`4px 12px`:`12px 16px`};
  border-radius: 8px;
  background: var(--foreground);
  color: var(--surface-1);
  box-shadow: var(--shadow-3);
  opacity: ${({$shown:e})=>+!!e};
  transform: ${({$shown:e})=>e?`translateY(0)`:`translateY(-4px)`};
  transition:
    opacity
      ${({$shown:e})=>e?`var(--dur-fast,80ms) var(--ease-fast,ease-out)`:`60ms var(--ease-exit,ease-in)`},
    transform
      ${({$shown:e})=>e?`var(--dur-fast,80ms) var(--ease-fast,ease-out)`:`60ms var(--ease-exit,ease-in)`};
  button {
    display: flex;
    width: 24px;
    height: 24px;
    border: 0;
    border-radius: 4px;
    background: transparent;
    color: inherit;
    cursor: pointer;
    flex-shrink: 0;
    padding: 6px;
  }
  button:hover {
    background: var(--tint);
  }
  button:focus-visible {
    outline: 2px solid var(--focus-ring);
  }
  svg {
    width: 12px;
    height: 12px;
    fill: currentColor;
  }
  @media (prefers-reduced-motion: reduce) {
    transform: none;
    transition-property: opacity;
  }
  ${({$sx:e})=>e}
`,Rt=({autoHideDuration:e=5,message:t=``,open:n,onClose:r,variant:i=`default`,condensed:a=!1,closeButton:o,sx:s,mode:c=`portal`})=>{let l=z(),f=n&&l,{compact:p}=F(),m=Q(),[h,g]=(0,u.useState)(!1),[_,v]=(0,u.useState)(f),[y,b]=(0,u.useState)(!1),x=(0,u.useRef)(r);if(x.current=r,(0,u.useEffect)(()=>{f&&v(!0)},[f]),(0,u.useEffect)(()=>{if(f&&_){let e=requestAnimationFrame(()=>b(!0));return()=>cancelAnimationFrame(e)}b(!1);let e=setTimeout(()=>v(!1),60);return()=>clearTimeout(e)},[f,_]),(0,u.useEffect)(()=>{if(!f||h||e<=0)return;let t=setTimeout(()=>x.current(),e*1e3);return()=>clearTimeout(t)},[f,h,e]),!_||!t)return null;let S=(0,j.jsxs)(Lt,{$compact:p,"aria-hidden":!f||void 0,style:{pointerEvents:f?void 0:`none`},$condensed:a,$inline:c===`inline`,$shown:y,$sx:s,role:i===`error`||i===`warning`?`alert`:`status`,onMouseEnter:()=>g(!0),onMouseLeave:()=>g(!1),onFocus:()=>g(!0),onBlur:()=>g(!1),children:[(0,j.jsx)(`span`,{children:t}),o&&(0,j.jsx)(`button`,{type:`button`,disabled:!f,"aria-label":m.close,onClick:r,children:(0,j.jsx)(J,{})})]});return c===`portal`?(0,d.createPortal)(S,document.body):S},zt=K(`LucideFingerprintPattern`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`path`,{d:`M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4`}),(0,j.jsx)(`path`,{d:`M14 13.12c0 2.38 0 6.38-1 8.88`}),(0,j.jsx)(`path`,{d:`M17.29 21.02c.12-.6.43-2.3.5-3.02`}),(0,j.jsx)(`path`,{d:`M2 12a10 10 0 0 1 18-6`}),(0,j.jsx)(`path`,{d:`M2 16h.01`}),(0,j.jsx)(`path`,{d:`M21.8 16c.2-2 .131-5.354 0-6`}),(0,j.jsx)(`path`,{d:`M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2`}),(0,j.jsx)(`path`,{d:`M8.65 22c.21-.66.45-1.32.57-2`}),(0,j.jsx)(`path`,{d:`M9 6.8a6 6 0 0 1 9 5.2v2`})]})),Bt=K(`LucideFileVideoCamera`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`path`,{d:`M4 12V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2`}),(0,j.jsx)(`path`,{d:`M14 2v5a1 1 0 0 0 1 1h5`}),(0,j.jsx)(`path`,{d:`m10 17.843 3.033-1.755a.64.64 0 0 1 .967.56v4.704a.65.65 0 0 1-.967.56L10 20.157`}),(0,j.jsx)(`rect`,{width:`7`,height:`6`,x:`3`,y:`16`,rx:`1`})]}));function Vt(e){return u.Children.toArray(e).some(e=>u.isValidElement(e)&&(e.type===`title`||e.type===u.Fragment&&Vt(e.props.children)))}function Ht(e,t){let n=u.forwardRef(({className:e,children:n,title:r,role:i,"aria-hidden":a,...o},s)=>{let c=!!(o[`aria-label`]||o[`aria-labelledby`]||r||Vt(n)||i&&i!==`none`&&i!==`presentation`);return(0,j.jsxs)(`svg`,{xmlns:`http://www.w3.org/2000/svg`,width:24,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:2,strokeLinecap:`round`,strokeLinejoin:`round`,focusable:`false`,role:i??(c?`img`:void 0),"aria-hidden":a??(!c||void 0),...o,ref:s,className:[`min-icon`,`lucide-icon`,e].filter(Boolean).join(` `),children:[r&&(0,j.jsx)(`title`,{children:r}),n,(0,j.jsx)(`g`,{fill:`none`,children:t})]})});return n.displayName=e,n}var Ut=Ht(`LucideLanguages`,(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`path`,{d:`m5 8 6 6`}),(0,j.jsx)(`path`,{d:`m4 14 6-6 2-3`}),(0,j.jsx)(`path`,{d:`M2 5h12`}),(0,j.jsx)(`path`,{d:`M7 2h1`}),(0,j.jsx)(`path`,{d:`m22 22-5-10-5 10`}),(0,j.jsx)(`path`,{d:`M14 18h6`})]})),$={normal:400,semibold:550,bold:700},Wt={display:{size:28,line:34,compactSize:24,compactLine:30,weight:$.bold},title:{size:16,line:22,compactSize:15,compactLine:20,weight:$.semibold},subtitle:{size:14,line:20,compactSize:13,compactLine:18,weight:$.semibold},body:{size:13,line:20,compactSize:12,compactLine:18,weight:$.normal},caption:{size:12,line:16,compactSize:11,compactLine:14,weight:$.normal},micro:{size:11,line:14,compactSize:10,compactLine:12,weight:$.normal}},Gt={default:{controlHeight:36,controlPadding:12,rowPadding:8,gap:8,iconSize:16},compact:{controlHeight:28,controlPadding:10,rowPadding:6,gap:4,iconSize:14}};export{P as $,Xe as A,Ve as B,ct as C,Qe as D,$e as E,Ge as F,ge as G,W as H,We as I,ve as J,be as K,q as L,Je as M,qe as N,Ze as O,Ke as P,F as Q,Ue as R,Y as S,tt as T,U,G as V,he as W,L as X,R as Y,ce as Z,ht as _,Ht as a,x as at,Z as b,Rt as c,_ as ct,Ot as d,re as et,Tt as f,_t as g,vt as h,Ut as i,O as it,Ye as j,J as k,It as l,yt as m,$ as n,k as nt,Bt as o,y as ot,St as p,z as q,Wt as r,C as rt,zt as s,b as st,Gt as t,ne as tt,jt as u,Q as v,nt as w,X as x,pt as y,K as z};