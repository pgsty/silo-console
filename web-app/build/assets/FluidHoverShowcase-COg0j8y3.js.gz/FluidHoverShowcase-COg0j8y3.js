import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,t as n}from"./react-vendor-UL3KVrSx.js";import{q as r}from"./mds-BO2rKL5Q.js";import{T as i}from"./shared-vendor-BQfq49S_.js";import{t as a}from"./DataTable-Da20uHg8.js";import{t as o}from"./Tabs-DlsZw24K.js";import{a as s}from"./i18n-Bv0O4wSF.js";var c=e(t()),l=n(),u=i.section`
  display: grid;
  gap: 16px;
  min-width: 0;
  .fluidExamples {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 16px;
  }
  @media (max-width: 760px) {
    .fluidExamples {
      grid-template-columns: minmax(0, 1fr);
    }
  }
`;function d(){let e=s(),[t,n]=(0,c.useState)(`objects`),[i,d]=(0,c.useState)(`overview`),[f,p]=(0,c.useState)(``),m=[`archive`,`backups`,`documents`,`media`,`reports`,`snapshots`].map((e,t)=>({name:e,objects:(t+1)*128}));return(0,l.jsxs)(u,{"aria-labelledby":`fluid-showcase-title`,children:[(0,l.jsx)(`h2`,{id:`fluid-showcase-title`,children:e(`Lists and tabs`)}),(0,l.jsx)(`p`,{children:e(`Move through rows with the pointer or keyboard. Arrow keys focus tabs; Enter or Space opens them.`)}),(0,l.jsxs)(`div`,{className:`fluidExamples`,children:[(0,l.jsx)(`div`,{children:(0,l.jsx)(o,{horizontal:!0,currentTabOrPath:t,onTabClick:n,options:[{tabConfig:{id:`objects`,label:e(`Objects`)},content:e(`Browse and select stored objects.`)},{tabConfig:{id:`versions`,label:e(`Versions`)},content:e(`Review stored object versions.`)},{tabConfig:{id:`settings`,label:e(`Settings`)},content:e(`Manage bucket settings.`)}]})}),(0,l.jsx)(r,{density:`compact`,children:(0,l.jsx)(o,{horizontal:!0,variant:`subtle`,currentTabOrPath:i,onTabClick:d,options:[{tabConfig:{id:`overview`,label:e(`Overview`)},content:e(`Compact section tabs`)},{tabConfig:{id:`usage`,label:e(`Usage`)},content:e(`Storage and object usage`)},{tabConfig:{id:`activity`,label:e(`Activity`)},content:e(`Recent storage activity`)}]})})]}),(0,l.jsx)(a,{records:m,idField:`name`,entityName:e(`Example buckets`),customPaperHeight:`280px`,columns:[{label:e(`Name`),elementKey:`name`},{label:e(`Objects`),elementKey:`objects`}],itemActions:[{type:`view`,onClick:e=>p(e.name)}]}),(0,l.jsx)(`p`,{role:`status`,children:f})]})}export{d as default};