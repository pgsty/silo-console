const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./DeleteBucket-xeaVjmsk.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./store-BGxI9kEo.js","./lang-deC2ggFn.js","./mds-BO2rKL5Q.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./trash-Bfbr9RVQ.js","./i18n-Bv0O4wSF.js","./index-UVRc8OT4.js","./ModalPresence-OF_v2s_H.js","./index-BFo1l52q.css","./ConfirmDialog-DX63qcXf.js","./ModalBox-DT-uaPZI.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,d as n,f as r,r as i,t as a}from"./react-vendor-UL3KVrSx.js";import{i as o,n as s,o as c}from"./lang-deC2ggFn.js";import{P as l,_ as u,ot as d}from"./mds-BO2rKL5Q.js";import{D as f,T as p}from"./shared-vendor-BQfq49S_.js";import{i as ee,or as te,wr as ne}from"./store-BGxI9kEo.js";import{t as re}from"./trash-Bfbr9RVQ.js";import{t as m}from"./archive-CTc9EA80.js";import{t as h}from"./settings-J9nKBzCo.js";import{t as g}from"./folder-D6mn022e.js";import{t as ie}from"./Tabs-DlsZw24K.js";import{a as ae,n as oe}from"./i18n-Bv0O4wSF.js";import{t as se}from"./ModalPresence-OF_v2s_H.js";import{c as ce}from"./index-UVRc8OT4.js";import{t as _}from"./OverflowMenu-DC4Ttstq.js";import{t as v}from"./typography-DqmBZROV.js";import{g as y,n as b,o as x,p as S,r as C}from"./permissions-6ArR3S_m.js";import{t as w}from"./withSuspense-DTbtEWjP.js";import{n as le}from"./SecureComponent-BarZQrW7.js";import{t as T}from"./bucketMetadata-BAg0j77c.js";import{A as ue,K as de,d as fe,f as pe}from"./ConsoleKBar-DWQBCirp.js";var E=e(t()),D=(e,t,n)=>{let r=n=>t.hasPermission(e,n),i=!t.features.includes(`object-browser-only`)&&r(C[b.BUCKETS_ADMIN_VIEW]),a=`/buckets/${encodeURIComponent(e)}/admin`;return[{id:`objects`,label:o(`Objects`),to:`/browser/${encodeURIComponent(e)}`,permitted:r(S)},{id:`summary`,label:o(`Summary`),to:`${a}/summary`,permitted:i},{id:`events`,label:o(`Events`),to:`${a}/events`,permitted:i&&r([x.S3_GET_BUCKET_NOTIFICATIONS,x.S3_PUT_BUCKET_NOTIFICATIONS,x.S3_GET_ACTIONS,x.S3_PUT_ACTIONS])},{id:`replication`,label:o(`Replication`),to:`${a}/replication`,permitted:i&&t.distributedSetup&&!n&&r([x.S3_GET_REPLICATION_CONFIGURATION,x.S3_PUT_REPLICATION_CONFIGURATION,x.S3_GET_ACTIONS,x.S3_PUT_ACTIONS])},{id:`lifecycle`,label:o(`Lifecycle`),to:`${a}/lifecycle`,permitted:i&&t.distributedSetup&&r([x.S3_GET_LIFECYCLE_CONFIGURATION,x.S3_PUT_LIFECYCLE_CONFIGURATION,x.S3_GET_ACTIONS,x.S3_PUT_ACTIONS])},{id:`access`,label:o(`Access`),to:`${a}/access`,permitted:i&&r([x.ADMIN_GET_POLICY,x.ADMIN_LIST_USER_POLICIES,x.ADMIN_LIST_USERS])},{id:`anonymous`,label:o(`Anonymous`),to:`${a}/prefix`,permitted:i&&r([x.S3_GET_BUCKET_POLICY,x.S3_GET_ACTIONS])}].filter(e=>e.permitted)},O=a(),me=w(E.lazy(()=>d(()=>import(`./DeleteBucket-xeaVjmsk.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]),import.meta.url))),k=p.span`
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  a {
    color: var(--muted-foreground);
    text-decoration: none;
  }
  a:hover {
    color: var(--foreground);
  }
  > span:last-child {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
`,A=p.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  padding: 20px 24px 12px;
  @media (max-width: 1199px) {
    padding-inline: 16px;
  }
  @media (max-width: 767px) {
    padding-inline: 12px;
    .bucketIdentity {
      flex-basis: 100%;
    }
  }
  .bucketIdentity {
    min-width: 0;
    flex: 1;
  }
  h1 {
    ${v.title} margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    overflow-wrap: anywhere;
  }
  h1 svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
    color: var(--muted-foreground);
  }
  .bucketActions {
    display: flex;
    align-items: center;
    gap: 8px;
  }
`,j=p.div`
  ${v.caption}
  color: var(--muted-foreground);
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  row-gap: 4px;
  column-gap: 12px;
  margin-top: 8px;
  > span {
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }
  @media (min-width: 768px) {
    > span + span::before {
      content: "·";
      margin-right: 4px;
    }
  }
`,M=p.div`
  min-width: 0;
  > .tabs-container {
    height: auto;
  }
  > .tabs-container > .optionsContainer {
    padding: 0 24px 12px;
    border-bottom: 1px solid var(--border);
    @media (max-width: 767px) {
      padding-inline: 12px;
    }
  }
  > .tabs-container > .tabsPanels {
    padding: 0;
  }
`;function N({bucketName:e,bucketInfo:t,primaryAction:a,refreshAction:o,onRefresh:d,anonymous:p=!1,children:v}){let b=ae(),x=ce(),S=oe(),C=n(),w=r(),N=fe(),P=ee(ne),{listing:F,visit:I,objectRoute:L,refresh:R}=pe(),[z,B]=(0,E.useState)(null),V=F?.buckets?.find(t=>t.name===e),H=t?.name===e?t:void 0,U=V||H,W=V?F?.usageUpdatedAt:void 0,G=T(U,`size`,W),K=T(U,`objects`,W),q=H?.access||V?.access,J=V?.rw_access,he=q?b(q.toLowerCase()):J?.read?J.write?b(`Read and write`):b(`Read only`):J?.write?b(`Write only`):void 0,Y=U?.creation_date?f.fromISO(U.creation_date).setLocale(c(S)):void 0,X=D(e,N,P.enabled&&P.curSite),Z=X.find(e=>e.id===`objects`),Q=X.find(e=>e.id===`summary`),$=C.pathname.startsWith(`/browser/`),ge=$?Z?.to:C.pathname;(0,E.useEffect)(()=>{p||I(e),B(null)},[e,p,I]);let _e=[...!$&&Z?[{label:b(`Browse Bucket`),icon:(0,O.jsx)(g,{}),onClick:()=>w(L(e))}]:[],...$&&Q?[{label:b(`Configure Bucket`),icon:(0,O.jsx)(h,{}),onClick:()=>w(Q.to)}]:[],...!p&&le(e,y)?[{label:b(`Delete Bucket`),icon:(0,O.jsx)(re,{}),danger:!0,onClick:()=>B(e)}]:[]];return(0,O.jsxs)(O.Fragment,{children:[!p&&(0,O.jsx)(ue,{sx:{minHeight:56},label:(0,O.jsxs)(k,{children:[(0,O.jsx)(i,{to:`/buckets`,children:b(`Buckets`)}),(0,O.jsx)(`span`,{"aria-hidden":`true`,children:`/`}),(0,O.jsx)(`span`,{children:e})]}),help:!0}),(0,O.jsxs)(A,{children:[(0,O.jsxs)(`div`,{className:`bucketIdentity`,children:[(0,O.jsxs)(`h1`,{children:[(0,O.jsx)(m,{"aria-hidden":`true`}),e]}),!p&&(0,O.jsx)(j,{children:[Y?.isValid?(0,O.jsx)(`span`,{title:Y.toLocaleString(f.DATETIME_FULL),children:s(b(`Created {date}`),{date:Y.toLocaleString(f.DATE_MED)})}):null,he||null,G===void 0?null:te(G),K===void 0?null:s(b(`{count} objects`),{count:K.toLocaleString(S)}),V&&F?.usageUpdatedAt?(0,O.jsx)(de,{at:F.usageUpdatedAt,prefix:`Calculated`}):null].filter(e=>e!==null).map((e,t)=>(0,O.jsx)(`span`,{children:e},t))})]}),(0,O.jsxs)(`div`,{className:`bucketActions`,children:[a,!x&&(0,O.jsx)(u,{id:o?.id||`refresh-bucket-info`,label:o?.label||b(`Refresh`),disabled:o?.disabled,disabledReason:o?.disabledReason,onClick:o?.onClick||(()=>{d?.(),R()}),children:(0,O.jsx)(l,{})}),(0,O.jsx)(_,{label:b(`Bucket actions`),items:[...x?[o||{label:b(`Refresh`),onClick:()=>{d?.(),R()},icon:(0,O.jsx)(l,{})}]:[],..._e]})]})]}),p?v:(0,O.jsx)(M,{children:(0,O.jsx)(ie,{horizontal:!0,useRouteTabs:!0,currentTabOrPath:ge||``,options:X.map(({id:e,label:t,to:n})=>({tabConfig:{id:e,label:b(t),to:n}})),onTabClick:t=>w(t===Z?.to?L(e):t),routes:v})}),(0,O.jsx)(se,{open:z!==null,children:z!==null&&(0,O.jsx)(me,{deleteOpen:!0,selectedBucket:z,closeDeleteModalAndRefresh:e=>{B(null),e&&(R(),w(`/buckets`))}})})]})}export{N as t};