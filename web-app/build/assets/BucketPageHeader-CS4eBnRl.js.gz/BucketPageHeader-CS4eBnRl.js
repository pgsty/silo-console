const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./DeleteBucket-7E-iv0kN.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./store-C9Mm53c2.js","./lang-DMKw_tbl.js","./mds-Hm6-garf.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./trash-BB_JaxBi.js","./i18n-Drk-M_7X.js","./index-DALAjBvJ.js","./ModalPresence-EA3czOP5.js","./index-BFo1l52q.css","./ConfirmDialog-yG250qEO.js","./ModalBox-CgAJAa_u.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,d as n,f as r,r as i,t as a}from"./react-vendor-UL3KVrSx.js";import{i as o,n as s,o as c}from"./lang-DMKw_tbl.js";import{R as l,ct as u,x as ee}from"./mds-Hm6-garf.js";import{D as d,T as f}from"./shared-vendor-BQfq49S_.js";import{i as te,or as ne,wr as re}from"./store-C9Mm53c2.js";import{t as ie}from"./trash-BB_JaxBi.js";import{t as p}from"./archive-OuPIyv4o.js";import{n as m,t as h}from"./folder-Bp_xrdzR.js";import{t as g}from"./Tabs-mWs_oG0V.js";import{a as ae,n as oe}from"./i18n-Drk-M_7X.js";import{t as se}from"./ModalPresence-EA3czOP5.js";import{c as ce}from"./index-DALAjBvJ.js";import{t as _}from"./OverflowMenu-uk7R8BYl.js";import{t as v}from"./typography-BO7lxH25.js";import{g as y,n as b,o as x,p as S,r as C}from"./permissions-DtXShYFJ.js";import{t as w}from"./withSuspense-DTbtEWjP.js";import{n as le}from"./SecureComponent-CpdQFUTP.js";import{t as T}from"./bucketMetadata-BAg0j77c.js";import{A as ue,K as de,d as fe,f as pe}from"./ConsoleKBar-Dxo3YH9b.js";var E=e(t()),D=(e,t,n)=>{let r=n=>t.hasPermission(e,n),i=!t.features.includes(`object-browser-only`)&&r(C[b.BUCKETS_ADMIN_VIEW]),a=`/buckets/${encodeURIComponent(e)}/admin`;return[{id:`objects`,label:o(`Objects`),to:`/browser/${encodeURIComponent(e)}`,permitted:r(S)},{id:`summary`,label:o(`Summary`),to:`${a}/summary`,permitted:i},{id:`events`,label:o(`Events`),to:`${a}/events`,permitted:i&&r([x.S3_GET_BUCKET_NOTIFICATIONS,x.S3_PUT_BUCKET_NOTIFICATIONS,x.S3_GET_ACTIONS,x.S3_PUT_ACTIONS])},{id:`replication`,label:o(`Replication`),to:`${a}/replication`,permitted:i&&t.distributedSetup&&!n&&r([x.S3_GET_REPLICATION_CONFIGURATION,x.S3_PUT_REPLICATION_CONFIGURATION,x.S3_GET_ACTIONS,x.S3_PUT_ACTIONS])},{id:`lifecycle`,label:o(`Lifecycle`),to:`${a}/lifecycle`,permitted:i&&t.distributedSetup&&r([x.S3_GET_LIFECYCLE_CONFIGURATION,x.S3_PUT_LIFECYCLE_CONFIGURATION,x.S3_GET_ACTIONS,x.S3_PUT_ACTIONS])},{id:`access`,label:o(`Access`),to:`${a}/access`,permitted:i&&r([x.ADMIN_GET_POLICY,x.ADMIN_LIST_USER_POLICIES,x.ADMIN_LIST_USERS])},{id:`anonymous`,label:o(`Anonymous`),to:`${a}/prefix`,permitted:i&&r([x.S3_GET_BUCKET_POLICY,x.S3_GET_ACTIONS])}].filter(e=>e.permitted)},O=a(),me=w(E.lazy(()=>u(()=>import(`./DeleteBucket-7E-iv0kN.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]),import.meta.url))),k=f.span`
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  a {
    color: var(--muted-foreground);
    text-decoration: none;
  }
  a:hover {
    color: var(--foreground);
  }
  > span:last-child {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
`,A=f.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  padding: 20px 24px 12px;
  @media (max-width: 1199px) {
    padding-inline: 16px;
  }
  @media (max-width: 767px) {
    padding-inline: 12px;
    .bucketIdentity {
      flex-basis: 100%;
    }
  }
  .bucketIdentity {
    min-width: 0;
    flex: 1;
  }
  h1 {
    ${v.title} margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    overflow-wrap: anywhere;
  }
  h1 svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
    color: var(--muted-foreground);
  }
  .bucketActions {
    display: flex;
    align-items: center;
    gap: 8px;
  }
`,j=f.div`
  ${v.caption}
  color: var(--muted-foreground);
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  row-gap: 4px;
  column-gap: 12px;
  margin-top: 8px;
  > span {
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }
  @media (min-width: 768px) {
    > span + span::before {
      content: "·";
      margin-right: 4px;
    }
  }
`,M=f.div`
  min-width: 0;
  > .tabs-container {
    height: auto;
  }
  > .tabs-container > .optionsContainer {
    padding: 0 24px 12px;
    border-bottom: 1px solid var(--border);
    @media (max-width: 767px) {
      padding-inline: 12px;
    }
  }
  > .tabs-container > .tabsPanels {
    padding: 0;
  }
`;function N({bucketName:e,bucketInfo:t,primaryAction:a,refreshAction:o,onRefresh:u,anonymous:f=!1,children:v}){let b=ae(),x=ce(),S=oe(),C=n(),w=r(),N=fe(),P=te(re),{listing:F,visit:I,objectRoute:L,refresh:R}=pe(),[z,B]=(0,E.useState)(null),V=F?.buckets?.find(t=>t.name===e),H=t?.name===e?t:void 0,U=V||H,W=V?F?.usageUpdatedAt:void 0,G=T(U,`size`,W),K=T(U,`objects`,W),q=H?.access||V?.access,J=V?.rw_access,he=q?b(q.toLowerCase()):J?.read?J.write?b(`Read and write`):b(`Read only`):J?.write?b(`Write only`):void 0,Y=U?.creation_date?d.fromISO(U.creation_date).setLocale(c(S)):void 0,X=D(e,N,P.enabled&&P.curSite),Z=X.find(e=>e.id===`objects`),Q=X.find(e=>e.id===`summary`),$=C.pathname.startsWith(`/browser/`),ge=$?Z?.to:C.pathname;(0,E.useEffect)(()=>{f||I(e),B(null)},[e,f,I]);let _e=[...!$&&Z?[{label:b(`Browse Bucket`),icon:(0,O.jsx)(h,{}),onClick:()=>w(L(e))}]:[],...$&&Q?[{label:b(`Configure Bucket`),icon:(0,O.jsx)(m,{}),onClick:()=>w(Q.to)}]:[],...!f&&le(e,y)?[{label:b(`Delete Bucket`),icon:(0,O.jsx)(ie,{}),danger:!0,onClick:()=>B(e)}]:[]];return(0,O.jsxs)(O.Fragment,{children:[!f&&(0,O.jsx)(ue,{sx:{minHeight:56},label:(0,O.jsxs)(k,{children:[(0,O.jsx)(i,{to:`/buckets`,children:b(`Buckets`)}),(0,O.jsx)(`span`,{"aria-hidden":`true`,children:`/`}),(0,O.jsx)(`span`,{children:e})]}),help:!0}),(0,O.jsxs)(A,{children:[(0,O.jsxs)(`div`,{className:`bucketIdentity`,children:[(0,O.jsxs)(`h1`,{children:[(0,O.jsx)(p,{"aria-hidden":`true`}),e]}),!f&&(0,O.jsx)(j,{children:[Y?.isValid?(0,O.jsx)(`span`,{title:Y.toLocaleString(d.DATETIME_FULL),children:s(b(`Created {date}`),{date:Y.toLocaleString(d.DATE_MED)})}):null,he||null,G===void 0?null:ne(G),K===void 0?null:s(b(`{count} objects`),{count:K.toLocaleString(S)}),V&&F?.usageUpdatedAt?(0,O.jsx)(de,{at:F.usageUpdatedAt,prefix:`Calculated`}):null].filter(e=>e!==null).map((e,t)=>(0,O.jsx)(`span`,{children:e},t))})]}),(0,O.jsxs)(`div`,{className:`bucketActions`,children:[a,!x&&(0,O.jsx)(ee,{id:o?.id||`refresh-bucket-info`,label:o?.label||b(`Refresh`),disabled:o?.disabled,disabledReason:o?.disabledReason,onClick:o?.onClick||(()=>{u?.(),R()}),children:(0,O.jsx)(l,{})}),(0,O.jsx)(_,{label:b(`Bucket actions`),items:[...x?[o||{label:b(`Refresh`),onClick:()=>{u?.(),R()},icon:(0,O.jsx)(l,{})}]:[],..._e]})]})]}),f?v:(0,O.jsx)(M,{children:(0,O.jsx)(g,{horizontal:!0,useRouteTabs:!0,currentTabOrPath:ge||``,options:X.map(({id:e,label:t,to:n})=>({tabConfig:{id:e,label:b(t),to:n}})),onTabClick:t=>w(t===Z?.to?L(e):t),routes:v})}),(0,O.jsx)(se,{open:z!==null,children:z!==null&&(0,O.jsx)(me,{deleteOpen:!0,selectedBucket:z,closeDeleteModalAndRefresh:e=>{B(null),e&&(R(),w(`/buckets`))}})})]})}export{N as t};