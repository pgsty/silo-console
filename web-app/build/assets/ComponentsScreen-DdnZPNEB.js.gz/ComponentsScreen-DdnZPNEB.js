const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./FluidHoverShowcase-AC9ua2Bm.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./mds-B7pDlMNU.js","./DataTable-DZ2kzmOs.js","./circle-slash-BygNhiUP.js","./hard-drive-B4CIRsJz.js","./share-2-CjqMO8e6.js","./pencil-Cg37lTQM.js","./shield-check-q7jetnYS.js","./trash-CiPD8hS_.js","./circle-check--s-qzPFr.js","./download-m6916hdM.js","./terminal-D4eplTGJ.js","./Checkbox-AyDyii8V.js","./console-vendor-I3rSB1nD.js","./useTableLayout-ToMNXs38.js","./Tabs-vSudT0qV.js","./i18n-CKF7kMSP.js","./lang-C_0WK4Bf.js","./language-zh-CIVKhjrX.js","./language-fr-CxBkbLZx.js","./language-de-DLIf7DHQ.js","./language-ru-Dd01s8En.js","./language-es-mkgTXTf1.js","./language-pt-BR-i67To0AD.js","./language-ja-cj1U2eJV.js","./language-ar-Bk4qS7_3.js","./language-tr-DQYqQbrS.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,r as n,t as r}from"./react-vendor-UL3KVrSx.js";import{T as i}from"./shared-vendor-BQfq49S_.js";import{Dr as a,n as o}from"./store-HGwDj7kv.js";import{i as s,n as c}from"./lang-C_0WK4Bf.js";import{$ as l,G as u,H as d,K as f,T as p,a as m,et as h,h as g,i as ee,l as _,nt as v,o as y,ot as b,q as x,rt as S,s as C,tt as w}from"./mds-B7pDlMNU.js";import{t as T}from"./database-BlKx18pM.js";import{t as te}from"./pencil-Cg37lTQM.js";import{t as E}from"./trash-CiPD8hS_.js";import{t as D}from"./archive-Cu6uIv3W.js";import{t as ne}from"./info-Cg15zJKq.js";import{t as O}from"./Checkbox-AyDyii8V.js";import{n as k,t as A}from"./HelpBox-DJt8t65o.js";import{t as re}from"./SectionTitle-C1UrSNqk.js";import{t as j}from"./ModalBox-CSre1z64.js";import{t as M}from"./CommentBox-B0SvN_qu.js";import{t as N}from"./Autocomplete-CV9PhuoR.js";import{a as P,t as ie}from"./i18n-CKF7kMSP.js";import{t as ae}from"./preload-helper-CRzLMJPS.js";import{i as oe,n as se,r as ce,t as F}from"./index-DZPdmjev.js";import{t as le}from"./OverflowMenu-Dm5NOjiR.js";import{t as I}from"./typography-JApMsY3F.js";import{t as L}from"./StatusBadge-BTgl2fcD.js";import{t as ue}from"./CliEquivalent-BV0MzDFR.js";import{t as de}from"./ConfirmDialog-rMIwsAIt.js";import{A as fe,H as pe,J as R,K as z,U as B,V as me,W as V,X as he,Y as H,Z as U,q as ge}from"./ConsoleKBar-C4QsHk9C.js";var W=e(t()),G=r(),K=i.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 280px), 1fr));
  gap: var(--space-16);
`,q=i.div`
  padding: var(--space-20);
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  color: var(--foreground);
  min-width: 0;
  h2 {
    ${S(`title`)} margin: 0 0 var(--space-16);
  }
`,_e=i.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--space-8);
`,ve=i.div`
  ${S(`caption`)}
  padding: var(--space-12) var(--space-4);
  text-align: center;
  border-radius: var(--radius-control);
  box-shadow: var(--shadow-1);
  background: ${({$color:e})=>e};
`,ye=i.div`
  ${({$role:e})=>S(e)}
  padding: var(--space-8) 0;
  & + & {
    border-top: 1px solid var(--border);
  }
`,be=i.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--space-24);
  padding: var(--space-16) 0;
`,xe=i(l)`
  ${S(`caption`)}
  padding: var(--space-16) var(--space-4);
  border-radius: var(--radius-control);
  text-align: center;
`,Se=i.div`
  ${({$roleStyle:e})=>e}
  display: flex;
  align-items: center;
  height: var(--control-height);
  padding: 0 var(--control-padding);
  gap: var(--gap);
  border-radius: var(--radius-control);
  background: var(--hover);
  svg {
    width: var(--icon-size);
    height: var(--icon-size);
    color: var(--muted-foreground);
  }
`,J=()=>{let{compact:e,type:t,controlHeight:n}=v(),r=P();return(0,G.jsx)(`div`,{children:(0,G.jsxs)(Se,{$roleStyle:t.body,children:[(0,G.jsx)(D,{}),(0,G.jsx)(`span`,{children:r(e?`Compact density`:`Default density`)}),(0,G.jsx)(`span`,{className:`silo-num`,children:c(r(`{height} px`),{height:n})})]})})},Ce=i.div`
  margin-top: var(--space-12);
  padding: var(--space-4);
  border-radius: var(--radius-control);
  background: var(--muted);
`,we=i.div`
  width: 28px;
  height: 28px;
  border-radius: var(--radius-control);
  background: var(--foreground);
  transform: translateX(${({$moved:e})=>e?`140px`:`0`});
  opacity: ${({$moved:e})=>e?.6:1};
  transition:
    transform var(--dur-${({$tier:e})=>e})
      var(--ease-${({$tier:e})=>e}),
    opacity var(--dur-${({$tier:e})=>e})
      var(--ease-${({$tier:e})=>e});
  @media (prefers-reduced-motion: reduce) {
    transform: none;
  }
`,Te=i.button`
  ${S(`body`,{weight:`semibold`})}
  padding: var(--space-8) var(--space-12);
  border: none;
  border-radius: var(--radius-control);
  color: var(--foreground);
  background: var(--tint);
  cursor: pointer;
  &:hover {
    background: var(--tint-hover);
  }
`,Y=({tier:e,label:t})=>{let[n,r]=(0,W.useState)(!1),i=P();return(0,G.jsxs)(`div`,{children:[(0,G.jsx)(Te,{type:`button`,"aria-pressed":n,onClick:()=>r(!n),children:i(t)}),(0,G.jsx)(Ce,{children:(0,G.jsx)(we,{"data-motion-tier":e,$tier:e,$moved:n})})]})},Ee={display:s(`Display type`),title:s(`Title type`),subtitle:s(`Subtitle type`),body:s(`Body type`),caption:s(`Caption type`),micro:s(`Micro type`)},De=()=>{let e=P();return(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(K,{children:[`light`,`dark`].map(t=>(0,G.jsxs)(q,{style:oe(t===`light`?ce:se),children:[(0,G.jsx)(`h2`,{children:e(t===`light`?`Light palette`:`Dark palette`)}),(0,G.jsx)(_e,{children:Array.from({length:8},(t,n)=>(0,G.jsx)(ve,{$color:`var(--surface-${n+1})`,children:c(e(`Surface {level}`),{level:n+1})},n))}),(0,G.jsx)(`p`,{style:{marginTop:`var(--space-12)`,color:`var(--foreground)`},children:e(`Primary text`)}),(0,G.jsx)(`p`,{style:{color:`var(--muted-foreground)`},children:e(`Secondary text`)})]},t))}),(0,G.jsxs)(K,{children:[(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Typography roles`)}),Object.keys(b).map(t=>(0,G.jsxs)(ye,{$role:t,children:[e(Ee[t]),` `,(0,G.jsxs)(`span`,{className:`silo-num`,children:[b[t].size,`/`,b[t].line]})]},t))]}),(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Shadow ladder`)}),(0,G.jsx)(be,{children:Array.from({length:8},(e,t)=>(0,G.jsx)(xe,{offset:t,shadowLevel:t+1,children:t+1},t))}),(0,G.jsx)(`h2`,{children:e(`Density comparison`)}),(0,G.jsx)(w,{children:(0,G.jsx)(J,{})}),(0,G.jsx)(`div`,{style:{height:`var(--space-8)`}}),(0,G.jsx)(w,{density:`compact`,children:(0,G.jsx)(J,{})})]})]}),(0,G.jsxs)(q,{children:[(0,G.jsx)(`h2`,{children:e(`Motion tiers`)}),(0,G.jsxs)(K,{children:[(0,G.jsx)(Y,{tier:`fast`,label:s(`Fast · 80 ms`)}),(0,G.jsx)(Y,{tier:`moderate`,label:s(`Moderate · 160 ms`)}),(0,G.jsx)(Y,{tier:`slow`,label:s(`Slow · 240 ms`)})]})]})]})},Oe=i.section`
  display: grid;
  gap: 16px;
  padding: 24px;
  border-radius: 12px;
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  h2 {
    ${S(`title`)} margin: 0;
  }
  h3 {
    ${S(`subtitle`)} margin: 0;
  }
  .control-row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 12px;
  }
  .control-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 16px;
  }
  .inputItem {
    min-width: 0;
  }
  .inputLabel {
    margin-inline-end: 8px;
  }
  .inputLabel > span {
    min-width: 0;
  }
`,ke=()=>{let e=P(),[t,n]=(0,W.useState)(!0),[r,i]=(0,W.useState)(`one`),[a,o]=(0,W.useState)(`one`),[s,c]=(0,W.useState)(null),[l,u]=(0,W.useState)(!1),[g,v]=(0,W.useState)(!1),[b,S]=(0,W.useState)(!1),T=[{label:e(`Default`),value:`one`},{label:e(`Compact`),value:`two`}];return(0,G.jsx)(h,{level:3,children:(0,G.jsxs)(Oe,{id:`control-craft`,children:[(0,G.jsx)(`h2`,{children:e(`Control craft`)}),(0,G.jsx)(`p`,{children:e(`Hover, press or use Tab to inspect each control. All changes here are local demos.`)}),(0,G.jsx)(`h3`,{children:e(`Buttons and loading`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(f,{id:`press-80`,variant:`primary`,sx:{width:80},label:e(`Save`)}),(0,G.jsx)(f,{id:`press-400`,variant:`primary`,sx:{width:400,maxWidth:`100%`},label:e(`Create bucket`)}),(0,G.jsx)(f,{id:`control-secondary`,variant:`secondary`,label:e(`Secondary`)}),(0,G.jsx)(f,{id:`control-outline`,variant:`outline`,label:e(`Outline`)}),(0,G.jsx)(f,{id:`control-ghost`,variant:`ghost`,label:e(`Ghost`)}),(0,G.jsx)(f,{id:`control-danger`,variant:`danger`,label:e(`Delete`)}),(0,G.jsx)(f,{id:`control-disabled`,disabled:!0,disabledReason:e(`Select an object to download.`),label:e(`Disabled`)}),(0,G.jsx)(f,{id:`control-loading`,loading:!0,label:e(`Loading`)}),(0,G.jsx)(f,{id:`control-toggle-loading`,loading:b,label:e(`Save changes`),onClick:()=>{S(!0),setTimeout(()=>S(!1),1500)}}),(0,G.jsx)(p,{"aria-label":e(`Refresh`),children:(0,G.jsx)(d,{})})]}),(0,G.jsxs)(w,{density:`compact`,children:[(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(f,{id:`control-compact`,variant:`primary`,label:e(`Compact`)}),(0,G.jsx)(_,{id:`control-compact-input`,label:e(`Compact`),placeholder:e(`Name`)})]}),(0,G.jsx)(`div`,{id:`control-compact-help`,children:(0,G.jsx)(A,{iconComponent:(0,G.jsx)(ne,{}),title:e(`Compact`),help:e(`Usage is calculated by the server.`)})})]}),(0,G.jsx)(`h3`,{children:e(`Fields and validation`)}),(0,G.jsxs)(`div`,{className:`control-grid`,children:[(0,G.jsx)(_,{id:`control-input`,label:e(`Name`),placeholder:e(`Name`)}),(0,G.jsx)(_,{id:`control-password`,type:`password`,label:e(`Password`),defaultValue:`example`}),(0,G.jsx)(_,{id:`control-error`,label:e(`Name`),error:e(`A name is required.`)}),(0,G.jsx)(_,{id:`control-disabled-input`,label:e(`Disabled`),disabled:!0,value:e(`Unavailable`)}),(0,G.jsx)(_,{id:`control-disabled-empty`,label:e(`Disabled`),disabled:!0,placeholder:e(`Name`)}),(0,G.jsx)(_,{id:`control-number`,type:`number`,label:e(`Capacity`),defaultValue:20}),(0,G.jsx)(C,{id:`control-select`,label:e(`Density`),value:a,options:T,onChange:o}),(0,G.jsx)(C,{id:`control-disabled-select`,label:e(`Disabled`),value:`one`,options:T,onChange:()=>{},disabled:!0}),(0,G.jsx)(C,{id:`control-error-select`,label:e(`Density`),options:T,onChange:()=>{},error:e(`A name is required.`),placeholder:e(`Select`)}),(0,G.jsx)(C,{id:`control-disabled-placeholder`,label:e(`Disabled`),options:T,onChange:()=>{},disabled:!0,placeholder:e(`Select`)}),(0,G.jsx)(N,{id:`control-autocomplete`,label:e(`Search`),placeholder:e(`Select`),value:a,options:T,onChange:o}),(0,G.jsx)(N,{id:`control-error-autocomplete`,label:e(`Search`),placeholder:e(`Select`),options:T,onChange:()=>{},error:e(`A name is required.`)}),(0,G.jsx)(N,{id:`control-disabled-autocomplete`,label:e(`Disabled`),placeholder:e(`Select`),options:T,onChange:()=>{},disabled:!0}),(0,G.jsx)(M,{id:`control-disabled-textarea`,label:e(`Disabled`),disabled:!0,placeholder:e(`Description`)}),(0,G.jsx)(M,{id:`control-textarea`,label:e(`Description`),placeholder:e(`Description`)})]}),(0,G.jsx)(`h3`,{children:e(`Selection controls`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(O,{id:`control-checkbox`,label:e(`Enabled`),checked:t,onChange:e=>n(e.target.checked)}),(0,G.jsx)(O,{id:`control-disabled-checkbox`,label:e(`Disabled`),disabled:!0,checked:!0,readOnly:!0}),(0,G.jsx)(U,{id:`control-switch`,label:e(`Enabled`),checked:t,onChange:e=>n(e.target.checked)}),(0,G.jsx)(U,{id:`control-disabled-switch`,label:e(`Disabled`),checked:!0,disabled:!0}),(0,G.jsx)(he,{id:`control-radio`,name:`control-radio`,label:e(`Density`),currentValue:r,selectorOptions:T,onChange:e=>i(e.target.value)})]}),(0,G.jsx)(`h3`,{children:e(`Status and feedback`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[(0,G.jsx)(y,{id:`control-tag`,label:e(`Enabled`),color:`ok`}),(0,G.jsx)(y,{id:`control-tag-dot`,label:e(`Warning`),color:`warn`,variant:`dot`}),(0,G.jsx)(L,{tone:`danger`,label:e(`Offline`)}),(0,G.jsx)(L,{tone:`info`,label:e(`Built-in`),dot:!1}),(0,G.jsx)(x,{tooltip:e(`First tooltip`),children:(0,G.jsx)(f,{id:`control-tip-one`,label:e(`First tooltip`)})}),(0,G.jsx)(x,{tooltip:e(`Second tooltip`),children:(0,G.jsx)(f,{id:`control-tip-two`,label:e(`Second tooltip`)})})]}),(0,G.jsx)(k,{title:e(`Information`),tone:`info`,children:e(`Usage is calculated by the server.`)}),(0,G.jsx)(k,{title:e(`Warning`),tone:`warning`,contrast:`high`,children:e(`Above the 85% warning threshold`)}),(0,G.jsx)(m,{value:65,variant:`determinate`,progressLabel:!0,notificationLabel:e(`Progress`)}),(0,G.jsx)(m,{notificationLabel:e(`Loading`)}),(0,G.jsx)(`h3`,{children:e(`Dialogs`)}),(0,G.jsxs)(`div`,{className:`control-row`,children:[[`sm`,`lg`,`xl`].map(t=>(0,G.jsx)(f,{id:`control-dialog-${t}`,label:`${e(`Open Dialog`)} · ${t===`sm`?`400`:t===`lg`?`540`:`880`}`,onClick:()=>c(t)},t)),(0,G.jsx)(f,{id:`control-snackbar`,label:e(`Show notification`),onClick:()=>v(!0)})]}),(0,G.jsxs)(j,{open:s!==null,size:s||`lg`,title:e(`Dialog controls`),onClose:()=>c(null),children:[(0,G.jsxs)(`div`,{className:`control-grid`,style:{display:`grid`,gap:16},children:[(0,G.jsx)(_,{id:`dialog-name`,label:e(`Name`)}),(0,G.jsx)(C,{id:`dialog-select`,label:e(`Density`),value:a,options:T,onChange:o})]}),(0,G.jsxs)(`div`,{className:`control-row`,style:{display:`flex`,flexWrap:`wrap`,gap:8,justifyContent:`flex-end`,marginTop:24},children:[(0,G.jsx)(f,{id:`control-nested-open`,label:e(`Nested dialog`),onClick:()=>u(!0)}),(0,G.jsx)(f,{id:`control-dialog-cancel`,label:e(`Cancel`),onClick:()=>c(null)}),(0,G.jsx)(f,{id:`control-dialog-save`,variant:`primary`,label:e(`Save`),onClick:()=>c(null)})]}),(0,G.jsx)(j,{open:l,size:`sm`,title:e(`Nested dialog`),onClose:()=>u(!1),children:(0,G.jsx)(f,{id:`control-nested-close`,variant:`primary`,label:e(`Close`),onClick:()=>u(!1)})})]}),(0,G.jsx)(ee,{open:g,onClose:()=>v(!1),message:e(`Demo action completed.`),closeButton:!0})]})})},Ae=(0,W.lazy)(()=>ae(()=>import(`./FluidHoverShowcase-AC9ua2Bm.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]),import.meta.url)),X=i.div`
  color: var(--silo-text);
  display: grid;
  gap: var(--silo-space-24);
  margin-bottom: var(--silo-space-32);
  h1 {
    ${I.title} margin: 0 0 var(--silo-space-8);
  }
  h2 {
    ${I.section} margin: 0 0 var(--silo-space-16);
  }
  p {
    ${I.body} color: var(--silo-text-secondary);
    margin: 0;
  }
  a {
    color: var(--silo-primary);
  }
  #root & button.button-regular,
  #root & button.button-callAction {
    border-radius: var(--silo-radius-button);
    letter-spacing: normal;
  }
`,je=i.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--silo-space-16);
  @media (max-width: ${F.lg-1}px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: ${F.md-1}px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Z=i.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--silo-space-16);
  @media (max-width: ${F.md-1}px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,Q=i.div`
  min-width: 0;
  padding: var(--silo-space-20);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  border-radius: var(--silo-radius-card);
`,$=i.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--silo-space-12);
  & + & {
    margin-top: var(--silo-space-16);
  }
`,Me=i.span`
  ${I.small}
  display: inline-flex;
  align-items: center;
  padding: var(--silo-space-8) var(--silo-space-12);
  border: 1px dashed var(--silo-border-strong);
  border-radius: var(--silo-radius-input);
  color: var(--silo-text-muted);
`,Ne=()=>{let[e,t]=(0,W.useState)(!1),[r,i]=(0,W.useState)(!0),[c,l]=(0,W.useState)(``),[p]=(0,W.useState)(()=>new Date(Date.now()-18e4).toISOString()),m=o(),h=P();return(0,W.useEffect)(()=>{m(a(`components`))},[]),(0,G.jsxs)(W.Fragment,{children:[(0,G.jsx)(fe,{label:s(`Components`),help:!0}),(0,G.jsxs)(g,{sx:{padding:24,[`@media (max-width: ${F.lg-1}px)`]:{padding:16},[`@media (max-width: ${F.md-1}px)`]:{padding:12}},children:[(0,G.jsxs)(X,{children:[(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h1`,{children:h(`SILO primitives`)}),(0,G.jsx)(`p`,{children:h(`Shared building blocks for storage, identity and monitoring.`)})]}),(0,G.jsx)(ke,{}),(0,G.jsx)(De,{}),(0,G.jsx)(W.Suspense,{fallback:null,children:(0,G.jsx)(Ae,{})}),(0,G.jsxs)(je,{children:[(0,G.jsx)(V,{label:h(`Capacity`),icon:(0,G.jsx)(T,{}),value:`7.2`,unit:`TiB`,subline:h(`Healthy capacity`),progress:{value:.72},footer:(0,G.jsx)(z,{at:p,prefix:`Calculated`})}),(0,G.jsx)(V,{label:h(`Capacity warning`),icon:(0,G.jsx)(T,{}),value:`8.7`,unit:`TiB`,subline:h(`Above the 85% warning threshold`),progress:{value:.87}}),(0,G.jsx)(V,{label:h(`Capacity critical`),icon:(0,G.jsx)(T,{}),value:`9.6`,unit:`TiB`,subline:h(`Above the 95% critical threshold`),progress:{value:.96}}),(0,G.jsx)(V,{label:h(`Buckets`),icon:(0,G.jsx)(D,{}),value:`28`,subline:h(`Usage is calculated by the server.`),footer:(0,G.jsx)(n,{to:`/buckets`,children:h(`View buckets`)})})]}),(0,G.jsxs)(Z,{children:[(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:h(`Status and values`)}),(0,G.jsxs)($,{children:[(0,G.jsx)(L,{tone:`success`,label:h(`Online`)}),(0,G.jsx)(L,{tone:`warning`,label:h(`Healing`)}),(0,G.jsx)(L,{tone:`danger`,label:h(`Offline`)}),(0,G.jsx)(L,{tone:`neutral`,label:h(`Disabled`)}),(0,G.jsx)(L,{tone:`info`,label:h(`Built-in`),dot:!1})]}),(0,G.jsxs)($,{children:[(0,G.jsx)(H,{label:h(`Versioning`),value:(0,G.jsx)(L,{tone:r?`success`:`neutral`,label:h(r?`Enabled`:`Disabled`)}),onEdit:()=>i(e=>!e)}),(0,G.jsx)(H,{label:h(`Objects`),value:(0,G.jsx)(`span`,{className:`silo-num`,children:`1,248`})})]})]}),(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:h(`Freshness and actions`)}),(0,G.jsxs)($,{children:[(0,G.jsx)(z,{at:p}),(0,G.jsx)(z,{}),(0,G.jsx)(z,{at:p,pending:!0})]}),(0,G.jsxs)($,{children:[(0,G.jsx)(ge,{reason:h(`Select an object to inspect its details.`),children:(0,G.jsx)(Me,{children:h(`Object details`)})}),(0,G.jsx)(le,{items:[{label:h(`Delete`),icon:(0,G.jsx)(E,{}),danger:!0,onClick:()=>l(h(`Demo action completed.`))},{label:h(`Refresh`),icon:(0,G.jsx)(d,{}),onClick:()=>l(h(`Demo action completed.`))},{label:h(`Edit`),icon:(0,G.jsx)(te,{}),onClick:()=>l(h(`Demo action completed.`))},{label:h(`Download`),disabled:!0,disabledReason:h(`Select an object to download.`),onClick:()=>{}}]})]}),(0,G.jsx)(`p`,{role:`status`,children:c})]})]}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{children:h(`Empty and unavailable states`)}),(0,G.jsxs)(Z,{children:[(0,G.jsx)(Q,{children:(0,G.jsx)(R,{icon:(0,G.jsx)(D,{}),title:h(`No buckets yet`),description:h(`Create a bucket to start storing objects.`),docsUrl:`https://silo.pgsty.com/`,action:(0,G.jsx)(f,{id:`showcase-create-bucket`,type:`button`,variant:`callAction`,label:h(`Create bucket`),onClick:()=>l(h(`Demo action completed.`))})})}),(0,G.jsx)(Q,{children:(0,G.jsx)(R,{compact:!0,icon:(0,G.jsx)(D,{}),title:h(`No matching objects`),description:h(`Try a different name or clear the search filter.`)})}),(0,G.jsx)(Q,{children:(0,G.jsx)(B,{title:h(`Metrics are unavailable`),description:h(`Connect a Prometheus endpoint to view monitoring metrics.`),docsUrl:`https://silo.pgsty.com/`})}),(0,G.jsx)(Q,{children:(0,G.jsx)(pe,{required:[`admin:ServerInfo`,`s3:ListAllMyBuckets`]})})]})]}),(0,G.jsxs)(Z,{children:[(0,G.jsxs)(Q,{children:[(0,G.jsx)(`h2`,{children:h(`Loading rows`)}),(0,G.jsx)(me,{columns:3})]}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{children:h(`Command preview`)}),(0,G.jsx)(ue,{alias:`silo`,commands:[`mcli ls ALIAS`,`mcli version info ALIAS/demo-data`]})]})]})]}),(0,G.jsxs)(u,{container:!0,children:[(0,G.jsx)(u,{item:!0,xs:12,children:(0,G.jsx)(re,{children:h(`Confirm Dialogs`)})}),(0,G.jsx)(u,{item:!0,xs:12,children:(0,G.jsx)(`p`,{children:h(`Used to confirm a non-idempotent action.`)})}),(0,G.jsxs)(u,{item:!0,xs:12,children:[(0,G.jsx)(f,{id:`open-dialog-test`,type:`button`,variant:`regular`,onClick:()=>{t(!0)},label:h(`Open Dialog`)}),(0,G.jsx)(de,{destructive:!0,title:h(`Delete Bucket`),confirmText:h(`Delete`),isOpen:e,titleIcon:(0,G.jsx)(E,{}),isLoading:!1,onConfirm:()=>{t(!1)},onClose:()=>{t(!1)},confirmationContent:(0,G.jsxs)(W.Fragment,{children:[ie(h(`Are you sure you want to delete bucket {bucket}?`),{bucket:(0,G.jsx)(`b`,{children:`bucket`})}),(0,G.jsx)(`br`,{}),h(`A bucket can only be deleted if it's empty.`)]})})]})]})]})]})};export{Ne as default};