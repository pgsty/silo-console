import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,t as n}from"./react-vendor-UL3KVrSx.js";import{i as r}from"./lang-deC2ggFn.js";import{Y as i}from"./mds-BO2rKL5Q.js";import{T as a}from"./shared-vendor-BQfq49S_.js";import{t as o}from"./ModalBox-DT-uaPZI.js";import{a as s}from"./i18n-Bv0O4wSF.js";var c=e(t()),l=n(),u=a.dl`
  ${i(`body`)}
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 8px 20px;
  margin: 16px 0 0;
  dt {
    font-family: var(--font-mono);
    font-variant-numeric: tabular-nums;
  }
  dd {
    margin: 0;
    color: var(--muted-foreground);
  }
  @media (max-width: 600px) {
    grid-template-columns: 1fr;
    gap: 4px;
    dd {
      margin-bottom: 8px;
    }
  }
`,d=[[`↑ / ↓ · Home / End`,r(`Move through objects`)],[`PageUp / PageDown`,r(`Move one visible page`)],[`Enter`,r(`Open folder or object details`)],[`Backspace / Alt+↑`,r(`Go to parent folder within this bucket`)],[`Space`,r(`Toggle object selection`)],[`Shift+↑ / Shift+↓ · Shift+click`,r(`Extend selection range`)],[`Ctrl/⌘+click`,r(`Toggle object selection`)],[`Ctrl/⌘+A`,r(`Select all objects on the current page`)],[`Escape`,r(`Close menu, clear selection or close details`)],[`/`,r(`Focus object filter`)],[`p`,r(`Preview the focused object when available`)],[`Shift+F10 / ContextMenu`,r(`Open object actions`)],[`?`,r(`Keyboard shortcuts`)]];function f({onClose:e}){let t=s();return(0,l.jsxs)(o,{open:!0,title:t(`Keyboard shortcuts`),closeLabel:t(`Close`),onClose:e,size:`lg`,children:[(0,l.jsx)(`p`,{children:t(`Object browser shortcuts are available while browsing objects. They pause while typing or using a dialog.`)}),(0,l.jsx)(u,{children:d.map(([e,n])=>(0,l.jsxs)(c.Fragment,{children:[(0,l.jsx)(`dt`,{children:e}),(0,l.jsx)(`dd`,{children:t(n)})]},e))})]})}export{f as default};