import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{N as t,P as n,t as r}from"./react-vendor-UL3KVrSx.js";import{$ as i,G as a,Q as o,W as s,Y as c,k as l,q as u,v as d,x as f}from"./mds-Hm6-garf.js";import{T as p}from"./shared-vendor-BQfq49S_.js";var m=e(n()),h=e(t()),g=r(),_=[],v=(0,m.createContext)(null),y=new WeakMap,b=(e,t)=>{let n=y.get(e)?.current;for(;n;){if(n===t)return!0;n=y.get(n)?.current}return!1},x=null,S=()=>_.forEach((e,t)=>{let n=e.closest(`.modalBoxMain`);n&&(n.style.zIndex=String(1200+t*2));let r=e.querySelector(`.closeModalButton`);r&&(r.id=t===_.length-1&&!e.querySelector(`#close:not(.closeModalButton)`)?`close`:`${e.getAttribute(`aria-labelledby`)}-close`)}),C=`button:not(:disabled),a[href],input:not(:disabled):not([type="hidden"]),select:not(:disabled),textarea:not(:disabled),[tabindex]:not([tabindex="-1"])`,w=p.div`
  ${i(`body`)}
  position: fixed;
  inset: 0;
  z-index: 1200;
  display: flex;
  align-items: center;
  justify-content: center;
  pointer-events: ${({$shown:e})=>e?`auto`:`none`};
  background: ${({$overlay:e})=>e?`rgb(0 0 0 / .4)`:`transparent`};
  opacity: ${({$shown:e})=>+!!e};
  transition: opacity
    ${({$shown:e})=>e?`var(--dur-slow,240ms) var(--ease-slow,ease-out)`:`160ms var(--ease-exit,ease-in)`};
  .modalContainer {
    ${i(`body`)} box-sizing: border-box;
    width: calc(100% - 32px);
    max-width: ${({$width:e})=>typeof e==`number`?`${e}px`:e};
    max-height: calc(100dvh - 32px);
    border-radius: 16px;
    padding: 24px;
    display: flex;
    flex-direction: column;
    outline: none;
    transform: ${({$shown:e})=>e?`scale(1)`:`scale(.97)`};
    transition: transform
      ${({$shown:e})=>e?`var(--dur-slow,240ms) var(--ease-slow,ease-out)`:`160ms var(--ease-exit,ease-in)`};
  }
  .modalTitleBar {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 20px;
  }
  .title {
    ${i(`title`)} margin: 0;
    color: var(--foreground);
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .titleIcon {
    display: inline-flex;
    color: ${({$iconColor:e})=>e===`delete`?`var(--destructive)`:e===`accept`?`var(--success)`:`var(--foreground)`};
  }
  .titleIcon > svg {
    width: 20px;
    height: 20px;
    fill: currentColor;
    flex-shrink: 0;
  }
  .closeModalButton {
    @media (pointer: coarse) { width: 40px; height: 40px; }
    margin: -6px -6px -6px 0;
  }
  .dialogContent {
    min-height: 0;
    overflow: auto;
    /* Keep the 2px outline plus 1px offset inside the scroll clip without
       moving content away from the panel's logical 24px padding. */
    margin: -3px;
    padding: 3px;
  }
  @media (max-width: 575px) {
    .modalContainer { width: calc(100% - 24px); max-height: calc(100dvh - 24px); padding: 16px; }
    .title { min-width: 0; overflow-wrap: anywhere; }
  }
  @media (prefers-reduced-motion: reduce) {
    .modalContainer {
      transform: none;
      transition: none;
    }
    transition-duration: var(--dur-fast, 80ms);
  }
  ${({$inline:e})=>e&&`
    position: relative; inset: auto; z-index: auto; background: transparent;
    opacity: 1; pointer-events: auto; display: block;
    .modalContainer { width: 100%; max-width: none; max-height: none; border-radius: 0; padding: 16px; transform: none; box-shadow: none; background: transparent; }
    .modalTitleBar { margin-bottom: 12px; }
    .dialogContent { overflow: visible; }
  `}
  ${({$sx:e})=>e}
`,T=({onClose:e,inline:t,restoreFocusTo:n,open:r,title:i,children:p,widthLimit:T=!0,titleIcon:E,backgroundOverlay:D=!0,customMaxWidth:O,sx:k,size:A=`lg`,closeLabel:j,iconColor:M=`default`})=>{let N=u(),P=r&&N,F=(0,m.useRef)(t);F.current=t;let I=(0,m.useRef)(n);I.current=n;let L=P&&!t,R=(0,m.useRef)(null),z=(0,m.useRef)(null),B=(0,m.useContext)(v),[V]=(0,m.useState)(()=>t===void 0?null:document.createElement(`div`));(0,m.useLayoutEffect)(()=>{if(V)return(t?R.current:document.body)?.appendChild(V),z.current?.isConnected&&z.current.focus({preventScroll:!0}),z.current=null,()=>{z.current=document.activeElement instanceof HTMLElement&&V.contains(document.activeElement)?document.activeElement:null,V.remove()}},[V,t]);let H=d(),{compact:U}=o(),W=(0,m.useId)(),G=(0,m.useRef)(null),K=(0,m.useRef)(null);(0,m.useLayoutEffect)(()=>{K.current&&y.set(K.current,B)});let q=(0,m.useRef)(e);q.current=e;let[J,Y]=(0,m.useState)(P),[X,Z]=(0,m.useState)(!1);if((0,m.useLayoutEffect)(()=>{P&&Y(!0)},[P]),(0,m.useLayoutEffect)(()=>{G.current&&(G.current.inert=!P)},[P,J]),(0,m.useEffect)(()=>{if(!J)return;if(P){let e=requestAnimationFrame(()=>Z(!0));return()=>cancelAnimationFrame(e)}Z(!1);let e=setTimeout(()=>Y(!1),160);return()=>clearTimeout(e)},[P,J]),(0,m.useEffect)(()=>{let e=K.current;if(!L||!J||!e)return;let t=document.activeElement instanceof HTMLElement?document.activeElement:null;_.length||(x=document.body.style.overflow,document.body.style.overflow=`hidden`);let n=_.findIndex(t=>b(t,e));_.splice(n<0?_.length:n,0,e),a(_.length),S();let r=t=>{if(!t)return!1;if(e.contains(t))return!0;let n=t.closest(`[data-silo-popup]`)?.dataset.popupAnchor;return!!n&&r(document.getElementById(n))},i=()=>Array.from(e.querySelectorAll(C)).filter(e=>e.getClientRects().length>0),o=t=>{if(!(_.at(-1)!==e||t.defaultPrevented)&&(t.key===`Escape`&&(t.preventDefault(),t.stopPropagation(),q.current()),t.key===`Tab`)){if(document.activeElement?.closest(`[data-silo-popup]`))return;let n=i(),a=n[0],o=n.at(-1);a?t.shiftKey&&(document.activeElement===a||!r(document.activeElement))?(t.preventDefault(),o?.focus()):t.shiftKey||document.activeElement!==o&&r(document.activeElement)||(t.preventDefault(),a.focus()):(t.preventDefault(),e.focus())}},s=t=>{_.at(-1)===e&&!r(t.target)&&(i()[0]||e).focus()};return document.addEventListener(`keydown`,o),document.addEventListener(`focusin`,s),_.at(-1)===e&&!r(document.activeElement)&&(e.querySelector(`[autofocus]`)||i().find(e=>!e.classList.contains(`closeModalButton`)&&!e.hasAttribute(`data-field-help`))||e).focus(),()=>{document.removeEventListener(`keydown`,o),document.removeEventListener(`focusin`,s);let n=_.at(-1)===e,r=_.indexOf(e);r>=0&&_.splice(r,1),a(_.length);let i=e.querySelector(`.closeModalButton`);if(i&&(i.id=`${e.getAttribute(`aria-labelledby`)}-close`),e.closest(`.modalBoxMain`)?.style.removeProperty(`z-index`),S(),!_.length&&x!==null&&(document.body.style.overflow=x,x=null),n&&!F.current){let e=I.current?.()||t,n=_.at(-1);e?.isConnected&&e.getClientRects().length>0&&(!n||n.contains(e))?e.focus():n&&(n.querySelector(C)||n).focus()}}},[L,J]),!J&&!V)return null;let Q=(0,h.createPortal)((0,g.jsx)(s,{open:P,children:(0,g.jsx)(w,{ref:G,style:!P&&V?{display:`none`}:void 0,$inline:!!t,"aria-hidden":!P||void 0,className:`modalBoxMain`,$shown:X,$iconColor:M,$overlay:D,$width:T?O||(U?{sm:360,lg:480,xl:800}:{sm:400,lg:540,xl:880})[A]:`calc(100% - 32px)`,$sx:k,children:(0,g.jsxs)(c,{ref:K,offset:4,shadowLevel:5,className:`modalContainer`,role:t?`region`:`dialog`,"aria-modal":!t||void 0,"aria-labelledby":W,tabIndex:-1,children:[(0,g.jsxs)(`div`,{className:`modalTitleBar`,children:[(0,g.jsxs)(`h2`,{id:W,className:`title`,children:[E&&(0,g.jsx)(`span`,{className:`titleIcon`,"aria-hidden":`true`,children:E}),i]}),(0,g.jsx)(f,{id:`${W}-close`,className:`closeModalButton`,"aria-label":j||H.close,size:`small`,onClick:e,children:(0,g.jsx)(l,{})})]}),(0,g.jsx)(`div`,{className:`dialogContent`,children:(0,g.jsx)(v.Provider,{value:K,children:p})})]})})}),V||document.body);return V?(0,g.jsxs)(g.Fragment,{children:[(0,g.jsx)(`span`,{ref:R,style:{display:`contents`}}),Q]}):Q};export{T as t};