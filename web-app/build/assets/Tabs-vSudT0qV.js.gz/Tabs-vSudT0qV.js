import{a as e,r as t}from"./rolldown-runtime-BWaJ3C7D.js";import{P as n,t as r}from"./react-vendor-UL3KVrSx.js";import{T as i}from"./shared-vendor-BQfq49S_.js";import{C as a,S as o,b as s,nt as c,rt as l}from"./mds-B7pDlMNU.js";var u=e(n()),d=r(),f=i.button`
  ${l(`body`)}
  display: flex;
  position: relative;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  gap: var(--gap, 8px);
  cursor: pointer;
  height: calc(var(--control-height, 36px) - var(--segment-pad, 4px) * 2);
  padding: 0 var(--control-padding, 12px);
  @media (pointer: coarse) { min-height: 40px; }
  border: 0;
  border-radius: var(--radius-control, 8px);
  background: transparent;
  color: var(--muted-foreground, #737373);
  &[aria-selected="true"],
  &[data-fluid-hover] {
    color: var(--foreground, #171717);
  }
  &[aria-selected="true"] {
    font-weight: var(--fw-semibold, 550);
  }
  &:disabled {
    cursor: not-allowed;
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring, #6b97ff);
    outline-offset: 1px;
  }
  svg {
    width: var(--icon-size, 16px);
    height: var(--icon-size, 16px);
  }
  .label {
    display: grid;
  }
  .label > span {
    grid-area: 1 / 1;
  }
  .measure {
    visibility: hidden;
    font-weight: var(--fw-semibold, 550);
  }
`,p=({id:e,panelId:t,index:n,tabIndex:r,onClick:i,label:a,disabled:o,icon:s,selected:c})=>(0,d.jsxs)(f,{id:e,type:`button`,role:`tab`,"aria-selected":!!c,"aria-controls":t,tabIndex:r,disabled:o,"data-fluid-index":n,"data-fluid-key":e,"data-fluid-selected":c,onClick:i,children:[s,(0,d.jsxs)(`span`,{className:`label`,children:[(0,d.jsx)(`span`,{className:`measure`,"aria-hidden":`true`,children:a}),(0,d.jsx)(`span`,{children:a})]})]}),m=t({default:()=>g}),h=i.div`
  display: flex;
  flex-direction: ${({$horizontal:e})=>e?`column`:`row`};
  height: 100%;
  min-width: 0;
  .optionsContainer {
    display: flex;
    align-items: ${({$horizontal:e})=>e?`center`:`flex-start`};
    max-height: 100%;
    gap: var(--gap, 8px);
    min-width: 0;
    overflow: auto;
  }
  .optionsList {
    position: relative;
    isolation: isolate;
    display: flex;
    flex-direction: ${({$horizontal:e})=>e?`row`:`column`};
    width: ${({$horizontal:e})=>e?`max-content`:`220px`};
    max-width: 100%;
    max-height: 100%;
    overflow: auto;
    flex-shrink: 0;
    padding: var(--segment-pad, 4px);
    border-radius: var(--radius-control, 8px);
    background: var(--muted, #f4f4f5);
  }
  .optionsList:not(.subtle) [role="tab"] {
    color: var(--foreground, #171717);
  }
  [aria-orientation="vertical"] [role="tab"] {
    justify-content: flex-start;
    text-align: start;
    min-height: var(--control-height, 36px);
  }
  [aria-orientation="vertical"] [role="tab"] > svg {
    flex-shrink: 0;
  }
  [data-fluid-highlight] {
    z-index: -1;
  }
  [data-selected="true"] {
    background: var(--surface-3, white);
    box-shadow: var(--shadow-2);
  }
  .subtle {
    background: transparent;
    box-shadow: none;
    padding: 4px;
  }
  .subtle [data-selected="true"] {
    background: transparent;
    border-radius: 0;
    box-shadow: inset 0 -2px 0 var(--foreground);
  }
  .tabsPanels {
    min-width: 0;
    flex: 1;
    width: 100%;
    padding: 16px;
  }
  ${({$sx:e})=>e}
`,g=({horizontal:e,options:t,currentTabOrPath:n,useRouteTabs:r=!1,routes:i,onTabClick:l,optionsInitialComponent:f,optionsEndComponent:m,sx:g,variant:_=`segmented`})=>{let v=(0,u.useId)(),y=(0,u.useRef)(null),{compact:b}=c(),x=a(y,{axis:e?`x`:`y`,gapClick:{maxDistance:16}}),S=e=>(r?t[e].tabConfig.to:t[e].tabConfig.id)===n,C=t.findIndex((e,t)=>S(t)),w=t.findIndex(e=>!e.tabConfig.disabled),T=C>=0&&!t[C].tabConfig.disabled?C:w,[E,D]=(0,u.useState)(t[T]?.tabConfig.id);(0,u.useEffect)(()=>{let e=t.find(e=>(r?e.tabConfig.to:e.tabConfig.id)===n);e&&D(e.tabConfig.id)},[n,r]);let O=t.findIndex(e=>e.tabConfig.id===E&&!e.tabConfig.disabled),k=O>=0?O:T;return(0,u.useEffect)(()=>{let e=y.current;if(!e)return;let t=()=>{let t=e.querySelector(`[role="tab"]:focus:not(:disabled)`)??e.querySelector(`[aria-selected="true"]`);t&&s(t)},n=new ResizeObserver(t);return n.observe(e),t(),()=>n.disconnect()},[C,e]),(0,d.jsxs)(h,{$horizontal:!!e,className:`tabs-container`,$sx:g,style:{"--segment-pad":b?`2px`:`4px`},children:[(0,d.jsxs)(`div`,{className:`optionsContainer`,children:[f,(0,d.jsxs)(`div`,{ref:y,role:`tablist`,"aria-orientation":e?`horizontal`:`vertical`,className:`optionsList ${_===`subtle`?`subtle`:``}`,onKeyDown:n=>{let r=getComputedStyle(n.currentTarget).direction===`rtl`,i=e?r?`ArrowLeft`:`ArrowRight`:`ArrowDown`;if(![i,e?r?`ArrowRight`:`ArrowLeft`:`ArrowUp`,`Home`,`End`].includes(n.key))return;let a=Array.from(y.current?.querySelectorAll(`[role="tab"]:not(:disabled)`)||[]),o=a.indexOf(document.activeElement);if(o<0)return;n.preventDefault(),n.stopPropagation();let c=n.key===`Home`?0:n.key===`End`?a.length-1:(o+(n.key===i?1:-1)+a.length)%a.length;a[c]?.focus({preventScroll:!0});let l=a[c];l&&(D(t.find(e=>`${v}-${e.tabConfig.id}`===l.id)?.tabConfig.id),s(l))},children:[(0,d.jsx)(o,{hover:x,selected:!0}),(0,d.jsx)(o,{hover:x}),t.map((t,n)=>(0,d.jsx)(p,{id:`${v}-${t.tabConfig.id}`,panelId:r?`${v}-route-panel`:`${v}-${t.tabConfig.id}-panel`,index:n,tabIndex:n===k?0:-1,onClick:()=>{D(t.tabConfig.id),l(r?t.tabConfig.to||``:t.tabConfig.id)},horizontal:!!e,label:t.tabConfig.label,disabled:!!t.tabConfig.disabled,icon:t.tabConfig.icon,selected:S(n)},t.tabConfig.id))]}),m]}),(0,d.jsx)(`div`,{className:`tabsPanels`,children:r?(0,d.jsx)(`div`,{role:`tabpanel`,id:`${v}-route-panel`,"aria-labelledby":C>=0?`${v}-${t[C].tabConfig.id}`:void 0,children:i}):t.map((e,t)=>(0,d.jsx)(`div`,{role:`tabpanel`,id:`${v}-${e.tabConfig.id}-panel`,"aria-labelledby":`${v}-${e.tabConfig.id}`,hidden:!S(t),tabIndex:0,children:S(t)?e.content:null},e.tabConfig.id))})]})};export{m as n,g as t};