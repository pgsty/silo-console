const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./BulkReplicationModal-DIRq_qj5.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./store-Bs3aFuVt.js","./lang-D_hoMTDV.js","./languages-CQaj_RjM.js","./mds-B7pDlMNU.js","./triangle-alert-BYoxbxy1.js","./circle-check--s-qzPFr.js","./ReadBox-CKh3JaXl.js","./Wizard-NMksYTZ5.js","./i18n-CuId8BxB.js","./replicationValidation-1E0XMOv0.js","./ConsoleKBar-DKBTmpyh.js","./gauge-CSaLtwlg.js","./pencil-Cg37lTQM.js","./search-C5Hl7-Uo.js","./CircleIcon-BsXHTBH6.js","./shield-check-q7jetnYS.js","./chart-no-axes-column-Bc7SfxIT.js","./heart-pulse-TYfDkV8P.js","./trash-CiPD8hS_.js","./clock-BTaMdW1J.js","./activity-CtmEFmut.js","./plus-DdpTuvy_.js","./users-DqJf2nYi.js","./shield-DLyEUeHC.js","./archive-Cu6uIv3W.js","./webhook-DmZDdniN.js","./users-round-B0CKMX6y.js","./layers-BAlxGcwP.js","./rotate-ccw-BLAa--Dl.js","./settings-8EmlkJM3.js","./logs-zOC3x8DY.js","./info-Cg15zJKq.js","./scan-search-BlI8QzCl.js","./console-vendor-I3rSB1nD.js","./SectionTitle-C1UrSNqk.js","./useAvailableWidth-COFYcObd.js","./ModalBox-CSre1z64.js","./ModalPresence-CwKZcWyv.js","./preload-helper-CRzLMJPS.js","./index-0vdqfahH.js","./index-CDlbreCo.css","./shared-BY06TgMc.js","./OverflowMenu-DOHjU5zL.js","./typography-JApMsY3F.js","./permissions-BYrs_61w.js","./StatusBadge-BTgl2fcD.js","./CliEquivalent-BUyfMi-i.js","./copy-PhpXQRIk.js","./code-CkhtDBGc.js","./lib-BVN4wEer.js","./SecureComponent-Dx-vjU-W.js","./BulkLifecycleModal-wyOoBn17.js","./QueryMultiSelector-8CIgcbzp.js","./DeleteBucket-B3wA-aKG.js","./ConfirmDialog-BKzrgc92.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,d as n,f as r,h as i,r as a,t as o}from"./react-vendor-UL3KVrSx.js";import{D as s,T as c}from"./shared-vendor-BQfq49S_.js";import{Dr as l,Er as u,Qt as d,Tn as f,ar as p,n as ee,r as te,rn as ne,wn as m}from"./store-Bs3aFuVt.js";import{m as h,n as g}from"./lang-D_hoMTDV.js";import{C as _,H as re,K as v,M as ie,S as ae,T as oe,h as se,j as ce}from"./mds-B7pDlMNU.js";import{t as le}from"./trash-CiPD8hS_.js";import{t as ue}from"./boxes-_8PXvP4Q.js";import{t as de}from"./calendar-clock-BraTdpwh.js";import{t as fe}from"./plus-DdpTuvy_.js";import{t as y}from"./archive-Cu6uIv3W.js";import{t as b}from"./settings-8EmlkJM3.js";import{t as pe}from"./folder-D6KPo1XY.js";import{t as x}from"./Checkbox-AyDyii8V.js";import{t as S}from"./useTableLayout-ToMNXs38.js";import{a as C,n as w,o as me,t as he}from"./i18n-CuId8BxB.js";import{t as T}from"./ModalPresence-CwKZcWyv.js";import{t as E}from"./preload-helper-CRzLMJPS.js";import{c as ge}from"./index-0vdqfahH.js";import{n as D}from"./shared-BY06TgMc.js";import{t as _e}from"./OverflowMenu-DOHjU5zL.js";import{t as O}from"./typography-JApMsY3F.js";import{A as ve,a as k,g as A,i as ye,n as be,o as j,p as M,r as N,t as xe}from"./permissions-BYrs_61w.js";import{t as P}from"./StatusBadge-BTgl2fcD.js";import{t as Se}from"./SearchBox-Dn4Z6XDs.js";import{t as F}from"./withSuspense-DTbtEWjP.js";import{n as I}from"./SecureComponent-Dx-vjU-W.js";import{a as L,i as R,n as z,r as B,t as V}from"./prefixUsage-BPgfVH8L.js";import{t as Ce}from"./bucketMetadata-BAg0j77c.js";import{n as H}from"./react-window-0T2cJ04-.js";import{A as we,J as U,V as Te,f as Ee}from"./ConsoleKBar-DKBTmpyh.js";var W=e(t()),G=(0,W.createContext)(void 0),De=G.Provider,K=()=>(0,W.useContext)(G),Oe=e=>e.state===`queued`||e.state===`running`,q=[`not_scanned`,`queued`,`running`,`complete`,`error`,`limited`,`forbidden`,`missing`,`unavailable`],J=(e,t)=>e==null||t(e),ke=e=>{if(typeof e!=`object`||!e)return!1;let t=e,n=t.totals;return!!n&&B(n.current_bytes)&&R(n.current_objects)&&J(n.retained_bytes,B)&&J(n.retained_versions,R)&&J(n.delete_markers,R)&&R(t.scanned_entries)},Y=e=>{if(e&&typeof e.bucket==`string`)return q.includes(e.state)?{...e,last_good:ke(e.last_good)?e.last_good:void 0,progress:ke(e.progress)?e.progress:void 0}:{bucket:e.bucket,state:`unavailable`,versions_visible:!1}},Ae=e=>({...e,totals:{current_bytes:e.totals.current_bytes,current_objects:e.totals.current_objects}}),je=(e,t)=>e.state===`unavailable`&&!e.last_good&&t?.last_good?{...e,last_good:e.versions_visible?t.last_good:Ae(t.last_good),last_completed_at:t.last_completed_at}:e;function Me(e){let t=JSON.stringify(e),n=L(),r=(0,W.useRef)(),[i,a]=(0,W.useState)(0),o=(0,W.useRef)(!1),[s,c]=(0,W.useState)({requesting:!1,records:{}}),l=(0,W.useCallback)(()=>{o.current=!0,a(e=>e+1)},[]);return(0,W.useEffect)(()=>{let e=JSON.parse(t),i=new AbortController;r.current?.abort(),r.current=i;let a,s=()=>!i.signal.aborted&&n(),l=o.current;o.current=!1;let u=!l;c(t=>({...t,records:Object.fromEntries(Object.entries(t.records).filter(([t])=>e.includes(t)).flatMap(([e,n])=>t.enabled===!1&&n.state===`running`?n.last_good?[[e,{...n,state:`complete`,progress:void 0}]]:[]:[[e,n]]))}));let d=async()=>{c(e=>({...e,requesting:!0}));let t=[...e],n=async()=>{for(;s()&&t.length;){let e=t.shift(),n=I(e,[j.S3_LIST_BUCKET_VERSIONS]),r={bucket:e,state:`running`,versions_visible:n},a=()=>s()&&c(t=>{let i=t.records[e],a=i?.versions_visible===n&&r.state!==`forbidden`&&r.state!==`missing`;return{...t,records:{...t.records,[e]:{...r,last_good:r.last_good??(a?i?.last_good:void 0),last_completed_at:r.last_completed_at??(a?i?.last_completed_at:void 0)}}}});a();try{let t,o=await m.buckets.prefixUsage(e,{prefix:``,versions:n,folders:!1},{signal:i.signal});await z(o,{bucket:e,prefix:``,mode:n?`versions`:`current`},e=>{let i={totals:{...e.totals,...n?{}:{retained_bytes:void 0,retained_versions:void 0,delete_markers:void 0}},scanned_entries:e.scanned_entries,started_at:e.started_at,updated_at:e.updated_at};r={...r,state:e.status===`scanning`||e.status===`complete`?`running`:e.status===`failed`?`error`:e.status,progress:i},e.status===`complete`&&(t=i),a()}),t&&(r={...r,state:`complete`,last_good:t,last_completed_at:t.updated_at},a())}catch(e){let t=e instanceof Response?e.status:0;r={...r,state:t===401||t===403?`forbidden`:t===404?`missing`:`error`},a()}}};await Promise.all([n(),n()]),s()&&c(e=>({...e,requesting:!1}))},f=async t=>{if(s()){t&&c(e=>({...e,requesting:!0,error:!1}));try{let n=!1,r=2e3,o,l=[];for(let a=0;a<Math.max(e.length,1);a+=100){let s={buckets:e.slice(a,a+100)},c=t?await m.bucketUsage.bucketUsageRefresh(s,{signal:i.signal}):await m.bucketUsage.bucketUsageStatus(s,{signal:i.signal});if(n=c.data.enabled,r=c.data.poll_after_ms,o=c.data.coverage,l.push(...c.data.buckets),!n)break}if(!s())return;if(n&&t&&(u=!0),c(e=>({enabled:n,requesting:!1,records:n?Object.fromEntries(l.flatMap(t=>{let n=Y(t);return n?[[n.bucket,je(n,e.records[n.bucket])]]:[]})):e.enabled===!1?e.records:{},coverage:o})),!n){t&&(await d(),s()&&(u=!0));return}let p=l.some(Oe);a=setTimeout(()=>void f(!1),Math.min(6e4,Math.max(250,r)*(p?1:10)))}catch{s()&&(u=!0,c(e=>({...e,requesting:!1,error:!0})),a=setTimeout(()=>void f(!1),1e4))}}};return f(l),()=>{!u&&n()&&(o.current=!0),i.abort(),clearTimeout(a)}},[t,i,n]),{...s,refresh:l}}var X=o(),Ne=c.small`
  ${O.caption}
  display: block;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--muted-foreground);
`,Pe=c(Ne)`
  white-space: normal;
  text-overflow: clip;
  .usageValue {
    white-space: nowrap;
  }
`;function Fe({bucket:e}){let t=K(),n=t?.records[e],r=C(),i=h(w());if(!t||!n&&!t.enabled)return null;let a={not_scanned:r(`Not scanned`),queued:r(`Update queued`),running:r(`Updating usage…`),complete:r(`Updated`),error:r(`Update failed — retry with Refresh`),limited:r(`Scan limit reached — operator action required`),forbidden:r(`Usage listing not permitted`),missing:r(`Bucket no longer exists`),unavailable:r(`Usage temporarily unavailable`)},o=n?.last_completed_at?new Date(n.last_completed_at):void 0,s=[n?a[n.state]:r(`Checking usage…`),n?.state===`running`&&n.progress?g(r(`{count} entries scanned`),{count:n.progress.scanned_entries.toLocaleString(i)}):``,o&&Number.isFinite(o.getTime())?o.toLocaleTimeString(i):``].filter(Boolean).join(` · `);return(0,X.jsx)(Ne,{title:o&&Number.isFinite(o.getTime())?`${s} (${o.toLocaleString(i)})`:s,children:s})}function Ie(){let e=K(),t=C();if(!e)return null;let n=Object.values(e.records),r=n.filter(e=>e.state===`queued`||e.state===`running`).length,i=n.filter(e=>[`error`,`limited`,`unavailable`].includes(e.state)).length,a=e.coverage?.observer_alive&&e.coverage.connected&&e.coverage.reconciled,o=e.requesting?t(`Requesting usage updates…`):r?g(t(`{count} usage updates queued or running. Last completed totals remain visible.`),{count:r}):t(`Refresh requests a new metadata scan of all listed buckets.`),s=e.error?t(`Usage status is unavailable. Retrying…`):e.enabled?t(a?`Automatic change monitoring is active.`:`Automatic change monitoring is recovering; totals may be out of date.`):e.enabled===!1?t(`Automatic updates are not configured. Refresh calculates usage while this page is open.`):t(`Checking automatic updates…`),c=g(t(`{summary} {monitoring}`),{summary:o,monitoring:s});return i>0&&(c=g(t(`{summary} {warning}`),{summary:c,warning:g(t(`{count} updates need attention. Use Refresh to retry.`),{count:i})})),(0,X.jsx)(`div`,{role:`status`,"aria-live":`polite`,style:{marginBottom:12},children:c})}var Le=[`name`,`objects`,`size`,`created`],Re=e=>({sort:Le.includes(e.get(`sort`)||``)?e.get(`sort`):`name`,dir:e.get(`dir`)===`desc`?`desc`:`asc`,q:e.get(`q`)||``}),ze=(e,t)=>{let n=new URLSearchParams(e),r={...Re(e),...t};for(let e of[`sort`,`dir`,`q`])!r[e]||e===`sort`&&r.sort===`name`||e===`dir`&&r.dir===`asc`?n.delete(e):n.set(e,r[e]);return n},Be=e=>e===`cards`?`cards`:`table`,Ve=e=>!!(e&&Number.isFinite(Date.parse(e))),He=(e,t,n,r)=>{if(!(!e||n&&!Ve(r)))return!n&&e[t]===void 0?0:Ce(e,t,r)},Ue=(e,t,n,r,i)=>{let a=t.q.trim().toLocaleLowerCase(),o=e=>{if(t.sort===`name`)return e.name;if(t.sort===`created`){let t=Date.parse(e.creation_date||``);return Number.isFinite(t)?t:void 0}if(i){let n=i[e.name]?.last_good?.totals;return n?t.sort===`size`?BigInt(n.current_bytes):n.current_objects:void 0}return He(e,t.sort,n,r)};return e.filter(e=>e.name.toLocaleLowerCase().includes(a)).sort((e,n)=>{let r=o(e),i=o(n);return r===void 0&&i!==void 0?1:i===void 0&&r!==void 0?-1:(r===i||r===void 0||i===void 0?0:r<i?-1:1)*(t.dir===`desc`?-1:1)||e.name.localeCompare(n.name)})},We=(e,t)=>t.length>0&&t.every(t=>e.includes(t))?e.filter(e=>!t.includes(e)):Array.from(new Set([...e,...t])),Z=(e,t)=>({browse:I(e,M),settings:!t&&I(e,N[be.BUCKETS_ADMIN_VIEW]),delete:!t&&I(e,A),select:!t&&I(e,[j.S3_PUT_LIFECYCLE_CONFIGURATION,j.S3_PUT_REPLICATION_CONFIGURATION,j.S3_PUT_ACTIONS])}),Q=({bucket:e,field:t,canReadUsage:n,usageUpdatedAt:r})=>{let i=C(),a=w(),o=K(),s=(o?.records[e.name])?.last_good?.totals;if(s)return t===`objects`?(0,X.jsx)(X.Fragment,{children:s.current_objects.toLocaleString(h(a))}):(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`span`,{title:`${s.current_bytes} B`,children:V(s.current_bytes)}),s.retained_bytes!=null&&(0,X.jsx)(Pe,{title:`${s.retained_bytes} B`,children:he(i(`Retained: {size}`),{size:(0,X.jsx)(`span`,{className:`usageValue`,children:V(s.retained_bytes)})})})]});if(o)return(0,X.jsx)(`span`,{children:`—`});let c=He(e,t,n,r);return c===void 0?(0,X.jsx)(D,{text:n&&!Ve(r)?i(`Calculating…`):i(`Unknown`),children:(0,X.jsx)(`span`,{tabIndex:0,children:`—`})}):(0,X.jsx)(X.Fragment,{children:t===`size`?p(c):c.toLocaleString(h(a))})},Ge=({bucket:e})=>{let t=C();return(0,X.jsx)(X.Fragment,{children:e.rw_access?.read?e.rw_access.write?t(`Read & write`):t(`Read only`):e.rw_access?.write?t(`Write only`):t(`Unknown`)})},Ke=({enabled:e,suspended:t=!1})=>{let n=C();return(0,X.jsx)(P,{tone:t?`warning`:e?`success`:`neutral`,label:n(t?`Suspended`:e===void 0?`Unknown`:e?`Enabled`:`Disabled`)})},qe=({at:e})=>{let t=w(),n=e?s.fromISO(e).setLocale(h(t)):void 0;return n?.isValid?(0,X.jsx)(D,{text:n.toLocaleString(s.DATETIME_FULL_WITH_SECONDS),children:(0,X.jsx)(`time`,{dateTime:e,tabIndex:0,children:n.toRelative()})}):(0,X.jsx)(X.Fragment,{children:`—`})},Je=({bucket:e,obOnly:t,onDelete:n})=>{let i=C(),a=r(),o=Z(e.name,t),s=encodeURIComponent(e.name),c=[...o.browse?[{label:i(`Browse`),icon:(0,X.jsx)(pe,{}),onClick:()=>a(`/browser/${s}`)}]:[],...o.settings?[{label:i(`Settings`),icon:(0,X.jsx)(b,{}),onClick:()=>a(`/buckets/${s}/admin/summary`)}]:[],...o.delete?[{label:i(`Delete bucket`),icon:(0,X.jsx)(le,{}),danger:!0,onClick:()=>n(e.name)}]:[]];return c.length?(0,X.jsx)(`div`,{onClick:e=>e.stopPropagation(),onKeyDown:e=>e.stopPropagation(),children:(0,X.jsx)(_e,{label:g(i(`Actions for {bucket}`),{bucket:e.name}),tooltipPlacement:`left`,tooltipLabel:i(`Actions`),items:c})}):null},Ye=c.div`
  ${O.body}
  min-height: 148px;
  box-sizing: border-box;
  min-width: 0;
  padding: 8px 12px 12px;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  color: var(--muted-foreground);
  font-variant-numeric: tabular-nums;
  &[data-clickable="true"] {
    cursor: pointer;
  }
  &:hover,
  &[data-selected="true"] {
    color: var(--foreground);
    background: color-mix(in srgb, var(--hover) 100%, var(--surface-3));
  }
  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }
  .cardTitle {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;
    height: 36px;
  }
  .cardTitle > svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
  }
  h2 {
    ${O.section} margin: 0;
    min-width: 0;
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  a {
    color: inherit;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
  .cardMetrics {
    /* Fixed tracks keep each metric aligned across every card. */
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) auto;
    gap: 12px;
    margin-top: 4px;
  }
  .cardMetrics > div {
    min-width: 0;
  }
  .metricLabel {
    ${O.caption} color: var(--muted-foreground);
  }
  .metricValue {
    display: block;
    color: var(--foreground);
  }
  .cardAccess {
    ${O.caption} text-align: end;
    align-self: end;
  }
`,Xe=e=>{let{bucket:t,onSelect:n,selected:i,obOnly:o}=e,s=C(),c=r(),l=Z(t.name,o),u=()=>l.browse&&c(`/browser/${encodeURIComponent(t.name)}`);return(0,X.jsxs)(Ye,{className:`bucket-card`,role:`listitem`,"aria-label":t.name,"data-clickable":l.browse,"data-selected":n?i:void 0,tabIndex:l.browse?0:void 0,onClick:u,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),u())},children:[(0,X.jsxs)(`div`,{className:`cardTitle`,children:[n?(0,X.jsx)(`span`,{onClick:e=>e.stopPropagation(),children:(0,X.jsx)(x,{label:``,checked:i,disabled:!l.select,"aria-label":g(s(`Select {bucket}`),{bucket:t.name}),onChange:()=>n(t.name)})}):(0,X.jsx)(y,{"aria-hidden":`true`}),(0,X.jsx)(`h2`,{children:l.browse?(0,X.jsx)(a,{to:`/browser/${encodeURIComponent(t.name)}`,onClick:e=>e.stopPropagation(),children:(0,X.jsx)(`bdi`,{dir:`ltr`,children:t.name})}):(0,X.jsx)(`bdi`,{dir:`ltr`,children:t.name})}),(0,X.jsx)(Je,{...e})]}),(0,X.jsx)(Fe,{bucket:t.name}),(0,X.jsxs)(`div`,{className:`cardMetrics`,children:[(0,X.jsxs)(`div`,{children:[(0,X.jsx)(`span`,{className:`metricLabel`,children:s(`Objects`)}),(0,X.jsx)(`span`,{className:`metricValue`,children:(0,X.jsx)(Q,{...e,field:`objects`})})]}),(0,X.jsxs)(`div`,{children:[(0,X.jsx)(`span`,{className:`metricLabel`,children:s(`Current size`)}),(0,X.jsx)(`span`,{className:`metricValue`,children:(0,X.jsx)(Q,{...e,field:`size`})})]}),(0,X.jsx)(`span`,{className:`cardAccess`,children:(0,X.jsx)(Ge,{bucket:t})})]})]})},Ze=c.div`
  ${O.body}
  min-width: 0;
  border-radius: var(--radius-card);
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  overflow: hidden;
  font-variant-numeric: tabular-nums;
  --bucket-select-width: 28px;
  --bucket-menu-width: 36px;
  /* Font-relative, so "Retained: 9.5 MiB" fits with wider fallback fonts
     (e.g. DejaVu Sans on Linux); longer values wrap rather than clip. */
  --bucket-size-min: 15ch;
  .bucketGrid {
    display: grid;
    grid-template-columns:
      minmax(120px, 1.8fr)
      minmax(0, 0.7fr) minmax(var(--bucket-size-min), 1.1fr) minmax(0, 1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    align-items: center;
    column-gap: 8px;
    padding: 0 12px;
    box-sizing: border-box;
    height: var(--bucket-row-height, var(--control-height));
  }
  &[data-selection="true"] .bucketGrid {
    grid-template-columns:
      var(--bucket-select-width) minmax(120px, 1.8fr)
      minmax(0, 0.7fr) minmax(var(--bucket-size-min), 1.1fr) minmax(0, 1fr)
      minmax(0, 1.1fr) minmax(0, 0.8fr) minmax(0, 1.1fr)
      minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
  }
  .bucketCell {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .bucketCell a {
    color: inherit;
    text-decoration: none;
  }
  /* Text overflow applies per line; the name and its usage caption are blocks. */
  .bucketName {
    display: block;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .bucketCell a:hover {
    text-decoration: underline;
  }
  .bucketCell a:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  .bucketNumber {
    text-align: end;
  }
  @media (min-width: 1200px) {
    .bucketNumber {
      padding-inline-end: 12px;
    }
  }
  .bucketCheck {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .bucketMenu {
    overflow: visible;
    display: flex;
    justify-content: end;
  }
  .bucketRow {
    border-bottom: 1px solid var(--border);
    color: var(--muted-foreground);
    transition:
      color var(--dur-fast) ease,
      border-color var(--dur-fast) ease;
  }
  .bucketRow[data-fluid-activator] {
    cursor: pointer;
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[aria-selected="true"] {
    color: var(--foreground);
  }
  .bucketRow[data-fluid-hover],
  .bucketRow[data-fluid-before] {
    border-bottom-color: transparent;
  }
  .bucketRow[aria-selected="true"] {
    background: var(--active);
  }
  .bucketRow:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: -2px;
  }
  @media (max-width: 1199.98px) {
    .bucketGrid {
      grid-template-columns:
        minmax(100px, 1.6fr) minmax(0, 0.6fr) minmax(
          var(--bucket-size-min),
          1fr
        )
        minmax(0, 1fr) minmax(0, 1fr) var(--bucket-menu-width);
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns:
        var(--bucket-select-width) minmax(100px, 1.6fr)
        minmax(0, 0.6fr) minmax(var(--bucket-size-min), 1fr) minmax(0, 1fr)
        minmax(0, 1fr) var(--bucket-menu-width);
    }
    .bucketLow {
      display: none;
    }
  }
  @media (max-width: 767.98px) {
    .bucketGrid {
      grid-template-columns: minmax(0, 1fr) var(--bucket-size-min) var(
          --bucket-menu-width
        );
      padding: 0 8px;
      gap: 4px;
    }
    &[data-selection="true"] .bucketGrid {
      grid-template-columns:
        var(--bucket-select-width) minmax(0, 1fr)
        var(--bucket-size-min) var(--bucket-menu-width);
    }
    .bucketMedium {
      display: none;
    }
  }
  @media (pointer: coarse) {
    --bucket-select-width: 40px;
    --bucket-menu-width: 40px;
  }
`,Qe=c.div`
  position: sticky;
  top: 0;
  z-index: 1;
  background: var(--surface-3);
  color: var(--foreground);
  border-bottom: 1px solid var(--border);
  /* Weight the cells, not the grid row: font-relative tracks (ch) must
     resolve against the same font as body rows to keep columns aligned. */
  & > * {
    font-weight: var(--fw-semibold);
  }
  button {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    border: 0;
    padding: 0;
    background: transparent;
    color: inherit;
    font: inherit;
    cursor: pointer;
    max-width: 100%;
  }
  @media (pointer: coarse) {
    button {
      min-height: 40px;
    }
  }
  button:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 1px;
  }
  button > svg {
    width: 12px;
    height: 12px;
    flex-shrink: 0;
    fill: currentColor;
  }
  /* A narrow column truncates its label, never the sort direction. */
  .sortLabel {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`,$e=c.div`
  position: relative;
  isolation: isolate;
  min-height: 0;
  [data-fluid-highlight] {
    z-index: -1;
  }
`;function et({index:e,style:t,records:n,columns:r,selected:i,common:a}){let o=n[e];return(0,X.jsx)(tt,{index:e,style:t,columns:r,...a,bucket:o,selected:i.includes(o.name)},o.name)}function tt({index:e,style:t,columns:n,...i}){let a=r(),{bucket:o,selected:s,onSelect:c,obOnly:l}=i,u=C(),d=Z(o.name,l),f=()=>d.browse&&a(`/browser/${encodeURIComponent(o.name)}`);return(0,X.jsxs)(`div`,{role:`row`,"aria-rowindex":e+2,"aria-label":o.name,"aria-selected":c?s:void 0,style:t,className:`bucketGrid bucketRow`,"data-fluid-index":d.browse?e:void 0,"data-fluid-key":o.name,"data-fluid-activator":d.browse?`true`:void 0,tabIndex:d.browse?0:void 0,onClick:f,onKeyDown:e=>{e.target===e.currentTarget&&[`Enter`,` `].includes(e.key)&&(e.preventDefault(),f())},children:[c&&(0,X.jsx)(`div`,{role:`cell`,className:`bucketCheck`,onClick:e=>e.stopPropagation(),children:(0,X.jsx)(x,{label:``,"aria-label":g(u(`Select {bucket}`),{bucket:o.name}),checked:s,disabled:!d.select,onChange:()=>c(o.name)})}),n.map(e=>(0,X.jsx)(`div`,{role:`cell`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``} ${e.id===`actions`?`bucketMenu`:``}`,children:e.render(i)},e.id))]})}function nt({records:e,query:t,onSort:n,selected:r,onSelectAll:i,...o}){let s=C(),c=S(),l=(0,W.useRef)(null),u=_(l,{gapClick:!1}),d=[{id:`name`,label:s(`Name`),sort:`name`,render:({bucket:e,obOnly:t})=>(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`span`,{dir:`ltr`,className:`bucketName`,title:e.name,children:Z(e.name,t).browse?(0,X.jsx)(a,{to:`/browser/${encodeURIComponent(e.name)}`,onClick:e=>e.stopPropagation(),children:e.name}):e.name}),(0,X.jsx)(Fe,{bucket:e.name})]})},{id:`objects`,label:s(`Objects`),priority:`Medium`,number:!0,sort:`objects`,render:e=>(0,X.jsx)(Q,{...e,field:`objects`})},{id:`size`,label:s(`Current size`),number:!0,sort:`size`,render:e=>(0,X.jsx)(Q,{...e,field:`size`})},{id:`versioning`,label:s(`Versioning`),priority:`Medium`,render:({bucket:e})=>(0,X.jsx)(Ke,{enabled:e.details?!!e.details.versioning:void 0,suspended:e.details?.versioningSuspended})},{id:`locking`,label:s(`Object lock`),priority:`Low`,render:({bucket:e})=>(0,X.jsx)(Ke,{enabled:e.details?!!e.details.locking:void 0})},{id:`quota`,label:s(`Quota`),priority:`Low`,number:!0,render:({bucket:e})=>(e.details?.quota?.quota||0)>0?p(e.details.quota.quota):`—`},{id:`replication`,label:s(`Replication`),priority:`Low`,render:({bucket:e})=>(0,X.jsx)(Ke,{enabled:e.details?!!e.details.replication:void 0})},{id:`access`,label:s(`Access`),priority:`Medium`,render:({bucket:e})=>(0,X.jsx)(Ge,{bucket:e})},{id:`created`,label:s(`Created`),priority:`Low`,sort:`created`,render:({bucket:e})=>(0,X.jsx)(qe,{at:e.creation_date})},{id:`actions`,label:s(`Actions`),render:e=>(0,X.jsx)(Je,{...e})}],f=e.filter(e=>Z(e.name,o.obOnly).select),ee={records:e,columns:d,selected:r,common:o};return(0,X.jsxs)(Ze,{role:`table`,"aria-label":s(`Buckets`),"aria-rowcount":e.length+1,"aria-colcount":d.length+ +!!o.onSelect,"data-selection":!!o.onSelect,style:{"--bucket-row-height":`${Math.max(c,64)}px`},children:[(0,X.jsxs)(Qe,{role:`row`,className:`bucketGrid`,"aria-rowindex":1,style:{"--bucket-row-height":`${c}px`},children:[o.onSelect&&(0,X.jsx)(`div`,{role:`columnheader`,className:`bucketCheck`,children:(0,X.jsx)(x,{label:``,"aria-label":s(`Select all visible buckets`),checked:f.length>0&&f.every(e=>r.includes(e.name)),disabled:!f.length,onChange:i})}),d.map(e=>(0,X.jsx)(`div`,{role:`columnheader`,className:`bucketCell bucket${e.priority||`High`} ${e.number?`bucketNumber`:``}`,"aria-sort":e.sort?t.sort===e.sort?t.dir===`asc`?`ascending`:`descending`:`none`:void 0,children:e.sort?(0,X.jsxs)(`button`,{type:`button`,"aria-label":e.label,onClick:()=>n(e.sort),children:[(0,X.jsx)(`span`,{className:`sortLabel`,children:e.label}),t.sort===e.sort&&(t.dir===`asc`?(0,X.jsx)(ie,{}):(0,X.jsx)(ce,{}))]}):e.id===`actions`?(0,X.jsx)(`span`,{className:`selectionHeaderLabel`,style:{position:`absolute`,clipPath:`inset(50%)`,width:1,height:1},children:e.label}):e.label},e.id))]}),(0,X.jsxs)($e,{ref:l,children:[(0,X.jsx)(ae,{hover:u}),e.length>100?(0,X.jsx)(H,{role:`rowgroup`,"aria-label":s(`Bucket rows`),rowCount:e.length,rowHeight:Math.max(c,64),rowComponent:et,rowProps:ee,overscanCount:6,style:{height:`min(65vh, 720px)`,minHeight:c*4}}):(0,X.jsx)(`div`,{role:`rowgroup`,style:{maxHeight:`min(65vh, 720px)`,overflowY:`auto`},children:e.map((e,t)=>(0,X.jsx)(tt,{...o,columns:d,bucket:e,index:t,selected:r.includes(e.name)},e.name))})]})]})}function rt(){let e=n(),[t,r]=i(),a=Re(t),[o,s]=(0,W.useState)(a.q);return(0,W.useEffect)(()=>s(a.q),[e.key,a.q]),(0,W.useEffect)(()=>{if(o===a.q)return;let e=window.location.href,t=window.setTimeout(()=>{window.location.href===e&&r(e=>ze(e,{q:o}),{replace:!0})},150);return()=>window.clearTimeout(t)},[o,a.q,e.key,r]),{query:a,search:o,setSearch:s,sort:e=>r(t=>ze(t,{sort:e,dir:a.sort===e&&a.dir===`asc`?`desc`:`asc`,q:o})),clear:()=>{s(``),r(e=>ze(e,{q:``}))}}}var it=F(W.lazy(()=>E(()=>import(`./BulkReplicationModal-DIRq_qj5.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55]),import.meta.url))),at=F(W.lazy(()=>E(()=>import(`./BulkLifecycleModal-wyOoBn17.js`),__vite__mapDeps([56,1,2,3,4,5,6,7,8,9,10,11,12,13,57,26,38,15,16,17,18,19,20,21,22,23,24,25,27,28,29,30,31,32,33,34,35,36,37,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55]),import.meta.url))),ot=F(W.lazy(()=>E(()=>import(`./DeleteBucket-B3wA-aKG.js`),__vite__mapDeps([58,1,2,5,3,4,6,7,8,23,13,44,42,43,45,59,41]),import.meta.url))),st=c.h1`
  ${O.title}
  margin: 0 0 16px;
`,ct=c.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 16px;
  .bucketSearch {
    min-width: 160px;
    flex: 1 1 190px;
  }
  .bucketActions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: flex-end;
    gap: 8px;
    margin-inline-start: auto;
  }
  .bucketView {
    display: flex;
    gap: 4px;
  }
  @media (max-width: 767.98px) {
    .bucketFreshness {
      order: 3;
      flex-basis: 100%;
    }
    .bucketSearch {
      flex-basis: 100%;
    }
    .bucketActions {
      flex-basis: 100%;
      /* Touch-sized controls and longer labels can exceed a phone's width;
         wrap the primary action instead of scrolling the page sideways. */
      flex-wrap: wrap;
      justify-content: flex-start;
      gap: 8px;
    }
    .bucketView {
      margin-inline-end: auto;
    }
    .bucketActions > #create-bucket {
      margin-inline-start: auto;
    }
  }
`,lt=c.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  @media (max-width: 1199.98px) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  @media (max-width: 767.98px) {
    grid-template-columns: minmax(0, 1fr);
  }
`,ut=c.div`
  ${O.caption}
  color: var(--muted-foreground);
  margin-bottom: 8px;
`,$=c.div`
  background: var(--surface-3);
  box-shadow: var(--shadow-2);
  border-radius: var(--radius-card);
  min-height: 180px;
`,dt=()=>{let e=ee(),t=r(),n=C(),i=me(),a=ge(),o=te(ne),s=!!o.features?.includes(`object-browser-only`),c=I(xe,[j.ADMIN_DATA_USAGE_INFO]),p=!s&&d(o.permissions),{updateListing:h}=Ee(),{query:_,search:ie,setSearch:ae,sort:ce,clear:le}=rt(),[b,pe]=(0,W.useState)(),[x,S]=(0,W.useState)(!0),[w,he]=(0,W.useState)(!1),[E,D]=(0,W.useState)(0),[O,A]=(0,W.useState)([]),[M,N]=(0,W.useState)(null),[P,F]=(0,W.useState)(null),[L,R]=(0,W.useState)(()=>{try{return Be(localStorage.getItem(`silo.buckets.view`))}catch{return`table`}}),z=(0,W.useCallback)(()=>D(e=>e+1),[]);(0,W.useEffect)(()=>{e(l(`ob_bucket_list`))},[e]),(0,W.useEffect)(()=>{let t=new AbortController;return S(!0),he(!1),m.buckets.listBuckets({signal:t.signal}).then(e=>{if(t.signal.aborted)return;if(!Array.isArray(e.data?.buckets))throw Error(n(`The bucket list could not be loaded.`));pe(e.data),h(e.data);let r=new Set(e.data.buckets.map(e=>e.name));A(e=>e.filter(e=>r.has(e)))}).catch(n=>{t.signal.aborted||(he(!0),e(u(f(n))))}).finally(()=>{t.signal.aborted||S(!1)}),()=>t.abort()},[E,e,h,o.accountAccessKey,n]),(0,W.useEffect)(()=>{try{localStorage.setItem(`silo.buckets.view`,L)}catch{}},[L]);let B=b?.buckets||[],V=Me(B.map(e=>e.name)),Ce=()=>{z(),V.refresh()},H=(0,W.useMemo)(()=>Ue(B,_,c,b?.usageUpdatedAt,V.records),[B,_.sort,_.dir,_.q,c,b?.usageUpdatedAt,V.records]),G=!s&&I(`*`,[j.S3_PUT_LIFECYCLE_CONFIGURATION,j.S3_PUT_REPLICATION_CONFIGURATION,j.S3_PUT_ACTIONS]),K=e=>A(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e]),Oe=()=>A(e=>We(e,H.filter(e=>Z(e.name,s).select).map(e=>e.name))),q=O.every(e=>I(e,ye[k.BUCKET_LIFECYCLE],!0)),J=O.every(e=>I(e,[j.S3_PUT_REPLICATION_CONFIGURATION,j.S3_PUT_ACTIONS])),ke=n(`Select one or more buckets first.`),Y=(e,t)=>O.length?e?void 0:ve(t,n(`configure the selected buckets`)):ke,Ae=e=>{N(null),e&&(A([]),z())},je={canReadUsage:c,usageUpdatedAt:b?.usageUpdatedAt,obOnly:s,onSelect:G?K:void 0,onDelete:F},Ne=p?(0,X.jsx)(v,{id:`empty-create-bucket`,variant:`callAction`,label:n(`Create bucket`),onClick:()=>t(be.ADD_BUCKETS)}):void 0;return(0,X.jsxs)(De,{value:V,children:[(0,X.jsx)(T,{open:M?.type===`replication`,children:M?.type===`replication`&&(0,X.jsx)(it,{open:!0,buckets:M.names,closeModalAndRefresh:Ae})}),(0,X.jsx)(T,{open:M?.type===`lifecycle`,children:M?.type===`lifecycle`&&(0,X.jsx)(at,{open:!0,buckets:M.names,closeModalAndRefresh:Ae})}),(0,X.jsx)(T,{open:P!==null,children:P!==null&&(0,X.jsx)(ot,{deleteOpen:!0,selectedBucket:P,closeDeleteModalAndRefresh:e=>{F(null),e&&(A(e=>e.filter(e=>e!==P)),z())}})}),!s&&(0,X.jsx)(we,{label:n(`Buckets`),titleElement:`h1`,help:!0}),(0,X.jsxs)(se,{children:[s&&(0,X.jsx)(st,{children:n(`Buckets`)}),(0,X.jsxs)(ct,{children:[(0,X.jsx)(`div`,{className:`bucketSearch`,children:(0,X.jsx)(Se,{id:`bucket-search`,placeholder:n(`Search buckets`),value:ie,onChange:ae,sx:{width:`100%`}})}),(0,X.jsxs)(`div`,{className:`bucketActions`,children:[(0,X.jsxs)(`div`,{className:`bucketView`,role:`group`,"aria-label":n(`Bucket view`),children:[(0,X.jsx)(v,{id:`buckets-view-table`,collapseOnSmall:!1,label:n(`Table`),variant:L===`table`?`secondary`:`ghost`,"aria-pressed":L===`table`,onClick:()=>R(`table`)}),(0,X.jsx)(v,{id:`buckets-view-cards`,collapseOnSmall:!1,label:n(`Cards`),variant:L===`cards`?`secondary`:`ghost`,"aria-pressed":L===`cards`,onClick:()=>R(`cards`)})]}),(0,X.jsx)(oe,{id:`refresh-buckets`,"aria-label":n(`Refresh buckets`),size:`medium`,disabled:x||V.requesting,onClick:Ce,children:(0,X.jsx)(re,{})}),G&&(a?(0,X.jsx)(_e,{label:n(`Actions`),items:[{label:n(`Set replication`),icon:(0,X.jsx)(ue,{}),disabled:x||!O.length||!J,disabledReason:Y(J,[j.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>N({type:`replication`,names:[...O]})},{label:n(`Set lifecycle`),icon:(0,X.jsx)(de,{}),disabled:x||!O.length||!q,disabledReason:Y(q,ye[k.BUCKET_LIFECYCLE]),onClick:()=>N({type:`lifecycle`,names:[...O]})}]}):(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(v,{id:`set-replication`,collapseOnSmall:!1,label:n(`Set replication`),icon:(0,X.jsx)(ue,{}),disabled:x||!O.length||!J,disabledReason:Y(J,[j.S3_PUT_REPLICATION_CONFIGURATION]),onClick:()=>N({type:`replication`,names:[...O]})}),(0,X.jsx)(v,{id:`set-lifecycle`,collapseOnSmall:!1,label:n(`Set lifecycle`),icon:(0,X.jsx)(de,{}),disabled:x||!O.length||!q,disabledReason:Y(q,ye[k.BUCKET_LIFECYCLE]),onClick:()=>N({type:`lifecycle`,names:[...O]})})]})),!s&&(0,X.jsx)(v,{id:`create-bucket`,label:n(`Create bucket`),icon:(0,X.jsx)(fe,{}),disabled:!p,disabledReason:p?void 0:ve([j.S3_CREATE_BUCKET],n(`create a bucket`)),onClick:()=>t(be.ADD_BUCKETS),variant:`primary`,collapseOnSmall:!1})]})]}),(0,X.jsx)(Ie,{}),O.length>0&&(0,X.jsx)(ut,{role:`status`,children:i(O.length,`{count} bucket selected`,`{count} buckets selected`)}),x&&!b?(0,X.jsx)($,{children:(0,X.jsx)(Te,{rows:5,columns:4})}):w&&!b?(0,X.jsx)($,{children:(0,X.jsx)(U,{compact:!0,icon:(0,X.jsx)(y,{}),title:n(`The bucket list could not be loaded.`),action:(0,X.jsx)(v,{id:`retry-buckets`,label:n(`Retry`),onClick:z})})}):H.length===0?(0,X.jsx)($,{children:_.q.trim()?(0,X.jsx)(U,{compact:!0,icon:(0,X.jsx)(y,{}),title:g(n(`No buckets match “{q}”`),{q:_.q.trim()}),action:(0,X.jsx)(v,{id:`clear-bucket-filter`,label:n(`Clear filter`),onClick:le})}):(0,X.jsx)(U,{icon:(0,X.jsx)(y,{}),title:n(`No buckets yet`),description:n(`Create a bucket to start storing objects.`),action:Ne})}):L===`table`?(0,X.jsx)(nt,{...je,records:H,query:_,onSort:ce,selected:O,onSelectAll:Oe}):(0,X.jsx)(lt,{role:`list`,"aria-label":n(`Buckets`),children:H.map(e=>(0,X.jsx)(Xe,{...je,bucket:e,selected:O.includes(e.name)},e.name))})]})]})};export{dt as default};