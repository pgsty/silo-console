import{n as e,r as t}from"./mds-Hm6-garf.js";import{x as n}from"./shared-vendor-BQfq49S_.js";var r=(r,{compact:i=!1,weight:a}={})=>{let o=t[r],s=i?`-compact`:``;return n`
    font-family: var(--font-sans);
    font-size: var(
      --fs-${r}${s},
      ${i?o.compactSize:o.size}px
    );
    line-height: var(
      --lh-${r}${s},
      ${i?o.compactLine:o.line}px
    );
    font-weight: ${a?e[a]:o.weight};
  `};export{r as t};